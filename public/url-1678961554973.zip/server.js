var express = require('express');
var path = require("path");
const cluster=require("cluster")
const os=require("os")
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
const numCpu=os.cpus().length
const statusMonitor = require('express-status-monitor')();


//  https://medium.com/@ehzevin/hang-in-there-a-solution-to-socket-hang-up-5e04c600fa89


var braintree = require("braintree");


const bcrypt = require('bcrypt')
var app = express();

app.use(statusMonitor);
app.get('/status', statusMonitor.pageRoute)
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
app.use('/img', express.static(path.join(__dirname, '/api/uploads/images')))
app.use('/uploads/images', express.static(path.join(__dirname, '../../../uploads/images')));
var morgan = require('morgan')




var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});



var gateway = braintree.connect({
  environment: braintree.Environment.Sandbox,
  merchantId: "8vth6dk6nd73mq4v",
  publicKey: "569v88wmkphh5k4d",
  privateKey: "c1e0991931c219069f06d36b67a28ee3"
});

// var jwt = require('jsonwebtoken');
// var uuid4 = require('uuid4');


// var app_access_key="628fbb3fb873787aa26f6c86"
// var app_secret= "WXZLBg3OWieYf3JRGq6QC4taVFnGIlSyuRczAiwxTHAIUmrM9tbfs8_rxHfNm0cuZSa6JaQbd_2yYZWlDNxFY9hFID6gU_aaT2Paju83V_-IDsPdQ2Bxd-8nlqN2AJEHiFjxQuykFInNYwVGHd7HYiB3-YPPiS_Y3pyXwsfHzpM="

// jwt.sign(
//     {
//         access_key: app_access_key,
//         type: 'management',
//         version: 2,
//         iat: Math.floor(Date.now() / 1000),
//         nbf: Math.floor(Date.now() / 1000)
//     },
//     app_secret,
//     {
//         algorithm: 'HS256',
//         expiresIn: '24h',
//         jwtid: uuid4()
//     },
//     function (err, token) {
//         console.log(token);
//     }
// );






// var db = mongo.connect("mongodb://localhost:8082/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
//    if(err){ console.log( err); }  
//    else{ //console.log('Connected to ' + db, ' + ', response); 
//     }  
// });  
// const ObjectId = mongo.Types.ObjectId;
// const Schema = mongo.Schema ;  
// const {email, first_name, last_name, password, social_id, image,type } = req.body;

// const TBL_TRAINER = new Schema({

//     social_id: String,
//     email: String,
//     password: String,
//     details_id:String,
//     type: String,
//     services:Array,
//     email_verification_id:String,
//     favourites:String,
//     status:String,
//     created_at:Number,
//     updated_at:Number,
//   });

//   const TBL_TRAINER_DETAIL = new Schema({
//     first_name: String,
//     last_name: String,
//     bio: String,
//     phone_number:String,
//     phone_verified: String,
//     email_verified:Array,
//     image:String,
//     goverment_id:String,
//     selfie:String,
//     created_at:Number,
//     updated_at:Number,
//   });


// const TBL_TRAINERS = mongo.model('TBL_TRAINERS', TBL_TRAINER, 'TBL_TRAINERS');
// const TBL_TRAINER_DETAILS = mongo.model('TBL_TRAINER_DETAILS', TBL_TRAINER_DETAIL, 'TBL_TRAINER_DETAILS');



app.use(bodyParser.json());
// app.use(bodyParser.urlencoded());
app.use(bodyParser.urlencoded({ extended: true }));

mongo.set('useFindAndModify', false);
app.use(express.urlencoded({ extended: false }))
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json());
app.use(morgan('combined'))
var r = require('./api/');
var trainerApp = require('./api/trainerApi/');
var gymApps = require('./api/houfulapp/')
var clientApp = require('./api/clientApi')

// app.use(express.urlencoded({extended:false}))   

app.use(function (req, res, next) {
  //  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');    
  res.setHeader('Access-Control-Allow-Origin', '*');

  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  if(req.method==="OPTIONS"){
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE')
    return res.status(200).json({})
  }
  next();
});



app.post('/api/notifyViaEmail', r.notifyViaEmail.email)


//paypal

app.post('/api/usePaypal', r.usePaypal.paypal)
app.post('/api/usePaypalCred', r.usePaypal.withcardPaypal)
// app.post('/api/transactionPaypal', r.usePaypal.transactionPaypal)

//api
app.post('/api/register', r.register.register)
app.post('/api/get_services', r.get_services.get_services)
app.post('/api/services', r.services.services)
app.post('/api/phone_verification', r.phone_verification.phone_verification)
app.post('/api/request_email_verification', r.request_email_verification.request_email_verification)
app.post('/api/upload_id', r.upload_id.upload_id)
app.post('/api/login', r.login.login)
app.post('/api/bio', r.bio.bio)
app.post('/api/filter', r.filter.filter)
app.post('/api/gyms', r.gyms.gyms)
app.post('/api/gym_details', r.gym_details.gym_details)
app.post('/api/schedule', r.schedule.schedule)
app.post('/api/add_client', r.add_client.add_client)

//-------------- from p2 ------------------------------------


app.post('/api/clients', r.clients.clients)
app.post('/api/trainer_profile', r.clients.profile)
app.post('/api/client_details', r.clients.client_details)
app.post('/api/trainer_client_list_info', r.clients.trainer_client_list_info)
app.post('/api/view_sessions_calander', r.sessions.view_sessions_calander_new)
app.post('/api/report_trainer', r.report_trainer.report_trainer)
app.post('/api/block_trainer', r.report_trainer.block_trainer)
// app.post('/api/import_clients',r.clients.import_clients)

app.post('/api/remove_client', r.clients.remove_client)

//--------------From p2 client -------------------------------

app.post('/api/client/report_client', clientApp.reporting_client.report_client)
app.post('/api/client/block_trainer', clientApp.reporting_trainer.block_trainer)
app.post('/api/client/trainer_info', clientApp.trainer_info.trainer_info)
app.post('/api/client/trainer_connect', clientApp.clients.trainer_connect)
app.post('/api/client/sessions', clientApp.sessions.view_sessions)
app.post('/api/client/trainer_availability', clientApp.trainer_availability.trainer_availability)
app.post('/api/client/create_session', clientApp.sessions.create_session)
app.post('/api/client/update_session', clientApp.sessions.update_session_stage)
app.post('/api/client/cancel_session', clientApp.sessions.cancel_session)
app.post("/api/client/update_profile", clientApp.update_profile.update_profile)
app.post('/api/client/payment_history', clientApp.session_payments.payment_history)
app.post('/api/client/delete_payment_method', clientApp.delete_payment_method.delete_payment_method)
app.post('/api/client/client_profile', clientApp.clients.client_profile)
app.post('/api/client/punch_card', clientApp.punch_card.punch_card)
app.post('/api/client/punch_card_details', clientApp.punch_card.punch_card_details)
app.post('/api/client/buy_punch_card', clientApp.punch_card.buy_punch_card)
app.post("/api/client/change_password", clientApp.change_password.change_password)
app.post("/api/client/reset_password", clientApp.reset_password.reset_password)
app.post("/api/client/get_user_payment_method", clientApp.get_user_payment_method.get_user_payment_method)
app.post('/api/client/register_push', clientApp.save_token.save_token)
app.post('/api/client/schedule', clientApp.schedule.schedule)
app.post('/api/client/filter', clientApp.filter.filter)
app.post('/api/client_profile',clientApp.clients.client_profile) 
app.post('/api/client/account', clientApp.session_payments.account)
app.post('/api/client/trainer_feedback',clientApp.client_feedback.trainer_feedback)

app.post('/api/client/favourite',clientApp.favourite.addFavorites)
app.post('/api/client/get_favourite',clientApp.favourite.getFavorites)




//  app.post('/api/client/login', clientApp.login.login)
//  app.post('/api/client/register', clientApp.register.register)



//-----------------------------------------------------------

app.post('/api/block_client', r.reporting_client.block_client)
app.post('/api/report_client', r.reporting_client.report_client)


app.post('/api/session_update_status', r.sessions.session_update_status)
app.post("/api/session_details", r.sessions.session_details)
app.post('/api/update_session', r.sessions.update_session_stage)
app.post('/api/sessions_new', r.sessions.view_sessions_new)
app.post('/api/delete_one_session', r.sessions.delete_one_session)
app.post('/api/requestSessions', r.sessions.requestSessions)
app.post('/api/account', r.session_payments.account)
app.post('/api/create_session', r.sessions.create_session)
app.post('/api/bank_info', r.trainer_bank.bank_info)
app.post('/api/update_bank_info', r.trainer_bank.update_bank_info)

app.post('/api/create_sessionv2', r.sessions.create_sessionv2)


app.post('/api/payment_request', r.transfer_payment.transfer_payment)


app.post('/api/view_sessions_history', r.view_sessions_history.view_sessions_history)




//--------------from personal trainer -----------------------------

app.post('/api/trainer/add_punch_card', trainerApp.punch_card.add_punch_card)
app.post('/api/trainer/delete_punch_card', trainerApp.punch_card.delete_punch_card)
app.post('/api/trainer/punch_cards', trainerApp.punch_card.punch_cards)
app.post('/api/trainer/punch_card_purchase_history', trainerApp.punch_card.punch_card_purchase_history)

app.post('/api/trainer/availabilities_trainer', trainerApp.availabilityt.availabilities)
app.post('/api/trainer/update_availability', trainerApp.availabilityt.availability_update)
app.post('/api/trainer/availability_delete', trainerApp.availabilityt.availability_delete)
app.post('/api/trainer/set_availability', trainerApp.availabilityt.availability)
app.post('/api/trainer/reset_password', trainerApp.reset_password.reset_password)

//# new
app.post('/api/trainers', trainerApp.trainers.trainers)

app.post('/delete-trainer-account',trainerApp.trainers.deleteTrainer)


app.post('/api/trainer/clients', trainerApp.clients.clients)
app.post('/api/trainer_details', trainerApp.trainer_details.trainer_details)
app.post('/api/trainer/availability', trainerApp.trainer_availability.availability)
app.post('/api/trainer/punch_card_details', trainerApp.trainers.getPurchasedClientPunchCard)


app.post('/api/trainer/client_feedback',trainerApp.client_feedback.client_feedback)
app.post('/api/trainer/rating',trainerApp.trainers.getRating)
app.post('/api/punch_card', r.punch_card.punch_card)
app.post('/api/buy_punch_card', r.punch_card.buy_punch_card)
app.post('/api/punch_card_details', r.punch_card.punch_card_details)

app.post('/api/test', trainerApp.trainers.testLocation)




//--------------------------------------------------------------------

app.post('/api/appointments', r.appointments.appointments)
app.post('/api/gyms_insert', r.appointments.appointments)
app.post('/api/availability', r.availability.availability)
app.post('/api/badges', r.badges.badges)
app.post('/api/feedback', r.feedback.feedback)
app.post('/api/mark_favorite', r.favorites.favorites)
app.post('/api/get_favorites', r.get_favorites.get_favorites)
app.post('/api/payment_method', r.payment_method.payment_method)
app.post('/api/reviews', r.reviews.reviews)
app.post('/api/add_notes', r.add_notes.add_notes)
app.post('/api/report_gym', r.report_gym.report_gym)
app.post('/api/cancel_booking', r.cancel_booking.cancel_booking)
app.post('/api/reschedule', r.reschedule.reschedule)
app.post('/api/gym_reviews', r.gym_reviews.gym_reviews)
app.post("/api/change_password", r.change_password.change_password)
app.post("/api/update_profile", r.update_profile.update_profile)
app.post("/api/reset_password", r.reset_password.reset_password)
app.post("/api/get_user_payment_method", r.get_user_payment_method.get_user_payment_method)
app.post("/api/availabilities", r.availabilities.availabilities)
app.post('/api/emailConfirm', r.emailConfirm.emailConfirm)
app.post('/api/debitBank', r.debitBank.debitBank)
app.post('/api/report_problem', r.report_problem.report_problem)
app.post('/api/get_aminities', r.get_aminities.get_aminities)
app.post('/api/profile', r.profile.profile)


//Gym
app.post("/api/getGyms", r.admingyms.allGyms)
app.post("/api/blockGym", r.admingyms.blockGym)
app.post("/api/searchGym", r.admingyms.search)
app.post("/api/gymDetails", r.admingyms.gymDetails)
app.post("/api/updateGym", r.admingyms.updateGym)
app.get("/api/gymsList", r.admingyms.gymsList)
app.post("/api/deleteGym", r.admingyms.delete)

app.post("/api/getGymsEarning", r.earningsAladmin.allGyms)
app.post("/api/searchEarning", r.earningsAladmin.search)

app.post('/api/bookDetail_email', r.getBookingDetailEmail.appointments)

app.get('/api/changeBookingStatusemail', gymApps.changeBookingStatusEMAIL.changeBookingStatusE)
app.get('/api/updateBooking', gymApps.changeBookingStatusEMAIL.changeBookingStatusE)

//Trainer
app.post("/api/getTrainers", r.admintrainers.allTrainers)
app.post("/api/trainerDetails", r.admintrainers.trainerDetails)
app.post("/api/searchTrainer", r.admintrainers.search)
app.post("/api/blockTrainer", r.admintrainers.block)
app.post("/api/updateTrainer", r.admintrainers.updateTrainer)
app.get("/api/trainerList", r.admintrainers.trainerList)
app.post("/api/deleteTrainer", r.admintrainers.delete)

//Bookings
app.post("/api/getBookings", r.adminbookings.allBookings)
app.post("/api/bookingDetails", r.adminbookings.bookingDetails)
app.post("/api/changeStatus", r.adminbookings.changeStatus)
app.post("/api/searchBooking", r.adminbookings.search)
app.post("/api/addBooking", r.adminbookings.addBooking)
app.post("/api/findAvailability", r.adminbookings.findAvailability)
app.post("/api/availabileSlots", r.adminbookings.availabileSlots)
app.post("/api/trainerPayment", r.adminbookings.trainerPayment)
app.post("/api/slotPrice", r.adminbookings.slotPrice)
app.post("/api/addCard", r.adminbookings.addCard)
//Feedbacks
app.post("/api/getFeedbacks", r.adminfeedback.feedbacks)
app.post("/api/deleteFeedback", r.adminfeedback.delete)
app.post("/api/filterFeedback", r.adminfeedback.filterFeedback)
app.post("/api/searchFeedback", r.adminfeedback.search)

//Equipments
app.get("/api/getEquipments", r.adminequipments.equipments)
app.post("/api/allEquipmentsp", r.adminequipments.allEquipments)
app.post("/api/addEquipmentsa", r.adminequipments.addEquipments)
app.post("/api/deleteEquipmentsa", r.adminequipments.delete)
app.post("/api/updateEquipmentsa", r.adminequipments.update)

//Services
app.get("/api/getServices", r.adminservices.services)
app.post("/api/addServicesa", r.adminservices.addServices)
app.post("/api/allServicesp", r.adminservices.allServices)
app.post("/api/deleteServicesa", r.adminservices.delete)
app.post("/api/updateServicesa", r.adminservices.update)


//login
app.post("/api/adminlogin", r.adminlogin.login)

//earnings
app.post("/api/allEarnings", r.adminearnings.allRequests)
app.post("/api/earningStatus", r.adminearnings.earningStatus)
app.post("/api/earningDetails", r.adminearnings.earningDetails)
app.post("/api/earningNote", r.adminearnings.earningnote)
app.post("/api/allEarningsGym", r.earningsAladmin.allEarnings)

//users
app.post("/api/adminUsers", r.adminusers.allUsers)
app.post("/api/searchUsers", r.adminusers.search)
app.post("/api/searchSession", r.adminsessions.search)
app.post("/api/allEarningsTrain",r.adminearnings.allRequestsTrainer)
//getsession
app.post("/api/getSessions", r.adminsessions.allSessions)
//save Token
app.post('/api/register_push', r.save_token.save_token)
app.post('/api/un_register_push', r.save_token.un_register_push)
app.post('/api/send_push', r.save_token.send_push)
// turn notification on/off
app.post('/api/push_settings', r.save_token.push_settings)
//leads
app.post('/api/getLeads', r.adminleads.allLeads)
app.post('/api/searchLead', r.adminleads.search)

//intrests_shown
app.post('/api/getIntrestsShown', r.getIntrestsShown.getIntrestsShown)
app.post('/api/intrestsSearch', r.getIntrestsShown.search)
//notifiactions

app.post('/api/notifications', r.notifications.notifications)




app.post('/api/registerowner', gymApps.register.registerowner)


app.post('/api/loginowner', gymApps.login.loginowner)

app.post('/api/addGym', gymApps.addGym.addGym)
app.post('/api/getGym', gymApps.getGym.getGym)
app.post('/api/emailConfirmOwner', gymApps.emailConfirmOwner.emailConfirmOwner)
app.post('/api/resendEmail', gymApps.emailConfirm.emailConfirm)
app.post('/api/getBooking', gymApps.getBookings.getBookings)
app.post('/api/getDayBooking', gymApps.getDayBooking.getDayBooking)
app.post('/api/changeBookingStatus', gymApps.changeBookingStatus.changeBookingStatus)
app.post('/api/checkevent', gymApps.checkevent.checkevent)
app.post('/api/addIntrests', gymApps.addIntrests.addIntrests)
app.post('/api/getGymsCalendar', gymApps.getGymsCalendar.getGymsCalendar)
app.post('/api/getChatData', gymApps.getChatData.getChatData)
app.post('/api/forgot_password', gymApps.forgot_password.forgot_password)
app.post('/api/webnotifications', gymApps.notifications.notifications)
app.post('/api/changeNotificatonStatus', gymApps.changeNotificatonStatus.changeNotificatonStatus)
app.post('/api/emailConfirmWeb', gymApps.emailConfirmWeb.emailConfirmWeb)
app.post('/api/transferAmountTobank', gymApps.transferAmountTobank.transferAmountTobank)
app.post('/api/getUserData', gymApps.getUserData.getUserData)
app.post('/api/updateUserData', gymApps.updateUserData.updateUserData)
app.post('/api/updateGymData', gymApps.updateGymData.updateGymData)
app.post('/api/getPaymentInfo', gymApps.getPaymentInfo.getPaymentInfo)
app.post('/api/cancelPayment', gymApps.cancelPayment.cancelPayment)
app.post('/api/getNotReveiewedBookings', gymApps.getNotReveiewedBookings.getNotReveiewedBookings)
app.post('/api/submitReview', gymApps.submitReview.submitReview)
app.post('/api/getGymAddress', gymApps.getGymAddress.getGymAddress)
app.post('/api/interest_shown', gymApps.interest_shown.interest_shown)
//hourful app front end


app.post('/api/getMonthSchedule', gymApps.getMonthSchedule.getMonthSchedule)
app.post('/api/getQuickSchedule', gymApps.getQuickSchedule.getQuickSchedule)
app.post('/api/saveDetailSetupForm', gymApps.saveDetailSetupForm.saveDetailSetupForm)
app.post('/api/saveQuickSetupForm', gymApps.saveQuickSetupForm.saveQuickSetupForm)





app.post('/api/gyms_insert', function (req, res) {
  MongoClient.connect(url, function (err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    dbo.collection('TBL_GYMS').insert({
      "name": "ravi Fitness",
      "logo": "",
      "bio": "we are best",
      "price": 50,
      "min_price": "1",
      "max_price": "3",
      "avg_rating": "4.2",
      "ratings": "67",
      "street_number": "230 West 39th Street",
      "administrative_area_level_1": "2nd Floor, New York, NY 10018, United States",
      "administrative_area_level_2": "2nd Floor, New York, NY 10018, United States",
      "locality": "2nd Floor, New York, NY 10018, United States",
      "country": "United States",
      "postal_code": "10018",
      "formatted_address": "230 West 39th Street | 2nd Floor, New York, NY 10018, United States",
      "latitude": "40.713050",
      "longitude": "-74.007230",
      "equipments_ids": [
        {
          "id": ObjectId("5e5e3632f03a4e713238c565")
        },
        {
          "id": ObjectId("5e5e3653f03a4e713238c566")
        },
        {
          "id": ObjectId("5e5e3664f03a4e713238c567")
        },
        {
          "id": ObjectId("5e5e366ff03a4e713238c568")
        }
      ],
      "images_ids": [
        {
          "id": ObjectId("5e60d4f6f03a4e713238c56c")
        },
        {
          "id": ObjectId("5e60d515f03a4e713238c56d")
        },
        {
          "id": ObjectId("5e60d52af03a4e713238c56e")
        },
        {
          "id": ObjectId("5e60d557f03a4e713238c56f")
        }
      ],
      "location": {
        "type": "Point",
        "coordinates": [
          41.71305,
          -75.00723
        ]
      }
    });
    dbo.collection('TBL_GYMS').createIndex({ location: "2dsphere" })
  })
})







///not used
app.post('/api/createProfile', function (req, res) {
  //console.log()
  if (req.files != undefined) {
    var sampleFile = req.files.avatar;
    sampleFile.mv(__dirname + "/uploads/images/" + sampleFile.md5 + ".png", function (err) {
      if (err) {
        res.send({ "err": "unable to get files" });
      }
      else {
        console.log(req.body)
        const { location, gymType } = req.body;
        let errors = [];

        if (!location || !gymType) {
          errors.push({ msg: 'Please enter all fields' });
        }
        if (errors.length > 0) {
          res.send(errors);
        }
        else {
          MongoClient.connect(url, function (err, db) {
            if (err) throw err;
            var dbo = db.db("gymtraining");
            var myobj = { location: req.body.location, gymType: req.body.gymType, image: sampleFile.md5 + ".png" };
            dbo.collection("profile").insertOne(myobj, function (err, res) {
              if (err) throw err;
              console.log("1 document inserted");
              db.close();
            });
          });
        }
      }
    });
  }
  else {
    res.send({ "err": "unable to get files" });
  }

  // const tempPath = req.file.path;

  // const targetfilename =  req.file.filename;
  // const targetPath = path.join(__dirname, "./uploads/images/"+targetfilename+""+path.extname(req.file.originalname).toLowerCase());

  //   fs.rename(tempPath, targetPath, err => {
  //     if (err) return handleError(err, res);

  //     res
  //       .status(200)
  //       .contentType("text/plain")
  //       .end(targetPath);
  //   });

});




// console.log('----dir------')
// console.log(path.join(__dirname, '/api/uploads/images'))
// console.log(path.join(__dirname, '/uploads/images'))
//  var location = path.join(__dirname, '../../../uploads/images'); 
//  console.log(location)

//  console.log(path.join(__dirname+'/uploads/images', '../../../uploads/images'))

// console.log('-----dir-----')
// //http://localhost:8088/img/02add1e868e76f3ecf71ebe464af197b_1615053481.jpeg

// const Utill = require('./helper/Constant')
// console.log(Utill.IMAGE_BASE_URL)
// if(cluster.isMaster){
//   for(let i=0;i<numCpu;i++){
//     cluster.fork()
//   } 
//   cluster.on('online', function(worker) {
//     console.log('Worker ' + worker.process.pid + ' is online');
// });

// cluster.on('exit', function(worker, code, signal) {
//     console.log('Worker ' + worker.process.pid + ' died with code: ' + code + ', and signal: ' + signal);
//     console.log('Starting a new worker');
//     cluster.fork();
// });
// }
// else{
//   app.listen(8088, function () {
//     console.log(`serveris  listening on port 8088! with ${process.pid}`)
//   }) 

// }
app.listen(8088, function () {
  console.log(`serveris  listening on port 8088! with ${process.pid}`)
}) 


 