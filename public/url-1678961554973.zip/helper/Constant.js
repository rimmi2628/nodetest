
exports.BASE_URL="http://54.177.41.166/",
exports.EMAIL_SERVICE="gmail",
exports.EMAIL="hourfuladm9116@gmail.com"
//exports.EMAIL_PASSWORD="Enact_12345"
exports.EMAIL_PASSWORD="mrszknphkqujjuxs"
exports.HOST ='smtp.gmail.com'
exports.EMAIL_SUBJECT=  'Reset Password'
exports.IMAGE_BASE_URL="https://stage.hourful.io/"
