var db = mongo.connect("mongodb://localhost:8082/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
   if(err){ console.log( err); }  
   else{ //console.log('Connected to ' + db, ' + ', response); 
    }  
});  
  
const Schema = mongo.Schema;  
const UserDetail = new Schema({
    name: String,
    email: String,
    password: String
  });
const UserDetails = mongo.model('users', UserDetail, 'users');

