var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
const Utill = require('../helper/Constant')
console.log('stripe key ',Utill.STRIPE_KEY)

// var stripe = require('stripe')('sk_test_1tqRe2GJZqKbCChbIZvB4GKs');
var emailTemp = require('./emails');

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'info@hourful.io',
        pass: 'Panda999$'
    }
});
var stripe = require('stripe')(Utill.STRIPE_KEY);
const bcrypt = require('bcrypt')
var app = express() ;
const { admin } = require('./firebaseConfig.js');
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());




var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;

var options = {
  priority: "high",
  timeToLive: 60 * 60 *24
};

 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
 
var mongodbutil = require( './mongodbutil' );
 exports.cancel_booking = async function(req, res) {
    const {user_id,gym_id,booking_id} = req.body;
    if(!user_id ){
      res.send({"success":false,"message":"user_id empty","data":{}});
      return false;
    }
    else if(!gym_id){
      res.send({"success":false,"message":"gym_id empty","data":{}});
      return false;
    }
    else if(!booking_id){
      res.send({"success":false,"message":"booking id cannot be empty","data":{}});
      return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    // if (err) throw err;
    let dbo =  await mongodbutil.Get();
    const gyymdetails = dbo.collection('TBL_BOOKINS').find({ _id: ObjectId(booking_id) })
			.toArray(function (err, data) {
				if (err) {
					throw err;
				} else {
          if (data[0].payment_method == '0' && (data[0].status == 0 || data[0].status == 1 || data[0].status == 2) ) {
             stripe.refunds.create({
                    charge:  data[0].transaction_id,
                  },
                  function(err, refund) {
                    if(err){
                        console.log(err)
                       return false;
                    }
                    else{
                      var newvalues1 = { $set: { status: 4,refund_id:refund.id } };
                      var myqueryB = { _id: ObjectId(booking_id) };
                      dbo.collection("TBL_BOOKINS").updateOne(myqueryB, newvalues1, function (err, data) {
                          console.log(data);
                      });
                    }
                }
              );
              
          }
					dbo.collection('TBL_GYMS').find({ _id: ObjectId(gym_id) })
					.toArray(function (err, dataG) {
						if (err) {
							throw err;
						} else {
							var NotiObj = { trainer_id:data[0].user_id,date:data[0].date,time:data[0].time,gym_id:data[0].gym_id,gym_name:dataG[0].name,logo:dataG[0].logo,text:"",type:'3',price:data[0].price,status:1,date_time:data[0].schedule_time,created_at:getCurrentTime(),updated:getCurrentTime()};
							dbo.collection("TBL_NOTIFICATIONS").insertOne(NotiObj, function(err,resr){
							
							});
              if(data[0].status == 1 || data[0].status == 2){
                dbo.collection("TBL_AVAILABILITY_SLOTS").updateOne({_id:ObjectId(data[0].slot_id)},{$inc: {availableSlots: 1}} ,  function(err, resultsss) {
                })
              }
							dbo.collection('TBL_TRAINER_DETAILS').find({ user_id: ObjectId(user_id) })
							.toArray(function (err, data1) {
								if (err) {
									throw err;
								} else { 
									var actionInstant = 1
									var text =""
									text ='You have Rejected '+data1[0].first_name+" "+data1[0].last_name+' on  '+formatDateTime(getCurrentTime())+''
									var gymNotiObj = { trainer_id: data[0].user_id,trainer_name:data1[0].first_name+" "+data1[0].last_name,gym_id: data[0].gym_id,gym_name:dataG[0].name,price:''+data[0].price+'',text:text,action:actionInstant,status:0,date_time:data[0].schedule_time,created_at:getCurrentTime(),updated:getCurrentTime(),type:3,date:data[0].date,time:data[0].time,user_id:ObjectId(dataG[0].space_owner)};
									dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(gymNotiObj, function(err,resr){
										// if (err){
										// 	throw err;
										// }
                    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                    dbo.collection('TBL_AVAILABILITY_SLOTS').find({
                              _id: data[0].slot_id
                          })
                          .toArray(function(err, dataAAA) {
                              if (err) {
                                  // throw err;
                              } else {
                                  dbo.collection('TBL_GYM_AVAILABILITY').find({
                                  _id: dataAAA[0].gym_availability_id
                              })
                              .toArray(function(err, dataAV) {
                                  if (err) {
                                      // throw err;
                                  } else {
                                    // console.log(data[0])
                                    // console.log('dataAV')
                                    // return false
                                    dbo.collection('TBL_TRAINERS').find({
                                            _id: ObjectId(user_id)
                                        })
                                        .toArray(function(err, dataTT) {
                                            if (err) {
                                                throw err;
                                            } else {
                                              if (dataG[0].space_owner != '') {
                                                dbo.collection('TBL_SPACE_OWNER').find({ _id: dataG[0].space_owner })
                                                  .toArray(function (err, dataOO) {
                                                    if (err) {
                                                      throw err;
                                                    } else {
                                                      var date_split = data[0].date.split("-");
                                                      var time_split = data[0].time.split(":");
                                                      var time_Hr = parseInt(time_split[0]) + 1;
                                                      var time_till = time_Hr.toString()+':'+time_split[1];
                                                      var monthBB = monthNames[date_split[1]-1];
                                                      stuff = [];
                                                      stuff['email'] = dataOO[0].email
                                                      stuff['name'] = data1[0].first_name+" "+data1[0].last_name
                                                      stuff['monthBB'] = monthBB
                                                      stuff['day'] = date_split[2]
                                                      stuff['year'] = date_split[0]
                                                      stuff['start_time'] = tConvert(data[0].time)
                                                      stuff['end_time'] = tConvert(time_till)
                                                      console.log(stuff)
                                                       // if (dataOO[0].email == 'nayakacp@gmail.com') {
                                                          var email = emailTemp.bookingEmails.trainerCancel(stuff)
                                                          // console.log(stuff)
                                                          console.log(email)
                                                      // }
                                                    }
                                                  })
                                               
                                              }
                                               // tConvert ('18:00:00');
                                              // transporter.sendMail(mailOptions, function(error, info) {
                                              //     if (error) {
                                              //         // res.send({"success":true,"message":"Mail Not sent","data":{}});
                                              //         console.log(error)
                                              //     } else {
                                              //         console.log('mail sent b Cancel')
                                              //     }
                                              // });
                                            }
                                          })
                                    
                                  }
                                })
                              }
                            })
                    
                   
                     
									});
								}
							});
						}
					});
					
				} 
			});	
    dbo.collection("TBL_BOOKINS").updateOne({user_id:ObjectId(user_id),gym_id:ObjectId(gym_id),_id:ObjectId(booking_id)},{$set:{status:4}}, function(err, resv) {
        if (err){
          throw err;
        }
        else{
          if(resv){
            dbo.collection('TBL_PUSH_TOKENS').find({ trainer_id: ObjectId(user_id) })
              .toArray(function (err, tokens) {
                var dTokens= []
                for (let e = 0; e < tokens.length; e++) {
                  dTokens[e] = tokens[e].token;
                }
                var payload = {
                  notification: {
                    title: "Booking Cancel",
                    body: "Cancel Request Sent."
                  },
                  data: {
                    booking_id: booking_id,
                    user_id: user_id,
                    gym_id: gym_id,
                  }
                };
                var registrationToken = dTokens;
                if(tokens.length != 0){
                    admin.messaging().sendToDevice(registrationToken, payload, options)
                    .then(function(response) {
                      console.log("Successfully sent message:", response);
                    })
                    .catch(function(error) {
                      console.log("Error sending message:", error);
                    });
                  }
              });
            
            res.send({"success":true,"message":"We have cancelled your booking."});
            return false; 
          }
          else{
            res.send({"success":false,"message":"something went wrong","data":[]});
            return false;
          }
        }
    })
      // }); 
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

  function formatDateTime(datetime){
      const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
      const d = new Date(datetime*1000);
      var month =  monthNames[d.getMonth()];
      var date = d.getDate();
      var year = d.getFullYear();

      var hours = d.getHours();
      var minutes = d.getMinutes();
      var ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0'+minutes : minutes;
      var strTime = hours + ':' + minutes + ' ' + ampm;
    // February 10, 2020 at 10:15 AM
      return month+" "+date+","+year+" at "+strTime
    }
    function tConvert (time) {
    // Check correct time format and split into components
    time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join (''); // return adjusted time or original string
  }

 