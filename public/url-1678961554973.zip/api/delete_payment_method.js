var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')
const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');

exports.delete_payment_method = async function (req, res) {
	 if (!req.body.user_id || !req.body.payment_id) {
	    res.send({
	      "success": false,
	      "message": "user_id or payment_id empty",
	      "data": []
	    });
	    return false;
	  }
	  let dbo = await mongodbutil.Get();
	  var myquery = { _id: ObjectId(req.body.payment_id) };
	  dbo.collection("TBL_CARDS").deleteOne(myquery, function (err, obj) {
	    if (err) throw err;
	    res.send({ "success": true, "message": 'We have successfully deleted the requested payment method',"data": [] });
	  });
}