
var mongo = require("mongoose");
// console.log(sourceFile)
const {
  admin
} = require('./firebaseConfig.js');

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;



mongo.set('useFindAndModify', false);
var options = {
  priority: "high",
  timeToLive: 60 * 60 * 24
};

var mongodbutil = require('./mongodbutil');

exports.save_token = async function (req, res) {
  const { user_id, token, platform } = req.body;
  if (!user_id) {
    res.send({ "success": false, "message": "user_id empty", "data": {} });
    return false;
  }
  else if (!token) {
    res.send({ "success": false, "message": "token empty", "data": {} });
    return false;
  }
  else if (!platform) {
    res.send({ "success": false, "message": "platform cannot be empty empty", "data": {} });
    return false;
  }
  let dbo = await mongodbutil.Get();
  // data = {"trainer_id":ObjectId(trainer_id),"token":token,"platform":platform,'created_at':getCurrentTime(),'updated_at':getCurrentTime()}
  var toki = dbo.collection("TBL_PUSH_TOKENS").replaceOne(
    { "token": token },
    { "token": token, "user_id": ObjectId(user_id), "platform": platform, 'created_at': getCurrentTime(), 'updated_at': getCurrentTime() },
    { upsert: true }, function (err, resr) {
      if (err) {
        throw err;
      }
      else {
        if (resr) {
          res.send({ "success": true, "message": "We have successfully registered your device for push notifications", "data": [] });
          return false;
        }
        else {
          res.send({ "success": false, "message": "something went wrong", "data": [] });
          return false;
        }
      }
    });
  // console.log(toki)
  //  dbo.collection("TBL_PUSH_TOKENS").insertOne(data, function(err,resr){
  //     if (err){
  //         throw err;
  //     }
  //     else{
  //         if(resr){

  //             res.send({"success":true,"message":"We have successfully registered your device for push notifications","data":[]});
  //             return false;
  //         }
  //         else{
  //             res.send({"success":false,"message":"something went wrong","data":[]});
  //             return false;
  //         }
  //     }
  // }); 
  //});
}

exports.un_register_push = async function (req, res) {
  let dbo = await mongodbutil.Get();
  const { user_id, token, platform } = req.body;
  if (!user_id) {
    res.send({ "success": false, "message": "trainer_id empty", "data": {} });
    return false;
  }
  else if (!token) {
    res.send({ "success": false, "message": "token empty", "data": {} });
    return false;
  }
  else if (!platform) {
    res.send({ "success": false, "message": "platform cannot be empty empty", "data": {} });
    return false;
  }
  var myquery = { "user_id": ObjectId(user_id), "token": token, "platform": platform, };
  dbo.collection("TBL_PUSH_TOKENS").deleteMany(myquery, function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      if (resr) {
        res.send({ "success": true, "message": "We have successfully De-registered your device for push notifications", "data": [] });
        return false;
      }
      else {
        res.send({ "success": false, "message": "something went wrong", "data": [] });
        return false;
      }
    }
  });
}

exports.send_push = async function (req, res) {
  // user_id
  // to_user_id
  // message
  // session_id (optional in case of session)
  // conversation_id (optional, in case of message)
  console.log('---------send_push-------->')
  console.log(req.body)
  console.log('----------------->')
  if (!req.body.user_id || !req.body.to_user_id || !req.body.message || !req.body.title) {
    res.send({
      "success": false,
      "message": "user_id , message,title and to_user_id required",
      "data": {}
    });
    return false;
  }
  let dbo = await mongodbutil.Get();
  //check here is notification on or not 

  // table trainers details & tbl_push _tokens 

  dbo.collection('TBL_CLIENTS').find({
    _id: ObjectId(req.body.to_user_id)
  })
    .toArray(function (err, getNotification) {
      console.log('user_details')
      if (getNotification.length === 0) {
        console.log('personal trainer ')
        //send trainer notification
        sendNotificationTrainer(dbo, req, res)
      } else {
        console.log('----->client section<--------')
        if (getNotification[0].notifications == '1' || !getNotification[0].notifications || getNotification[0].notifications == '0') {
          dbo.collection('TBL_PUSH_TOKENS').find({
            user_id: ObjectId(req.body.to_user_id)
          })
            .toArray(function (err, tokens) {
              var dTokens = []
              for (let e = 0; e < tokens.length; e++) {
                dTokens[e] = tokens[e].token;
              }
              if (!req.body.session_id) {
                req.body.session_id = ''
              }
              if (!req.body.conversation_id) {
                req.body.conversation_id = ''
              }

              var dat = {
                user_id: req.body.user_id,
                session_id: req.body.session_id,
                conversation_id: req.body.conversation_id,
              }
              var payload = {
                notification: {
                  title: req.body.title,
                  body: req.body.message
                },
                data: dat
              };


              var registrationToken = dTokens;
              if (tokens.length != 0) {
                admin.messaging().sendToDevice(registrationToken, payload, options)
                  .then(function (response) {
                    //return res.json(response)
                    console.log("Successfully sent message:", response);
                    res.send({
                      "success": true,
                      "message": "Sent",
                      "data": []
                    });
                  })
                  .catch(function (error) {
                    console.log("Error sending message:", error);
                    res.send({
                      "success": false,
                      "message": "something went wrong",
                      "data": []
                    });
                  });
              } else {
                res.send({
                  "success": true,
                  "message": "No Token found",
                  "data": []
                });
              }

            });
        } else {
          res.send({
            "success": true,
            "message": "Notification is off for to user "
          });

        }
      }

    })

}

function sendNotificationTrainer(dbo, req, res) {
  dbo.collection('TBL_TRAINERS').find({
    _id: ObjectId(req.body.to_user_id)
  }).toArray(function (err, trainerNotification) {
    if (trainerNotification.length === 0) {
      return res.send({
        message: 'trainer not found '
      })
    } else {
      //  console.log(trainerNotification)
      console.log('----->trainer section<--------')
      console.log(trainerNotification[0].notifications)
      if (trainerNotification[0].notifications == '1' || !trainerNotification[0].notifications || trainerNotification[0].notifications == '0') {
        dbo.collection('TBL_PUSH_TOKENS').find({
          user_id: ObjectId(req.body.to_user_id)
        })
          .toArray(function (errs, tokens) {
            console.log('trainer_tokens---->',tokens)
            var dTokens = []
            for (let e = 0; e < tokens.length; e++) {
              dTokens[e] = tokens[e].token;
            }
            if (!req.body.session_id) {
              req.body.session_id = ''
            }
            if (!req.body.conversation_id) {
              req.body.conversation_id = ''
            }

            var dat = {
              user_id: req.body.user_id,
              session_id: req.body.session_id,
              conversation_id: req.body.conversation_id,
            }
            var payload = {
              notification: {
                title: req.body.title,
                body: req.body.message
              },
              data: dat
            };
            var registrationToken = dTokens;
            if (tokens.length != 0) {
              admin.messaging().sendToDevice(registrationToken, payload, options)
                .then(function (response) {
                  //return res.json(response)
                  console.log("Successfully sent message:", response);
                  res.send({
                    "success": true,
                    "message": "Sent",
                    "data": [],
                    response:response
                  });
                })
                .catch(function (error) {
                  console.log("Error sending message:", error);
                  res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": []
                  });
                });
            } else {
              res.send({
                "success": true,
                "message": "No Token found",
                "data": []
              });
            }



          })

      } else {
        res.send({
          "success": true,
          "message": "Notification Is Off For To User",
          "data": []
        });
      }


    }

  })

}



exports.push_settings = async function (req, res) {
  console.log(req.body)
  if (!req.body.client_id && !req.body.trainer_id) {
    res.send({
      "success": false,
      "message": "client_id or trainer_id required",
      "data": {}
    });
    return false;
  }
  if (!req.body.status) {
    res.send({
      "success": false,
      "message": "status is required",
      "data": {}
    });

  }
  let dbo = await mongodbutil.Get();
  if (req.body.client_id) {
    dbo.collection("TBL_CLIENTS").findOneAndUpdate({ _id: ObjectId(req.body.client_id) }, { $set: { notifications: req.body.status } }, function (err, result) {
      if (err) {
        res.send({ "success": false, "message": "something went wrong", "data": [] });
        return false;
      }
      else {
        res.send({ "success": true, "message": "Setting updated!", "data": [] });
        return false;
      }
    })
  }
  else {
    dbo.collection("TBL_TRAINERS").findOneAndUpdate({ _id: ObjectId(req.body.trainer_id) }, { $set: { notifications: req.body.status } }, function (err, result) {
      if (err) {
        res.send({ "success": false, "message": "something went wrong", "data": [] });
        return false;
      }
      else {
        res.send({ "success": true, "message": "Setting updated!", "data": [] });
        return false;
      }
    })

  }

}

function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}

