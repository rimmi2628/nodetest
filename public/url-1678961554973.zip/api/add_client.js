var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());







var sourceFile = require('./register.js');
// console.log(sourceFile)
var mongodbutil = require( './mongodbutil' );
  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);

exports.add_client = async function(req, res) {
    const {booking_id,client_name} = req.body;
    if(!booking_id || !client_name){
      res.send({"success":false,"message":"Please enter all fields","data":{}});
      return false;
    }
    // MongoClient.connect(url, function(err, db) {
      // if (err) throw err;
      let dbo =  await mongodbutil.Get();
      // TBL_TRAINERS.( { _id: user_id}, {$set: {services: serv } }, {upsert: true},  
      dbo.collection('TBL_BOOKINS').updateOne({ _id: ObjectId(booking_id)}, {$set: {client_name: client_name } }, {upsert: true},function(err, rese){
        if (err){
          res.send({"success":false,"message":"Something went wrong!","data":{} });
        } 
        else{
          res.send({"success":true,"message":"We have recorded the client name for requested booking","data":{}});
          // db.close();
          return false;
        }
      } );
    // })
  }