var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

var nodemailer = require('nodemailer');

var emailTemp = require('./emails');

var transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'info@hourful.io',
        pass: 'Panda999$'
    }
});

const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
const Utill = require('../helper/Constant')
//console.log(Utill.IMAGE_BASE_URL)
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);

var mongodbutil = require('./mongodbutil');

exports.feedback = async function(req, res) {
    const {
        user_id,
        gym_id,
        booking_id
    } = req.body;

    req.body.badges = JSON.parse(JSON.stringify(req.body.badges));
    // console.log(req.body.badges)
    // return
    if (!user_id) {
        res.send({
            "success": false,
            "message": "user_id empty",
            "data": {}
        });
        return false;
    } else if (!gym_id) {
        res.send({
            "success": false,
            "message": "gym_id empty",
            "data": {}
        });
        return false;
    } else if (!booking_id) {
        res.send({
            "success": false,
            "message": "booking_id empty",
            "data": {}
        });
        return false;
    }
    if (!req.body.rating) {
        req.body.rating = ''
    }
    if (!req.body.comment) {
        req.body.comment = ''
    }
    if (!req.body.badges) {
        req.body.badges = {}
    } else {
        var badge = []
        var badgesArr = []
        badge = req.body.badges.split(',')
        for (let f = 0; f < badge.length; f++) {
            badgesArr.push({
                id: ObjectId(badge[f])
            })
        }
    }
    // console.log(badgesArr)
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    // if (err) throw err;
    let dbo = await mongodbutil.Get();
    data = {
        "user_id": ObjectId(user_id),
        "gym_id": ObjectId(gym_id),
        "booking_id": ObjectId(booking_id),
        "rating": req.body.rating,
        "comment": req.body.comment,
        "badges": badgesArr,
        'created_at': getCurrentTime(),
        'updated_at': getCurrentTime()
    }

    dbo.collection("TBL_FEEDBACK").insertOne(data, function(err, resr) {
        if (err) {
            throw err;
        } else {
            if (resr) {

                // res.send({"success":true,"message":"Thank you, we have recorded your review."});
                // return false;
                dbo.collection("TBL_GYMS").find({
                    "_id": ObjectId(gym_id)
                }).toArray(function(err, result) {
                    dbo.collection('TBL_TRAINER_DETAILS').find({
                            user_id: ObjectId(user_id)
                        })
                        .toArray(function(err, dataTD) {
                            if (err) {
                                // throw err;
                            } else {
                                if (result[0].space_owner != '' || result[0].space_owner != null) {
                                    dbo.collection('TBL_SPACE_OWNER').find({
                                            _id: result[0].space_owner
                                        })
                                        .toArray(function(err, dataTT) {
                                            if (err) {
                                                // throw err;
                                            } else {
                                                // emailllll
                                                 var stuff=[];
                                                stuff['first_name']= dataTD[0].first_name
                                                stuff['last_name']= dataTD[0].last_name 
                                                stuff['email']= dataTT[0].email
                                                stuff['chat']= Utill.IMAGE_BASE_URL+'gymapp/#/?message=feedback'
                                                // if (dataTT[0].email == 'nayakacp@gmail.com') {
                                                    var email = emailTemp.bookingEmails.feedbackMailT(stuff)
                                                    // console.log(stuff)
                                                    console.log(email)
                                                // }
                                                // transporter.sendMail(mailOptions, function(error, info) {
                                                //     if (error) {
                                                //         // res.send({"success":true,"message":"Mail Not sent","data":{}});
                                                //         console.log(error)
                                                //     } else {
                                                //         console.log('mail sent b feed')
                                                //     }
                                                // });
                                            }
                                        })
                                }
                            }
                        })

                    // console.log("1",parseInt(result[0].availableSlots) - 1)
                    // console.log(parseFloat(result[0].avg_rating))
                    // console.log(parseFloat(result[0].ratings))
                    // console.log(req.body.rating)
                    var prevTotal = (parseFloat(result[0].avg_rating) * parseFloat(result[0].ratings)) + parseFloat(req.body.rating);
                    // console.log(prevTotal)
                    var avg = ((parseFloat(result[0].avg_rating) * parseFloat(result[0].ratings)) + parseFloat(req.body.rating)) / (parseFloat(result[0].ratings) + 1);
                    var total = parseInt(result[0].ratings) + 1
                    dbo.collection("TBL_GYMS").updateOne({
                        _id: ObjectId(gym_id)
                    }, {
                        $set: {
                            avg_rating: String(avg.toFixed(2)),
                            ratings: String(total)
                        }
                    }, function(err, resv) {

                        res.send({
                            "success": true,
                            "message": "Thank you, we have recorded your review."
                        });
                        return false;
                    })
                })

            } else {
                res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": []
                });
                return false;
            }
        }
    });
    // });  
}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}