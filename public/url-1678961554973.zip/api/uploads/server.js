
var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});










var db = mongo.connect("mongodb://localhost:27017/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
   if(err){ console.log( err); }  
   else{ //console.log('Connected to ' + db, ' + ', response); 
    }  
});  
const ObjectId = mongo.Types.ObjectId;
const Schema = mongo.Schema;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;

const TBL_TRAINER = new Schema({

    social_id: String,
    email: String,
    password: String,
    details_id:String,
    type: String,
    services:Array,
    email_verification_id:String,
    favourites:String,
    status:String,
    created_at:Number,
    updated_at:Number,
  });

  const TBL_TRAINER_DETAIL = new Schema({
    first_name: String,
    last_name: String,
    bio: String,
    phone_number:String,
    phone_verified: String,
    email_verified:Array,
    image:String,
    goverment_id:String,
    selfie:String,
    created_at:Number,
    updated_at:Number,
  });


const TBL_TRAINERS = mongo.model('TBL_TRAINERS', TBL_TRAINER, 'TBL_TRAINERS');
const TBL_TRAINER_DETAILS = mongo.model('TBL_TRAINER_DETAILS', TBL_TRAINER_DETAIL, 'TBL_TRAINER_DETAILS');



 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
// app.use(express.urlencoded({extended:false}))   
  
app.use(function (req, res, next) {        
     res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');    
     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');    
     res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');      
     res.setHeader('Access-Control-Allow-Credentials', true);       
     next();  
 });  
  

 app.post('/api/register', function(req, res) {
      // console.log(window.location.origin);return;
   const {email, first_name, last_name, password, social_id, image,type } = req.body;
   let errors = [];
 // console.log(req.body);return;
   if (!first_name || (!email && !social_id) || !last_name || (!password && !social_id)  || !type) {
     res.send({"success":false,"message":"Please enter all fields","data":[]});
     return false;
   }
 
// return 
 if(password){
  if (password.length < 6) {
    res.send({"success":false,"message":"Password must be atleast 6 chracter long","data":[]});
    return false;
  }
  
 }
 else{
  req.body.password = makeid(10);
}
//  console.log(req.files); //return;
  if(req.files != undefined || req.files != null){
    var sampleFile = req.files.image;
    sampleFile.mv(__dirname+"/uploads/images/"+sampleFile.md5+"."+req.files.image.mimetype.split('/')[1], function(err) {
      if (err){
        res.send({"success":false,"message":"Unable to fetch image","data":[]});
       return false;
      }
      else{
        req.body['image'] = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
      }
    })
  } 
  else{
    req.body['image'] = "" 
  }
    if(type == 0){
      TBL_TRAINERS.findOne({ email: email }).then(user => {
        if (user) {
          res.send({"success":false,"message":"Email already exists","data":[]});
          return false;
        } 
        else {
          
          const newUser = new TBL_TRAINERS(req.body);
          // console.log(newUser)
          //  res.send(newUser.save());
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newUser.password, salt, (err, hash) => {
              if (err) throw err;
              newUser.password = hash;
              var verifyEmailId=makeid(20);
              newUser.email_verification_id = verifyEmailId
              //console.log(newUser)
              //newUser.image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
              newUser
              .save()
              .then(user => {
                // const TBL_TRAINER_DETAILS = new TBL_TRAINER_DETAILS(req.body);
                MongoClient.connect(url, function(err, db) {
                  if (err) throw err;
                  var dbo = db.db("gymtraining");
                  var myobj = {user_id:newUser._id, first_name: req.body.first_name,last_name: req.body.last_name,image: req.body['image'],created_at:getCurrentTime(),updated:getCurrentTime() };
                  dbo.collection("TBL_TRAINER_DETAILS").insertOne(myobj, function(err, resv) {
                    if (err){
                      throw err;
                    }
                    else{
                           ///console.log(newUser)                   
                        var mailOptions = {
                          from: 'ravikantenact@gmail.com',
                          to: newUser.email,
                          subject: 'HourfulApp',
                          text: `Hi `+req.body.first_name+`, thank you for registering with us.
                                  Please click this link below to verify your mail <br> `
                          // html: '<h1>Hi Smartherd</h1><p>Your Messsage</p>'        
                        };
                        transporter.sendMail(mailOptions, function(error, info){
                          const userDetails = {
                            user_id:newUser._id,
                            first_name:req.body.first_name,
                            last_name:req.body.last_name,
                            email:req.body.email,
                            social_id:req.body.social_id,
                            image: req.body['image'],
                            type:newUser.type,
                          }
                          // console.log("sdsds"); 
                          if (error) {  
                            // console.log("sdsds"); 
                            res.send({"success":true,"message":"Mail Not sent","data":userDetails});
                            return false;
                          } else {
                            // console.log(userDetails);
                            res.send({"success":true,"message":"registered","data":userDetails});
                            return false;
                          }
                        });
                    }

                    db.close();
                  });
                });
              })
              .catch(err => console.log(err));
            });
          });
        }
      });
    }
    else{
      TBL_TRAINERS.findOne({ social_id: social_id }).then(user => {
        if (user) {
          res.send({"success":false,"message":"Social Id already exists","data":[]});
          return false;
        } 
        else {
          
          const newUser = new TBL_TRAINERS(req.body);
          // console.log(newUser)
          //  res.send(newUser.save());
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newUser.password, salt, (err, hash) => {
              if (err) throw err;
              newUser.password = hash;
              var verifyEmailId=makeid(20);
              newUser.email_verification_id = verifyEmailId
              //console.log(newUser)
              //newUser.image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
              newUser
              .save()
              .then(user => {
                // const TBL_TRAINER_DETAILS = new TBL_TRAINER_DETAILS(req.body);
                MongoClient.connect(url, function(err, db) {
                  if (err) throw err;
                  var dbo = db.db("gymtraining");
                  var myobj = {user_id:newUser._id, first_name: req.body.first_name,last_name: req.body.last_name,image: req.body['image'],created_at:getCurrentTime(),updated:getCurrentTime() };
                  dbo.collection("TBL_TRAINER_DETAILS").insertOne(myobj, function(err, resv) {
                    if (err){
                      throw err;
                    }
                    else{
                           ///console.log(newUser)                   
                        var mailOptions = {
                          from: 'ravikantenact@gmail.com',
                          to: newUser.email,
                          subject: 'HourfulApp',
                          text: `Hi `+req.body.first_name+`, thank you for registering with us.
                                  Please click this link below to verify your mail <br> `
                          // html: '<h1>Hi Smartherd</h1><p>Your Messsage</p>'        
                        };
                        transporter.sendMail(mailOptions, function(error, info){
                          const userDetails = {
                            user_id:newUser._id,
                            type:newUser.type,
                            first_name:req.body.first_name,
                            last_name:req.body.last_name,
                            email:req.body.email,
                            social_id:req.body.social_id,
                            image: req.body['image'],
                          }
                          // console.log("sdsds"); 
                          if (error) {  
                            // console.log("sdsds"); 
                            res.send({"success":true,"message":"Mail Not sent","data":userDetails});
                            return false;
                          } else {
                            // console.log(userDetails);
                            res.send({"success":true,"message":"registered","data":userDetails});
                            return false;
                          }
                        });
                    }

                    db.close();
                  });
                });
              })
              .catch(err => console.log(err));
            });
          });
        }
      });
    }

  }); 


 app.post('/api/get_services', (req, res) => {
    MongoClient.connect(url, function(err, db) {
      if (err) throw err;
      var dbo = db.db("gymtraining");
      dbo.collection("TBL_SERVICES").find().toArray(function(err, resr) {
        if (err){
          res.send({"success":false,"message":"Something went wrong","data":[]});
          return false;
        }
        else{
          res.send({"success":true,"message":"Success","data":resr});
          return false;
        }
      });
    })
 });

 app.post('/api/services', (req, res) => {
  //  console.log(req.body);return;
    const {user_id, services} = req.body;
    let errors = [];
  
    if (!user_id || !services) {
          res.send({"success":false,"message":"Please enter all fields","data":[]});
          return false;
    }
    else{
      var array = req.body.services.split(',');
      var serv = [];
      for(var i = 0 ;i<array.length;i++){
        serv.push({id:ObjectId(array[i])});
      }
      //console.log(serv);return
      //var service =[{id:ObjectId("5e5e0fa8f03a4e713238c562")},{id:ObjectId("5e5e0ff4f03a4e713238c563")}];
      TBL_TRAINERS.findOneAndUpdate( { _id: user_id}, {$set: {services: serv } }, {upsert: true},  
        
        function(err,doc) {
        if (err) {
          res.send({"success":false,"message":"Failed to update User","data":[]});
          return false;
          }
        else {
          MongoClient.connect(url, function(err, db) {
            if (err) throw err;
            var dbo = db.db("gymtraining");
            var query = { _id: user_id };
            dbo.collection('TBL_TRAINERS').aggregate([
              { $match : { _id : ObjectId(user_id) } } ,
              
              { 
                $lookup:
                 {
                   from: 'TBL_TRAINER_DETAILS',
                   localField: '_id',
                   foreignField: 'user_id',
                   as: 'userdetails'
                 }
               },
               {
                 $lookup : 
                 {
                   from : 'TBL_SERVICES', 
                   localField: 'services.id', 
                   foreignField: '_id', 
                   as : 'services'
                 }
                },
               
              ]).toArray(function(err, resr) {
              if (err){
                throw err;
              }
              else{
                if(resr){
                  //console.log(JSON.stringify(resr));return;
                  var data = JSON.parse(JSON.stringify(resr));
                            data={
                                  "user_id":data[0]['_id'],
                                  "first_name":data[0]['userdetails'][0]['first_name'],
                                  "last_name":data[0]['userdetails'][0]['last_name'],
                                  "social_id":data[0]['social_id'],
                                  "phone_number":data[0]['userdetails'][0]['phone'],
                                  "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                                  "email_verified":data[0]['userdetails'][0]['email_verified'],
                                  "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                                  "selfie":data[0]['userdetails'][0]['selfie'],
                                  "image":data[0]['userdetails'][0]['image'],
                                  "status":data[0]['status'],
                                  "services":data[0]['services']
                              }


                            // delete resr[0].password
                            // delete resr[0].__v
                            res.send({"success":true,"message":"Services Updated","data":data});
                            return false;
                }
                else{
                  res.send({"success":false,"message":"something went wrong","data":[]});
                  return false;
                }
              }
              
            });
          });
        }
      }); 
    }
 });
 app.post('/api/phone_verification', (req, res) => {
  //  console.log(req.body);return;
    const {user_id, verified,phone} = req.body;
    let errors = [];
  
    if (!user_id || !verified || !phone)  {
          res.send({"success":false,"message":"Please enter all fields","data":[]});
          return false;
    }
    else{
     
      TBL_TRAINER_DETAILS.findOne({user_id: ObjectId(user_id) }).then(user => {
        console.log(user)
        if (user) {
          TBL_TRAINER_DETAILS.findOneAndUpdate({_id: user._id}, {$set: {phone_verified: req.body.verified,phone_number: phone}}, {upsert: true}, function(err,doc) {
            if (err) {
              console.log(err)
              res.send({"success":false,"message":"Failed to update User","data":[]});
              return false;
              }
            else {
              TBL_TRAINERS.findOne({ _id: user_id }).then(user => {
                if (user) {
                  MongoClient.connect(url, function(err, db) {
                    if (err) throw err;
                    var dbo = db.db("gymtraining");
                    var query = { _id: user_id };
                    dbo.collection('TBL_TRAINERS').aggregate([
                      { $match : { _id : ObjectId(user_id) } } ,
                      { 
                        $lookup:
                         {
                           from: 'TBL_TRAINER_DETAILS',
                           localField: '_id',
                           foreignField: 'user_id',
                           as: 'userdetails'
                         }
                       },
                       {
                        $lookup : 
                        {
                          from : 'TBL_SERVICES', 
                          localField: 'services.id', 
                          foreignField: '_id', 
                          as : 'services'
                        }
                       },
                       
                      ]).toArray(function(err, resr) {
                      if (err){
                        throw err;
                      }
                      else{
                        if(resr){
                          
                          var data = JSON.parse(JSON.stringify(resr));
                            data={
                                  "user_id":data[0]['_id'],
                                  "first_name":data[0]['userdetails'][0]['first_name'],
                                  "last_name":data[0]['userdetails'][0]['last_name'],
                                  "phone_number":data[0]['userdetails'][0]['phone_number'],
                                  "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                                  "email_verified":data[0]['userdetails'][0]['email_verified'],
                                  "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                                  "selfie":data[0]['userdetails'][0]['selfie'],
                                  "image":data[0]['userdetails'][0]['image'],
                                  "status":data[0]['status'],
                                  "services":data[0]['services']
                              }


                            // delete resr[0].password
                            // delete resr[0].__v
                            res.send({"success":true,"message":"Login successfull","data":data});
                            return false;
                        }
                        else{
                          res.send({"success":false,"message":"something went wrong","data":[]});
                          return false;
                        }
                      }
                      
                    });
                  });
                }
                else{
                  res.send({"success":false,"message":"Something went wrong","data":[]});
                  return false;
                } 
              })
              }
          });
        } 
        else {
          res.send({"success":false,"message":"User not found","data":[]});
          return false;
        }
      }) 
    }
 });
 app.post('/api/request_email_verification', (req, res) => {
  //  console.log(req.body);return;
    const {email} = req.body;
    let errors = [];
  
    if (!email) {
          res.send({"success":false,"message":"Please enter all fields","data":[]});
          return false;
    }
    else{
      var verifyEmailId=makeid(20);
          TBL_TRAINERS.findOne({ email: email }).then(user => {
                  if (user) {
                    TBL_TRAINERS.findOneAndUpdate({email: email}, {$set: {email_verification_id:verifyEmailId}}, {upsert: true}, function(err,doc) {
                      if (err) {
                        res.send({"success":false,"message":"Failed to Send mail","data":[]});
                        return false;
                        }
                        else{
                          var mailOptions = {
                            from: 'ravikantenact@gmail.com',
                            to: email,
                            subject: 'HourfulApp',
                            text: `Hi `+user.first_name+`, thank you for registering with us.
                                    Please click this link below to verify your mail <br> `+verifyEmailId
                            // html: '<h1>Hi Smartherd</h1><p>Your Messsage</p>'        
                          };
                          transporter.sendMail(mailOptions, function(error, info){
                            if (error) {  
                              res.send({"success":true,"message":"Mail Not sent","data":[]});
                            } else {
                              res.send({"success":true,"message":"Mail Send","data":[]});
                            }
                          });
                        }
                      })
                    } 
              else {
                res.send({"success":false,"message":"email doesn't exist","data":[]});
                return false;
              }
            });
          //}
      //}); 
    }
 });
app.post('/api/upload_id', (req, res) => {
    // console.log(req.files);return;
    const {user_id,type} = req.body;
    if (!type || !user_id) {
      res.send({"success":false,"message":"Please enter all fields","data":[]});
      return false;
    }
    if(req.files != undefined ){ 
          var sampleFile = req.files.image;
          sampleFile.mv(__dirname+"/uploads/images/"+sampleFile.md5+"."+req.files.image.mimetype.split('/')[1], function(err) {
            if (err){
              res.send({"success":false,"message":"Unable to fetch image","data":[]});
              return false;
            }
            else{
              var image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];

     
              TBL_TRAINER_DETAILS.findOne({user_id: ObjectId(user_id) }).then(user => {
                //console.log(user)
                if(type==0){
                  var ttt ={goverment_id:image};
                }
                else{
                  var ttt ={selfie:image};
                }
                if (user) {
                  TBL_TRAINER_DETAILS.findOneAndUpdate({_id: user._id}, {$set: ttt}, {upsert: true}, function(err,doc) {
                    if (err) {
                      console.log(err)
                      res.send({"success":false,"message":"Failed to update User","data":[]});
                      return false;
                      }
                    else {
                      TBL_TRAINERS.findOne({ _id: user_id }).then(user => {
                        if (user) {
                          MongoClient.connect(url, function(err, db) {
                            if (err) throw err;
                            var dbo = db.db("gymtraining");
                            var query = { _id: user_id };
                            dbo.collection('TBL_TRAINERS').aggregate([
                              { $match : { _id : ObjectId(user_id) } } ,
                              { 
                                $lookup:
                                {
                                  from: 'TBL_TRAINER_DETAILS',
                                  localField: '_id',
                                  foreignField: 'user_id',
                                  as: 'userdetails'
                                }
                              },
                              {
                                $lookup : 
                                {
                                  from : 'TBL_SERVICES', 
                                  localField: 'services.id', 
                                  foreignField: '_id', 
                                  as : 'services'
                                }
                               },
                              
                              
                              ]).toArray(function(err, resr) {
                              if (err){
                                throw err;
                              }
                              else{
                                if(resr){
                                  
                                  var data = JSON.parse(JSON.stringify(resr));
                                    data={
                                          "user_id":data[0]['_id'],
                                          "first_name":data[0]['userdetails'][0]['first_name'],
                                          "last_name":data[0]['userdetails'][0]['last_name'],
                                          "phone_number":data[0]['userdetails'][0]['phone_number'],
                                          "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                                          "email_verified":data[0]['userdetails'][0]['email_verified'],
                                          "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                                          "selfie":data[0]['userdetails'][0]['selfie'],
                                          "image":data[0]['userdetails'][0]['image'],
                                          "status":data[0]['status'],
                                          "services":data[0]['services']
                                      }


                                    // delete resr[0].password
                                    // delete resr[0].__v
                                    res.send({"success":true,"message":"Login successfull","data":data});
                                    return false;
                                }
                                else{
                                  res.send({"success":false,"message":"something went wrong","data":[]});
                                  return false;
                                }
                              }
                              
                            });
                          });
                        }
                        else{
                          res.send({"success":false,"message":"Something went wrong","data":[]});
                          return false;
                        } 
                      })
                      }
                  });
                } 
                else {
                  res.send({"success":false,"message":"User not found","data":[]});
                  return false;
                }
              }) 

            } 
          });
    }
    else{
      res.send({"success":false,"message":"Unable to fetch image","data":[]});
      return false;
    }
 });
app.post('/api/login', (req, res) => {
    // console.log(req.body);return;
    const {email, password , social_id ,type} = req.body;
    let errors = [];
    if(type != 1){
      if(!password || !email){
        res.send({"success":false,"message":"Please enter all fields","data":[]});
        return false;
      }
    }
    else{
      if(!social_id){
        res.send({"success":false,"message":"Please enter all fields","data":[]});
        return false;
      }
    }

      if(type == 0){
        TBL_TRAINERS.findOne({ email: email }).then(user => {
          if (user) {
           bcrypt.compare(req.body.password, user.password, function(err, resaa) {
               if (err){
                 res.send({"success":false,"message":"Something went wrong","data":[]});
                 return false;
               }
               if (resaa){
                TBL_TRAINERS.findOne({ email: email }).then(user => {
                  if (user) {
                    MongoClient.connect(url, function(err, db) {
                      if (err) throw err;
                      var dbo = db.db("gymtraining");
                      // var query = { _id: user_id };
                      dbo.collection('TBL_TRAINERS').aggregate([
                        { $match : { _id : ObjectId(user._id) } } ,
                        { 
                          $lookup:
                           {
                             from: 'TBL_TRAINER_DETAILS',
                             localField: '_id',
                             foreignField: 'user_id',
                             as: 'userdetails'
                           }
                         },
                         {
                          $lookup : 
                          {
                            from : 'TBL_SERVICES', 
                            localField: 'services.id', 
                            foreignField: '_id', 
                            as : 'services'
                          }
                         },
                         
                         
                        ]).toArray(function(err, resr) {
                        if (err){
                          throw err;
                        }
                        else{
                          if(resr){
                            
                            var data = JSON.parse(JSON.stringify(resr));
                            data={
                                  "user_id":data[0]['_id'],
                                  "first_name":data[0]['userdetails'][0]['first_name'],
                                  "last_name":data[0]['userdetails'][0]['last_name'],
                                  "phone_number":data[0]['userdetails'][0]['phone_number'],
                                  "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                                  "email_verified":data[0]['userdetails'][0]['email_verified'],
                                  "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                                  "selfie":data[0]['userdetails'][0]['selfie'],
                                  "image":data[0]['userdetails'][0]['image'],
                                  "status":data[0]['status'],
                                  "email":data[0]['email'],
                                  "social":data[0]['social_id'],
                                  "services":data[0]['services']
                              }


                            // delete resr[0].password
                            // delete resr[0].__v
                            res.send({"success":true,"message":"Login successfull","data":data});
                            return false;
                          }
                          else{
                            res.send({"success":false,"message":"something went wrong","data":[]});
                            return false;
                          }
                        }
                        
                      });
                    });
                  }
                  else{
                    res.send({"success":false,"message":"Something went wrong","data":[]});
                    return false;
                  } 
                })
               } else {
                res.send({"success":false,"message":"Password Does not matched","data":[]});
                return false;
               }
             });
          } else {
            res.send({"success":false,"message":"Email not exists","data":[]});
            return false;
          }
        });
      }
      else{
        TBL_TRAINERS.findOne({ social_id: social_id }).then(user => {
          if (user) {
            MongoClient.connect(url, function(err, db) {
              if (err) throw err;
              var dbo = db.db("gymtraining");
              // var query = { _id: user_id };
              dbo.collection('TBL_TRAINERS').aggregate([
                { $match : { _id : ObjectId(user._id) } } ,
                { 
                  $lookup:
                   {
                     from: 'TBL_TRAINER_DETAILS',
                     localField: '_id',
                     foreignField: 'user_id',
                     as: 'userdetails'
                   }
                 },
                 
                 
                ]).toArray(function(err, resr) {
                if (err){
                  throw err;
                }
                else{
                  if(resr){
                    var data = JSON.parse(JSON.stringify(resr));
                    data={
                          "user_id":data[0]['_id'],
                          "first_name":data[0]['userdetails'][0]['first_name'],
                          "last_name":data[0]['userdetails'][0]['last_name'],
                          "phone_number":data[0]['userdetails'][0]['phone'],
                          "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                          "email_verified":data[0]['userdetails'][0]['email_verified'],
                          "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                          "selfie":data[0]['userdetails'][0]['selfie'],
                          "image":data[0]['userdetails'][0]['image'],
                          "status":data[0]['status'],
                          "social_image":data[0]['userdetails'][0]['social_image']
                      }


                    // delete resr[0].password
                    // delete resr[0].__v
                    res.send({"success":true,"message":"Login successfull","data":data});
                    return false;
                  }
                  else{
                    res.send({"success":false,"message":"something went wrong","data":[]});
                    return false;
                  }
                }
                
              });
            });
          } else {
           const newUser = new TBL_TRAINERS(req.body);
           newUser
              .save()
              .then(user => {
                // const TBL_TRAINER_DETAILS = new TBL_TRAINER_DETAILS(req.body);
                MongoClient.connect(url, function(err, db) {
                  if (err) throw err;
                  var dbo = db.db("gymtraining");
                  var myobj = {user_id:newUser._id, first_name: req.body.first_name,last_name: req.body.last_name,social_image: req.body['social_image'],created_at:getCurrentTime(),updated:getCurrentTime() };
                  dbo.collection("TBL_TRAINER_DETAILS").insertOne(myobj, function(err, resv) {
                    if (err){
                      throw err;
                    }
                    else{
                          
                          // console.log(userDetails);
                          req.body.user_id = newUser._id;
                          // req.body.user_id = newUser._id;
                          delete req.body.type;
                          delete req.body.social_id;

                          res.send({"success":true,"message":"login successfull","data":req.body});
                          return false;
                        //}

                    }

                    db.close();
                  });
                });
              }) 
           //  res.send({"success":"0","message":"Social Id not exists","data":[]});
          //  return false;
          }
        });
      }

  
 });

app.post('/api/bio', (req, res) => {
  //  console.log(req.body);return;
    const {user_id,bio} = req.body;
    let errors = [];
  
    if (!user_id || !bio)  {
          res.send({"success":false,"message":"Please enter all fields","data":[]});
          return false;
    }
    else{
     
      TBL_TRAINER_DETAILS.findOne({user_id: ObjectId(user_id) }).then(user => {
        console.log(user)
        if (user) {
          TBL_TRAINER_DETAILS.findOneAndUpdate({_id: user._id}, {$set: {bio: req.body.bio}}, {upsert: true}, function(err,doc) {
            if (err) {
              console.log(err)
              res.send({"success":false,"message":"Failed to update User","data":[]});
              return false;
              }
            else {
              TBL_TRAINERS.findOne({ _id: user_id }).then(user => {
                if (user) {
                  MongoClient.connect(url, function(err, db) {
                    if (err) throw err;
                    var dbo = db.db("gymtraining");
                    var query = { _id: user_id };
                    dbo.collection('TBL_TRAINERS').aggregate([
                      { $match : { _id : ObjectId(user_id) } } ,
                      { 
                        $lookup:
                         {
                           from: 'TBL_TRAINER_DETAILS',
                           localField: '_id',
                           foreignField: 'user_id',
                           as: 'userdetails'
                         }
                       },
                       {
                        $lookup : 
                        {
                          from : 'TBL_SERVICES', 
                          localField: 'services.id', 
                          foreignField: '_id', 
                          as : 'services'
                        }
                       },
                       
                       
                      ]).toArray(function(err, resr) {
                      if (err){
                        throw err;
                      }
                      else{
                        if(resr){
                          
                          var data = JSON.parse(JSON.stringify(resr));
                            data={
                                  "user_id":data[0]['_id'],
                                  "first_name":data[0]['userdetails'][0]['first_name'],
                                  "last_name":data[0]['userdetails'][0]['last_name'],
                                  "phone_number":data[0]['userdetails'][0]['phone_number'],
                                  "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                                  "email_verified":data[0]['userdetails'][0]['email_verified'],
                                  "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                                  "selfie":data[0]['userdetails'][0]['selfie'],
                                  "image":data[0]['userdetails'][0]['image'],
                                  "bio":data[0]['userdetails'][0]['bio'],
                                  "status":data[0]['status'],
                                  "services":data[0]['services']
                              }


                            // delete resr[0].password
                            // delete resr[0].__v
                            res.send({"success":true,"message":"Login successfull","data":data});
                            return false;
                        }
                        else{
                          res.send({"success":false,"message":"something went wrong","data":[]});
                          return false;
                        }
                      }
                      
                    });
                  });
                }
                else{
                  res.send({"success":false,"message":"Something went wrong","data":[]});
                  return false;
                } 
              })
              }
          });
        } 
        else {
          res.send({"success":false,"message":"User not found","data":[]});
          return false;
        }
      }) 
    }
});
app.post('/api/filter', function(req, res) {
      var minPrice = 80;
      var maxPrice = 250; 
      var minRadius = 0; 
      var maxRadius = 100;
      MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("gymtraining");
        dbo.collection("TBL_EQUIPMENTS").find().toArray(function(err, resr) {
        if (err){
          res.send({"success":true,"message":"Something went wrong","data":[]});
          return false;
        }
        else{
          // console.log(resr);
          var data={
            "price":{"min":minPrice,"max":maxPrice},
            "radius":{"min":minRadius,"max":maxRadius},
            "equipments":resr,
            
          }
          res.send({"success":true,"message":"Success","data":data});
          return false;
        }
      });
    })
})
app.post('/api/gyms', function(req, res) {

  const {latitude,longitude,min_price,max_price,radius,datetime} = req.body;
  if(!latitude || !longitude){
    res.send({"success":false,"message":"Please enter all fields","data":[]});
    return false;
  }
  if(radius == undefined){
    var rad = '16000';
  }
  else{
    var rad = radius
  }
  if(min_price == undefined){
    var min = '0';
  }
  else{
    var min = min_price;
  }
  if(max_price == undefined){
    var max ='250';
  }
  else{
    var max =max_price;
  }
  // if(datetime == undefined){
  //   var datetime ="12312312312";
  // }
  // if(datetime == undefined){
  //   var datetime ="12312312312";
  // }
  // console.log(latitude);return;
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    // var query = { _id: user_id };
    // dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
    dbo.collection('TBL_GYMS').aggregate([
      
   
      { 
        
        $geoNear: {
          near: { type: "Point", coordinates: [  parseFloat(latitude),
            parseFloat(longitude) ] },
          spherical: true,
          maxDistance: parseInt(rad),
          distanceField: "dist.calculated",
          query: { "price": { "$gte": String(min), "$lte": String(max) } },
       }
      },
      {
        $lookup : 
        {
          from : 'TBL_EQUIPMENTS', 
          localField: 'equipments_ids.id', 
          foreignField: '_id', 
          as : 'equipments_ids'
        }
        },
      {
      $lookup : 
      {
        from : 'TBL_GYM_IMAGES', 
        localField: 'images_ids.id', 
        foreignField: '_id', 
        as : 'images_ids'
      }
      },
      ]).toArray(function(err, resr) {
      if (err){
        throw err;
      }
      else{
        if(resr){
          
          var data = JSON.parse(JSON.stringify(resr));
          console.log(data)
          res.send({"success":true,"message":"success","data":data});
          return false;
        }
        else{
          res.send({"success":false,"message":"something went wrong","data":[]});
          return false;
        }
      }
      
    });
  });
})
app.post('/api/gym_details',function(req,res){
  const {gym_id} = req.body;
  if(!gym_id ){
    res.send({"success":false,"message":"Please enter all fields","data":[]});
    return false;
  }
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    // var query = { _id: user_id };
    // dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
    dbo.collection('TBL_GYMS').aggregate([
      { $match : { _id : ObjectId(gym_id) } } ,
      {
        $lookup : 
        {
          from : 'TBL_EQUIPMENTS', 
          localField: 'equipments_ids.id', 
          foreignField: '_id', 
          as : 'equipments_ids'
        }
        },
      {
      $lookup : 
      {
        from : 'TBL_GYM_IMAGES', 
        localField: 'images_ids.id', 
        foreignField: '_id', 
        as : 'images_ids'
      }
      },
      ]).toArray(function(err, resr) {
      if (err){
        throw err;
      }
      else{
        if(resr){
          
          var data = JSON.parse(JSON.stringify(resr));
           //console.log(data)
          var gymdetails=
            {
              "id":data[0]._id, 
              "name":data[0].name,
              "logo":data[0].link,
              "price":data[0].price,
              "favorite":0,
              "avg_rating":data[0].avg_rating,
              "num_of_ratings":data[0].ratings,
              "images":data[0].images_ids,
              "address":data[0].formatted_address,
              "open_now":{
                  "from":"7 am",
                  "to":"10 pm"
              },
              "description":data[0].bio,
              "equipments":data[0].equipments_ids,
              "availability":[1583406224,1583516224],
          }
          res.send({"success":true,"message":"success","data":gymdetails});
          return false;
        }
        else{
          res.send({"success":false,"message":"something went wrong","data":[]});
          return false;
        }
      }
      
    });
  });
})
app.post('/api/schedule', function(req, res) {

  const {user_id,gym_id,datetime,payment_method,transaction_id} = req.body;
  if(!user_id || !gym_id || !datetime || !payment_method || !transaction_id){
    res.send({"success":false,"message":"Please enter all fields","data":[]});
    return false;
  }
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    
    var gymID =  ObjectId(gym_id)
    var userID =  ObjectId(user_id)
    var myobj = { user_id: userID,gym_id: gymID,datetime: datetime};
    var myobj2 = { transaction_id: transaction_id,payment_method: payment_method,user_id: userID,gym_id:gymID};
    if(req.body.duration != undefined){
      myobj.duration = req.body.duration
    }
    if(req.body.client_name != undefined){
      myobj.client_name = req.body.client_name
    }
    dbo.collection("TBL_BOOKINS").insertOne(myobj, function(err, rese) {
      if (err) throw err;
      //console.log(res.insertedId);
      myobj2.booking_id = ObjectId(rese.insertedId)
      dbo.collection("TBL_PAYMENT_LOGS").insertOne(myobj2, function(err, resee) {
        if (err){
          res.send({"success":false,"message":"Something went wrong!","data":[] });
        } 
        else{
          res.send({"success":true,"message":"Thank you, we have received your booking request. You shall receive updates from Gym when request is confirmed.","data":{"booking_id":myobj2.booking_id}});
          db.close();
          return false;
        }
        
      });
      db.close();
    });
  })
})
app.post('/api/add_client', function(req, res) {

  const {booking_id,client_name} = req.body;
  if(!booking_id || !client_name){
    res.send({"success":false,"message":"Please enter all fields","data":[]});
    return false;
  }
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    // TBL_TRAINERS.( { _id: user_id}, {$set: {services: serv } }, {upsert: true},  
    dbo.collection('TBL_BOOKINS').updateOne({ _id: ObjectId(booking_id)}, {$set: {client_name: client_name } }, {upsert: true},function(err, rese){
      if (err){
        res.send({"success":false,"message":"Something went wrong!","data":[] });
      } 
      else{
        res.send({"success":true,"message":"We have recorded the client name for requested booking","data":[]});
        db.close();
        return false;
      }
    } );
  })
})


app.post('/api/appointments', function(req, res) {
  const {user_id,type} = req.body;
  if(!user_id || !type){
    res.send({"success":false,"message":"Please enter all fields","data":[]});
    return false;
  }
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    dbo.collection('TBL_BOOKINS').aggregate([
      { $match : { user_id : ObjectId(user_id) } } ,
      {$sort: {datetime: -1}},
      { 
        $lookup:
         {
           from: 'TBL_GYMS',
           localField: 'gym_id',
           foreignField: '_id',
           as: 'gymdetails'
         }
       },
       {
        "$project": {
          "_id": 1,
          "gymdetails.name": 1,
          "gymdetails.logo": 1,
          "client_name": 1,
          "datetime": 1,
        }
      }
    ]).toArray(function(err, resr) {
      if (err){
        res.send({"success":false,"message":"something went wrong","data":[]});
        return false;
      }
      else{
        if(resr){
          var data = JSON.stringify(resr);
          console.log(data)

          console.log(resr[0]);
          gymdeta=[];
          for(var i = 0;i<resr.length;i++){
              gymdeta.push({"id":resr[i]["_id"],"name":resr[i]['gymdetails'][0].name,"logo":resr[i]['gymdetails'][0].logo,"logo":resr[i]['gymdetails'][0].logo ,"time":{
                "from":"",
                "to":"",
                "client_name":resr[i].client_name
  
              }
            })
          }
         

        res.send({"success":true,"message":"success","data":gymdeta});
        return false;
        //   return false;
        }
        else{
          res.send({"success":false,"message":"something went wrong","data":[]});
          return false;
        }
      }
      
    });
  })
})


app.post('/api/gyms_insert', function(req, res) {
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    dbo.collection('TBL_GYMS').insert( {
      name: "Polo Grounds",
      location: { type: "Point", coordinates: [ -73.9375, 40.8303 ] },
      category: "Stadiums"
   } );
   dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
  })
})




function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}

function makeid(length) {
   var result           = '';
   var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   var charactersLength = characters.length;
   for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   return result;
}


///not used
app.post('/api/createProfile', function(req, res) {
  //console.log()
   if(req.files != undefined){
     var sampleFile = req.files.avatar;
     sampleFile.mv(__dirname+"/uploads/images/"+sampleFile.md5+".png", function(err) {
       if (err){
         res.send({"err":"unable to get files"});
       }
       else{
         console.log(req.body)
         const { location, gymType } = req.body;
         let errors = [];
       
         if (!location || !gymType) {
           errors.push({ msg: 'Please enter all fields' });
         }
         if (errors.length > 0) {
          res.send(errors);
         }
         else{
           MongoClient.connect(url, function(err, db) {
             if (err) throw err;
             var dbo = db.db("gymtraining");
             var myobj = { location: req.body.location,gymType: req.body.gymType,image: sampleFile.md5+".png" };
             dbo.collection("profile").insertOne(myobj, function(err, res) {
               if (err) throw err;
               console.log("1 document inserted");
               db.close();
             });
           });
         }
       } 
     });
   }
   else{
     res.send({"err":"unable to get files"});
   }
  
   // const tempPath = req.file.path;
   
   // const targetfilename =  req.file.filename;
   // const targetPath = path.join(__dirname, "./uploads/images/"+targetfilename+""+path.extname(req.file.originalname).toLowerCase());
   
   //   fs.rename(tempPath, targetPath, err => {
   //     if (err) return handleError(err, res);
 
   //     res
   //       .status(200)
   //       .contentType("text/plain")
   //       .end(targetPath);
   //   });
 
});






 

  
app.listen(8088, function () {  
    
 //console.log('Example app listening on port 8080!')  
})  