// routes for api
exports.register = require('./register.js')
exports.get_services = require('./get_services.js')
exports.services = require('./services.js')
exports.phone_verification = require('./phone_verification.js')
exports.request_email_verification = require('./request_email_verification.js')
exports.upload_id = require('./upload_id.js')
exports.login = require('./login.js')
exports.bio = require('./bio.js')
exports.filter = require('./filter.js')
exports.gyms = require('./gyms.js')
exports.gym_details = require('./gym_details.js')
exports.schedule = require('./schedule.js')
exports.add_client = require('./add_client.js') 



exports.clients = require('./clients.js')
exports.reporting_client = require('./report_client.js')
exports.sessions = require('./sessions.js')
exports.session_payments = require('./session_payments.js')
exports.trainer_bank = require('./trainer_bank.js')
exports.transfer_payment = require('./transfer_payment.js')
exports.view_sessions_history = require('./sessionsHistory.js')
// exports.punch_card = require('./punch_card.js')
// exports.availabilityt = require('./availability.js')
exports.punch_card = require('./punch_card.js');
exports.reporting_trainer = require('./report_trainer.js')
exports.trainer_info = require('./trainer_info.js')
exports.trainer_availability = require('./trainer_availability.js')
exports.delete_payment_method = require('./delete_payment_method.js')
exports.report_trainer=require('./report_trainer')



exports.appointments = require('./appointments.js')
exports.getBookingDetailEmail = require('./get_book_detailsEmail.js')
exports.availability = require('./availability.js') 
exports.badges = require('./badges.js')
exports.feedback = require('./feedback.js')
exports.favorites = require('./mark_favorite.js')
exports.get_favorites = require('./get_favorites.js')
exports.payment_method = require('./payment_method.js')
exports.reviews = require('./reviews.js')
exports.add_notes = require('./add_notes.js')
exports.report_gym = require('./report_gym.js')
exports.cancel_booking = require('./cancel_booking.js')
exports.reschedule = require('./reschedule.js')
exports.gym_reviews = require('./gym_reviews.js')
exports.notifications = require('./notifications.js')
exports.change_password = require('./change_password.js')
exports.update_profile = require('./update_profile.js')
exports.reset_password = require('./reset_password.js')
exports.get_user_payment_method = require('./get_user_payment_method.js')
exports.availabilities = require('./availabilities.js')
exports.emailConfirm = require('./emaiConfirm.js')
exports.debitBank = require('./debitBank.js')
exports.usePaypal = require('./paypal.js')
exports.report_problem = require('./report_problem.js')
exports.get_aminities = require('./get_aminities.js')
exports.profile = require('./profile.js')


// availabilities
exports.save_token = require('./saveToken.js')

// routes for admin
exports.admingyms = require('./admin/adminGyms.js');
exports.admintrainers = require('./admin/adminTrainers.js');
exports.adminbookings = require('./admin/adminBookings.js');
exports.adminequipments = require('./admin/equipments.js');
exports.adminservices = require('./admin/services.js');
exports.adminfeedback = require('./admin/adminFeedbacks.js');
exports.adminlogin = require('./admin/login.js');
exports.adminearnings = require('./admin/adminEarnings.js');
exports.adminleads = require('./admin/adminLeads.js');
exports.earningsAladmin = require('./admin/earnings.js');
exports.getIntrestsShown = require('./admin/getIntrestsShown.js');
exports.adminusers = require('./admin/adminUsers.js');
exports.adminsessions = require('./admin/adminSessions.js');

exports.notifyViaEmail = require('./offlineEmail.js');
exports.cronSession = require('./cronP3ClientTrainerSessions.js')

// exports.bookingEmails = require('./email.js')
