var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = require('mongodb').ObjectID
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
var mongodbutil = require('./mongodbutil');
var sourceFile = require('./register.js');


exports.transfer_payment = async function (req, res) {
	let dbo = await mongodbutil.Get();

	var myobj = {
		user_id: ObjectId(req.body.user_id),
		amount: req.body.amount,
		routing_number: req.body.routing_number,
		account_number: req.body.account_number,
		paypal_email: '-',
		payment_method: req.body.payment_method,
		status: 0,
		created_at: getCurrentTime(),
		trainer:1
	};

	var paymentObj = {'trainer_id':ObjectId(req.body.user_id), 'amount': -Number(req.body.amount), 'notes':'', 'created_at':getCurrentTime(), status:2}
      dbo.collection("TBL_SESSION_PAYMENTS").insertOne(paymentObj, function (err, resvP) {
      	if (err) {
			res.send({
				"success": false,
				"message": "Something went wrong!",
				"data": {}
			});

		}
		else {
			var session_payment_id = ObjectId(resvP.insertedId)
			myobj.session_payment_id = session_payment_id;
			dbo.collection("TBL_PAYMENT_REQUEST").insertOne(myobj, function (err, resee) {
				if (err) {
					res.send({
						"success": false,
						"message": "Something went wrong!",
						"data": {}
					});
				} else {
					res.send({
						"success": true,
						"message": "Withdrawal request sent!",
						"data": {}
					});
				}
			})
		}
    })
	
}

function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}