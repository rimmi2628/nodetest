var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var sourceFile = require('./register.js');
var db = mongo.connect("mongodb://localhost:27017/gymtraining", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}, function (err, response) {
    if (err) {
        console.log(err);
    } else { //console.log('Connected to ' + db, ' + ', response); 
    }
});
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.update_bank_info = async function (req, res) {

    if (!req.body.user_id) {
        res.send({
            "success": false,
            "message": "user_id missing",
            "data": {}
        });
        return false;
    } else if (!req.body.account_number) {
        res.send({
            "success": false,
            "message": "account_number missing",
            "data": {}
        });
        return false;
    } else if (!req.body.bank_name) {
        res.send({
            "success": false,
            "message": "bank_name missing",
            "data": {}
        });
        return false;
    }
    else if (!req.body.name_on_account) {
        res.send({
            "success": false,
            "message": "name_on_account missing",
            "data": {}
        });
        return false;
    } else if (!req.body.routing_number) {
        res.send({
            "success": false,
            "message": "routing_number missing",
            "data": {}
        });
        return false;
    } else if (!req.body.payment_type) {
        res.send({
            "success": false,
            "message": "payment_type missing",
            "data": {}
        });
        return false;
    }
    data = {
        "trainer_id": ObjectId(req.body.user_id),
        "payment_type": req.body.payment_type,
        "account_type": req.body.account_type,
        "name": req.body.bank_name,
        "routing_number": req.body.routing_number,
        "account_number": req.body.account_number,
        "account_name" : req.body.name_on_account,
        'created_at': getCurrentTime(),
        'updated_at': getCurrentTime()
    }
    let dbo = await mongodbutil.Get();
    dbo.collection('TBL_CARDS').updateOne({
        trainer_id: ObjectId(req.body.user_id),
        payment_type: req.body.payment_type
    }, {
        $set: data
    }, {
        upsert: true
    }, function (err, rese) {
        if (err) {
            res.send({
                "success": false,
                "message": "Unable to save data.",
                "data": {}
            });
            return false;
        } else {
            delete data.trainer_id
            delete data.created_at
            delete data.updated_at
            if (req.body.primary == '1') {
                dbo.collection('TBL_CARDS').updateMany({
                    trainer_id: ObjectId(req.body.user_id)
                }, {
                    $set: {
                        "primary": '0'
                    }
                }, function (err, rese) {
                    if (err) {
                        res.send({
                            "success": true,
                            "message": "Unable to save data.",
                            "data": {}
                        });
                        return false;
                    } else {
                        dbo.collection('TBL_CARDS').updateOne({
                            trainer_id: ObjectId(req.body.user_id),
                            payment_type: req.body.payment_type
                        }, {
                            $set: {
                                "primary": '1'
                            }
                        }, {
                            upsert: true
                        }, function (err, rese) {
                            if (err) {
                                res.send({
                                    "success": true,
                                    "message": "Unable to save data.",
                                    "data": {}
                                });
                                return false;
                            } else {
                                res.send({
                                    "success": true,
                                    "message": "Bank details has been saved",
                                    "data": data
                                });
                                return false;
                            }
                        })

                    }
                })
            } else {
                res.send({
                    "success": true,
                    "message": "Bank details has been saved",
                    "data": data
                });
                return false;
            }
        }

    })
}

exports.bank_info = async function (req, res) {

    if (!req.body.user_id) {
        res.send({
            "success": false,
            "message": "user_id missing",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    dbo.collection('TBL_CARDS').aggregate([{
        $match: {
            trainer_id: ObjectId(req.body.user_id),
            payment_type: '1'
        }
    }]).toArray(function (err, resr) {
        if (err) {
            throw err;
        } else {
            if (resr) {
                for (var i = 0; i < resr.length; i++) {
                    // resr[i].user_id = resr[i].trainer_id;
                    resr[i].payment_type = resr[i].payment_type;
                    resr[i].bank_name = resr[i].name;
                    resr[i].name_on_account = resr[i].account_name;
                    resr[i].primary = 1;
                    // resr[i].id = resr[i]._id;
                    // delete resr[i].payment_method;
                    delete resr[i].trainer_id;
                    delete resr[i].paypal_authorization;
                    delete resr[i].paypal_email;
                    delete resr[i].updated_at;
                    delete resr[i].created_at;
                    if (resr[i].payment_type == "0") {
                        delete resr[i].account_number
                        delete resr[i].routing_number
                        delete resr[i].account_type
                    } else {
                        delete resr[i].customer_id
                        delete resr[i].cvv
                        delete resr[i].mm
                        delete resr[i].number
                        delete resr[i].number
                        delete resr[i].yy
                        delete resr[i].zip

                    }
                    // delete resr[i].payment_type
                    // delete resr[i].account_type
                    delete resr[i]._id
                }
                res.send({
                    "success": true,
                    "message": "success",
                    "data": resr[0]
                });
                return false;
            } else {
                res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": []
                });
                return false;
            }
        }
    });

}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}