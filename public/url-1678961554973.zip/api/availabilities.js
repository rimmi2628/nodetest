var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
// var cors = require('cors')


// const bcrypt = require('bcrypt')
var app = express() ;
// app.use(cors());
// app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 


 
var ObjectId = mongo.Types.ObjectId;
// var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);

var mongodbutil = require( './mongodbutil' );



 exports.availabilities = async function(req, res) {
//   - month
// - year
// - gym_id
    const {month,year,gym_id} = req.body;
    console.log(req.body)
    if (!month || !gym_id || !year)  {
          res.send({"success":"0","message":"Please enter all fields","data":{}});
          return false;
    }
   // MongoClient.connect(url, function(err, db) {
        let dbo =  await mongodbutil.Get();
        //var dbo = db.db("gymtraining");

// TBL_GYM_AVAILABILITY for which  (repeat = 1 && gym_id = <gym_id> ) OR (repeat = 0 && month = <month> && year = <year> && gym_id =<gym_id> )

//,start_time: { "$ne": '2020-04-30' }
        dbo.collection("TBL_GYM_AVAILABILITY").find( { $or: [ { repeat:1,gym_id:ObjectId(gym_id) }, {"month":parseInt(month),"year":parseInt(year),"gym_id":ObjectId(gym_id)} ]}).toArray(function(err, result) {
        // dbo.collection("TBL_GYM_AVAILABILITY").find({"month":parseInt(month),"year":parseInt(year),"gym_id":ObjectId(gym_id)}).toArray(function(err, result) {
            if (err){
                res.send({"success":false,"message":"something went wrong","data":[]});
                //return false;
            }
            else{

              console.log(result);
              var datearray =[];
              for(var i= 0;i<result.length;i++){
                // console.log(result[i]['start_time'],result[i]['end_time'])
                // if(result[i]['start_time'] != result[i]['end_time']){
                  //console.log(result[i]['start_time'],result[i]['end_time'])
                 datearray.push(getWeeke(result[i],month,year));
                //}
              }
                 var datearray = datearray.join();
                 res.send({"success":true,"message":"success","data":{"available":datearray} });
               }
            // dbo.close();
          });
          
    //})




  function getWeeke(result,month,year) {
     // console.log(result);
     var tuesdays= [];
    if(result.repeat == 1){
      // console.log("here")
      var d =  new Date(year, month - 1, 1);
      month = d.getMonth(1);
      // tuesdays= [];
      // console.log("month",month)
      // Get the first Monday in the month
      while (d.getDay() !== result.day) {
          d.setDate(d.getDate() + 1);
      }

      // Get all the other Tuesdays in the month
      while (d.getMonth() === month) {
          tuesdays.push(new Date(d.getTime()).getDate());
          d.setDate(d.getDate() + 7);
      }
      // console.log(tuesdays)
       // return tuesdays;
    }
    else{
      console.log("SDfs",result.year)
      console.log("SDfsss",result.month)
        if (result.year==year && result.month == month) {
            // days = day = 13
             var day = new Date(result.date) 
             tuesdays.push(day.getDate());
        }

    }

     return tuesdays;

  }

}



