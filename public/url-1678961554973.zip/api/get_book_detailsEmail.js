var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
const Utill = require('../helper/Constant')
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());





var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.appointments = async function(req, res) {
    const {booking_id} = req.body;
    if(!booking_id ){
      res.send({"success":false,"message":"Please enter all fields","data":{}});
      return false;
    }
    // MongoClient.connect(url, function(err, db) {
      // if (err) throw err;
      let dbo =  await mongodbutil.Get();


      dbo.collection('TBL_BOOKINS').aggregate([
        //{ $match : { user_id : ObjectId(user_id) } } ,
        { 
          $match: {
               $and: [ 
                   {_id : ObjectId(booking_id)},
                   // { schedule_time: part  } ,

                   // {"status": { $in: stat }},
                  //  {time: {$lt:ISODate("2013-12-09T00:00:00Z")}}
               ]
          }
        },
        {$sort: {schedule_time: -1}},
        { 

          $lookup:
           {
             from: 'TBL_FEEDBACK',
             localField: '_id',
             foreignField: 'booking_id',
             as: 'reviews'
           }
         },
         {
                $unwind: {
                    path: "$reviews",
                    preserveNullAndEmptyArrays: true
                }
            },
         { 

          $lookup:
           {
             from: 'TBL_BADGES',
             localField: 'reviews.badges.id',
             foreignField: '_id',
             as: 'reviews.badges'
           }
         },
         
         { 
          
          $lookup:
           {
             from: 'TBL_GYMS',
             localField: 'gym_id',
             foreignField: '_id',
             as: 'gymdetails'
           }
         },

         {
          "$project": {
            "_id": 1,
            "gymdetails.name": 1,
            "gymdetails.logo": 1,
            "gymdetails.space_owner": 1,
            "client_name": 1,
            "date": 1,
            "time": 1,
            "gym_id":1,
            "schedule_time":1,
            "reviews.comment":1,
            "reviews._id":1,
            "reviews.rating":1,
            "reviews.badges":1,
            "status":1

          }
        }
      ]).toArray(function(err, resr) {
        if (err){
          res.send({"success":false,"message":"something went wrong","data":{}});
          return false;
        }
        else{
          if(resr){
            var data = JSON.stringify(resr);
            // console.log(data)
  
            // console.log(resr[0]);
            gymdeta=[];
            for(var i = 0;i<resr.length;i++){
              // if(type == 1){
                if(resr[i]['status'] == undefined){
                  resr[i]['status'] = 0;
                }
                  if(resr[i]['gymdetails'].length){

                       gymdeta.push({"_id":resr[i]["_id"],"review":resr[i]['reviews'],"status":resr[i]['status'],"gym_id":resr[i]["gym_id"],"name":resr[i]['gymdetails'][0].name
                      
                      ,"schedule_time":String(resr[i].schedule_time),"client_name":resr[i].client_name,
                      "logo":Utill.IMAGE_BASE_URL+resr[i]['gymdetails'][0].logo,
                      "space_owner":resr[i]['gymdetails'][0].space_owner ,"time":{
                      "from":resr[i]["time"],
                      "date":resr[i]["date"]
                      
        
                        }
                      })
                   }
                // }
                
                
                // else{
                //   if(resr[i]['status'] == undefined){
                //     resr[i]['status'] = 0;
                //   }
                //   if(resr[i]['gymdetails'].length){
                //     gymdeta.push({"_id":resr[i]["_id"],"gym_id":resr[i]["gym_id"],"status":resr[i]['status'],"name":resr[i]['gymdetails'][0].name
                //       ,"schedule_time":String(resr[i].schedule_time),"client_name":resr[i].client_name,
                //       "logo":"https://hourful.io/"+resr[i]['gymdetails'][0].logo ,
                //       "space_owner":resr[i]['gymdetails'][0].space_owner,"time":{
                //       "from":resr[i]["time"],
                //       "date":resr[i]["date"]
                      
        
                //         }
                //       })
                //   }
                  
                // }
                
                
            }
           
  
          res.send({"success":true,"message":"success","data":gymdeta});
          return false;
          //   return false;
          }
          else{
            res.send({"success":false,"message":"something went wrong","data":{}});
            return false;
          }
        }
        
      });
    // })
  }
  function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }
  
  function makeid(length) {
     var result           = '';
     var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
     var charactersLength = characters.length;
     for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
     }
     return result;
  }