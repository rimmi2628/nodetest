

  var express = require('express');  
  var path = require("path");   
  var bodyParser = require('body-parser');  
  var mongo = require("mongoose");  
  // const multer = require('multer');
  // const upload = multer({dest: __dirname + '/uploads/images'});
  var cors = require('cors')
  
  
  const bcrypt = require('bcrypt')
  var app = express() ;
  app.use(cors());
  app.options('*', cors());
  var fs = require("fs");
  // for parsing application/json
  app.use(bodyParser.json()); 
  var fileupload = require("express-fileupload");
  app.use(fileupload());
  
 
  var ObjectId = mongo.Types.ObjectId;
  var Schema = mongo.Schema ;  
     //const {email, first_name, last_name, password, social_id, image,type } = req.body;
  

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});



  
   app.use(bodyParser.json());
   app.use(bodyParser.urlencoded());
   
   mongo.set('useFindAndModify', false);
  var mongodbutil = require( './mongodbutil' );
   exports.addIntrests = async function(req, res) {   
    //   console.log(req.body.id); 
    const {email,type} = req.body;
    let errors = [];
    if(!email || !type){
        res.send({"success":false,"message":"Please enter all fields","data":{}});
        return false;
    }
                // MongoClient.connect(url, function(err, db) {
                let dbo =  await mongodbutil.Get();
                dbo.collection('TBL_INTEREST_SHOWN').insertOne( {emai:email,type:type,created_at:getCurrentTime()} );
                // dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } );

                 var mailOptions = {
                    from: 'jotpal.enact@gmail.com',
                    to: email
                    subject: 'HourfulApp',
                    //text: `Hi `+user.first_name+`, thank you for registering with us.
                            //Please click this link below to verify your mail <br> `+verifyEmailId
                    // html: '<h1>Hi '+doc.first_name+', </h1><p>Please click this link below to verify your mail </p><a href="http://13.56.225.168:8088/api/emailConfirm?id='+verifyEmailId+'">Click</a><br>Thanks'        
                    html:'<!doctype html><html lang="en"><head><meta charset="utf-8"><link rel="stylesheet" href="fonts/stylesheet.css"><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous"><title>Verify</title><style>body{font-family:"SF Pro Display"}.verify-main-top{max-width:1140px;margin:auto;width:70%}.verify{background:#fff3ee;height:100%;padding:60px 0}.verify-logo{text-align:center;margin-bottom:30px}.verify-logo img{width:17%}.verify-main{background:#fff;padding:50px;border-radius:30px;font-weight:600}.verify-main h2{font-size:35px;margin-bottom:50px}.verify-main h3,h4,h5,h6{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;line-height:40px}.verify-main p{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;margin-top:70px;line-height:50px}.verify-btn{text-align:center}a.verify-btn{font-size:20px;color:#fff !important;background:#ff885b;font-weight:400;border-radius:50px;padding:18px 55px;display:inline-block;text-decoration:none}.verify-bottom{text-align:center}.verify-bottom ul{display:inline-block;margin:40px 0}.verify-bottom li{display:inline-block;margin:0 15px}.verify-bottom p{font-size:22px;color:#232323;font-weight:400;padding:0 60px}.bottom-text p{font-size:22px;color:#232323;font-weight:400;margin:50px 0 0}.bottom-text h5{background:none;padding:0;color:#0066cb!important;margin:5px 0 0}.verify-main h6{margin-top:30px}@media only screen and (max-width: 1599px){.verify-main-top{width:65%}.verify-main h2{margin-top:0}.verify-bottom li img{width:60px}.verify-bottom li{margin:0 10px}}@media only screen and (max-width: 1366px){.verify-main h2{font-size:30px;font-weight:500;margin-bottom:35px}.verify-main h3,h4,h5,h6{font-size:19px;line-height:22px}a.verify-btn{padding:15px 50px}.verify{background:#fff3ee;height:100%;padding:40px 0}.verify-main p{font-size:19px;color:#353535;font-weight:400;margin-bottom:0;margin-top:48px;line-height:22px}.verify-main{padding:35px}.verify-bottom li img{width:55px}.bottom-text p{font-size:19px;color:#232323;font-weight:400;margin:26px 0 0}</style></head><body> <main class="verify"><div class="verify-main-top"><div class="container"><div class="verify-logo"> <a href=""><img src="images/verify-logo.png" alt="logo"></a></div><div class="verify-main"><h3>Hi '+email+',</h3><h5>Thanks for showing your interest in Hourful. We are super excited.</h5><div class="bottom-text"><p>We will keep you posted on Hourful updates.</p></div><h6>Don’t forget to add hello@hourful.io to your Contact/Address book or Safe Senders list to ensure you receive our emails.</h6><p>Ben Carson,<br> Hourful Care Team</p><div class="verify-btn"></div></div><div class="verify-bottom"><ul><li><a href=""><img src="images/bottom-icon1.png" alt="icon"></a></li><li><a href=""><img src="images/bottom-icon2.png" alt="icon"></a></li><li><a href=""><img src="images/bottom-icon3.png" alt="icon"></a></li></ul></div></div></div> </main></body></html>'
                    //html:'<b>Hey there! </b><br> <a href="http://13.56.225.168:8088/api/emailConfirm?id='+verifyEmailId+'">is</a  >This is our first message sent with Nodemailer'
                  };
                  transporter.sendMail(mailOptions, function(error, info){
                    if (error) {  
                      res.send({"success":true,"message":"Mail Not sent","data":{}});
                    } else {
                      res.send({"success":true,"message":"Success"});
                      return false;
                    }
                  });



                
            // })
          
}
  
  
  
      // MongoClient.connect(url, function(err, db) {
      //     if (err) throw err;
      //       var dbo = db.db("gymtraining");
      //       dbo.collection("TBL_SPACE_OWNER").find({"email":email}).toArray(function(err, result) {
      //         if (err){
      //             res.send({"success":false,"message":"something went wrong","data":[]});
      //             return false;
      //         }
      //         else{
      //             // console.log(result)
      //             if(result.length > 0){
      //                 bcrypt.compare(password, result[0].password, function(err, resaa) {
      //                     if(err){
      //                        //console.log(err)
      //                         res.send({"success":false,"message":"Email or password is wrong","data":[]});
      //                         return false;
      //                     }
      //                     else{
      //                         if(resaa){
      //                             delete result[0].password
      //                             res.send({"success":true,"message":"success","data":result[0]});
      //                             return false;
      //                         }
      //                         else{
      //                             res.send({"success":false,"message":"Email or password is wrong","data":[]});
      //                             return false;
      //                         }
      //                     }
      //                 })
      //             }
      //             else{
      //                 res.send({"success":false,"message":"Email does not exists","data":[]});
      //                 return false;
      //             }
              
      //         } 
              
      //         });
      //         // dbo.close();
      //   })
  
  
       function getCurrentTime() {
          var d = new Date();
          var n = d.toUTCString();
          var date = new Date(n);
          var seconds = date.getTime() / 1000; //1440516958
          return seconds;
        }
        
        function makeid(length) {
           var result           = '';
           var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
           var charactersLength = characters.length;
           for ( var i = 0; i < length; i++ ) {
              result += characters.charAt(Math.floor(Math.random() * charactersLength));
           }
           return result;
        }