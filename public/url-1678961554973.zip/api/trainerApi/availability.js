var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);

var mongodbutil = require('./mongodbutil');


exports.availability = async function (req, res) {
    const { availability, trainer_id } = req.body;
    var error = false
    console.log("-------set avail ---------->")
    console.log(req.body)
    console.log("<-------set avail ----------")
    if (!availability || !trainer_id) {
        res.send({ "success": false, "message": "Please enter all fields", "data": {} });
        return false;
    }
    // console.log(req.body)

    // console.log((req.body.availability))
    // return

    var availabilitys = JSON.parse(req.body.availability);

    if (availabilitys.length > 1) {
        for (var j = 0; j < availabilitys.length; j++) {
            console.log('OUT HERE')
            // console.log(availabilitys[j+1])
            // continue
            if (availabilitys[j + 1] != undefined && (((availabilitys[j].to_utc >= availabilitys[j + 1].from_utc && availabilitys[j].to_utc <= availabilitys[j + 1].to_utc) || (availabilitys[j].from_utc >= availabilitys[j + 1].from_utc && availabilitys[j].from_utc <= availabilitys[j + 1].to_utc)) || ((availabilitys[j + 1].to_utc >= availabilitys[j].from_utc && availabilitys[j + 1].to_utc <= availabilitys[j].to_utc) || (availabilitys[j + 1].from_utc >= availabilitys[j].from_utc && availabilitys[j + 1].from_utc <= availabilitys[j].to_utc)))) {
                console.log('HERE')
                error = true
                res.send({ "success": false, "message": "Availabilities overlap with each other. Please cross check and submit again.", "data": [] });
                break;
            }
            // if (availabilitys[j+1] != undefined && ((availabilitys[j].to_utc >= availabilitys[j+1].from_utc  && availabilitys[j].to_utc <= availabilitys[j+1].to_utc   ) || (availabilitys[j].from_utc >= availabilitys[j+1].from_utc   && availabilitys[j].from_utc <= availabilitys[j+1].to_utc ))) {
            //     console.log('HERE')
            // }
        }
    }
    if (error) {
        return
    }
    // return false

    let dbo = await mongodbutil.Get();
    for (var i = 0; i < availabilitys.length; i++) {

        availabilitys[i].trainer_id = ObjectId(trainer_id)
        availabilitys[i].created_at = getCurrentTime()
        availabilitys[i].updated_at = getCurrentTime()
        if (i == availabilitys.length - 1) {
            allData(availabilitys)
        }

    }
    async function allData(data) {
        let promise = Promise.resolve();
        const posts = data;
        posts.forEach(post => {
            var fSlotsS = []
            var minuteSlots = []
            var utcSlots = []
            var dd = []
            // $gte: ISODate("2010-04-29T00:00:00.000Z"),
            // $lt: ISODate("2010-05-01T00:00:00.000Z")
            promise = promise.then(() => {
                var dataIn = post
                console.log('dataIn.from', dataIn.from)
                console.log('dataIn.to', dataIn.to)
                dbo.collection("TBL_TRAINER_AVAILABILITY").find({ 'trainer_id': ObjectId(req.body.trainer_id), 'day': dataIn.day, 'month': dataIn.month, 'year': dataIn.year })
                    .toArray(function (err, result2) {
                        if (err) {
                            res.send({ "success": false, "message": "something went wrong", "data": [] });
                            //return false;
                        }
                        else {
                            console.log('result2*********', result2)
                            if (result2 && result2.length > 0) {

                                var loop_data = result2
                                for (var k = 0; k < loop_data.length; k++) {
                                    console.log(dataIn.to_utc + ' >= ' + loop_data[k].from_utc + ' && ' + dataIn.to_utc + ' <=  ' + loop_data[k].to_utc)
                                    console.log(dataIn.to_utc >= loop_data[k].from_utc && dataIn.to_utc <= loop_data[k].to_utc)
                                    console.log(dataIn.from_utc + ' >= ' + loop_data[k].from_utc + ' && ' + dataIn.from_utc + ' <= ' + loop_data[k].to_utc)
                                    console.log(dataIn.from_utc >= loop_data[k].from_utc && dataIn.from_utc <= loop_data[k].to_utc)


                                    // var startTime = loop_data[k].from;
                                    // var endTime = loop_data[k].to;
                                    // var checkTime = dataIn.from;

                                    // var checkTime2 = dataIn.to;

                                    // var startDateTime = toDate(dataIn.day+'.'+dataIn.month+'.'+dataIn.year+' '+loop_data[k].from);
                                    // var endDateTime = toDate(dataIn.day+'.'+dataIn.month+'.'+dataIn.year+' '+loop_data[k].to);

                                    // var checkDateTime = toDate(dataIn.day+'.'+dataIn.month+'.'+dataIn.year+' '+dataIn.from);

                                    // var checkDateTime2 = toDate(dataIn.day+'.'+dataIn.month+'.'+dataIn.year+' '+dataIn.to);
                                    // console.log('hh')
                                    // console.log(checkDateTime2)
                                    // console.log(startDateTime)
                                    // console.log(endDateTime)

                                    // console.log(isBetween(checkDateTime,startDateTime,endDateTime));

                                    // console.log(isBetween(checkDateTime2,startDateTime,endDateTime));


                                    if ((dataIn.to_utc >= loop_data[k].from_utc && dataIn.to_utc <= loop_data[k].to_utc) || (dataIn.from_utc >= loop_data[k].from_utc && dataIn.from_utc <= loop_data[k].to_utc)) {
                                        console.log('FOUND')
                                        error = true
                                        // console.log(loop_data[k].to_utc ,dataIn.to_utc)
                                        // console.log(loop_data[k].from_utc , dataIn.from_utc)
                                        res.send({ "success": false, "message": "Availabilities overlap with each other. Please cross check and submit again.", "data": [] });
                                        break;
                                    }

                                }
                                // res.send({"success":false,"message":"Your availably is overriding with one of previous availability for this day","data":[]});

                            }
                            if (error) {
                                return false
                            }
                            // else{
                            dbo.collection("TBL_TRAINER_AVAILABILITY").insertOne(dataIn, function (err, resr) {
                                if (err) {
                                    throw err;
                                }
                                else {
                                    console.log(resr.insertedId + " after insert id");
                                    if (resr) {
                                        var set_t = parseInt(dataIn['length'])
                                        var break_bw_sessions = "";
                                        //console.log("break between session "+ break_bw_sessions);

                                        if (typeof dataIn['break_bw_sessions'] == "undefined" || dataIn['break_bw_sessions'] == null) {

                                            break_bw_sessions = 15;
                                        } else {

                                            break_bw_sessions = parseInt(dataIn['break_bw_sessions']);
                                        }
                                        // console.log(set_t)
                                        // console.log(dataIn.from)
                                        // console.log(dataIn.to)

                                        var done = false
                                        // for (var d = parseInt(dataIn.from); d < parseInt(dataIn.to); d = d+set_t) {

                                        // console.log(date_test);return;
                                        // var curD = addMinutes_test(date_test,set_t)
                                        var prev = ''
                                        for (var d = dataIn.from; d < dataIn.to; d = (addMinutes(d, set_t, break_bw_sessions))) {


                                            var split = d.split(":");
                                            var hr = split[0];

                                            prev = hr
                                            var next = addMinutes(d, set_t, 0)

                                            var split2 = next.split(":");

                                            var hr2 = split2[0]

                                            if (parseInt(hr2) == 0 && parseInt(hr) == 23) {
                                                console.log('I AM IN')
                                                break
                                            }

                                            // if (done) {
                                            //     console.log('BREAKING')
                                            //     break;
                                            // }
                                            // if (d > '23:45') {
                                            //     done = true;
                                            // }
                                            if (addMinutes(d, set_t, 0) > dataIn.to) {
                                                console.log('Break', d)
                                                var done = true
                                                break;
                                            }
                                            fSlotsS.push(d.toString())
                                            let slotsInMinute = getMinuteSlots(d.toString())
                                            minuteSlots.push(slotsInMinute)

                                            // console.log(d.toString())
                                        }
                                        let to = 1665376200, from = 1665394200, length = 30

                                        for (var i = parseInt(dataIn.from_utc); i <= parseInt(dataIn.to_utc); i = i + 60 * set_t) {
                                            utcSlots.push(i) 
                                        }
                                        console.log('slots', fSlotsS)
                                        console.log('slots min', minuteSlots)
                                        //console.log('slots utc', utcSlots)
                                        // console.log('Body',req.body)
                                        // return
                                        for (var l = 0; l < fSlotsS.length; l++) {
                                            dd.push({ trainer_availability_id: ObjectId(resr.insertedId), day: dataIn.day,time_utc:utcSlots[l], time: fSlotsS[l],price: '0', time_minute: minuteSlots[l], slots: '1', availableSlots: '1', instantBooking: '0', from_utc: dataIn.from_utc, to_utc: dataIn.to_utc, date_utc: parseInt(dataIn.date_utc), month: dataIn.month, year: dataIn.year, from: dataIn.from, to: dataIn.to, date: '', length: parseInt(dataIn['length']), date: '', 'trainer_id': ObjectId(trainer_id) })
                                        }
                                        //   for (var l = 0; l < utcSlots.length; l++) {
                                        //     dd.push({ trainer_availability_id: ObjectId(resr.insertedId), day: dataIn.day,time_utc:utcSlots[l],price: '0', slots: '1', availableSlots: '1', instantBooking: '0', from_utc: dataIn.from_utc, to_utc: dataIn.to_utc, date_utc: parseInt(dataIn.date_utc), month: dataIn.month, year: dataIn.year, from: dataIn.from, to: dataIn.to, date: '', length: parseInt(dataIn['length']), date: '', 'trainer_id': ObjectId(trainer_id) })
                                        // }
                                        if (!fSlotsS || fSlotsS.length == 0) {
                                            dd.push({ trainer_availability_id: ObjectId(resr.insertedId), day: dataIn.day, time: dataIn.from, price: '0', time_minute: getMinuteSlots(dataIn.from), slots: '1', availableSlots: '1', instantBooking: '0', from_utc: dataIn.from_utc, to_utc: dataIn.to_utc, date_utc: parseInt(dataIn.date_utc), month: dataIn.month, year: dataIn.year, from: dataIn.from, to: dataIn.to, date: '', length: parseInt(dataIn['length']), date: '', 'trainer_id': ObjectId(trainer_id) })
                                        }
                                        dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
                                            if (err) {
                                                throw err;
                                            }
                                        });
                                    }

                                }
                            });
                            // }

                        }
                    });

            });
        });

        promise.then(() => {
            setTimeout(function () {
                if (!res.headersSent) {
                    res.send({
                        "success": true,
                        "message": 'Success',
                        "data": []
                    });
                }
            }, 1000);

        })
        return false


    }
    // res.send({"success":true,"message":"Success."});

}
function getMinuteSlots(hrs) {
    let h = hrs.split(":")
    // console.log(h[0])
    let min = parseInt(h[0]) * 60 + parseInt(h[1])
    console.log(min)
    return min

}

exports.availability_update = async function (req, res) {
    const { availability, trainer_id, availability_id } = req.body;
    if (!availability || !trainer_id || !availability_id) {
        res.send({ "success": false, "message": "Please enter all fields", "data": {} });
        return false;
    }
    console.log(req.body)
    let dbo = await mongodbutil.Get();
    // dbo.collection("TBL_TRAINER_AVAILABILITY").deleteOne( { _id : ObjectId(req.body.availability_id) } );
    dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").deleteMany({ trainer_availability_id: ObjectId(req.body.availability_id) });

    var availabilitys = JSON.parse(req.body.availability);

    for (var i = 0; i < availabilitys.length; i++) {

        availabilitys[i].trainer_id = ObjectId(trainer_id)
        availabilitys[i].created_at = getCurrentTime()
        availabilitys[i].updated_at = getCurrentTime()
        if (i == availabilitys.length - 1) {
            allData(availabilitys)
        }

    }
    async function allData(data) {
        let promise = Promise.resolve();
        const posts = data;
        posts.forEach(post => {
            var fSlotsS = []
            var minuteSlots = []
            var dd = []
            var utcSlots = []
            promise = promise.then(() => {
                var dataIn = post
                dbo.collection("TBL_TRAINER_AVAILABILITY").updateOne({ _id: ObjectId(req.body.availability_id) }, { $set: dataIn }, function (err, resr) {
                    if (err) {
                        throw err;
                    }
                    else {
                        if (resr) {
                            var set_t = parseInt(dataIn['length'])
                            var done = false
                            var prev = ''
                            var break_bw_sessions = "";
                            //console.log("break between session "+ break_bw_sessions);

                            if (typeof dataIn['break_bw_sessions'] == "undefined" || dataIn['break_bw_sessions'] == null) {

                                break_bw_sessions = 15;
                            } else {

                                break_bw_sessions = parseInt(dataIn['break_bw_sessions']);
                            }
                            // for (var d = parseInt(dataIn.from); d < parseInt(dataIn.to); d = parseInt(d)+set_t) {
                            for (var d = dataIn.from; d < dataIn.to; d = addMinutes(d, set_t, break_bw_sessions)) {

                                // if (done) {
                                //     break;
                                // }
                                var split = d.split(":");
                                var hr = split[0];

                                prev = hr
                                var next = addMinutes(d, set_t, 0)

                                var split2 = next.split(":");

                                var hr2 = split2[0]

                                if (parseInt(hr2) == 0 && parseInt(hr) == 23) {
                                    console.log('I AM IN')
                                    break
                                }
                                if (addMinutes(d, set_t, 0) > dataIn.to) {
                                    console.log('Break')
                                    // var done = true
                                    break
                                }
                                fSlotsS.push(d.toString())
                                let slotsInMinute = getMinuteSlots(d.toString())
                                minuteSlots.push(slotsInMinute)
                            }
                            for (var i = parseInt(dataIn.from_utc); i <= parseInt(dataIn.to_utc); i = i + 60 * set_t) {
                                utcSlots.push(i) 
                            }

                            for (var l = 0; l < fSlotsS.length; l++) {
                                dd.push({ trainer_availability_id: ObjectId(req.body.availability_id), day: dataIn.day,time_utc:utcSlots[l], time: fSlotsS[l], time_minute: minuteSlots[l], price: '0', slots: '1', availableSlots: '1', instantBooking: '0', from_utc: dataIn.from_utc, to_utc: dataIn.to_utc, date_utc: parseInt(dataIn.date_utc), month: dataIn.month, year: dataIn.year, from: dataIn.from, to: dataIn.to, date: '', length: parseInt(dataIn['length']), date: '', 'trainer_id': ObjectId(trainer_id) })
                            }
                            if (!fSlotsS || fSlotsS.length == 0) {
                                dd.push({ trainer_availability_id: ObjectId(resr.insertedId), day: dataIn.day, time: dataIn.from, time_minute: getMinuteSlots(dataIn.from), price: '0', slots: '1', availableSlots: '1', instantBooking: '0', from_utc: dataIn.from_utc, to_utc: dataIn.to_utc, date_utc: parseInt(dataIn.date_utc), month: dataIn.month, year: dataIn.year, from: dataIn.from, to: dataIn.to, date: '', length: parseInt(dataIn['length']), date: '', 'trainer_id': ObjectId(trainer_id) })
                            }
                            dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
                                if (err) {
                                    throw err;
                                }
                            });
                        }

                    }
                });
            });
        });

        promise.then(() => {
            setTimeout(function () {
                dbo.collection("TBL_TRAINER_AVAILABILITY").find({ _id: ObjectId(req.body.availability_id) }).toArray(function (err, result) {
                    if (err) {
                        res.send({ "success": false, "message": "something went wrong", "data": [] });
                        //return false;
                    }
                    else {
                        res.send({ "success": true, "message": "success", "data": result });
                    }
                });
            }, 300);

        })
        return false


    }
    // res.send({"success":true,"message":"Success."});

}

exports.availability_delete = async function (req, res) {
    const { availability_id, trainer_id } = req.body;
    if (!availability_id || !trainer_id) {
        res.send({ "success": false, "message": "Please enter all fields", "data": {} });
        return false;
    }
    console.log(req.body)


    let dbo = await mongodbutil.Get();
    dbo.collection("TBL_TRAINER_AVAILABILITY").deleteOne({ _id: ObjectId(req.body.availability_id) });
    dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").deleteMany({ trainer_availability_id: ObjectId(req.body.availability_id) });

    res.send({ "success": true, "message": "Success Deleted." });

}

exports.availabilities = async function (req, res) {

    const { month, year, trainer_id } = req.body;
    console.log(req.body)
    if (!month || !trainer_id || !year) {
        res.send({ "success": false, "message": "Please enter all fields", "data": {} });
        return false;
    }
    let dbo = await mongodbutil.Get();
    if (!req.body.day) {

        dbo.collection("TBL_TRAINER_AVAILABILITY").find({ $or: [{ "month": month, "year": year, "trainer_id": ObjectId(trainer_id) }] }).toArray(function (err, result) {
            // dbo.collection("TBL_GYM_AVAILABILITY").find({"month":parseInt(month),"year":parseInt(year),"trainer_id":ObjectId(trainer_id)}).toArray(function(err, result) {
            if (err) {
                res.send({ "success": false, "message": "something went wrong", "data": [] });
                //return false;
            }
            else {
                res.send({ "success": true, "message": "success", "data": result });
            }
        });
    }
    else {
        dbo.collection("TBL_TRAINER_AVAILABILITY").find({ $or: [{ "month": month, "year": year, "day": req.body.day, "trainer_id": ObjectId(trainer_id) }] }).toArray(function (err, result) {
            if (err) {
                res.send({ "success": false, "message": "something went wrong", "data": [] });
                //return false;
            }
            else {
                res.send({ "success": true, "message": "success", "data": result });
            }
        });
    }


}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}
function addMinutes(time, minsToAdd, break_btw_session) {
    function D(J) { return (J < 10 ? '0' : '') + J; };
    var piece = time.split(':');
    var mins = piece[0] * 60 + +piece[1] + +minsToAdd + +break_btw_session;

    return D(mins % (24 * 60) / 60 | 0) + ':' + D(mins % 60);
}

function addMinutes_test(date, minutes) {
    return new Date(date.getTime() + minutes * 60000);
}

// function isBetween(n, a, b) {
//    return (n - a) * (n - b) <= 0
// }
function isBetween(checkDateTime, startDateTime, endDateTime) {

    return (checkDateTime >= startDateTime && checkDateTime <= endDateTime);

}

function toDate(str) {
    var [dd, MM, yyyy, hh, mm] = str.split(/[. :]/g);
    return new Date(`${MM}/${dd}/${yyyy} ${hh}:${mm}`);
}