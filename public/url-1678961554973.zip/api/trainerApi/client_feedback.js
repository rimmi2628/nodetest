var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
const { ObjectId } = require('mongodb');

exports.client_feedback = async function (req, res) {
    let dbo = await mongodbutil.Get();
    const { session_id, client_id, trainer_id, ratings, comments } = req.body
    console.log(req.body)
    if (!session_id || !client_id || !trainer_id || !ratings) {
        res.send({ "success": false, "message": "Please enter all fields", "data": {} });
        return false;
    }
    let insertData = {
        session_id: ObjectId(session_id),
        client_id: ObjectId(client_id),
        trainer_id: ObjectId(trainer_id),
        ratings: parseInt(ratings),
        comments: comments ? comments : ''

    }
    dbo.collection("TBL_TRAINER_CLIENT_RATINGS").insertOne(insertData, function (err, resr) {
        if (err) {

            return res.send({ "success": false, "message": "Something Went Wrong", error: err.message });

        }
        else {
            return res.send({ "success": true, "message": "Your Rating Submitted Sucessfully" });


        }
    })

}

