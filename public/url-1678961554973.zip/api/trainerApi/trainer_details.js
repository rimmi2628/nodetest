var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());





var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.trainer_details = async function (req, res) {
  const { trainer_id, user_id, date } = req.body;
  if (!trainer_id || !user_id || !date) {
    res.send({ "success": false, "message": "Please enter all fields", "data": {} });
    return false;
  }
  // MongoClient.connect(url, function(err, db) {
  let dbo = await mongodbutil.Get();
  // var dbo = db.db("gymtraining");
  // var query = { _id: user_id };
  // dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
  dbo.collection('TBL_TRAINERS').aggregate([
    { $match: { _id: ObjectId(trainer_id) } },
    // {
    //   $lookup : 
    //   {
    //     from : 'TBL_EQUIPMENTS', 
    //     localField: 'equipments_id', 
    //     foreignField: '_id', 
    //     as : 'equipments_ids'
    //   }
    //   },
    {
      $lookup:
      {
        from: 'TBL_TRAINER_PREF_GYMS',
        localField: '_id',
        foreignField: 'trainer_id',
        as: 'gyms'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_TRAININGS',
        localField: 'training_ids.id',
        foreignField: '_id',
        as: 'training_ids'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_TRAINER_DETAILS',
        localField: '_id',
        foreignField: 'user_id',
        as: 'userdetails'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_TRAINERS_IMAGES',
        localField: 'images_ids.id',
        foreignField: '_id',
        as: 'images_ids'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_SERVICES',
        localField: 'services.id',
        foreignField: '_id',
        as: 'services'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_FAVORITES',
        localField: '_id',
        foreignField: 'trainer_id',
        as: 'favorites'
      }
    },
    {

      "$addFields": {
        "favorites": {
          "$arrayElemAt": [
            {
              "$filter": {
                "input": "$favorites",
                "as": "comp",
                "cond": {
                  $and: [
                    { "$eq": ["$$comp.client_id", ObjectId(user_id)] },
                    { "$eq": ["$$comp.favorite", "1"] }

                  ]
                }
              }
            }, 0
          ]
        }
      }


    },

    {
      "$project": {
        "_id": 1,
        "trainer_main_id": 1,
        "name": 1,
        // "logo": 1,
        // "timezone": 1,
        "price": 1,
        "avg_rating": 1,
        "ratings": 1,
        "images_ids": 1,
        "favorites": 1,
        "latitude": 1,
        "longitude": 1,
        "location": 1,
        "image": 1,
        // "space_owner":1,
        "dist": 1,
        "gyms": 1,
        "formatted_address": 1,
        "bio": 1,
        "training_ids": 1,
        "services": 1,
        "userdetails": 1,
        // "storefront":1,
        // "reception":1,
        // "gym_interior":1,

      }
    },
  ]).toArray(function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      if (resr) {

        var data = JSON.parse(JSON.stringify(resr));
        console.log("-------------->")
        console.log(data)
        console.log("<----------")
       //  return res.json(data)
        var avg_rati = data[0].avg_rating
        if (data[0].userdetails[0]) {
          data[0].image = data[0].userdetails[0].image
        }
        delete data[0].userdetails
        if (isNaN(avg_rati)) {
          data[0].avg_rating = '0'
          data[0].ratings = '0'
        }
        data[0]._id = data[0].trainer_main_id;
        if (data[0].favorites != undefined) {
          data[0].favorite = true;
        }
        else {
          data[0].favorite = false;
        }

        delete data[0].favorites;

        dbo.collection("TBL_TRAINER_AVAILABILITY").find({ "date": date, "trainer_id": ObjectId(trainer_id) }).toArray(function (err, result) {
          if (err) {
            res.send({ "success": false, "message": "something went wrong", "data": [] });
            return false;
          }
          else {
            //  console.log(result)
            if (result.length > 0) {
              dbo.collection("TBL_AVAILABILITY_SLOTS").find({ "trainer_availability_id": ObjectId(result[0]['_id']) }).toArray(function (err, ress) {
                if (err) {
                  res.send({ "success": false, "message": "something went wrong", "data": [] });
                  return false;
                }
                else {
                  // console.log("ress",ress)
                  delete data[0].equipments_id;
                  var gymdetails = data[0];
                  res.send({ "success": true, "message": "success", "data": gymdetails });
                  return false;
                }

              });
              // console.log("adsd");
            } else {
              var day = new Date(date);
              day = day.getDay();
              // console.log(day)
              dbo.collection('TBL_TRAINER_AVAILABILITY').aggregate([
                { $match: { day: String(day), repeat: "1", trainer_id: ObjectId(trainer_id) } },
                { $sort: { date: -1 } },
                { $limit: 1 },
                {
                  $lookup:
                  {
                    from: 'TBL_AVAILABILITY_SLOTS',
                    localField: '_id',
                    foreignField: 'trainer_availability_id',
                    as: 'trainer'
                  }
                },


              ]).toArray(function (err, resr) {
                if (err) {
                  throw err;
                }
                else {
                  if (resr) {
                    // console.log("asd",resr.length)
                    if (resr.length > 0) {


                      /* var gymdetails=
                        {
                          "_id":data[0]._id, 
                          "name":data[0].name,
                          "logo":data[0].link,
                          "price":data[0].price,
                          "avg_rating":data[0].avg_rating,
                          "num_of_ratings":data[0].ratings,
                          "images":data[0].images_ids,
                          "address":data[0].formatted_address,
                          
                          "description":data[0].bio,
                          "equipments":data[0].equipments_ids,
                          "availability":resr[0]['gym'],
                          "favorite":data[0].favorite,
                           "time_zone":"US/Eastern",
      } */
                      delete data[0].equipments_id;
                      var gymdetails = data[0];
                      gymdetails['time_zone'] = gymdetails['timezone'];
                      if (!gymdetails['latitude']) {
                        gymdetails['latitude'] = ''
                      }
                      else {
                        gymdetails['latitude'] = gymdetails['latitude'].toString()
                      }
                      if (!gymdetails['longitude']) {
                        gymdetails['longitude'] = ''
                      }
                      else {
                        gymdetails['longitude'] = gymdetails['longitude'].toString()
                      }

                      res.send({ "success": true, "message": "success", "data": gymdetails });
                      return false;
                    }
                    else {
                      /* var gymdetails=
                        {
                        "_id":data[0]._id, 
                        "name":data[0].name,
                        "logo":data[0].link,
                        "price":data[0].price,
                        "avg_rating":data[0].avg_rating,
                        "num_of_ratings":data[0].ratings,
                        "images":data[0].images_ids,
                        "address":data[0].formatted_address,
                      	
                        "description":data[0].bio,
                        "equipments":data[0].equipments_ids,
                        "availability":[],
                        "favorite":data[0].favorite,
                          "time_zone":"US/Eastern",
                      } */
                      delete data[0].equipments_id;
                      var gymdetails = data[0];
                      gymdetails['time_zone'] = gymdetails['timezone'];
                      // gymdetails['latitude'] = gymdetails['latitude'].toString()
                      // gymdetails['longitude'] = gymdetails['longitude'].toString()
                      if (!gymdetails['latitude']) {
                        gymdetails['latitude'] = ''
                      }
                      else {
                        gymdetails['latitude'] = gymdetails['latitude'].toString()
                      }
                      if (!gymdetails['longitude']) {
                        gymdetails['longitude'] = ''
                      }
                      else {
                        gymdetails['longitude'] = gymdetails['longitude'].toString()
                      }
                      res.send({ "success": true, "message": "success", "data": gymdetails });
                      return false;
                    }

                  }
                  else {
                    //console.log(data);return;
                    /* var gymdetails=
                    {
                      "_id":data[0]._id, 
                      "name":data[0].name,
                      "logo":data[0].link,
                      "price":data[0].price,
                      "avg_rating":data[0].avg_rating,
                      "num_of_ratings":data[0].ratings,
                      "images":data[0].images_ids,
                      "address":data[0].formatted_address,
                    	
                      "description":data[0].bio,
                      "equipments":data[0].equipments_ids,
                      "availability":[],
                      "favorite":data[0].favorite,
                        "time_zone":"US/Eastern",
                    } */

                    delete data[0].equipments_id;
                    var gymdetails = data[0];
                    gymdetails['time_zone'] = gymdetails['timezone'];
                    // gymdetails['latitude'] = gymdetails['latitude'].toString()
                    //   gymdetails['longitude'] = gymdetails['longitude'].toString()
                    if (!gymdetails['latitude']) {
                      gymdetails['latitude'] = ''
                    }
                    else {
                      gymdetails['latitude'] = gymdetails['latitude'].toString()
                    }
                    if (!gymdetails['longitude']) {
                      gymdetails['longitude'] = ''
                    }
                    else {
                      gymdetails['longitude'] = gymdetails['longitude'].toString()
                    }
                    res.send({ "success": true, "message": "success", "data": gymdetails });
                    return false;
                  }
                }

              });
              //console.log(day);

            }


          }
          // dbo.close();
        });
      }
      else {
        res.send({ "success": false, "message": "something went wrong", "data": {} });
        return false;
      }
    }

  });
  // });
}

