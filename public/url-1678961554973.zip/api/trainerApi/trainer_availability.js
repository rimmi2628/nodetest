var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());




var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);

var mongodbutil = require('./mongodbutil');
const { throws } = require('assert');


exports.availability = async function (req, res) {
  const { date, trainer_id } = req.body;
  if (!date || !trainer_id) {
    res.send({ "success": "0", "message": "Please enter all fields", "data": {} });
    return false;
  }

  // day
  // month
  // year
  console.log(req.body)
  let dbo = await mongodbutil.Get();

  //remove those slots if already booked
  let timeSlots=[]
  dbo.collection("TBL_SESSIONS").find({
    'day': req.body.day,
    'month': req.body.month,
    'year': req.body.year,
    "trainer_id": ObjectId(trainer_id),
    'status':{$in:[0,1]}
  }).toArray(async function (err1, result_session) {
    if (err1) {
      throw err1
    }
    else {
     // return res.json(result_session)
      for(let i=0;i<result_session.length;i++ ){
       // console.log(result_session[i])
        timeSlots.push(result_session[i].time)

      }


  //update checks in TBL_TRAINER_AVAILABILITY_SLOTSin create_session api isBooked:1 
  dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").find(
    { 'month': req.body.month, 'year': req.body.year, "trainer_id": ObjectId(trainer_id),"time": {$nin:timeSlots}}).toArray(async function (err, result_month) {
      dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").find({
        $or: [{ day: req.body.day, trainer_id: ObjectId(trainer_id), repeat: 1 ,"time": {$nin:timeSlots}},
        { 'day': req.body.day, 'month': req.body.month, 'year': req.body.year, "trainer_id": ObjectId(trainer_id),"time": {$nin:timeSlots} }]
      }).sort({ time: 1 }).toArray(async function (err, result) {

        var avail_month = []
        //console.log(timeSlots)
       // console.log(result_month)


        for (var j = 0; j < result_month.length; j++) {
          avail_month.push(result_month[j].day)
        }
        var data = []
        //return res.json(avail_month)

        for (var i = 0; i < result.length; i++) {
          data.push({
            id: result[i]._id,
            time: result[i].time,
            length: String(result[i].length),
            time_utc:result[i].time_utc?result[i].time_utc:0
          })
        }

        if (avail_month.length > 0) {
          avail_month = unique(avail_month);
          avail_month = avail_month.join(',')
        }
        else {
          avail_month = ''
        }

        res.send({ "success": true, "message": "success", "data": data, "month": avail_month });
      })
      
   
    })
  }
})

  return
  var data = [{
    "id": "60cb2a66d5131262c88c6236",
    "time": "05:00",
    "length": "45"
  },
  {
    "id": "60c88b82dd69a25905bf2387",
    "time": "13:00",
    "length": "45"
  },
  {
    "id": "60c88b82dd69a25905bf238f",
    "time": "17:00",
    "length": "45"
  }]
  console.log(data)
  res.send({ "success": true, "message": "success", "data": data });
  return false;
  // MongoClient.connect(url, function(err, db) {


  // if (err) throw err;
  // var dbo = db.db("gymtraining");
  var day = new Date(date);
  day = day.getDay();
  console.log("date", date, day)
  // Select TBL_GYM_AVAILABILITY for which  (day = <day> && repeat = 1 && gym_id = <gym_id> ) OR (date = <date> && gym_id =<gym_id> )


  dbo.collection("TBL_TRAINER_AVAILABILITY").find({ $or: [{ day: day, trainer_id: ObjectId(trainer_id), repeat: 1 }, { "date": date, "trainer_id": ObjectId(trainer_id) }] }).toArray(async function (err, result) {

    // dbo.collection("TBL_GYM_AVAILABILITY").find({"date":date,"gym_id":ObjectId(gym_id)}).toArray(function(err, result) {
    if (err) {
      res.send({ "success": false, "message": "something went wrong", "data": [] });
      return false;
    }
    else {
      console.log("result", result)
      // return;
      var day_availability
      var date_availability
      if (result.length > 0) {
        // var jj = 0;
        for (var i = result.length - 1; i >= 0; i--) {
          // console.log("index",i)
          // console.log("result",result[i])
          if (result[i].date == date) {
            // console.log("exact date matched")
            dbo.collection("TBL_AVAILABILITY_SLOTS").find({ "trainer_availability_id": ObjectId(result[i]._id), availableSlots: { $gt: 0 } }).sort({ date: -1 }).toArray(await function (err, result) {
              // console.log("result",i)
              res.send({ "success": true, "message": "success", "data": result });
              //return;
              //jj = 1;
            })
            return;
          } else if (result[i].repeat == 1) {
            // console.log("repeat case")
            dbo.collection("TBL_AVAILABILITY_SLOTS").find({ "trainer_availability_id": ObjectId(result[i]._id), availableSlots: { $gt: 0 } }).sort({ date: -1 }).toArray(async function (err, result) {
              res.send({ "success": true, "message": "success", "data": result });

            })
            return;
          }
        }

      }
      else {
        res.send({ "success": true, "message": "success", "data": [] });
      }




    }
    // dbo.close();
  });

  // })
}
function unique(array) {
  return array.filter(function (el, index, arr) {
    return index == arr.indexOf(el);
  });
}
