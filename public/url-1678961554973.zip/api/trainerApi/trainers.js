
var mongo = require("mongoose");
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;


mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');


exports.testLocation = async function (req, res) {
  let dbo = await mongodbutil.Get();
  const { latitude, longitude, radius } = req.body

  dbo.collection('TBL_TRAINERS').aggregate([
    {

      $geoNear: {
        near: {
          type: "Point", coordinates: [parseFloat(longitude),
          parseFloat(latitude)]
        },
        spherical: true,
        maxDistance: parseInt(radius) * 1609,
        distanceMultiplier: 0.001,

        distanceField: "dist.calculated",
        // query: { "price": { "$gte": parseInt(min), "$lte": parseInt(max) } },
      }
    }
  ]).toArray(function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      console.log(resr)
      return res.json(resr)
    }
  })
}


exports.trainers2 = async function (req, res) {
  console.log('-------------------trainer-filter------------->')
  console.log(req.body)
  console.log('<--------------------------------')
  const { latitude, longitude, min_price, max_price, radius, datetime, user_id, trainings, page_id } = req.body;
  console.log('BODY TRAINERS', req.body)
  if (!latitude || !longitude) {
    res.send({ "success": false, "message": "Please enter all fields", "data": [] });
    return false;
  }
  if (radius == undefined) {
    var rad = '50';
  }
  else {
    if (radius > 50) {
      var rad = '50'
    }
    else {
      var rad = radius
    }

  }
  if (min_price == undefined) {
    var min = 0;
  }
  else {
    var min = min_price;
  }
  if (max_price == undefined) {
    var max = 250;
  }
  else {
    var max = max_price;
  }

  if (trainings != undefined) {
    var equipArr = []
    equip = req.body.trainings.split(',')
    for (let f = 0; f < equip.length; f++) {
      equipArr.push(ObjectId(equip[f]))
    }
    //var eqp = { "training_ids": { $in: equipArr }};
    var eqp = { "training_ids.id": { $in: equipArr } };
    // var eqp = { "training_ids": { $in: equipArr }, isBlocked: { $ne: "1" } };
  }
  else {
    var equipArr = [];
    var eqp = {};
    // var eqp = { isBlocked: { $ne: "1" } };
  }
  console.log('eqp', eqp)
  if (page_id != undefined) {
    var page = page_id * 3;
    var skip = (page_id - 1) * 3;
  } else {
    var page = 1000000;
    var skip = 0;
  }

  let dbo = await mongodbutil.Get();

  if (!req.body.min_price) {
    req.body.min_price = 0
  }
  if (!req.body.max_price) {
    req.body.max_price = 10000
  }
  if (!req.body.keyword) {
    req.body.keyword = ''
  }
  if (req.body.datetime_to) {
    // if (req.body.datetime_to.indexOf('optional') !== -1) {
    // string.includes(substring)
    // # req.body.datetime_to = new Date(req.body.datetime_to * 1000).toISOString().substr(11, 8)
    // # req.body.datetime_from = new Date(req.body.datetime_from * 1000).toISOString().substr(11, 8)

    var time_match = {

      $or: [
        { "availabilityy.to": { $gte: req.body.datetime_to, $lt: req.body.datetime_from } },
        { "availabilityy.from": { $gte: req.body.datetime_to, $lt: req.body.datetime_from } }
      ]
    };
    console.log('time_match------>', time_match)

    // console.log('new Date(req.body.datetime_to * 1000).toISOString().substr(11, 8)')
  } else {
    req.body.datetime_to = "00:00"
    req.body.datetime_from = "23:59"
    var time_match = {}
  }
  if (latitude == '0' || longitude == '0' || latitude == 0 || longitude == 0) {
    dbo.collection('TBL_TRAINERS').aggregate([

      {
        "$match": {
          $and: [
            { 'price': { $gte: parseInt(req.body.min_price), $lt: parseInt(req.body.max_price) } },
            eqp

          ]
        }
      },


      {
        $lookup:
        {
          from: 'TBL_TRAININGS',
          localField: 'training_ids.id',
          foreignField: '_id',
          as: 'training_ids'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_SERVICES',
          localField: 'services.id',
          foreignField: '_id',
          as: 'services'
        }
      },


      {
        $lookup:
        {
          from: 'TBL_TRAINERS_IMAGES',
          localField: 'images_ids.id',
          foreignField: '_id',
          as: 'images_ids'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_FAVORITES',
          localField: 'trainer_main_id',
          foreignField: 'trainer_id',
          as: 'favorites'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_TRAINER_DETAILS',
          localField: '_id',
          foreignField: 'user_id',
          as: 'userdetails'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_STRIPE_TRAINERS',
          localField: 'trainer_main_id',
          foreignField: 'trainer_id',
          as: 'stripe'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_TRAINER_AVAILABILITY',
          localField: 'trainer_main_id',
          foreignField: 'trainer_id',
          as: 'availabilityy'
        }
      },

      {
        "$addFields": {
          "favorites": {
            "$arrayElemAt": [
              {
                "$filter": {
                  "input": "$favorites",
                  "as": "comp",
                  "cond": {
                    "$eq": ["$$comp.client_id", ObjectId(user_id)]
                  }
                }
              }, 0
            ]
          },
        }


      },


      {
        "$match": time_match
      },
      {
        "$project": {
          "_id": 1,
          "trainer_main_id": 1,
          "name": 1,
          "formatted_address": 1,
          "bio": 1,
          "image": 1,
          // "logo": 1,
          // "timezone": 1,
          "price": 1,
          "avg_rating": 1,
          "ratings": 1,
          "images_ids": 1,
          "training_ids": 1,
          "favorites": 1,
          "latitude": 1,
          "longitude": 1,
          "location": 1,
          // "space_owner":1,
          "dist": 1,
          "stripe": 1,
          "services": 1,
          "availabilityy": 1,
          "userdetails": 1,
          // "storefront":1,
          // "reception":1,
          // "gym_interior":1,

        }

      },

    ]).toArray(function (err, resr) {
      if (err) {
        throw err;
      }
      else {
        console.log(resr)
        if (resr) {

          for (var i = 0; i < resr.length; i++) {
            var avg_rati = resr[i].avg_rating
            if (isNaN(avg_rati)) {
              resr[i].avg_rating = '0'
              resr[i].ratings = '0'
            }
            //  resr[i]._id = resr[i].trainer_main_id

            if (!resr[i].latitude) {
              resr[i].latitude = ''
            }
            else {
              resr[i].latitude = resr[i].latitude.toString()

            }
            if (!resr[i].longitude) {
              resr[i].longitude = ''
            }
            else {
              resr[i].longitude = resr[i].longitude.toString()
            }
            // delete resr[i].trainer_main_id
            if (resr[i].favorites != undefined) {
              //delete resr[i].equipments_id
              resr[i].favorite = true;
              resr[i].time_zone = resr[i].timezone;
            }
            else {
              //delete resr[i].equipments_id
              resr[i].favorite = false;
              resr[i].time_zone = resr[i].timezone;
            }
            if (!resr[i].formatted_address) {
              //delete resr[i].equipments_id
              resr[i].address = '';
            }
            else {
              resr[i].address = resr[i].formatted_address;
            }
            if (!resr[i].image) {
              resr[i].image = ''
            }
            else {
              images = [];
              resr[i].image = resr[i].image
              images.push(resr[i].image)
              resr[i].images_ids = images;
            }
            if (!resr[i].stripe[0]) {
              //delete resr[i].equipments_id
              resr[i].stripe_connect_id = '';
              resr[i].stripe_connect_email = '';
            }
            else {
              resr[i].stripe_connect_id = resr[i]['stripe'][0].stripe_connect_id.toString();
              resr[i].stripe_connect_email = resr[i]['stripe'][0].stripe_connect_email.toString();

              delete resr[i].stripe;
            }


            delete resr[i].favorites;
          }

          // return;
          var data = JSON.parse(JSON.stringify(resr));
          res.send({ "success": true, "message": "success", "data": data });
          return false;
        }
        else {
          res.send({ "success": false, "message": "something went wrong", "data": [] });
          return false;
        }
      }

    });
  }
  else {
    console.log('loc section')


    dbo.collection('TBL_TRAINERS').aggregate([
      {

        $geoNear: {
          near: {
            type: "Point", coordinates: [parseFloat(longitude),
            parseFloat(latitude)]
          },
          spherical: true,
          maxDistance: parseInt(rad) * 1609,
          // distanceMultiplier : 0.001,

          distanceField: "dist.calculated",
          // query: { "price": { "$gte": parseInt(min), "$lte": parseInt(max) } },
        }
      },
      {
        "$match": {
          $and: [

            { 'price': { $gte: parseInt(req.body.min_price), $lt: parseInt(req.body.max_price) } },
            eqp


          ]
        }
      },


      {
        $lookup:
        {
          from: 'TBL_TRAININGS',
          localField: 'training_ids.id',
          foreignField: '_id',
          as: 'training_ids'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_SERVICES',
          localField: 'services.id',
          foreignField: '_id',
          as: 'services'
        }
      },

      //{$match:eqp},
      {
        $lookup:
        {
          from: 'TBL_TRAINERS_IMAGES',
          localField: 'images_ids.id',
          foreignField: '_id',
          as: 'images_ids'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_FAVORITES',
          localField: 'trainer_main_id',
          foreignField: 'trainer_id',
          as: 'favorites'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_TRAINER_DETAILS',
          localField: '_id',
          foreignField: 'user_id',
          as: 'userdetails'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_STRIPE_TRAINERS',
          localField: 'trainer_main_id',
          foreignField: 'trainer_id',
          as: 'stripe'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_TRAINER_AVAILABILITY',
          localField: 'trainer_main_id',
          foreignField: 'trainer_id',
          as: 'availabilityy'
        }
      },

      {
        "$addFields": {
          "favorites": {
            "$arrayElemAt": [
              {
                "$filter": {
                  "input": "$favorites",
                  "as": "comp",
                  "cond": {
                    "$eq": ["$$comp.client_id", ObjectId(user_id)]
                  }
                }
              }, 0
            ]
          },
        }


      },

      {
        "$match": time_match
      },
      {
        "$project": {
          "_id": 1,
          "trainer_main_id": 1,
          "name": 1,
          "formatted_address": 1,
          "bio": 1,
          "image": 1,
          // "logo": 1,
          // "timezone": 1,
          "price": 1,
          "avg_rating": 1,
          "ratings": 1,
          "images_ids": 1,
          "training_ids": 1,
          "favorites": 1,
          "latitude": 1,
          "longitude": 1,
          "location": 1,
          // "space_owner":1,
          "dist": 1,
          "stripe": 1,
          "services": 1,
          "availabilityy": 1,
          "userdetails": 1
          // "storefront":1,
          // "reception":1,
          // "gym_interior":1,

        }

      },

    ]).toArray(function (err, resr) {
      if (err) {
        throw err;
      }
      else {
        console.log(resr)
        // return res.json(resr)
        if (resr) {
          for (var i = 0; i < resr.length; i++) {
            var avg_rati = resr[i].avg_rating
            if (isNaN(avg_rati)) {
              resr[i].avg_rating = '0'
              resr[i].ratings = '0'
            }
            // resr[i]._id = resr[i]._id

            if (!resr[i].latitude) {
              resr[i].latitude = ''
            }
            else {
              resr[i].latitude = resr[i].latitude.toString()

            }
            if (!resr[i].longitude) {
              resr[i].longitude = ''
            }
            else {
              resr[i].longitude = resr[i].longitude.toString()
            }
            //delete resr[i].trainer_main_id
            if (resr[i].favorites != undefined) {
              //delete resr[i].equipments_id
              resr[i].favorite = true;
              resr[i].time_zone = resr[i].timezone;
            }
            else {
              //delete resr[i].equipments_id
              resr[i].favorite = false;
              resr[i].time_zone = resr[i].timezone;
            }
            if (!resr[i].formatted_address) {
              //delete resr[i].equipments_id
              resr[i].address = '';
            }
            else {
              resr[i].address = resr[i].formatted_address;
            }
            // if (!resr[i].userdetails ) {
            //   resr[i].image = ''
            // }
            // else{
            //   images = [];
            //   resr[i].image = resr[i].image
            //   images.push(resr[i].image)
            //   resr[i].images_ids = images;
            // }
            if (resr[i].userdetails[0]) {
              resr[i].image = resr[i].userdetails[0].image
              resr[i].first_name = resr[i].userdetails[0].first_name,
                resr[i].last_name = resr[i].userdetails[0].last_name
            }

            delete resr[i].userdetails
            if (!resr[i].stripe[0]) {
              //delete resr[i].equipments_id
              resr[i].stripe_connect_id = '';
              resr[i].stripe_connect_email = '';
            }
            else {
              resr[i].stripe_connect_id = resr[i]['stripe'][0].stripe_connect_id.toString();
              resr[i].stripe_connect_email = resr[i]['stripe'][0].stripe_connect_email.toString();

              delete resr[i].stripe;
            }
            // if(resr[i].images_ids !=undefined || resr[i].images_ids.length){

            //   for(var j = 0;j<resr[i].images_ids.length;j++){
            //     if(String(resr[i].images_ids[j]['image']).includes('http')){

            //       resr[i].images_ids[j]['image'] = resr[i].images_ids[j]['image']  
            //       if(resr[i].images_ids[j]['image']   == undefined ||  resr[i].images_ids[j]['image']   == null || resr[i].images_ids[j]['image']   == ""){
            //         resr[i].images_ids[j]['image'] = resr[i].images_ids[j]['name']  
            //       }
            //     }
            //     else{
            //       resr[i].images_ids[j]['image'] = "https://hourful.io/"+resr[i].images_ids[j]['image']
            //       // console.log(resr[i].images_ids[j]['image'])
            //       if(resr[i].images_ids[j]['image']   == "https://hourful.io/undefined" ){
            //         resr[i].images_ids[j]['image'] = resr[i].images_ids[j]['name']  
            //       }
            //     }

            //     images.push(resr[i].images_ids[j])
            //   }
            // }
            // resr[i].images_ids = images;

            delete resr[i].favorites;
          }

          // return;
          var data = JSON.parse(JSON.stringify(resr));
          res.send({ "success": true, "message": "success", "data": data });
          return false;
        }
        else {
          res.send({ "success": false, "message": "something went wrong", "data": [] });
          return false;
        }
      }

    });
  }
  // });
}


exports.trainers = async function (req, res) {
  console.log('-------------------trainer-filter------------->')
  console.log(req.body)
  console.log('<--------------------------------')
  const { latitude, longitude, min_price, max_price, radius, datetime, user_id, trainings, page_id } = req.body;
  console.log('BODY TRAINERS', req.body)
  if (!latitude || !longitude) {
    res.send({ "success": false, "message": "Please enter all fields", "data": [] });
    return false;
  }

  if (radius == undefined) {
    var rad = '50';
  }
  else {
    if (radius > 50) {
      var rad = '50'
    }
    else {
      var rad = radius
    }

  }
  if (min_price == undefined) {
    var min = 0;
  }
  else {
    var min = min_price;
  }
  if (max_price == undefined) {
    var max = 250;
  }
  else {
    var max = max_price;
  }

  if (trainings != undefined) {
    var equipArr = []
    equip = req.body.trainings.split(',')
    for (let f = 0; f < equip.length; f++) {
      equipArr.push(ObjectId(equip[f]))
    }
    //var eqp = { "training_ids": { $in: equipArr }};
    var eqp = { "services.id": { $in: equipArr } };
    // var eqp = { "training_ids": { $in: equipArr }, isBlocked: { $ne: "1" } };
  }
  else {
    var equipArr = [];
    var eqp = {};
    // var eqp = { isBlocked: { $ne: "1" } };
  }
  console.log('eqp', eqp)
  if (page_id != undefined) {
    var page = page_id * 3;
    var skip = (page_id - 1) * 3;
  } else {
    var page = 1000000;
    var skip = 0;
  }

  let dbo = await mongodbutil.Get();

  if (!req.body.min_price) {
    req.body.min_price = 0
  }
  if (!req.body.max_price) {
    req.body.max_price = 10000
  }
  if (!req.body.keyword) {
    req.body.keyword = ''
  }
  //to get upcoming availability
  let currentTime = getCurrentTime()
  let upcoming_availability = { "availabilityy_slots.date_utc": { $gte: currentTime } }
  console.log(upcoming_availability)
  let length_filter = {}
  if (req.body.max_session_length || req.body.min_session_length) {
    length_filter = {
      "availabilityy_slots.length": { $gte: parseInt(req.body.min_session_length), $lte: parseInt(req.body.max_session_length) }
    }
  }
  console.log('length filter----->', length_filter)


  if (req.body.to_minute || req.body.max_session_length) {
    if (req.body.to_minute)
      var time_match_filter = { "availabilityy_slots.time_minute": { $gte: parseInt(req.body.from_minute), $lte: parseInt(req.body.to_minute) } }
    var time_match = { ...time_match_filter, ...length_filter, ...upcoming_availability }

    //return res.send(merge)
    console.log('availability_filter----->', time_match)
    // return res.json(time_match)
    // console.log('new Date(req.body.datetime_to * 1000).toISOString().substr(11, 8)')
  }



  else {
    req.body.datetime_to = "00:00"
    req.body.datetime_from = "23:59"
    var time_match = {}
  }
  //console.log('time_match-----', time_match)
  // time_match={...time_match,...upcoming_availability}
  console.log('time_match----->>>>', time_match)
  //return

  // return
  if (latitude == '0' || longitude == '0' || latitude == 0 || longitude == 0) {
    dbo.collection('TBL_TRAINERS').aggregate([
      {
        "$match": {
          $and: [
            { 'price': { $gte: parseInt(req.body.min_price), $lte: parseInt(req.body.max_price) } },
            eqp

          ]
        }
      },
      {
        $lookup:
        {
          from: 'TBL_TRAININGS',
          localField: 'training_ids.id',
          foreignField: '_id',
          as: 'training_ids'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_SERVICES',
          localField: 'services.id',
          foreignField: '_id',
          as: 'services'
        }
      },


      {
        $lookup:
        {
          from: 'TBL_TRAINERS_IMAGES',
          localField: 'images_ids.id',
          foreignField: '_id',
          as: 'images_ids'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_FAVORITES',
          localField: '_id',
          foreignField: 'trainer_id',
          as: 'favorites'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_TRAINER_DETAILS',
          localField: '_id',
          foreignField: 'user_id',
          as: 'userdetails'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_STRIPE_TRAINERS',
          localField: '_id',
          foreignField: 'trainer_id',
          as: 'stripe'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_TRAINER_AVAILABILITY_SLOTS',
          localField: '_id',
          foreignField: 'trainer_id',
          as: 'availabilityy_slots'
        }
      },
      { $unwind: { path: '$availabilityy_slots', preserveNullAndEmptyArrays: true } },
      // { $unwind: '$availabilityy_slots' },

      // { $match: time_match },

      {
        "$group": {
          "_id": "$_id",
          "trainer_id": { "$first": "$_id" },
          "training_ids": { "$first": "$training_ids" },
          "price": { "$first": "$price" },
          "avg_rating": { "$first": "$avg_ratings" },
          "ratings": { "$first": "$ratings" },
          "userdetails": { "$first": "$userdetails" },
          "images_ids": { "$first": "$images_ids" },
          "latitude": { "$first": "$latitude" },
          "longitude": { "$first": "$longitude" },
          "formatted_address": { "$first": "$formatted_address" },
          "stripe": { "$first": "$stripe" },
          "services": { "$first": "$services" },
          // "favorites": { "$first": "$favorites" },
          //"formatted_address": { "$first": "$formatted_address" },
          // "availabilityy": { "$push": "$availabilityy_slots" }
        }
      }

    ]).toArray(function (err, resr) {
      if (err) {
        throw err;
      }
      else {
        console.log(resr)
        // return res.json(resr)
        if (resr) {

          for (var i = 0; i < resr.length; i++) {
            var avg_rati = resr[i].avg_rating

            console.log(avg_rati)
            if (isNaN(avg_rati)) {
              resr[i].avg_rating = '0'
              resr[i].ratings = '0'
            }
            else {
              resr[i].avg_rating = resr[i].avg_rating ? String(resr[i].avg_rating.toFixed(1)) : '0'
              resr[i].ratings = resr[i].ratings ? String(resr[i].ratings) : '0'

            }
            //  resr[i]._id = resr[i].trainer_main_id

            if (!resr[i].latitude) {
              resr[i].latitude = ''
            }
            else {
              resr[i].latitude = resr[i].latitude.toString()

            }
            if (!resr[i].longitude) {
              resr[i].longitude = ''
            }
            else {
              resr[i].longitude = resr[i].longitude.toString()
            }
            // delete resr[i].trainer_main_id
            if (resr[i].favorites != undefined) {
              //delete resr[i].equipments_id
              resr[i].favorite = true;
              resr[i].time_zone = resr[i].timezone;
            }
            else {
              //delete resr[i].equipments_id
              resr[i].favorite = false;
              resr[i].time_zone = resr[i].timezone;
            }
            if (!resr[i].formatted_address) {
              //delete resr[i].equipments_id
              resr[i].address = '';
            }
            else {
              resr[i].address = resr[i].formatted_address;
            }
            if (!resr[i].image) {
              resr[i].image = ''
            }
            else {
              images = [];
              resr[i].image = resr[i].image
              images.push(resr[i].image)
              resr[i].images_ids = images;
            }
            if (!resr[i].stripe[0]) {
              //delete resr[i].equipments_id
              resr[i].stripe_connect_id = '';
              resr[i].stripe_connect_email = '';
            }
            else {
              resr[i].stripe_connect_id = resr[i]['stripe'][0].stripe_connect_id.toString();
              resr[i].stripe_connect_email = resr[i]['stripe'][0].stripe_connect_email.toString();

              delete resr[i].stripe;
            }
            if (!resr[i].userdetails[0]) {
              //delete resr[i].equipments_id
              resr[i].first_name = '';
              resr[i].last_name = '';
            }
            else {
              resr[i].first_name = resr[i]['userdetails'][0].first_name
              resr[i].last_name = resr[i]['userdetails'][0].last_name
              resr[i].image = resr[i]['userdetails'][0].image
              resr[i].bio = resr[i]['userdetails'][0].bio
              resr[i].phone_number = resr[i]['userdetails'][0].phone_number ? resr[i]['userdetails'][0].phone_number : ""

            }

            delete resr[i].userdetails;


            delete resr[i].favorites;
          }

          // return;
          var data = JSON.parse(JSON.stringify(resr));
          res.send({ "success": true, "message": "success", "data": data });
          return false;
        }
        else {
          res.send({ "success": false, "message": "something went wrong", "data": [] });
          return false;
        }
      }

    });
  }
  else {
    console.log('loc section')
    dbo.collection('TBL_TRAINERS').aggregate([
      {

        $geoNear: {
          near: {
            type: "Point", coordinates: [parseFloat(longitude),
            parseFloat(latitude)]
          },
          spherical: true,
          maxDistance: parseInt(rad) * 1609,
          // distanceMultiplier: 0.001,

          distanceField: "dist.calculated",
          // query: { "price": { "$gte": parseInt(min), "$lte": parseInt(max) } },
        }
      },
      {
        "$match": {
          $and: [

            { 'price': { $gte: parseInt(req.body.min_price), $lte: parseInt(req.body.max_price) } },
            eqp


          ]
        }
      },


      {
        $lookup:
        {
          from: 'TBL_TRAININGS',
          localField: 'training_ids.id',
          foreignField: '_id',
          as: 'training_ids'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_SERVICES',
          localField: 'services.id',
          foreignField: '_id',
          as: 'services'
        }
      },


      {
        $lookup:
        {
          from: 'TBL_TRAINERS_IMAGES',
          localField: 'images_ids.id',
          foreignField: '_id',
          as: 'images_ids'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_FAVORITES',
          localField: '_id',
          foreignField: 'trainer_id',
          as: 'favorites'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_TRAINER_DETAILS',
          localField: '_id',
          foreignField: 'user_id',
          as: 'userdetails'
        }
      },
      {
        $lookup:
        {
          from: 'TBL_STRIPE_TRAINERS',
          localField: '_id',
          foreignField: 'trainer_id',
          as: 'stripe'
        }
      },

      {
        $lookup:
        {
          from: 'TBL_TRAINER_AVAILABILITY_SLOTS',
          localField: '_id',
          foreignField: 'trainer_id',
          as: 'availabilityy_slots'
        }
      },
      { $unwind: { path: '$availabilityy_slots', preserveNullAndEmptyArrays: true } },
      //  { $unwind: '$availabilityy_slots' },

      // { $match: time_match },

      {
        "$group": {
          "_id": "$_id",
          "trainer_id": { "$first": "$_id" },
          "training_ids": { "$first": "$training_ids" },
          "price": { "$first": "$price" },
          "avg_rating": { "$first": "$avg_ratings" },
          "ratings": { "$first": "$ratings" },
          "userdetails": { "$first": "$userdetails" },
          "images_ids": { "$first": "$images_ids" },
          "latitude": { "$first": "$latitude" },
          "longitude": { "$first": "$longitude" },
          "stripe": { "$first": "$stripe" },
          "formatted_address": { "$first": "$formatted_address" },
          "services": { "$first": "$services" },
          "dist": { "$first": "$dist" },
          // "favorites": { "$first": "$favorites" },
          //"formatted_address": { "$first": "$formatted_address" },
          // "availabilityy": { "$push": "$availabilityy_slots" }
        }
      }

    ]).toArray(function (err, resr) {
      if (err) {
        throw err;
      }
      else {
        //console.log(resr)

        if (resr) {
          for (var i = 0; i < resr.length; i++) {
            var avg_rati = resr[i].avg_rating
            console.log(avg_rati)
            if (isNaN(avg_rati)) {
              resr[i].avg_rating = '0'
              resr[i].ratings = '0'
            }
            else {
              resr[i].avg_rating = resr[i].avg_rating ? String(resr[i].avg_rating.toFixed(1)) : '0'
              resr[i].ratings = resr[i].ratings ? String(resr[i].ratings) : '0'

            }
            //  resr[i]._id = resr[i].trainer_main_id

            if (!resr[i].latitude) {
              resr[i].latitude = ''
            }
            else {
              resr[i].latitude = resr[i].latitude.toString()

            }
            if (!resr[i].longitude) {
              resr[i].longitude = ''
            }
            else {
              resr[i].longitude = resr[i].longitude.toString()
            }
            // delete resr[i].trainer_main_id
            if (resr[i].favorites != undefined) {
              //delete resr[i].equipments_id
              resr[i].favorite = true;
              resr[i].time_zone = resr[i].timezone;
            }
            else {
              //delete resr[i].equipments_id
              resr[i].favorite = false;
              resr[i].time_zone = resr[i].timezone;
            }
            if (!resr[i].formatted_address) {
              //delete resr[i].equipments_id
              resr[i].address = '';
            }
            else {
              resr[i].address = resr[i].formatted_address;
            }
            if (!resr[i].image) {
              resr[i].image = ''
            }
            else {
              images = [];
              resr[i].image = resr[i].image
              images.push(resr[i].image)
              resr[i].images_ids = images;
            }
            if (!resr[i].stripe[0]) {
              //delete resr[i].equipments_id
              resr[i].stripe_connect_id = '';
              resr[i].stripe_connect_email = '';
            }
            else {
              resr[i].stripe_connect_id = resr[i]['stripe'][0].stripe_connect_id.toString();
              resr[i].stripe_connect_email = resr[i]['stripe'][0].stripe_connect_email.toString();

              delete resr[i].stripe;
            }
            if (!resr[i].userdetails[0]) {
              //delete resr[i].equipments_id
              resr[i].first_name = '';
              resr[i].last_name = '';
            }
            else {
              resr[i].first_name = resr[i]['userdetails'][0].first_name
              resr[i].last_name = resr[i]['userdetails'][0].last_name
              resr[i].image = resr[i]['userdetails'][0].image
              resr[i].bio = resr[i]['userdetails'][0].bio
              //resr[i].avg_rating = resr[i]['userdetails'][0].avg_rating ? String(resr[i]['userdetails'][0].avg_rating ): ""
              //  resr[i].ratings = resr[i]['userdetails'][0].ratings ? String(resr[i]['userdetails'][0].ratings) : ""
              resr[i].phone_number = resr[i]['userdetails'][0].phone_number ? resr[i]['userdetails'][0].phone_number : ""

            }
            delete resr[i].userdetails;


            delete resr[i].favorites;
          }

          // return;
          var data = JSON.parse(JSON.stringify(resr));
          res.send({ "success": true, "message": "success", "data": data });
          return false;
        }
        else {
          res.send({ "success": false, "message": "something went wrong", "data": [] });
          return false;
        }
      }

    });
  }
  // });
}

exports.deleteTrainer = async function (req, res) {
  if (!req.body.email) {
    return res.send({ message: "email is required" })
  }
  let dbo = await mongodbutil.Get();
  const { email } = req.body
  let myquery = { email: email }
  dbo.collection("TBL_TRAINERS").deleteOne(myquery, function (err, obj) {
    if (err) {
      throw err;
    }
    else {
      console.log(obj.deletedCount)
      if (!obj.deletedCount) {
        return res.send({ message: "Failed To Delete Trainer " })
      }
      else {
        return res.send({ message: "Trainer Deleted  Sucessfully" })

      }
    }

  })
}

exports.getRating = async function (req, res) {
  let dbo = await mongodbutil.Get();
  dbo.collection('TBL_TRAINER_CLIENT_RATINGS').aggregate([
    { $match: { trainer_id: ObjectId(req.body.trainer_id) } },
    {
      $group: {
        _id: '$trainer_id',
        sum_Of_total_rating: { $sum: "$ratings" },
        number_of_user_rated: { $sum: 1 },
      }
    },
    {
      $addFields: {
        avg_rating: { $divide: ["$sum_Of_total_rating", "$number_of_user_rated"] }
      }
    }



  ]).toArray(function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      console.log(resr)
      return res.json(...resr)
    }
  })



}


exports.getPurchasedClientPunchCard = async (req, res) => {
  const { trainer_id, punch_card_id } = req.body
  if (!trainer_id || !punch_card_id) {
    res.send({ "success": false, "message": "trainer id and punch card id ", "data": [] });
    return false;
  }
  let dbo = await mongodbutil.Get();
  dbo.collection('TBL_SESSIONS').aggregate([
    {
      $match: {
        trainer_id: ObjectId(trainer_id),
        punch_card_id: ObjectId(punch_card_id)

      }
    },
    {
      $lookup:
      {
        from: 'TBL_CLIENTS',
        localField: 'client_id',
        foreignField: '_id',
        as: 'client_details'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_TRAINERS',
        localField: 'trainer_id',
        foreignField: '_id',
        as: 'trainer_details'
      }
    },




  ]).toArray(function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      var data_user = JSON.parse(JSON.stringify(resr));
      var gymdeta = []

      for (var i = 0; i < data_user.length; i++) {
        gymdeta.push({
          "_id": String(resr[i]["_id"]),
          "client_id": String(resr[i]["client_id"]),
          // "review": String(resr_user_fin[i]['reviews']),
          // "rating": String(resr_user_fin[i]['rating']),
          "status": String(resr[i]['status']),
          "price": String(resr[i]['price'] ? resr[i]['price'] : ""),
          "trainer_id": String(resr[i]["trainer_id"]),
          "session_type": String(resr[i]["session_type"]),
          // "name": String(name),
          "first_name": resr[i]['client_details'][0].first_name ? resr[i]['client_details'][0].first_name : '',
          "last_name": resr[i]['client_details'][0].last_name ? resr[i]['client_details'][0].last_name : '',
          "image": String(resr[i]['client_details'][0] ? resr[i]['client_details'][0].image : ""),
          "time": String(resr[i].time),
          "trainer_first_name": resr[i]['trainer_details'][0].first_name,
          "trainer_last_name": resr[i]['trainer_details'][0].last_name,
          "trainer_formatted_address": resr[i]['trainer_details'][0].formatted_address,
          "trainer_avg_ratings": resr[i]['trainer_details'][0].avg_ratings,

          "time": {
              "from": String(resr[i]["time"]),
              "date": String(resr[i]["date_str"]),
              "day": String(resr[i]["day"]),
              "month": String(resr[i]["month"]),
              "year": String(resr[i]["year"]),
              "utc": String(resr[i]["utc"]),
              // "slot_id": String(resr_user_fin[i]["slot_id"]),
              "gym_name": String(resr[i]['gym'] ? resr[i]['gym'][0].name : ""),


          }
      })
      }

      console.log(resr)
      return res.send({
        "success": true,
        "message": "success",
        "data": gymdeta
    });
    }
  })
}
/*
{
  "latitude": "43.67575674293647",
  "user_id": "61d5984489eb86401fd0b6c9",
  "trainings": "60c88b82dd69a25905bf238b",
  "min_price": "20.0",
  "datetime_from": "1643283576.725932",
  "datetime_to": "1643283576.725993",
  "min_session_length": "20.0",
  "max_price": "149.",
  "radius": "2",
  "longitude": "-79.43444207310678",
  "max_session_length": "120.0"
 }
*/

function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}