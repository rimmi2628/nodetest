var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);

var mongodbutil = require('./mongodbutil');

exports.clients = async function (req, res) {
    if (!req.body.trainer_id) {
        res.send({
            "success": false,
            "message": "trainer id  required",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();

    dbo.collection('TBL_BOOKINGS').aggregate([

        {
          "$match": {
            'trainer_id':ObjectId(req.body.trainer_id)
          }
        },
      ]).toArray(function (err, resr1) {
        if (err) {
          throw err;
        }
        else {
          var data = []
            

            for (var i = 0; i < resr1.length; i++) {
              data.push(ObjectId(resr1[i].user_id))
            }
            dbo.collection('TBL_CLIENTS').aggregate([
        {
            $match: {
                isBlocked: {$ne:1},
                _id:{ $in: data }
            }
        },
        {
            $lookup: {
                from: 'TBL_CLIENTS_DETAILS',
                localField: '_id',
                foreignField: 'user_id',
                as: 'userdetails'
            }
        },

        {
            $lookup: {
                from: 'TBL_TRAININGS',
                localField: 'training_ids.id',
                foreignField: '_id',
                as: 'training_ids'
            }
        },

        {
            $lookup: {
                from: 'TBL_GOALS',
                localField: 'goal_id',
                foreignField: '_id',
                as: 'goal'
            }
        },


    ]).toArray(function (err, resr) {
        if (err) {
            throw err;
        } else {
            if (resr) {

                var data = JSON.parse(JSON.stringify(resr));
                // return res.json(data)
                
                var res_data = []
                for (var j = 0; j < data.length; j++) {
                
                    if (data[j]['userdetails'][0]['goverment_id'] != undefined) {
                        var gov_id_verified = true;
                    } else {
                        var gov_id_verified = false;
                    }

                    if (!data[j]['isBlocked']) {
                        data[j]['isBlocked'] = '0'
                    }
                    if (!data[j]['goal'][0]) {
                        var g_name = '';
                    } else {
                        var g_name = data[j]['goal'][0].name
                    }
                    if (!data[j]['training_ids']) {
                        var t_id = [];
                    } else {
                        // console.log( data[j])
                        var loop_arr = data[j]['training_ids']
                        var t_id = []
                        for (var i = 0; i < loop_arr.length; i++) {
                            t_id.push(loop_arr[i])
                        }
                    }
                    res_data.push({
                        "user_id": data[j]['_id'],
                        "first_name": data[j]['userdetails'][0]['first_name'],
                        "last_name": data[j]['userdetails'][0]['last_name'],
                        "image": data[j]['userdetails'][0]['image'],
                        "status": data[j]['status'],
                        "email": data[j]['email'],
                        "social": data[j]['social_id'],
                        "type": data[j]['type'],
                        "status": data[j]['isBlocked'],
                        "goal": g_name,
                        "trainings": t_id,
                        "address":'',
                        "avg_rating":'0'
                    })
                }
                res.send({
                    "success": true,
                    "message": "success",
                    "data": res_data
                });
                return false;
            } else {
                res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": {}
                });
                return false;
            }
        }

    });
            console.log(data)
        }
      })

    
}

exports.client_details = async function (req, res) {
    if (!req.body.trainer_id || !req.body.client_id) {
        res.send({
            "success": false,
            "message": "trainer id and client_id required",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    dbo.collection('TBL_CLIENTS').aggregate([
        {
            $match: {
                _id: ObjectId(req.body.client_id)
            }
        },
        {
            $lookup: {
                from: 'TBL_CLIENTS_DETAILS',
                localField: '_id',
                foreignField: 'user_id',
                as: 'userdetails'
            }
        },

        {
            $lookup: {
                from: 'TBL_TRAININGS',
                localField: 'training_ids.id',
                foreignField: '_id',
                as: 'training_ids'
            }
        },

        {
            $lookup: {
                from: 'TBL_GOALS',
                localField: 'goal_id',
                foreignField: '_id',
                as: 'goal'
            }
        },


    ]).toArray(function (err, resr) {
        if (err) {
            throw err;
        } else {
            if (resr) {
                dbo.collection('TBL_BOOKINGS').aggregate([
                    {
                        $match: {
                            trainer_id: ObjectId(req.body.trainer_id),
                            user_id: ObjectId(req.body.client_id),
                            status:{ $in: [0,1, 2] }
                        }
                    },
                    
                ]).toArray(function (err, resr_book) {

                    console.log(resr_book)
                    var booking_data = JSON.parse(JSON.stringify(resr_book));

                    if (!booking_data) {
                        var last = ''
                        var next = ''
                        var last_session_timezone_str = ''
                        var next_session_timezone_str = ''
                    } else {
                        var last = ''
                        var next = ''
                        var last_session_timezone_str = ''
                        var next_session_timezone_str = ''
                        var sessionloop = booking_data
                        var counts = []
                        var session_data_all = []
                        var session_detail_last = {}
                        var session_detail_next = {}
                        for (var j = 0; j < sessionloop.length; j++) {
                            var goal = getCurrentTime();
                            if (sessionloop[j].status != 3 && sessionloop[j].status != 4 && sessionloop[j].status != 5 && req.body.trainer_id == sessionloop[j].trainer_id) {

                                counts.push(parseInt(sessionloop[j].schedule_time))
                                session_data_all.push(sessionloop[j])

                            }

                        }
                        if (typeof counts != "undefined" && counts != null && counts.length != null && counts.length > 0) {
                            counts = counts.sort();
                            next = counts.find(e => e >= goal);
                            last = counts.reverse().find(e => e <= goal);
                            // console.log('next',next)
                            // console.log('last',last)
                            if (next) {
                                var search_time_next = arraySearch(counts,next)
                                console.log('search_time_next',search_time_next)
                                // console.log('session_data_all',session_data_all)
                                // session_data_all = session_data_all.sort()
                                // console.log(search(next,session_data_all));
                                var session_detail_next = search(next,session_data_all)
                                // var session_detail_next = session_data_all[search_time_next]
                                session_detail_next.gym_name = session_detail_next.gym[0].name
                                delete session_detail_next.gym
                                // console.log(session_detail_next)
                            }
                            else{
                                var session_detail_next = {}
                            }
                            if (last) {
                                var search_time_last = arraySearch(counts,last)
                                var session_detail_last = search(last,session_data_all)
                                // var session_detail_last = session_data_all[search_time_last]
                                session_detail_last.gym_name = session_detail_last.gym[0].name
                                delete session_detail_last.gym
                                // console.log(session_detail_last)
                            }
                            if (last >= goal) {
                                last = ''
                                var session_detail_next = {}
                            }
                        } else {
                            last = ''
                            var session_detail_next = {}
                        }
                    }
                    // console.log(last)
                    // console.log(next)
                    // return;
                    var data = JSON.parse(JSON.stringify(resr));
                    
                    var res_data = []
                    
                    if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
                        var gov_id_verified = true;
                    } else {
                        var gov_id_verified = false;
                    }

                    if (!data[0]['isBlocked']) {
                        data[0]['isBlocked'] = '0'
                    }
                    if (!data[0]['goal'][0]) {
                        var g_name = '';
                    } else {
                        var g_name = data[0]['goal'][0].name
                    }
                    if (!data[0]['training_ids']) {
                        var t_id = [];
                    } else {
                        // console.log( data[0])
                        var loop_arr = data[0]['training_ids']
                        var t_id = []
                        for (var i = 0; i < loop_arr.length; i++) {
                            t_id.push(loop_arr[i])
                        }
                    }
                    res_data = {
                        "user_id": data[0]['_id'],
                        "first_name": data[0]['userdetails'][0]['first_name'],
                        "last_name": data[0]['userdetails'][0]['last_name'],
                        "image": data[0]['userdetails'][0]['image'],
                        "status": data[0]['status'],
                        "email": data[0]['email'],
                        "social": data[0]['social_id'],
                        "type": data[0]['type'],
                        "status": data[0]['isBlocked'],
                        "goal": g_name,
                        "trainings": t_id,
                        "address":'',
                        "avg_rating":'0',
                        "next_session":session_detail_next,
                        "last_session":session_detail_last,

                    }
                    res.send({
                        "success": true,
                        "message": "success",
                        "data": res_data
                    });
                    return false;
                    
                })
                
                
            } else {
                res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": {}
                });
                return false;
            }
        }

    });
}


function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}
function arrayMin(array) {
    return Math.min.apply(Math, array);
};
function arraySearch(arr,val) {
    console.log(arr)
    for (var i=0; i<arr.length; i++)
        if (arr[i] === val)                    
            return i;
    return false;
}

function search(nameKey, myArray){
    for (var i=0; i < myArray.length; i++) {
        if (myArray[i].schedule_time === nameKey) {
            return myArray[i];
        }
    }
}