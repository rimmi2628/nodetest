
exports.punch_card = require('./punch_card.js')



exports.availabilityt = require('./availability.js')

exports.trainers = require('./trainers.js')

exports.clients = require('./clients.js')

exports.trainer_details=require("./trainer_details")

exports.trainer_availability=require("./trainer_availability")

exports.client_feedback=require("./client_feedback")

exports.reset_password=require('./reset_password')