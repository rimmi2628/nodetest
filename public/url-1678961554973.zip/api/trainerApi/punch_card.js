
var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
 
mongo.set('useFindAndModify', false);

var mongodbutil = require( './mongodbutil' );

exports.punch_cards = async function(req, res) {
    if (!req.body.trainer_id) {
        res.send({"success":false,"message":"trainer id  required","data":{}});
        return false;
    }
    let dbo =  await mongodbutil.Get();
    dbo.collection('TBL_TRAINER_PUNCH_CARDS').aggregate([
        {
            $match: {
                trainer_id: ObjectId(req.body.trainer_id),
                status: {$ne: '0'}
            }
        },
        
    ]).toArray(function(err, resr) {
        // console.log(resr)
        var data = [];
        var resp = resr
        for (var i = 0; i < resp.length; i++) {
            
            data.push(resp[i])

        }
        res.send({"success":true,"message":"success","data":data});
    })
}

exports.add_punch_card = async function(req, res) {
    // - trainer_id 
    // - name
    // - address
    // - lat
    // - long
    // - image
    
    if (!req.body.trainer_id || !req.body.name || !req.body.sessions || !req.body.price || !req.body.location || !req.body.descriptions ||!req.body.length ) {
        res.send({"success":false,"message":"All fields required","data":{}});
        return false;
    }
    let dbo =  await mongodbutil.Get();
    var serv = [];
    // - trainer_id
    // - sessions
    // - price
    var trainer_id = req.body.trainer_id
    var data = {
        'status':"1",trainer_id:ObjectId(trainer_id),sessions:req.body.sessions,
                  price:req.body.price,
                  location:req.body.location,
                  descriptions:req.body.descriptions,
                  length:req.body.length,
                  created_at:getCurrentTime(),
                  updated_at:getCurrentTime()
                
                }
     dbo.collection("TBL_TRAINER_PUNCH_CARDS").insertOne(data, function(err,resr){
        if (err){
            throw err;
        }
        else{
            if(resr){
                res.send({"success":true,"message":"Punch Card Added!","data":[]});
                return false;
            }
            else{
                res.send({"success":false,"message":"something went wrong","data":[]});
                return false;
            }
        }
    }); 
     
    
}

exports.delete_punch_card = async function(req, res) {
    if (!req.body.trainer_id || !req.body.punch_card_id) {
        res.send({"success":false,"message":"All fields required","data":{}});
        return false;
    }
    let dbo =  await mongodbutil.Get();
    var myquery = { _id: ObjectId(req.body.punch_card_id) };
    dbo.collection("TBL_TRAINER_PUNCH_CARDS").updateOne(myquery,{ $set: { status: "0" }}, function (err, obj) {
        if (err) throw err;
        res.send({ "success": true, "message": 'Punchcard deleted Successfully!',"data":[] });
        // db.close();
    });
}
exports.punch_card_purchase_history = async function(req, res) {
    if (!req.body.trainer_id || !req.body.punch_card_id) {
        res.send({"success":false,"message":"trainer id and punch_card_id  required","data":{}});
        return false;
    }
    let dbo =  await mongodbutil.Get();
    

    dbo.collection('TBL_CLIENT_PUNCH_CARDS').aggregate([
        { 
            $match: {
                trainer_id: ObjectId(req.body.trainer_id),
                punch_id: ObjectId(req.body.punch_card_id)
                // status: {$ne: '0'}
            }
        },
        {

            $lookup: {
                from: 'TBL_CLIENTS',
                localField: 'client_id',
                foreignField: '_id',
                as: 'userdetails'
            }
        },
         {

            $lookup: {
                from: 'TBL_TRAINER_PUNCH_CARDS',
                localField: 'punch_id',
                foreignField: '_id',
                as: 'punch_cards_details'
            }
        },
        {

            $lookup: {
                from: 'TBL_TRAINERS',
                localField: 'trainer_id',
                foreignField: '_id',
                as: 'trainer_details'
            }
        },
    ]).toArray(function(err, resr) {
        console.log("----------")
     console.log(resr)
    // return res.json(resr)
        var data = [];
        var resp = resr
        for (var i = 0; i < resp.length; i++) {
            
            resp[i].client_name = resp[i].userdetails[0]?resp[i].userdetails[0].first_name+' '+ resp[i].userdetails[0].last_name:''
            resp[i].purchased_on = resp[i].created_at,
            resp[i].trainer_address= resp[i].trainer_details[0]? resp[i].trainer_details[0].formatted_address:''
            resp[i].trainer_avg_rating=resp[i].trainer_details[0] && resp[i].trainer_details[0].avg_ratings? resp[i].trainer_details[0].avg_ratings:0

            delete resp[i].userdetails
            delete resp[i].created_at
            delete resp[i].trainer_details
            data.push(resp[i])

        }
        res.send({"success":true,"message":"success","data":data});
    })
}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}