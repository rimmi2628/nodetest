var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});

var sourceFile = require('./register.js');
// console.log(sourceFile)
var db = mongo.connect("mongodb://localhost:27017/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
   if(err){ console.log( err); }  
   else{ //console.log('Connected to ' + db, ' + ', response); 
    }  
});  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.reviews = async function(req, res) {
       if(!req.body.user_id){
           res.send({"success":false,"message":"user_id empty","data":[]});
           return false;
       }
       // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
            // if (err) throw err;
            // var dbo = db.db("gymtraining");
            let dbo =  await mongodbutil.Get();

            dbo.collection('TBL_TRAINERS').aggregate([
                { 
                    $match : { 
                        _id : ObjectId(req.body.user_id) 
                    } 
                } , 
                {
                    $lookup: {
                        from: 'TBL_CLIENT_TRAINER_RATINGS',
                        localField: '_id',
                        foreignField: 'trainer_id',
                        as: 'trainer_details'
                    }
                },
            ]).toArray(function(err, resr) {
                if (err){
                    throw err;
                }
                else{
                    if(resr){
                        var data = JSON.parse(JSON.stringify(resr));
                        console.log(data)
                       // return res.json(data)
                        if(data[0].avg_ratings != undefined){
                          var avg_rating = parseFloat(data[0].avg_ratings.toFixed(1));
                        }
                        else{
                          var avg_rating =0
                        }
                        if(data[0].ratings != undefined){
                          var num_of_ratings = parseFloat(data[0].ratings.toFixed(1));
                        }
                        else{
                          var num_of_ratings =0
                        }
                        // var ratings = 0
                        var reviews =[]
                        for (let p = 0; p < data[0].trainer_details.length; p++) {
                            //ratings += parseFloat(resr[p].rating)
                            reviews.push({
                              'rating':data[0].trainer_details[p].ratings,
                            'comment':data[0].trainer_details[p].comments,
                            'date_time':data[0].trainer_details[p].created_at?data[0].trainer_details[p].created_at:''})
                        }
                        // var num_of_ratings = resr.length
                        // var avg_rating = ratings/num_of_ratings

                        res.send({"success":true,"message":"success","data":{'avg_rating':avg_rating,'num_of_ratings':num_of_ratings,"reviews":reviews}});
                        return false;
                    }
                    else{
                        res.send({"success":false,"message":"something went wrong","data":[]});
                        return false;
                    }
                }
                // console.log(data)
            }); 
        // });  
  }