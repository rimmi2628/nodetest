var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());
const Utill = require('../helper/Constant')




var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);

var mongodbutil = require( './mongodbutil' );

 exports.get_favorites = async function(req, res) {
     if(!req.body.user_id ){
      res.send({"success":false,"message":"user_id empty","data":{}});
      return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    //     if (err) throw err;
        let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_TRAINERS').aggregate([
            { 
                $match : { 
                    _id : ObjectId(req.body.user_id) 
                } 
            } ,
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'favorites',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            {
                $unwind: {
                    path: "$gym",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYM_IMAGES',
                    localField: 'gym.images_ids.id',
                    foreignField: '_id',
                    as: 'gym.images_ids'
                }
            },
             {
          $lookup : 
          {
            from : 'TBL_EQUIPMENTS', 
            localField: 'gym.equipments_id', 
            foreignField: '_id', 
            as : 'gym.equipments_ids'
          }
          },
          {
          $lookup : 
          {
            from : 'TBL_NOTES', 
            localField: 'gym._id', 
            foreignField: 'gym_id', 
            as : 'gym.notes'
          }
          },
          {
            "$addFields": {
                "gym.notes": {
                    "$arrayElemAt": [
                        {
                            "$filter": {
                                "input": "$gym.notes",
                                "as": "comp",
                                "cond": {
                                    "$eq": [ "$$comp.user_id", ObjectId(req.body.user_id) ]
                                }
                            }
                        }, 0
                    ]
                },
            }
            
        },
        ]).toArray(function(err, resr) {
            if (err){
                throw err;
            }
            else{
                console.log(resr)
                 
                if(resr){
                    var obj =[];
                    for(var i=0;i<resr.length;i++){
                        
                        obj.push(resr[i].gym)

                    }   
                    // console.log("obj",obj[0]['images_ids'][0])
                    for(var j = 0;j<obj.length;j++){
                      if(obj[j].logo !=undefined){
                          obj[j].logo = Utill.IMAGE_BASE_URL+obj[j].logo
                      }
                      if(obj[j].storefront !=undefined){
                          obj[j].storefront = Utill.IMAGE_BASE_URL+obj[j].storefront
                      }
                      if(obj[j].reception !=undefined){
                          obj[j].reception = Utill.IMAGE_BASE_URL+obj[j].reception
                      }
                      if(obj[j].gym_interior !=undefined){
                          obj[j].gym_interior = Utill.IMAGE_BASE_URL+obj[j].gym_interior
                      }
                      for(var k = 0;k<obj[j]['images_ids'].length;k++){
                        console.log("obj[j].images_ids[k]",obj[j].images_ids[k])
                        obj[j].images_ids[k].image = Utill.IMAGE_BASE_URL+obj[j].images_ids[k].image
                      }
                     
                    }
                    
                    // console.log()
                    if(obj[0].name != undefined){
                        res.send({"success":true,"message":"success","data":obj});
                        return false;
                    }
                    else{
                        res.send({"success":true,"message":"success","data":[]});
                        return false;
                    }
                    
                }
                else{

                    res.send({"success":false,"message":"Something went wrong","data":[]});
                    return false;
                }
                    
                // }
                    
                // }
                // else{
                //     res.send({"success":false,"message":"something went wrong","data":[]});
                //     return false;
                // }
                  // if(resr){

                  //   for(var i = 0;i<obj.length;i++){
                  //     if(obj.favorites !=undefined){
                  //       delete obj.equipments_id
                  //       obj.favorite = true;
                  //       obj.time_zone = "US/Eastern";
                  //     }
                  //     else{
                  //       delete obj.equipments_id
                  //       obj.favorite = false;
                  //       obj.time_zone = "US/Eastern";
                  //     }
                  //   }
                  //   var data = JSON.parse(JSON.stringify(obj));
                  //   res.send({"success":true,"message":"success","data":data});
                  //   return false;
                  // }
                  // else{
                  //   res.send({"success":false,"message":"something went wrong","data":[]});
                  //   return false;
                  // }
             }
            // console.log(data)
        }); 
    // });  
  }