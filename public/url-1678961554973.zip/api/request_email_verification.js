var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());

var nodemailer = require('nodemailer');
const Utill = require("../helper/Constant")

var transporter = nodemailer.createTransport({
  service: Utill.EMAIL_SERVICE,
  auth: {
    user: Utill.EMAIL,
    pass: Utill.EMAIL_PASSWORD
  }
});
console.log(Utill.IMAGE_BASE_URL)

var sourceFile = require('./register.js');
// console.log(sourceFile)
var db = mongo.connect("mongodb://localhost:27017/gymtraining", { useNewUrlParser: true, useUnifiedTopology: true }, function (err, response) {
  if (err) { console.log(err); }
  else { //console.log('Connected to ' + db, ' + ', response); 
  }
});
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
exports.request_email_verification = function (req, res) {
  //  app.post('/api/request_email_verification', (req, res) => {
  //  console.log(req.body);return;
  const { email } = req.body;
  let errors = [];
  if (!email) {
    res.send({ "success": false, "message": "Please enter all fields", "data": {} });
    return false;
  }
  else {
    var verifyEmailId = makeid(20);
    sourceFile.TBL_TRAINERS.findOne({ email: email }).then(user => {
      if (user) {
        sourceFile.TBL_TRAINERS.findOneAndUpdate({ email: email }, { $set: { email_verification_id: verifyEmailId } }, { upsert: true }, function (err, doc) {
          if (err) {
            res.send({ "success": false, "message": "Failed to Send mail", "data": {} });
            return false;
          }
          else {
            sourceFile.TBL_TRAINER_DETAILS.findOne({ user_id: doc._id }, function (err, doc) {
              if (err) {
                res.send({ "success": false, "message": "Failed to Send mail", "data": {} });
                return false;
              }
              else {
                var mailOptions = {
                  from: Utill.EMAIL,
                  to: user.email,
                  subject: Utill.EMAIL_SUBJECT,
                  html: '<!doctype html><html lang="en"> <head> <meta charset="utf-8"> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/> <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous"> <title>Verify</title> <style>/*body{font-family: "SF Pro Display";}.verify-main-top{max-width: 1140px;margin: auto;width:70%;}.verify{background:#fff3ee;height:100%;padding:60px 0;}.verify-logo{text-align:center;margin-bottom:30px;}.verify-logo img{width:17%;}.verify-main{background:#fff;padding:50px;border-radius:30px;font-weight:600;}.verify-main h2{font-size:35px;margin-bottom:50px;}.verify-main h3,h4,h5,h6{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;line-height:40px;}.verify-main p{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;margin-top:70px;line-height:50px;}.verify-btn{text-align:center;}a.verify-btn{font-size:20px;color:#fff !important;background:#ff885b;font-weight:400;border-radius: 50px;padding:18px 55px;display:inline-block;text-decoration:none;}.verify-bottom{text-align:center;}.verify-bottom ul{display:inline-block;margin:40px 0;}.verify-bottom li{display:inline-block;margin:0 15px;}.verify-bottom p{font-size:22px;color:#232323;font-weight:400;padding:0 60px;}.bottom-text p{font-size:22px;color:#232323;font-weight:400;margin:50px 0 0;}.bottom-text h5{background:none;padding:0;color:#0066cb!important;margin:5px 0 0;}.verify-main h6{margin-top:30px;}*/@media only screen and (max-width: 1599px){.verify-main-top{width:65%;}.verify-main h2{margin-top:0;}.verify-bottom li img{width: 60px;}.verify-bottom li{margin: 0 10px;}}@media only screen and (max-width: 1366px){.verify-main h2{font-size: 30px;font-weight:500;margin-bottom:35px;}.verify-main h3, h4, h5, h6{font-size: 19px;line-height:22px;}a.verify-btn{padding:15px 50px;}.verify{background: #fff3ee; height: 100%; padding: 40px 0;}.verify-main p{font-size: 19px; color: #353535; font-weight: 400; margin-bottom: 0; margin-top: 48px; line-height: 22px;}.verify-main{padding:35px;}.verify-bottom li img{width: 55px;}.bottom-text p{font-size: 19px; color: #232323; font-weight: 400; margin: 26px 0 0;}ul li img{width: 55px !important;}}@media only screen and (max-width:767px){h3, h5, h4, h6, h2 , p{font-size: 1.1em !important; margin-bottom: 18px !important; margin-top: 20px !important; line-height: 26px !important; padding:0px !important; word-break: break-all; white-space: pre-line;}ul li a img{width: 40px !important;}div{width: 100% !important;}div > p > a > img{width: 48% !important;}h6 > a{padding:18px 35px !important;font-size:18px !important}}</style> </head> <body style="font-family: "SF Pro Display";box-sizing: border-box; margin:0px; padding:0px;"> <main class="verify" style="background:#fff3ee;height:100%;padding:60px 0;"> <div class="verify-main-top" style="margin: auto;width:100%;background:#fff3ee;padding:20px;box-sizing: border-box;" bgcolor="#fff3ee"> <div class="container"> <div class="verify-logo" style="text-align:center;margin-bottom:30px;"> <p><a href="http://hourful.io/images/verify-logo.png"><img src="http://hourful.io/images/verify-logo.png" style="width:17%;"></a></p></div><div class="verify-main" style="background:#fff;padding:30px;border-radius:30px;font-weight:600;max-width: 1300px; margin: 10px auto; width:70%;box-sizing: border-box;"> <h2 style="font-size:1.4em;margin-bottom:40px; padding: 0 20px">Verify This Email Address</h2> <h3 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;padding: 0 20px;line-height:36px;">Hi ' + doc.first_name + ',</h3> <h4 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;padding: 0 20px;line-height:36px;">Welcome to Hourful !</h4> <h5 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;padding: 0 20px;line-height:36px;">Please click the button to verify your email address.</h5> <h6><a href="'+Utill.IMAGE_BASE_URL+'/gymapp/#/email-confirm-trainer?id=' + verifyEmailId + '" class="verify-btn" style="padding: 0 20px;font-size:20px;color:#fff !important;background:#ff885b;font-weight:400;border-radius: 50px;padding:18px 55px; display:inline-block;text-decoration:none;">Verify your email</a></h6> <div class="bottom-text"><p style="padding: 0 20px;font-size:1.3em;color:#232323;font-weight:400;margin:50px 0 0;">if you have trouble paste this link into your web browser</p><h5 style="background:none;padding: 0 20px;word-break: break-all;color:#0066cb!important;margin:5px 0 0;font-size: 1.3em;font-weight: 500;line-height: 40px;">'+Utill.IMAGE_BASE_URL+'/gymapp/#/email-confirm-trainer?id=' + verifyEmailId + '</h5> </div><h6 style="margin-top:30px;padding: 0 20px;font-size: 1.3em;padding: 0 20px; font-weight: 400;line-height: 36px; ">If you did not sign up to Hourful then please ignore email or contact us at<br>info@hourful.com</h6> <p style="padding: 0 20px;font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;margin-top:70px;line-height:50px;">- The Hourful Team</p><div class="verify-btn"> </div></div><div class="verify-bottom" style="text-align:center;"> <ul style="display:inline-block;margin:40px 0;padding: 0 20px"> <li style="display:inline-block;margin:0 15px;"> <a href="https://twitter.com/HourfulApp"><img src="http://hourful.io/images/bottom-icon1.png" alt="icon"></a> </li><li style="display:inline-block;margin:0 15px;"> <a href="https://www.instagram.com/HourfulApp"><img src="http://hourful.io/images/bottom-icon4.png" alt="icon"></a> </li><li style="display:inline-block;margin:0 15px;"> <a href="https://www.facebook.com/hourfulapp"><img src="http://hourful.io/images/bottom-icon3.png" alt="icon"></a> </li></ul> </div></div></div></main> </body></html>'

                };
                transporter.sendMail(mailOptions, function (error, info) {
                  if (error) {
                    console.log(error)
                    res.send({ "success": true, "message": "Mail Not sent", "data": {} });
                  } else {
                    res.send({ "success": true, "message": "Mail Send", "data": {} });
                  }
                });
              }
            })
          }
        })
      }
      else {
        res.send({ "success": false, "message": "email doesn't exist", "data": {} });
        return false;
      }
    });
    //}
    //}); 
  }
};
function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}