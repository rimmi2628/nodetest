'use strict';
var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = require('mongodb').ObjectID
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
var mongodbutil = require('./mongodbutil');
var sourceFile = require('./register.js');
var constants = require('./constants.js');

var ApiContracts = require('authorizenet').APIContracts;
var ApiControllers = require('authorizenet').APIControllers;
var utils = require('./utils.js');
const { json } = require('body-parser');
const Utill = require('../helper/Constant')
//console.log(Utill.STRIPE_KEY)

const stripe = require('stripe')(Utill.STRIPE_KEY);
// const stripe = require('stripe')('sk_test_1tqRe2GJZqKbCChbIZvB4GKs');

exports.add_client = async function (req, res) {
	const {
		user_id,
		first_name,
		last_name,
		phone,
		image,
		address
	} = req.body;
	if (!user_id || !first_name || !last_name || !phone || !address) {
		res.send({
			"success": false,
			"message": "All fields are required.",
			"data": {}
		});
		return false;
	}
	if (req.files != undefined || req.files != null) {
		var sampleFile = req.files.image;
		var location = path.join(__dirname, '../../uploads/images');
		sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1], function (err) {
			if (err) {
				res.send({
					"success": false,
					"message": "Unable to fetch image",
					"data": []
				});
				return false;
			} else {
				req.body.image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
			}
		})
	} else {
		req.body.image = ""
	}
	req.body.user_id = ObjectId(req.body.user_id)
	req.body.created_at = getCurrentTime()
	req.body.updated_at = getCurrentTime()
	let dbo = await mongodbutil.Get();
	req.body.phone = req.body.phone.replace(/\D/g, '');
	console.log(req.body.phone)
	// return false
	var query = {
		'phone': req.body.phone
	};

	var update = {
		$set: {
			current_trainer: ObjectId(req.body.user_id),
			phone: req.body.phone,
			disabled: 0
		}
	};
	var options = {
		upsert: true
	};
	dbo.collection('TBL_CLIENTS').updateOne(query, update, options, function (err, resv) {
		if (err) {
			throw err;
		} else {
			console.log(resv)
			// upsertedId: { index: 0, _id: 600a73b30af98486dda1eda9 }, upsertedCount: 0,
			if (resv.result.upserted == undefined) {
				console.log('hey')
				dbo.collection('TBL_CLIENTS').findOne({
					'phone': req.body.phone
				}, function (err, resv1) {
					if (err) {
						throw err;
					} else {
						console.log(resv1._id)
						var client_id = ObjectId(resv1._id)
						var query1 = {
							'client_id': client_id,
							'trainer_id': req.body.user_id
						};
						var update1 = {
							$set: {
								client_id: client_id,
								first_name: req.body.first_name,
								last_name: req.body.last_name,
								image: "",
								address: req.body.address,
								trainer_id: req.body.user_id
							}
						};
						var options1 = {
							upsert: true
						};
						dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)
					}
				})

			} else {
				console.log(resv.result.upserted[0]._id)
				// return false
				var client_id = ObjectId(resv.result.upserted[0]._id)
				var query1 = {
					'client_id': client_id,
					'trainer_id': req.body.user_id
				};
				var update1 = {
					$set: {
						client_id: client_id,
						first_name: req.body.first_name,
						last_name: req.body.last_name,
						image: "",
						address: req.body.address,
						trainer_id: req.body.user_id
					}
				};
				var options1 = {
					upsert: true
				};
				dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)

			}
			// dbo.collection('TBL_CLIENTS').aggregate([{
			// 	$match: {
			// 		_id: ObjectId(resv.insertedId)
			// 	}
			// }, ]).toArray(function (err, resr) {
			// 	if (err) {
			// 		throw err;
			// 	} else {
			// 		if (resr) {
			// 			var data = JSON.parse(JSON.stringify(resr));
			// 			dat = {
			// 				"id": data[0]['_id'],
			// 				"user_id": data[0]['user_id'],
			// 				"repeat": data[0]['repeat'],
			// 				"phone": data[0]['phone'],
			// 				"address": data[0]['address'],
			// 				"first_name": data[0]['first_name'],
			// 				"last_name": data[0]['last_name'],
			// 				"image": data[0]['image'],

			// 			}
			// 			res.send({
			// 				"success": true,
			// 				"message": "Client Added successfully!",
			// 				"data": dat
			// 			});
			// 			return false;
			// 		} else {
			// 			res.send({
			// 				"success": false,
			// 				"message": "something went wrong",
			// 				"data": {}
			// 			});
			// 			return false;
			// 		}
			// 	}

			// });
			res.send({
				"success": true,
				"message": "Client Added successfully!",
				"data": {}
			});
			return false;

		}
	});

	// dbo.collection("TBL_CLIENTS").insertOne({req.phone}, function (err, resv) {
	// 	if (err) {
	// 		throw err;
	// 	} else {
	// 		dbo.collection('TBL_CLIENTS').aggregate([{
	// 			$match: {
	// 				_id: ObjectId(resv.insertedId)
	// 			}
	// 		}, ]).toArray(function (err, resr) {
	// 			if (err) {
	// 				throw err;
	// 			} else {
	// 				if (resr) {
	// 					var data = JSON.parse(JSON.stringify(resr));
	// 					dat = {
	// 						"id": data[0]['_id'],
	// 						"user_id": data[0]['user_id'],
	// 						"repeat": data[0]['repeat'],
	// 						"phone": data[0]['phone'],
	// 						"address": data[0]['address'],
	// 						"first_name": data[0]['first_name'],
	// 						"last_name": data[0]['last_name'],
	// 						"image": data[0]['image'],

	// 					}
	// 					res.send({
	// 						"success": true,
	// 						"message": "Client Added successfully!",
	// 						"data": dat
	// 					});
	// 					return false;
	// 				} else {
	// 					res.send({
	// 						"success": false,
	// 						"message": "something went wrong",
	// 						"data": {}
	// 					});
	// 					return false;
	// 				}
	// 			}

	// 		});

	// 	}
	// });
}

exports.clients2 = async function (req, res) {
	const {
		user_id
	} = req.body;
	if (!user_id) {
		res.send({
			"success": false,
			"message": "user_id is required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	// dbo.collection('TBL_CLIENTS').aggregate([

	// 	{
	// 		$lookup: {
	// 			from: 'TBL_CLIENT_INFO',
	// 			localField: '_id',
	// 			foreignField: 'client_id',
	// 			as: 'client_info'
	// 		}
	// 	},
	// 	{
	// 		$lookup: {
	// 			from: 'TBL_PUSH_TOKENS',
	// 			localField: '_id',
	// 			foreignField: 'trainer_id',
	// 			as: 'client_push'
	// 		}
	// 	},
	// 	{
	// 		$match: {
	// 			// 'client_info.trainer_id': ObjectId(req.body.user_id),
	// 			// disabled: {
	// 			// 	$ne: 1
	// 			// }
	// 			'client_info.disabled': {
	// 				$ne: 1
	// 			}
	// 		}
	// 	},
	dbo.collection('TBL_CLIENT_INFO').aggregate([

		{
			$lookup: {
				from: 'TBL_CLIENTS',
				localField: 'client_id',
				foreignField: '_id',
				as: 'client_info'
			}
		},
		{
			$lookup: {
				from: 'TBL_PUSH_TOKENS',
				localField: 'client_id',
				foreignField: 'trainer_id',
				as: 'client_push'
			}
		},
		{
			$match: {
				trainer_id: ObjectId(req.body.user_id),
				// disabled: {
				// 	$ne: 1
				// }
				disabled: {
					$ne: 1
				}
			}
		},
	]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {

			if (resr) {
				var data = JSON.parse(JSON.stringify(resr));
				var dat = [];
				// console.log(resr)

				if (!data[0]) {
					data = []
				} else {
					data = data
				}


				// return false
				for (var i = 0; i < data.length; i++) {
					var push_tokki = [];
					if (!data[i].client_info[0]) { } else {
						// if (data[i].client_info[0]['trainer_id'] == req.body.user_id) {
						// for (var k = 0; k < data[i].client_info.length; k++) {
						// if (data[i].client_info[k]['trainer_id'] == req.body.user_id) {
						if (!data[i]['image']) {
							data[i]['image'] = ''
						}
						if (!data[i]['first_name']) {
							data[i]['first_name'] = ''
						}
						console.log(data[i].client_info)
						if (!data[i].client_info[0]['isSignup']) {
							data[i].client_info[0]['isSignup'] = 0
						} else {
							data[i].client_info[0]['isSignup'] = 1
						}
						if (!data[i]['isBlocked']) {
							data[i]['isBlocked'] = '0'
						} else {
							data[i]['isBlocked'] = data[i]['isBlocked'];
						}
						if (data[i].client_push.length != 0) {
							for (var kl = 0; kl < data[i].client_push.length; kl++) {
								push_tokki.push(data[i].client_push[kl].token)
							}
						}

						dat.push({
							"id": data[i]['client_id'],
							"user_id": data[i]['user_id'],
							"phone": data[i]['phone'],
							"address": data[i]['address'],
							"first_name": data[i]['first_name'],
							"last_name": data[i]['last_name'],
							"image": data[i]['image'],
							"isSignup": data[i].client_info[0]['isSignup'],
							"current_trainer": data[i].client_info[0]['current_trainer'],
							"isBlocked": data[i]['isBlocked'],
							"push_token": push_tokki
						})
						// }
						// }
						// for (var k = 0; k < data[i].client_info.length; k++) {
						// 	if (data[i].client_info[k]['trainer_id'] == req.body.user_id) {
						// 	if (!data[i].client_info[k]['image']) {
						// 		data[i].client_info[k]['image'] = ''
						// 		}
						// 		if (!data[i].client_info[k]['first_name']) {
						// 			data[i].client_info[k]['first_name'] = ''
						// 		}
						// 		if (!data[i]['isSignup']) {
						// 			data[i]['isSignup'] = 0
						// 		}
						// 		else{
						// 			data[i]['isSignup'] = 1
						// 		}
						// 		if (!data[i].client_info[k]['isBlocked']) {
						// 			data[i].client_info[k]['isBlocked'] = '0'
						// 		}
						// 		else{
						// 			data[i].client_info[k]['isBlocked'] = data[i].client_info[k]['isBlocked'];
						// 		}
						// 		if (data[i].client_push.length != 0 ) {
						// 			for (var kl = k; kl < data[i].client_push.length; kl++) {
						// 				push_tokki.push(data[i].client_push[kl].token)
						// 			}
						// 		}
						// 		// console.log(data[i].client_push)
						// 		// if (data[i]['disabled'] != 1) {
						// 			dat.push({
						// 				"id": data[i].client_info[k]['client_id'],
						// 				"user_id": data[i].client_info[k]['user_id'],
						// 				"phone": data[i].client_info[k]['phone'],
						// 				"address": data[i].client_info[k]['address'],
						// 				"first_name": data[i].client_info[k]['first_name'],
						// 				"last_name": data[i].client_info[k]['last_name'],
						// 				"image": data[i].client_info[k]['image'],
						// 				"isSignup" : data[i]['isSignup'],
						// 				"current_trainer" : data[i]['current_trainer'],
						// 				"isBlocked" : data[i].client_info[k]['isBlocked'],
						// 				"push_token" : push_tokki
						// 			})
						// 	}
						// }
						// 	if (!data[i].client_info[0]['image']) {
						// 	data[i].client_info[0]['image'] = ''
						// 	}
						// 	if (!data[i].client_info[0]['first_name']) {
						// 		data[i].client_info[0]['first_name'] = ''
						// 	}
						// 	if (!data[i]['isSignup']) {
						// 		data[i]['isSignup'] = 0
						// 	}
						// 	else{
						// 		data[i]['isSignup'] = 1
						// 	}
						// 	if (!data[i].client_info[0]['isBlocked']) {
						// 		data[i].client_info[0]['isBlocked'] = '0'
						// 	}
						// 	else{
						// 		data[i].client_info[0]['isBlocked'] = data[i].client_info[0]['isBlocked'];
						// 	}
						// 	if (data[i].client_push.length != 0 ) {
						// 		for (var kl = 0; kl < data[i].client_push.length; kl++) {
						// 			push_tokki.push(data[i].client_push[kl].token)
						// 		}
						// 	}
						// 	// console.log(data[i].client_push)
						// 	// if (data[i]['disabled'] != 1) {
						// 		dat.push({
						// 			"id": data[i].client_info[0]['client_id'],
						// 			"user_id": data[i].client_info[0]['user_id'],
						// 			"phone": data[i].client_info[0]['phone'],
						// 			"address": data[i].client_info[0]['address'],
						// 			"first_name": data[i].client_info[0]['first_name'],
						// 			"last_name": data[i].client_info[0]['last_name'],
						// 			"image": data[i].client_info[0]['image'],
						// 			"isSignup" : data[i]['isSignup'],
						// 			"current_trainer" : data[i]['current_trainer'],
						// 			"isBlocked" : data[i].client_info[0]['isBlocked'],
						// 			"push_token" : push_tokki
						// 		})
						// // }

					}

					// }

				}
				res.send({
					"success": true,
					"message": "Success",
					"data": dat
				});
				return false;
			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}
	});
}
exports.clients = async function (req, res) {
	const {
		user_id
	} = req.body;
	if (!user_id) {
		res.send({
			"success": false,
			"message": "user_id is required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	// dbo.collection('TBL_CLIENTS').aggregate([

	// 	{
	// 		$lookup: {
	// 			from: 'TBL_CLIENT_INFO',
	// 			localField: '_id',
	// 			foreignField: 'client_id',
	// 			as: 'client_info'
	// 		}
	// 	},
	// 	{
	// 		$lookup: {
	// 			from: 'TBL_PUSH_TOKENS',
	// 			localField: '_id',
	// 			foreignField: 'trainer_id',
	// 			as: 'client_push'
	// 		}
	// 	},
	// 	{
	// 		$match: {
	// 			// 'client_info.trainer_id': ObjectId(req.body.user_id),
	// 			// disabled: {
	// 			// 	$ne: 1
	// 			// }
	// 			'client_info.disabled': {
	// 				$ne: 1
	// 			}
	// 		}
	// 	},
	dbo.collection('TBL_SESSIONS').aggregate([
		{
			$match: {
				trainer_id: ObjectId(req.body.user_id),

			}
		},
		{
			$group: {
				_id: {
					client_id: "$client_id",
					trainer_id: "$trainer_id"
				},

			}
		},
		{
			$lookup: {
				from: 'TBL_CLIENTS',
				localField: '_id.client_id',
				foreignField: '_id',
				as: 'clients'
			}
		}


	]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {

			if (resr) {
				//return res.json(resr)
				var data = JSON.parse(JSON.stringify(resr));
				var dat = [];
				//console.log(data)
				//return 

				if (!data[0]) {
					data = []
				} else {
					data = data
				}


				// return false
				for (var i = 0; i < data.length; i++) {
					var push_tokki = [];
					if (!data[i].clients[0]) { } else {
						// if (data[i].client_info[0]['trainer_id'] == req.body.user_id) {
						// for (var k = 0; k < data[i].client_info.length; k++) {
						// if (data[i].client_info[k]['trainer_id'] == req.body.user_id) {

						dat.push({
							"id": data[i]._id.client_id,
							"user_id": data[i]._id.trainer_id,
							"phone": data[i].clients[0]['phone_number'],
							"address":  data[i].clients[0]['formatted_address']?data[i].clients[0]['formatted_address'] :"" ,
							"first_name": data[i].clients[0] ? data[i].clients[0]['first_name'] : "",
							"last_name": data[i].clients[0] ? data[i].clients[0]['last_name'] : "",
							"image": data[i].clients[0] ? data[i].clients[0]['image'] : "",


						})
						// }
						// }
						// for (var k = 0; k < data[i].client_info.length; k++) {
						// 	if (data[i].client_info[k]['trainer_id'] == req.body.user_id) {
						// 	if (!data[i].client_info[k]['image']) {
						// 		data[i].client_info[k]['image'] = ''
						// 		}
						// 		if (!data[i].client_info[k]['first_name']) {
						// 			data[i].client_info[k]['first_name'] = ''
						// 		}
						// 		if (!data[i]['isSignup']) {
						// 			data[i]['isSignup'] = 0
						// 		}
						// 		else{
						// 			data[i]['isSignup'] = 1
						// 		}
						// 		if (!data[i].client_info[k]['isBlocked']) {
						// 			data[i].client_info[k]['isBlocked'] = '0'
						// 		}
						// 		else{
						// 			data[i].client_info[k]['isBlocked'] = data[i].client_info[k]['isBlocked'];
						// 		}
						// 		if (data[i].client_push.length != 0 ) {
						// 			for (var kl = k; kl < data[i].client_push.length; kl++) {
						// 				push_tokki.push(data[i].client_push[kl].token)
						// 			}
						// 		}
						// 		// console.log(data[i].client_push)
						// 		// if (data[i]['disabled'] != 1) {
						// 			dat.push({
						// 				"id": data[i].client_info[k]['client_id'],
						// 				"user_id": data[i].client_info[k]['user_id'],
						// 				"phone": data[i].client_info[k]['phone'],
						// 				"address": data[i].client_info[k]['address'],
						// 				"first_name": data[i].client_info[k]['first_name'],
						// 				"last_name": data[i].client_info[k]['last_name'],
						// 				"image": data[i].client_info[k]['image'],
						// 				"isSignup" : data[i]['isSignup'],
						// 				"current_trainer" : data[i]['current_trainer'],
						// 				"isBlocked" : data[i].client_info[k]['isBlocked'],
						// 				"push_token" : push_tokki
						// 			})
						// 	}
						// }
						// 	if (!data[i].client_info[0]['image']) {
						// 	data[i].client_info[0]['image'] = ''
						// 	}
						// 	if (!data[i].client_info[0]['first_name']) {
						// 		data[i].client_info[0]['first_name'] = ''
						// 	}
						// 	if (!data[i]['isSignup']) {
						// 		data[i]['isSignup'] = 0
						// 	}
						// 	else{
						// 		data[i]['isSignup'] = 1
						// 	}
						// 	if (!data[i].client_info[0]['isBlocked']) {
						// 		data[i].client_info[0]['isBlocked'] = '0'
						// 	}
						// 	else{
						// 		data[i].client_info[0]['isBlocked'] = data[i].client_info[0]['isBlocked'];
						// 	}
						// 	if (data[i].client_push.length != 0 ) {
						// 		for (var kl = 0; kl < data[i].client_push.length; kl++) {
						// 			push_tokki.push(data[i].client_push[kl].token)
						// 		}
						// 	}
						// 	// console.log(data[i].client_push)
						// 	// if (data[i]['disabled'] != 1) {
						// 		dat.push({
						// 			"id": data[i].client_info[0]['client_id'],
						// 			"user_id": data[i].client_info[0]['user_id'],
						// 			"phone": data[i].client_info[0]['phone'],
						// 			"address": data[i].client_info[0]['address'],
						// 			"first_name": data[i].client_info[0]['first_name'],
						// 			"last_name": data[i].client_info[0]['last_name'],
						// 			"image": data[i].client_info[0]['image'],
						// 			"isSignup" : data[i]['isSignup'],
						// 			"current_trainer" : data[i]['current_trainer'],
						// 			"isBlocked" : data[i].client_info[0]['isBlocked'],
						// 			"push_token" : push_tokki
						// 		})
						// // }

					}

					// }

				}
				res.send({
					"success": true,
					"message": "Success",
					"data": dat
				});
				return false;
			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}
	});
}
exports.update_client = async function (req, res) {
	const {
		user_id,
		first_name,
		client_id,
		last_name,
		phone,
		image,
		address
	} = req.body;
	if (!user_id || !first_name || !client_id) {
		// if (!user_id || !first_name || !phone || !address || !client_id) {
		res.send({
			"success": false,
			"message": "All fields are required.",
			"data": {}
		});
		return false;
	}
	if (req.files != undefined || req.files != null) {
		var sampleFile = req.files.image;
		var location = path.join(__dirname, '../../uploads/images');
		sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1], function (err) {
			if (err) {
				res.send({
					"success": false,
					"message": "Unable to fetch image",
					"data": []
				});
				return false;
			} else {
				req.body.image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
				update_cl()
			}
		})
	} else {
		delete req.body.image
		update_cl()
	}
	async function update_cl() {
		let dbo = await mongodbutil.Get();
		var client_ids = req.body.client_id
		console.log(client_ids)
		console.log(req.body.client_id)
		req.body.updated_at = getCurrentTime()
		delete req.body.client_id
		req.body.user_id = ObjectId(req.body.user_id)
		// req.body.client_id = req.body.client_id
		dbo.collection('TBL_CLIENT_INFO').aggregate([{
			$match: {
				client_id: ObjectId(client_ids),
				trainer_id: ObjectId(req.body.user_id)
			}
		},
		]).toArray(function (err, data_ses) {
			if (err) {
				throw err;
			} else {
				console.log(data_ses)
				// if (!data_ses[0].no_of_sessions) {

				// }
				// else{
				// 	req.body.no_of_sessions = Number(req.body.no_of_sessions) + Number(data_ses[0].no_of_sessions)
				// 	req.body.no_of_sessions = req.body.no_of_sessions.toString()
				// }
				dbo.collection('TBL_CLIENT_INFO').updateOne({
					client_id: ObjectId(client_ids),
					trainer_id: ObjectId(req.body.user_id)
				}, {
					$set: req.body
				}, function (err, rese) {
					if (err) {
						res.send({
							"success": true,
							"message": "Unable to save data.",
							"data": {}
						});
						return false;
					} else {
						// req.body.previous_payment_type = '2'
						if (req.body.previous_payment_type && req.body.previous_payment_type == '2') {
							dbo.collection('TBL_CLIENT_INFO').findOne({ 'client_id': ObjectId(client_ids) }, async function (err, resv1) {
								if (err) {
									throw err;
								} else {

									// console.log(resv1)
									var subs_id = resv1.subscription_id
									// console.log('SUBS',subs_id)
									// return
									if (subs_id != '') {
										// resv1.payment_type = '1';
										// console.log('cdvnjk,dfg jkdfbdnvjk,b fjkhfgjkndfjkgnk')
										if (resv1.payment_type == '1') {
											var merchantAuthenticationType = new ApiContracts.MerchantAuthenticationType();
											merchantAuthenticationType.setName(constants.apiLoginKey);
											merchantAuthenticationType.setTransactionKey(constants.transactionKey);

											var cancelRequest = new ApiContracts.ARBCancelSubscriptionRequest();
											cancelRequest.setMerchantAuthentication(merchantAuthenticationType);
											cancelRequest.setSubscriptionId(subs_id);

											// console.log(JSON.stringify(cancelRequest.getJSON(), null, 2));

											var ctrl = new ApiControllers.ARBCancelSubscriptionController(cancelRequest.getJSON());

											ctrl.execute(function () {

												var apiResponse = ctrl.getResponse();

												var response = new ApiContracts.ARBCancelSubscriptionResponse(apiResponse);

												// console.log(JSON.stringify(response, null, 2));

												if (response != null) {
													if (response.getMessages().getResultCode() == ApiContracts.MessageTypeEnum.OK) {
														console.log('Message Code : ' + response.getMessages().getMessage()[0].getCode());
														console.log('Message Text : ' + response.getMessages().getMessage()[0].getText());
														if (req.body.PAID == '1') {
															var note = "Payment succeeded"
															var paymentObj = { 'trainer_id': ObjectId(req.body.user_id), 'client_id': ObjectId(client_ids), 'amount': Number(req.body.amount), 'notes': note, 'created_at': getCurrentTime(), status: 1 }
															dbo.collection("TBL_SESSION_PAYMENTS").insertOne(paymentObj, function (err, resvP) {
															})
														}
														dbo.collection('TBL_CLIENTS').aggregate([{
															$match: {
																_id: ObjectId(client_ids)
															}
														},
														{
															$lookup: {
																from: 'TBL_CLIENT_INFO',
																localField: '_id',
																foreignField: 'client_id',
																as: 'client_info'
															}
														},
														{
															"$unwind": "$client_info"
														},
														{
															"$match": {
																"client_info.trainer_id": ObjectId(req.body.user_id)
															}
														},
														]).toArray(function (err, resr) {
															if (err) {
																throw err;
															} else {
																if (resr) {
																	var dat = []
																	var data = JSON.parse(JSON.stringify(resr));
																	// console.log(data)
																	// return false
																	if (!data[0]['client_info']) {
																		data[0]['client_info'] = []
																		data[0]['client_info'].push({
																			first_name: '',
																			last_name: '',
																			image: '',
																			timezone: ''
																		})
																	} else {
																		var client_info2 = data[0]['client_info'];
																		data[0]['client_info'] = []
																		data[0]['client_info'].push(client_info2)
																	}
																	if (!data[0].client_info[0]['last_name']) {
																		data[0].client_info[0]['last_name'] = ''
																	}
																	if (!data[0].client_info[0]['payment']) {
																		data[0].client_info[0]['payment'] = -1
																		dat.push({
																			"id": data[0].client_info[0]['client_id'],
																			// "last_session": last,
																			// "next_session": next,
																			"payment": data[0].client_info[0]['payment'],
																			"user_id": data[0].client_info[0]['user_id'],
																			"phone": data[0].client_info[0]['phone'],
																			"address": data[0].client_info[0]['address'],
																			"first_name": data[0].client_info[0]['first_name'],
																			"last_name": data[0].client_info[0]['last_name'],
																			"image": data[0].client_info[0]['image'],
																		})
																	} else {
																		if (data[0].client_info[0]['payment'] == 0) {
																			if (!data[0].client_info[0]['per_session_fee']) {
																				data[0].client_info[0]['per_session_fee'] = ''
																			}
																			if (!data[0].client_info[0]['session_length']) {
																				data[0].client_info[0]['session_length'] = ''
																			}
																			dat.push({
																				"id": data[0].client_info[0]['client_id'],
																				// "last_session": last,
																				// "next_session": next,
																				"payment": data[0].client_info[0]['payment'],
																				"per_session_fee": data[0].client_info[0]['per_session_fee'],
																				"session_length": data[0].client_info[0]['session_length'],
																				"user_id": data[0].client_info[0]['user_id'],
																				"phone": data[0].client_info[0]['phone'],
																				"address": data[0].client_info[0]['address'],
																				"first_name": data[0].client_info[0]['first_name'],
																				"last_name": data[0].client_info[0]['last_name'],
																				"image": data[0].client_info[0]['image'],
																			})
																		} else if (data[0].client_info[0]['payment'] == 1) {
																			if (!data[0].client_info[0]['no_of_sessions']) {
																				data[0].client_info[0]['no_of_sessions'] = ''
																			}
																			if (!data[0].client_info[0]['punchcard_price']) {
																				data[0].client_info[0]['punchcard_price'] = ''
																			}
																			dat.push({
																				"id": data[0].client_info[0]['client_id'],
																				// "last_session": last,
																				// "next_session": next,
																				"payment": data[0].client_info[0]['payment'],
																				"punchcard_price": data[0].client_info[0]['punchcard_price'],
																				"no_of_sessions": data[0].client_info[0]['no_of_sessions'],
																				"user_id": data[0].client_info[0]['user_id'],
																				"phone": data[0].client_info[0]['phone'],
																				"address": data[0].client_info[0]['address'],
																				"first_name": data[0].client_info[0]['first_name'],
																				"last_name": data[0].client_info[0]['last_name'],
																				"image": data[0].client_info[0]['image'],
																			})
																		} else if (data[0].client_info[0]['payment'] == 2) {
																			if (!data[0].client_info[0]['no_of_sessions_week']) {
																				data[0].client_info[0]['no_of_sessions_week'] = ''
																			}
																			if (!data[0].client_info[0]['monthly_fee']) {
																				data[0].client_info[0]['monthly_fee'] = ''
																			}
																			dat.push({
																				"id": data[0].client_info[0]['client_id'],
																				// "last_session": last,
																				// "next_session": next,
																				"payment": data[0].client_info[0]['payment'],
																				"no_of_sessions_week": data[0].client_info[0]['no_of_sessions_week'],
																				"monthly_fee": data[0].client_info[0]['monthly_fee'],
																				"user_id": data[0].client_info[0]['user_id'],
																				"phone": data[0].client_info[0]['phone'],
																				"address": data[0].client_info[0]['address'],
																				"first_name": data[0].client_info[0]['first_name'],
																				"last_name": data[0].client_info[0]['last_name'],
																				"image": data[0].client_info[0]['image'],
																			})
																		}
																	}
																	// dat = {
																	// 	"id": data[0]['_id'],
																	// 	"user_id": data[0]['user_id'],
																	// 	"phone": data[0]['phone'],
																	// 	"address": data[0]['address'],
																	// 	"first_name": data[0]['first_name'],
																	// 	"last_name": data[0]['last_name'],
																	// 	"image": data[0]['image'],

																	// }
																	res.send({
																		"success": true,
																		"message": "Client updated successfully!",
																		"data": dat
																	});
																	return false;
																} else {
																	res.send({
																		"success": false,
																		"message": "something went wrong",
																		"data": {}
																	});
																	return false;
																}
															}

														});
													}
													else {
														console.log('Result Code: ' + response.getMessages().getResultCode());
														console.log('Error Code: ' + response.getMessages().getMessage()[0].getCode());
														console.log('Error message: ' + response.getMessages().getMessage()[0].getText());
														res.send({
															"success": false,
															"message": "something went wrong",
															"data": {}
														});
														return false

													}
												}
												else {
													console.log('Null Response.');
													res.send({
														"success": false,
														"message": "something went wrong",
														"data": {}
													});
													return false

												}


												// callback(response);
												// console.log(response)


											});
											// setTimeout(function () {
											// 	console.log('unsubs')
											// 	console.log(unsubs)
											// 	// res.send({
											// 	// 	"success": true,
											// 	// 	"message": 'Clients imported successfully',
											// 	// 	"data": []
											// 	// });
											// }, 600);
										}
										else {
											const deleted = await stripe.subscriptions.del(
												subs_id
											).then(
												function (result) {
													console.log('---------------resv1---------------')
													if (req.body.PAID == '1') {
														var note = "Payment succeeded"
														var paymentObj = { 'trainer_id': ObjectId(req.body.user_id), 'client_id': ObjectId(client_ids), 'amount': Number(req.body.amount), 'notes': note, 'created_at': getCurrentTime(), status: 1 }
														dbo.collection("TBL_SESSION_PAYMENTS").insertOne(paymentObj, function (err, resvP) {
														})
													}
													dbo.collection('TBL_CLIENTS').aggregate([{
														$match: {
															_id: ObjectId(client_ids)
														}
													},
													{
														$lookup: {
															from: 'TBL_CLIENT_INFO',
															localField: '_id',
															foreignField: 'client_id',
															as: 'client_info'
														}
													},
													{
														"$unwind": "$client_info"
													},
													{
														"$match": {
															"client_info.trainer_id": ObjectId(req.body.user_id)
														}
													},
													]).toArray(function (err, resr) {
														if (err) {
															throw err;
														} else {
															if (resr) {
																var dat = []
																var data = JSON.parse(JSON.stringify(resr));
																// console.log(data)
																// return false
																if (!data[0]['client_info']) {
																	data[0]['client_info'] = []
																	data[0]['client_info'].push({
																		first_name: '',
																		last_name: '',
																		image: '',
																		timezone: ''
																	})
																} else {
																	var client_info2 = data[0]['client_info'];
																	data[0]['client_info'] = []
																	data[0]['client_info'].push(client_info2)
																}
																if (!data[0].client_info[0]['last_name']) {
																	data[0].client_info[0]['last_name'] = ''
																}
																if (!data[0].client_info[0]['payment']) {
																	data[0].client_info[0]['payment'] = -1
																	dat.push({
																		"id": data[0].client_info[0]['client_id'],
																		// "last_session": last,
																		// "next_session": next,
																		"payment": data[0].client_info[0]['payment'],
																		"user_id": data[0].client_info[0]['user_id'],
																		"phone": data[0].client_info[0]['phone'],
																		"address": data[0].client_info[0]['address'],
																		"first_name": data[0].client_info[0]['first_name'],
																		"last_name": data[0].client_info[0]['last_name'],
																		"image": data[0].client_info[0]['image'],
																	})
																} else {
																	if (data[0].client_info[0]['payment'] == 0) {
																		if (!data[0].client_info[0]['per_session_fee']) {
																			data[0].client_info[0]['per_session_fee'] = ''
																		}
																		if (!data[0].client_info[0]['session_length']) {
																			data[0].client_info[0]['session_length'] = ''
																		}
																		dat.push({
																			"id": data[0].client_info[0]['client_id'],
																			// "last_session": last,
																			// "next_session": next,
																			"payment": data[0].client_info[0]['payment'],
																			"per_session_fee": data[0].client_info[0]['per_session_fee'],
																			"session_length": data[0].client_info[0]['session_length'],
																			"user_id": data[0].client_info[0]['user_id'],
																			"phone": data[0].client_info[0]['phone'],
																			"address": data[0].client_info[0]['address'],
																			"first_name": data[0].client_info[0]['first_name'],
																			"last_name": data[0].client_info[0]['last_name'],
																			"image": data[0].client_info[0]['image'],
																		})
																	} else if (data[0].client_info[0]['payment'] == 1) {
																		if (!data[0].client_info[0]['no_of_sessions']) {
																			data[0].client_info[0]['no_of_sessions'] = ''
																		}
																		if (!data[0].client_info[0]['punchcard_price']) {
																			data[0].client_info[0]['punchcard_price'] = ''
																		}
																		dat.push({
																			"id": data[0].client_info[0]['client_id'],
																			// "last_session": last,
																			// "next_session": next,
																			"payment": data[0].client_info[0]['payment'],
																			"punchcard_price": data[0].client_info[0]['punchcard_price'],
																			"no_of_sessions": data[0].client_info[0]['no_of_sessions'],
																			"user_id": data[0].client_info[0]['user_id'],
																			"phone": data[0].client_info[0]['phone'],
																			"address": data[0].client_info[0]['address'],
																			"first_name": data[0].client_info[0]['first_name'],
																			"last_name": data[0].client_info[0]['last_name'],
																			"image": data[0].client_info[0]['image'],
																		})
																	} else if (data[0].client_info[0]['payment'] == 2) {
																		if (!data[0].client_info[0]['no_of_sessions_week']) {
																			data[0].client_info[0]['no_of_sessions_week'] = ''
																		}
																		if (!data[0].client_info[0]['monthly_fee']) {
																			data[0].client_info[0]['monthly_fee'] = ''
																		}
																		dat.push({
																			"id": data[0].client_info[0]['client_id'],
																			// "last_session": last,
																			// "next_session": next,
																			"payment": data[0].client_info[0]['payment'],
																			"no_of_sessions_week": data[0].client_info[0]['no_of_sessions_week'],
																			"monthly_fee": data[0].client_info[0]['monthly_fee'],
																			"user_id": data[0].client_info[0]['user_id'],
																			"phone": data[0].client_info[0]['phone'],
																			"address": data[0].client_info[0]['address'],
																			"first_name": data[0].client_info[0]['first_name'],
																			"last_name": data[0].client_info[0]['last_name'],
																			"image": data[0].client_info[0]['image'],
																		})
																	}
																}
																// dat = {
																// 	"id": data[0]['_id'],
																// 	"user_id": data[0]['user_id'],
																// 	"phone": data[0]['phone'],
																// 	"address": data[0]['address'],
																// 	"first_name": data[0]['first_name'],
																// 	"last_name": data[0]['last_name'],
																// 	"image": data[0]['image'],

																// }
																res.send({
																	"success": true,
																	"message": "Client updated successfully!",
																	"data": dat
																});
																return false;
															} else {
																res.send({
																	"success": false,
																	"message": "something went wrong",
																	"data": {}
																});
																return false;
															}
														}

													});
												},
												function (err) {
													res.send({
														"success": false,
														"message": "something went wrong",
														"data": {}
													});
													return false

												}
											);
										}



									}
									else {
										if (req.body.PAID == '1') {
											var note = "Payment succeeded"
											var paymentObj = { 'trainer_id': ObjectId(req.body.user_id), 'client_id': ObjectId(client_ids), 'amount': Number(req.body.amount), 'notes': note, 'created_at': getCurrentTime(), status: 1 }
											dbo.collection("TBL_SESSION_PAYMENTS").insertOne(paymentObj, function (err, resvP) {
											})
										}
										dbo.collection('TBL_CLIENTS').aggregate([{
											$match: {
												_id: ObjectId(client_ids)
											}
										},
										{
											$lookup: {
												from: 'TBL_CLIENT_INFO',
												localField: '_id',
												foreignField: 'client_id',
												as: 'client_info'
											}
										},
										{
											"$unwind": "$client_info"
										},
										{
											"$match": {
												"client_info.trainer_id": ObjectId(req.body.user_id)
											}
										},
										]).toArray(function (err, resr) {
											if (err) {
												throw err;
											} else {
												if (resr) {
													var dat = []
													var data = JSON.parse(JSON.stringify(resr));
													// console.log(data)
													// return false
													if (!data[0]['client_info']) {
														data[0]['client_info'] = []
														data[0]['client_info'].push({
															first_name: '',
															last_name: '',
															image: '',
															timezone: ''
														})
													} else {
														var client_info2 = data[0]['client_info'];
														data[0]['client_info'] = []
														data[0]['client_info'].push(client_info2)
													}
													if (!data[0].client_info[0]['last_name']) {
														data[0].client_info[0]['last_name'] = ''
													}
													if (!data[0].client_info[0]['payment']) {
														data[0].client_info[0]['payment'] = -1
														dat.push({
															"id": data[0].client_info[0]['client_id'],
															// "last_session": last,
															// "next_session": next,
															"payment": data[0].client_info[0]['payment'],
															"user_id": data[0].client_info[0]['user_id'],
															"phone": data[0].client_info[0]['phone'],
															"address": data[0].client_info[0]['address'],
															"first_name": data[0].client_info[0]['first_name'],
															"last_name": data[0].client_info[0]['last_name'],
															"image": data[0].client_info[0]['image'],
														})
													} else {
														if (data[0].client_info[0]['payment'] == 0) {
															if (!data[0].client_info[0]['per_session_fee']) {
																data[0].client_info[0]['per_session_fee'] = ''
															}
															if (!data[0].client_info[0]['session_length']) {
																data[0].client_info[0]['session_length'] = ''
															}
															dat.push({
																"id": data[0].client_info[0]['client_id'],
																// "last_session": last,
																// "next_session": next,
																"payment": data[0].client_info[0]['payment'],
																"per_session_fee": data[0].client_info[0]['per_session_fee'],
																"session_length": data[0].client_info[0]['session_length'],
																"user_id": data[0].client_info[0]['user_id'],
																"phone": data[0].client_info[0]['phone'],
																"address": data[0].client_info[0]['address'],
																"first_name": data[0].client_info[0]['first_name'],
																"last_name": data[0].client_info[0]['last_name'],
																"image": data[0].client_info[0]['image'],
															})
														} else if (data[0].client_info[0]['payment'] == 1) {
															if (!data[0].client_info[0]['no_of_sessions']) {
																data[0].client_info[0]['no_of_sessions'] = ''
															}
															if (!data[0].client_info[0]['punchcard_price']) {
																data[0].client_info[0]['punchcard_price'] = ''
															}
															dat.push({
																"id": data[0].client_info[0]['client_id'],
																// "last_session": last,
																// "next_session": next,
																"payment": data[0].client_info[0]['payment'],
																"punchcard_price": data[0].client_info[0]['punchcard_price'],
																"no_of_sessions": data[0].client_info[0]['no_of_sessions'],
																"user_id": data[0].client_info[0]['user_id'],
																"phone": data[0].client_info[0]['phone'],
																"address": data[0].client_info[0]['address'],
																"first_name": data[0].client_info[0]['first_name'],
																"last_name": data[0].client_info[0]['last_name'],
																"image": data[0].client_info[0]['image'],
															})
														} else if (data[0].client_info[0]['payment'] == 2) {
															if (!data[0].client_info[0]['no_of_sessions_week']) {
																data[0].client_info[0]['no_of_sessions_week'] = ''
															}
															if (!data[0].client_info[0]['monthly_fee']) {
																data[0].client_info[0]['monthly_fee'] = ''
															}
															dat.push({
																"id": data[0].client_info[0]['client_id'],
																// "last_session": last,
																// "next_session": next,
																"payment": data[0].client_info[0]['payment'],
																"no_of_sessions_week": data[0].client_info[0]['no_of_sessions_week'],
																"monthly_fee": data[0].client_info[0]['monthly_fee'],
																"user_id": data[0].client_info[0]['user_id'],
																"phone": data[0].client_info[0]['phone'],
																"address": data[0].client_info[0]['address'],
																"first_name": data[0].client_info[0]['first_name'],
																"last_name": data[0].client_info[0]['last_name'],
																"image": data[0].client_info[0]['image'],
															})
														}
													}
													// dat = {
													// 	"id": data[0]['_id'],
													// 	"user_id": data[0]['user_id'],
													// 	"phone": data[0]['phone'],
													// 	"address": data[0]['address'],
													// 	"first_name": data[0]['first_name'],
													// 	"last_name": data[0]['last_name'],
													// 	"image": data[0]['image'],

													// }
													res.send({
														"success": true,
														"message": "Client updated successfully!",
														"data": dat
													});
													return false;
												} else {
													res.send({
														"success": false,
														"message": "something went wrong",
														"data": {}
													});
													return false;
												}
											}

										});
									}

								}
							})

						}
						else {
							if (req.body.PAID == '1') {
								var note = "Payment succeeded"
								var paymentObj = { 'trainer_id': ObjectId(req.body.user_id), 'client_id': ObjectId(client_ids), 'amount': Number(req.body.amount), 'notes': note, 'created_at': getCurrentTime(), status: 1 }
								dbo.collection("TBL_SESSION_PAYMENTS").insertOne(paymentObj, function (err, resvP) {
								})
							}
							dbo.collection('TBL_CLIENTS').aggregate([{
								$match: {
									_id: ObjectId(client_ids)
								}
							},
							{
								$lookup: {
									from: 'TBL_CLIENT_INFO',
									localField: '_id',
									foreignField: 'client_id',
									as: 'client_info'
								}
							},
							{
								"$unwind": "$client_info"
							},
							{
								"$match": {
									"client_info.trainer_id": ObjectId(req.body.user_id)
								}
							},
							]).toArray(function (err, resr) {
								if (err) {
									throw err;
								} else {
									if (resr) {
										var dat = []
										var data = JSON.parse(JSON.stringify(resr));
										// console.log(data)
										// return false
										if (!data[0]['client_info']) {
											data[0]['client_info'] = []
											data[0]['client_info'].push({
												first_name: '',
												last_name: '',
												image: '',
												timezone: ''
											})
										} else {
											var client_info2 = data[0]['client_info'];
											data[0]['client_info'] = []
											data[0]['client_info'].push(client_info2)
										}
										if (!data[0].client_info[0]['last_name']) {
											data[0].client_info[0]['last_name'] = ''
										}
										if (!data[0].client_info[0]['payment']) {
											data[0].client_info[0]['payment'] = -1
											dat.push({
												"id": data[0].client_info[0]['client_id'],
												// "last_session": last,
												// "next_session": next,
												"payment": data[0].client_info[0]['payment'],
												"user_id": data[0].client_info[0]['user_id'],
												"phone": data[0].client_info[0]['phone'],
												"address": data[0].client_info[0]['address'],
												"first_name": data[0].client_info[0]['first_name'],
												"last_name": data[0].client_info[0]['last_name'],
												"image": data[0].client_info[0]['image'],
											})
										} else {
											if (data[0].client_info[0]['payment'] == 0) {
												if (!data[0].client_info[0]['per_session_fee']) {
													data[0].client_info[0]['per_session_fee'] = ''
												}
												if (!data[0].client_info[0]['session_length']) {
													data[0].client_info[0]['session_length'] = ''
												}
												dat.push({
													"id": data[0].client_info[0]['client_id'],
													// "last_session": last,
													// "next_session": next,
													"payment": data[0].client_info[0]['payment'],
													"per_session_fee": data[0].client_info[0]['per_session_fee'],
													"session_length": data[0].client_info[0]['session_length'],
													"user_id": data[0].client_info[0]['user_id'],
													"phone": data[0].client_info[0]['phone'],
													"address": data[0].client_info[0]['address'],
													"first_name": data[0].client_info[0]['first_name'],
													"last_name": data[0].client_info[0]['last_name'],
													"image": data[0].client_info[0]['image'],
												})
											} else if (data[0].client_info[0]['payment'] == 1) {
												if (!data[0].client_info[0]['no_of_sessions']) {
													data[0].client_info[0]['no_of_sessions'] = ''
												}
												if (!data[0].client_info[0]['punchcard_price']) {
													data[0].client_info[0]['punchcard_price'] = ''
												}
												dat.push({
													"id": data[0].client_info[0]['client_id'],
													// "last_session": last,
													// "next_session": next,
													"payment": data[0].client_info[0]['payment'],
													"punchcard_price": data[0].client_info[0]['punchcard_price'],
													"no_of_sessions": data[0].client_info[0]['no_of_sessions'],
													"user_id": data[0].client_info[0]['user_id'],
													"phone": data[0].client_info[0]['phone'],
													"address": data[0].client_info[0]['address'],
													"first_name": data[0].client_info[0]['first_name'],
													"last_name": data[0].client_info[0]['last_name'],
													"image": data[0].client_info[0]['image'],
												})
											} else if (data[0].client_info[0]['payment'] == 2) {
												if (!data[0].client_info[0]['no_of_sessions_week']) {
													data[0].client_info[0]['no_of_sessions_week'] = ''
												}
												if (!data[0].client_info[0]['monthly_fee']) {
													data[0].client_info[0]['monthly_fee'] = ''
												}
												dat.push({
													"id": data[0].client_info[0]['client_id'],
													// "last_session": last,
													// "next_session": next,
													"payment": data[0].client_info[0]['payment'],
													"no_of_sessions_week": data[0].client_info[0]['no_of_sessions_week'],
													"monthly_fee": data[0].client_info[0]['monthly_fee'],
													"user_id": data[0].client_info[0]['user_id'],
													"phone": data[0].client_info[0]['phone'],
													"address": data[0].client_info[0]['address'],
													"first_name": data[0].client_info[0]['first_name'],
													"last_name": data[0].client_info[0]['last_name'],
													"image": data[0].client_info[0]['image'],
												})
											}
										}
										// dat = {
										// 	"id": data[0]['_id'],
										// 	"user_id": data[0]['user_id'],
										// 	"phone": data[0]['phone'],
										// 	"address": data[0]['address'],
										// 	"first_name": data[0]['first_name'],
										// 	"last_name": data[0]['last_name'],
										// 	"image": data[0]['image'],

										// }
										res.send({
											"success": true,
											"message": "Client updated successfully!",
											"data": dat
										});
										return false;
									} else {
										res.send({
											"success": false,
											"message": "something went wrong",
											"data": {}
										});
										return false;
									}
								}

							});
						}

					}
				})
			}
		})

	}
}

exports.import_clients = async function (req, res) {
	if (!req.body.user_id || !req.body.clients) {
		res.send({
			"success": false,
			"message": "user_id or clients empty",
			"data": []
		});
		return false;
	}
	console.log(req.files)
	console.log(req.body)

	let dbo = await mongodbutil.Get();
	var data = JSON.parse(req.body.clients)
	// console.log(data.length)
	var imagesDat = []
	var phn_Filtered = []
	for (var i = 0; i < data.length; i++) {
		data[i].user_id = ObjectId(req.body.user_id)
		data[i].trainer_id = ObjectId(req.body.user_id)
		data[i].created_at = getCurrentTime()
		data[i].updated_at = getCurrentTime()
		data[i].disabled = 0
		// data[i].phone_check = data[i].phone + "." + req.body.user_id
		if (req.files != undefined || req.files != null) {
			var imagesss = req.files.image
			var isArray = Array.isArray(imagesss);
			console.log(isArray)
			if (isArray == false) {
				var sampleFile = imagesss;
				if (sampleFile.name == data[i].contact_id + '.jpg') {
					data[i].image = sampleFile
					// data[i].phone_1 = data[i].phone
					imageUp(data[i].image, 1, data[i])
					data[i].image = sampleFile.md5 + "." + sampleFile.mimetype.split('/')[1]
				}
			} else {
				for (var j = 0; j < imagesss.length; j++) {
					var done = false
					var sampleFile = imagesss[j];
					if (sampleFile.name == data[i].contact_id + '.jpg') {
						data[i].image = sampleFile
						// data[i].phone_1 = data[i].phone
						imageUp(data[i].image, 1, data[i])
						data[i].image = sampleFile.md5 + "." + sampleFile.mimetype.split('/')[1]
					}
				}
			}

		}
		// else {
		// }
		if (i == data.length - 1) {
			allData(data)
		}

	}

	function imageUp(sampleFile, present, data) {
		var imagesData = []
		if (present == 1) {
			var location = path.join(__dirname, '../../uploads/images');
			sampleFile.mv(location + "/" + sampleFile.md5 + "." + sampleFile.mimetype.split('/')[1], function (err) {
				if (err) {
					res.send({
						"success": false,
						"message": "Unable to fetch image",
						"data": []
					});
					return false;
				} else {
					data.image = sampleFile.md5 + "." + sampleFile.mimetype.split('/')[1]
				}
			})
		}

	}
	async function allData(data) {
		let promise = Promise.resolve();
		const posts = data;
		var phn_Filtered = []
		var notImported = []
		posts.forEach(post => {
			promise = promise.then(() => {
				var dataIn = post
				var phn_Filtered = []
				// console.log(dataIn)
				for (var o = 0; o < dataIn.phone.length; o++) {
					var phones = dataIn.phone[o].replace(/\D/g, '')
					phn_Filtered.push(phones.substring(phones.length - 10))
				}

				dataIn.phone = phn_Filtered;
				console.log(dataIn.phone);
				// dataIn.phone = dataIn.phone.replace(/\D/g, '');
				// console.log(dataIn.phone)
				var query = {
					'phone': dataIn.phone
				};

				var update = {
					$set: {
						// current_trainer: ObjectId(req.body.user_id),
						current_trainer: '',
						phone: dataIn.phone,
						disabled: 0
					}
				};
				var options = {
					upsert: true
				};
				// var update1 = { $set: dataIn };
				// { tags: ['red', 'blank'] }
				// { qty: { $in: [ 5, 15 ] } }
				// {'phone':dataIn.phone[1]}
				dbo.collection('TBL_CLIENTS').find({
					phone: {
						$in: dataIn.phone
					}
				}).toArray(function (err, existsData) {
					if (err) {
						throw err;
					} else {
						console.log('existsData++++++++++++++++')
						console.log(existsData)
						console.log('existsData-----------------')
						if (existsData.length == 0 || req.body.user_id == existsData[0].current_trainer) {
							dbo.collection('TBL_CLIENTS').findOneAndUpdate({
								phone: {
									$in: dataIn.phone
								}
							}, update, options, function (err, resv) {
								if (err) {
									throw err;
								} else {
									// console.log('resv++++++++++++++++')
									// console.log(resv)
									// console.log('resv-----------------')
									// return false
									if (resv.lastErrorObject.updatedExisting == true) {
										console.log('---START----')
										console.log('Updated old client')
										// console.log(dataIn)
										dataIn.client_id = ObjectId(resv.value._id)
										var query1 = {
											'phone': dataIn.phone,
											'trainer_id': ObjectId(req.body.user_id)
										};
										var update1 = {
											$set: dataIn
										};
										var options1 = {
											upsert: true
										};
										dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)
										// 	}
										// })
										console.log('---END----')

									} else {
										console.log('---START----')
										console.log('Added new client')
										// console.log(dataIn)
										var client_id = ObjectId(resv.lastErrorObject.upserted)
										var query1 = {
											'client_id': client_id,
											'trainer_id': ObjectId(req.body.user_id)
										};
										var update1 = {
											$set: dataIn
										};
										var options1 = {
											upsert: true
										};
										dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)
										console.log('----END---')

									}

								}
							});
						} else {
							notImported.push({
								'name': dataIn.first_name
							})
							console.log('---START--ELSE--')
							console.log('Added new client ELSE CONDITION')
							// console.log(dataIn)
							var client_id = ObjectId(existsData[0]._id)
							console.log('client_id: ' + client_id)
							var query1 = {
								'client_id': client_id,
								'trainer_id': ObjectId(req.body.user_id)
							};
							var update1 = {
								$set: dataIn
							};
							var options1 = {
								upsert: true
							};
							// dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)
							dbo.collection('TBL_CLIENT_INFO').findOneAndUpdate(query1, update1, options1, function (err, hello_res) {
								// console.log(hello_res)
							})
							console.log('----END--ELSE--')
						}

					}
				});
				// return false
				// dbo.collection('TBL_CLIENTS').findOneAndUpdate(query, update, options, function (err, resv) {
				// 	if (err) {
				// 		throw err;
				// 	} else {

				// 		console.log(resv)
				// 		// return false
				// 		if (resv.lastErrorObject.updatedExisting == true) {
				// 			console.log('---START----')
				// 			console.log('Updated old client')
				// 			console.log(dataIn)
				// 			// dbo.collection('TBL_CLIENTS').findOne({'phone':dataIn.phone}, function (err, resv1) {
				// 			// if (err) {
				// 			// 	throw err;
				// 			// } else {
				// 			// console.log(resv1._id)
				// 			// var client_id = ObjectId(resv1._id)
				// 			// console.log('phone_number'+ dataIn.phone)
				// 			dataIn.client_id = ObjectId(resv.value._id)
				// 			// console.log(dataIn.client_id)
				// 			var query1 = {
				// 				'phone': dataIn.phone,
				// 				'trainer_id': ObjectId(req.body.user_id)
				// 			};
				// 			var update1 = {
				// 				$set: dataIn
				// 			};
				// 			var options1 = {
				// 				upsert: true
				// 			};
				// 			dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)
				// 			// 	}
				// 			// })
				// 			console.log('---END----')

				// 		} else {
				// 			console.log('---START----')
				// 			console.log('Added new client')
				// 			console.log(dataIn)
				// 			// console.log('Client_id'+resv.result.upserted[0]._id)
				// 			// return false
				// 			// var client_id = ObjectId(resv.result.upserted[0]._id)
				// 			// var client_id = ObjectId(resv.value._id)
				// 			// var client_id = ObjectId(resv.value._id)
				// 			var client_id = ObjectId(resv.lastErrorObject.upserted)
				// 			var query1 = {
				// 				'client_id': client_id,
				// 				'trainer_id': ObjectId(req.body.user_id)
				// 			};
				// 			var update1 = {
				// 				$set: dataIn
				// 			};
				// 			var options1 = {
				// 				upsert: true
				// 			};
				// 			dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)
				// 			console.log('----END---')

				// 		}

				// 	}
				// });
			});
		});

		promise.then(() => {
			setTimeout(function () {
				console.log(notImported)
				console.log('notImported')
				res.send({
					"success": true,
					"message": 'Clients imported successfully',
					"data": []
				});
			}, 100);

		})
		return false
		// // for (var i = 0; i < data.length; i++) {
		// 	var dataIn = data[i]
		// 	// delete dataIn.phone
		// 	delete dataIn.user_id
		// 	delete dataIn.disabled
		// 	dataIn.phone = dataIn.phone.replace(/\D/g,'');
		// 	console.log(data[i].phone)
		// 	var query = {'phone':data[i].phone };

		// 	var update = { $set: {current_trainer: ObjectId(req.body.user_id) , phone:dataIn.phone ,disabled:0} };
		// 	var options = { upsert: true };
		// 	var update1 = { $set: dataIn };


		// 	await dbo.collection('TBL_CLIENTS').updateOne(query, update, options, async function (err, resv) {
		// 		if (err) {
		// 			throw err;
		// 		} else {

		// 			// console.log(resv)
		// 			// return false
		// 			if (resv.result.upserted == undefined) {
		// 				console.log('hey')
		// 				await dbo.collection('TBL_CLIENTS').findOne({'phone':dataIn.phone},async function (err, resv1) {
		// 					if (err) {
		// 						throw err;
		// 					} else {
		// 						console.log(resv1._id)
		// 						var client_id = ObjectId(resv1._id)
		// 						var query1 = {'client_id':client_id , 'trainer_id': ObjectId(req.body.user_id)};

		// 						var options1 = { upsert: true };
		// 						await dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)
		// 					}
		// 				})

		// 			}
		// 			else{
		// 				// console.log(resv.result.upserted[0]._id)
		// 				// return false
		// 				var client_id = ObjectId(resv.result.upserted[0]._id)
		// 				var query1 = {'client_id':client_id , 'trainer_id': ObjectId(req.body.user_id)};
		// 				// var update1 = { $set: dataIn };
		// 				var options1 = { upsert: true };
		// 				await dbo.collection('TBL_CLIENT_INFO').updateOne(query1, update1, options1)

		// 			}

		// 		}
		// 	});
		// 	// var query = { 'user_id':ObjectId(data[i].user_id),'phone':dataIn.phone };
		// 	// var update = { $set: dataIn };
		// 	// var options = { upsert: true };
		// 	// await dbo.collection('TBL_CLIENTS').updateOne(query, update, options);

		// 	// let dd = await dbo.collection('TBL_CLIENTS').find({'user_id':data[i].user_id,'phone':data[i].phone }).toArray(function (err, existsData) {
		//           if (err) {
		//               throw err;
		//           }
		//           else {
		//           	console.log('----')
		//           	// console.log(existsData)
		//               if (Object.keys(existsData).length === 0) {
		//                   console.log('1')
		//               }
		//               else {
		//                   console.log('0')
		//               }
		//           }
		//       });
		// console.log(dd)
		// }
		// res.send({
		// 	"success": true,
		// 	"message": 'Clients imported successfully',
		// 	"data": []
		// });

	}

}

exports.client_details2 = async function (req, res) {
	const {
		user_id,
		client_id
	} = req.body;
	if (!user_id || !client_id) {
		res.send({
			"success": false,
			"message": "user_id and client_id is required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	console.log(req.body)
	// dbo.collection('TBL_CLIENTS').aggregate([{
	// 		$match: {
	// 			_id: ObjectId(req.body.client_id)
	// 		}
	// 	},
	dbo.collection('TBL_CLIENT_INFO').aggregate([
		{
			$match: {
				client_id: ObjectId(req.body.client_id),
				//trainer_id: ObjectId(req.body.user_id)
			}
		},
		{
			$lookup: {
				from: 'TBL_SESSIONS',
				localField: 'client_id',
				foreignField: 'client_id',
				as: 'sessions'
			}
		},
		{
			$lookup: {
				from: 'TBL_CLIENTS',
				localField: 'client_id',
				foreignField: '_id',
				as: 'client_info'
			}
		},
		// ,
		// {
		// 	$lookup: {
		// 		from: 'TBL_CLIENT_INFO',
		// 		localField: '_id',
		// 		foreignField: 'client_id',
		// 		as: 'client_info'
		// 	}
		// },
		{
			$lookup: {
				from: 'TBL_CARDS',
				localField: 'client_id',
				foreignField: 'trainer_id',
				as: 'payment_info'
			}
		},
		{
			$lookup: {
				from: 'TBL_PUSH_TOKENS',
				localField: 'client_id',
				foreignField: 'trainer_id',
				as: 'client_push'
			}
		},
	]).toArray(function (err, resr) {
		console.log(resr)
		if (err) {
			throw err;
		} else {
			if (resr) {
				dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.client_id),
						trainer_id: ObjectId(req.body.user_id),
						status: { $in: [0, 1, 2] }
					}
				},]).toArray(function (err, resr_ses) {
					if (err) {
						throw err;
					} else {
						if (resr_ses) {
							var data_ses = JSON.parse(JSON.stringify(resr_ses));
							var total_sessions = data_ses.length
						}
						else {
							var total_sessions = 0
						}
						var data = JSON.parse(JSON.stringify(resr));
						var dat = [];
						console.log(data)
						// return false
						if (!data || data.length == 0) {

						} else {
							for (var i = 0; i < data.length; i++) {
								var push_tokki = [];
								if (data[i].client_push.length != 0) {
									for (var kl = 0; kl < data[i].client_push.length; kl++) {
										push_tokki.push(data[i].client_push[kl].token)
									}
								}
								// if (!data[i]) {
								// 	data[i] = []
								// 	data[i].start_date = ''
								// 	data[i].PAID = ''
								// 	data[i].payment_type = '' 
								// }
								if (!data[i].start_date) {
									data[i].start_date = ''
								}
								if (!data[i].PAID) {
									data[i].PAID = ''
								}
								if (!data[i].payment_type) {
									data[i].payment_type = ''
								}
								if (data[i].payment_info.length == 0) {
									data[i].payment_info = []
									data[i].isPayment = '0'
								} else {
									console.log('111')
									data[i].isPayment = '1'
									for (var j = 0; j < data[i].payment_info.length; j++) {
										data[i].payment_info[j].user_id = data[i].payment_info[j].trainer_id;
										data[i].payment_info[j].type = data[i].payment_info[j].payment_type;
										data[i].payment_info[j].id = data[i].payment_info[j]._id;
										if (!data[i].payment_info[j].primary) {
											data[i].payment_info[j].primary = 0
										} else {
											data[i].payment_info[j].primary = parseInt(data[i].payment_info[j].primary)
										}
										delete data[i].payment_info[j].payment_method;
										delete data[i].payment_info[j].trainer_id;
										delete data[i].payment_info[j].paypal_authorization;
										delete data[i].payment_info[j].paypal_email;
										delete data[i].payment_info[j].updated_at;
										delete data[i].payment_info[j].created_at;
										if (data[i].payment_info[j].payment_type == "0") {
											delete data[i].payment_info[j].account_number
											delete data[i].payment_info[j].routing_number
											delete data[i].payment_info[j].account_type
										} else {
											delete data[i].payment_info[j].customer_id
											delete data[i].payment_info[j].cvv
											delete data[i].payment_info[j].mm
											delete data[i].payment_info[j].number
											delete data[i].payment_info[j].number
											delete data[i].payment_info[j].yy
											delete data[i].payment_info[j].zip

										}
										delete data[i].payment_info[j].payment_type
										delete data[i].payment_info[j]._id
									}
									// conso
								}
								if (!data[i]['image']) {
									data[i]['image'] = ''
								}
								if (!data[i]['first_name']) {
									data[i]['first_name'] = ''
								}
								if (!data[i].sessions) {
									var last = ''
									var next = ''
									var last_session_timezone_str = ''
									var next_session_timezone_str = ''
								} else {
									var last = ''
									var next = ''
									var last_session_timezone_str = ''
									var next_session_timezone_str = ''
									var sessionloop = data[i].sessions
									var counts = []
									var session_timezone_str_arr = []
									for (var j = 0; j < sessionloop.length; j++) {
										var goal = getCurrentTime();
										if (sessionloop[j].status != 3 && sessionloop[j].status != 4 && sessionloop[j].status != 5 && req.body.user_id == sessionloop[j].trainer_id) {

											counts.push(parseInt(sessionloop[j].utc))
											session_timezone_str_arr.push(sessionloop[j].timezone_str)

										}

									}
									if (typeof counts != "undefined" && counts != null && counts.length != null && counts.length > 0) {
										counts = counts.sort();
										next = counts.find(e => e >= goal);
										var ses_time_next = arraySearch(counts, next)
										console.log(session_timezone_str_arr)
										var ses_fin_next = session_timezone_str_arr[ses_time_next]
										next_session_timezone_str = ses_fin_next
										console.log('next_session_timezone_str ' + next_session_timezone_str)
										console.log('session_timezone_str_arr ' + session_timezone_str_arr)
										console.log('ses_time_next ' + ses_time_next)
										if (!next_session_timezone_str) {
											next_session_timezone_str = ''
										}
										last = counts.reverse().find(e => e <= goal);
										// last = arrayMin(counts);
										if (!last) {
											last_session_timezone_str = ''
										}
										else {
											var ses_time_last = arraySearch(counts, last)
											var ses_fin_last = session_timezone_str_arr[ses_time_last]
											last_session_timezone_str = ses_fin_last
										}
										console.log('ses_time_last: ' + ses_time_last)
										console.log('ses_fin_last: ' + ses_fin_last)
										console.log('goal: ' + goal)
										console.log('last: ' + last)
										if (last >= goal) {
											last = ''
											last_session_timezone_str = ''
										}
									} else {
										last = ''
										last_session_timezone_str = ''
									}
								}
								if (!data[i]['payment']) {
									console.log('222')
									if (!data[i]['isBlocked']) {
										data[i]['isBlocked'] = '0'
									}
									data[i]['payment'] = -1
									dat.push({
										"id": req.body.client_id,
										"last_session": last,
										"next_session": next,
										"current_trainer": data[i].client_info[0]['current_trainer'],
										"payment": data[i]['payment'],
										"user_id": data[i]['user_id'],
										"phone": data[i]['phone'],
										"address": data[i]['address'],
										"first_name": data[i]['first_name'],
										"last_name": data[i]['last_name'],
										"image": data[i]['image'],
										"isBlocked": data[i]['isBlocked'],
										"payment_info": data[i].payment_info,
										"isPayment": data[i].isPayment,
										"push_token": push_tokki,
										"start_date": data[i].start_date,
										"PAID": data[i].PAID,
										"payment_type": data[i].payment_type,
										"no_of_scheduled_sessions": total_sessions.toString(),
										"next_session_timezone_str": next_session_timezone_str.toString(),
										"last_session_timezone_str": last_session_timezone_str.toString(),

									})
								} else {
									console.log('333')
									if (!data[i]['isBlocked']) {
										data[i]['isBlocked'] = '0'
									}
									if (data[i]['payment'] == 0) {
										console.log('444')
										if (!data[i]['per_session_fee']) {
											data[i]['per_session_fee'] = ''
										}
										if (!data[i]['session_length']) {
											data[i]['session_length'] = ''
										}
										dat.push({
											"id": req.body.client_id,
											"last_session": last,
											"next_session": next,
											"payment": data[i]['payment'],
											"current_trainer": data[i].client_info[0]['current_trainer'],
											"per_session_fee": data[i]['per_session_fee'],
											"session_length": data[i]['session_length'],
											"user_id": data[i]['user_id'],
											"phone": data[i]['phone'],
											"address": data[i]['address'],
											"first_name": data[i]['first_name'],
											"last_name": data[i]['last_name'],
											"image": data[i]['image'],
											"isBlocked": data[i]['isBlocked'],
											"payment_info": data[i].payment_info,
											"isPayment": data[i].isPayment,
											"push_token": push_tokki,
											"start_date": data[i].start_date,
											"PAID": data[i].PAID,
											"payment_type": data[i].payment_type,
											"no_of_scheduled_sessions": total_sessions.toString(),
											"next_session_timezone_str": next_session_timezone_str.toString(),
											"last_session_timezone_str": last_session_timezone_str.toString(),
										})
									} else if (data[i]['payment'] == 1) {
										console.log('555')
										if (!data[i]['no_of_sessions']) {
											data[i]['no_of_sessions'] = ''
										}
										if (!data[i]['punchcard_price']) {
											data[i]['punchcard_price'] = ''
										}
										dat.push({
											"id": req.body.client_id,
											"last_session": last,
											"next_session": next,
											"payment": data[i]['payment'],
											"current_trainer": data[i].client_info[0]['current_trainer'],
											"punchcard_price": data[i]['punchcard_price'],
											"no_of_sessions": data[i]['no_of_sessions'],
											"user_id": data[i]['user_id'],
											"phone": data[i]['phone'],
											"address": data[i]['address'],
											"first_name": data[i]['first_name'],
											"last_name": data[i]['last_name'],
											"image": data[i]['image'],
											"isBlocked": data[i]['isBlocked'],
											"payment_info": data[i].payment_info,
											"isPayment": data[i].isPayment,
											"push_token": push_tokki,
											"start_date": data[i].start_date,
											"PAID": data[i].PAID,
											"payment_type": data[i].payment_type,
											"no_of_scheduled_sessions": total_sessions.toString(),
											"next_session_timezone_str": next_session_timezone_str.toString(),
											"last_session_timezone_str": last_session_timezone_str.toString(),
										})
									} else if (data[i]['payment'] == 2) {
										console.log('666')
										if (!data[i]['no_of_sessions_week']) {
											data[i]['no_of_sessions_week'] = ''
										}
										if (!data[i]['monthly_fee']) {
											data[i]['monthly_fee'] = ''
										}
										dat.push({
											"id": req.body.client_id,
											"last_session": last,
											"next_session": next,
											"payment": data[i]['payment'],
											"current_trainer": data[i].client_info[0]['current_trainer'],
											"no_of_sessions_week": data[i]['no_of_sessions_week'],
											"monthly_fee": data[i]['monthly_fee'],
											"user_id": data[i]['user_id'],
											"phone": data[i]['phone'],
											"address": data[i]['address'],
											"first_name": data[i]['first_name'],
											"last_name": data[i]['last_name'],
											"image": data[i]['image'],
											"isBlocked": data[i]['isBlocked'],
											"payment_info": data[i].payment_info,
											"isPayment": data[i].isPayment,
											"push_token": push_tokki,
											"start_date": data[i].start_date,
											"PAID": data[i].PAID,
											"payment_type": data[i].payment_type,
											"no_of_scheduled_sessions": total_sessions.toString(),
											"next_session_timezone_str": next_session_timezone_str.toString(),
											"last_session_timezone_str": last_session_timezone_str.toString(),
										})
									}
								}

							}
						}
						console.log(dat[0])
						res.send({
							"success": true,
							"message": "Success",
							"data": dat[0]
						});
						return false;
						// }
					}
				});

				// for (var i = 0; i < data.length; i++) {
				// 	var push_tokki = [];
				// 	if (data[i].client_push.length != 0 ) {
				// 		for (var kl = 0; kl < data[i].client_push.length; kl++) {
				// 			push_tokki.push(data[i].client_push[kl].token)
				// 		}
				// 	}
				// 	if (!data[i].client_info) {
				// 		data[i].client_info = []
				// 		data[i].client_info[0].start_date = ''
				// 		data[i].client_info[0].PAID = ''
				// 		data[i].client_info[0].payment_type = '' 
				// 	}
				// 	if (!data[i].client_info[0].start_date) {
				// 		data[i].client_info[0].start_date = ''
				// 	}
				// 	if (!data[i].client_info[0].PAID){
				// 		data[i].client_info[0].PAID = ''
				// 	}
				// 	if (!data[i].client_info[0].payment_type){
				// 		data[i].client_info[0].payment_type = '' 
				// 	}
				// 	if(data[i].payment_info.length == 0){
				// 		data[i].payment_info = []
				// 		data[i].isPayment = '0'
				// 	}
				// 	else{
				// 		data[i].isPayment = '1'
				// 		for (var j = 0; j < data[i].payment_info.length; j++) {
				//           data[i].payment_info[j].user_id = data[i].payment_info[j].trainer_id;
				//           data[i].payment_info[j].type = data[i].payment_info[j].payment_type;
				//           data[i].payment_info[j].id = data[i].payment_info[j]._id;
				//           if (!data[i].payment_info[j].primary) {
				//             data[i].payment_info[j].primary = 0
				//           }
				//           else{
				//             data[i].payment_info[j].primary = 1
				//           }
				//           delete data[i].payment_info[j].payment_method;
				//           delete data[i].payment_info[j].trainer_id;
				//           delete data[i].payment_info[j].paypal_authorization;
				//           delete data[i].payment_info[j].paypal_email;
				//           delete data[i].payment_info[j].updated_at;
				//           delete data[i].payment_info[j].created_at;
				//           if (data[i].payment_info[j].payment_type == "0") {
				//             delete data[i].payment_info[j].account_number
				//             delete data[i].payment_info[j].routing_number
				//             delete data[i].payment_info[j].account_type
				//           }
				//           else{
				//             delete data[i].payment_info[j].customer_id
				//             delete data[i].payment_info[j].cvv
				//             delete data[i].payment_info[j].mm
				//             delete data[i].payment_info[j].number
				//             delete data[i].payment_info[j].number
				//             delete data[i].payment_info[j].yy
				//             delete data[i].payment_info[j].zip

				//           }
				//           delete data[i].payment_info[j].payment_type
				//           delete data[i].payment_info[j]._id
				//         }
				//         // conso
				// 	}
				// 	if (!data[i]['image']) {
				// 		data[i]['image'] = ''
				// 	}
				// 	if (!data[i]['first_name']) {
				// 		data[i]['first_name'] = ''
				// 	}
				// 	if (!data[i].sessions) {
				// 		var last = ''
				// 		var next = ''
				// 	} else {
				// 		var last = ''
				// 		var next = ''

				// 		var sessionloop = data[i].sessions
				// 		var counts = []
				// 		for (var j = 0; j < sessionloop.length; j++) {
				// 			var goal = getCurrentTime();
				// 			if (sessionloop[j].status != 3 && sessionloop[j].status != 4  && sessionloop[j].status != 5 && req.body.user_id == sessionloop[j].trainer_id) {
				// 				// console.log(sessionloop[j])
				// 				counts.push(parseInt(sessionloop[j].utc))
				// 				// if (parseInt(sessionloop[j].utc) > goal && next == '') {
				// 				// 	next = sessionloop[j].utc
				// 				// 	console.log('next_1:  '+next)
				// 				// }
				// 				// if (next > goal && next > parseInt(sessionloop[j].utc)) {
				// 				// 	next = sessionloop[j].utc
				// 				// 	console.log('next_2:  '+next)
				// 				// }
				// 			}

				// 		}
				// 		if (typeof counts != "undefined" && counts != null && counts.length != null && counts.length > 0) {
				// 			// var goal1 = getCurrentTime();
				// 			// last = counts.reduce((prev, curr) => Math.abs(curr - goal) < Math.abs(prev - goal) ? curr : prev);
				// 			counts = counts.sort(); 
				// 			next = counts.find(e => e >= goal);
				// 			last = counts.reverse().find(e => e <= goal);
				// 			// last = arrayMin(counts);
				// 			console.log('goal: '+goal)
				// 			console.log('last: '+last)
				// 			if (last >= goal) {
				// 				last = ''
				// 			}
				// 		} else {
				// 			last = ''
				// 		}
				// 	}
				// 	if (!data[i].client_info[0]['payment']) {
				// 		if (!data[i].client_info[0]['isBlocked']) {
				// 			data[i].client_info[0]['isBlocked'] = '0'
				// 		}
				// 		data[i].client_info[0]['payment'] = -1
				// 		dat.push({
				// 			"id": req.body.client_id,
				// 			"last_session": last,
				// 			"next_session": next,
				// 			"current_trainer" : data[i]['current_trainer'],
				// 			"payment": data[i].client_info[0]['payment'],
				// 			"user_id": data[i].client_info[0]['user_id'],
				// 			"phone": data[i].client_info[0]['phone'],
				// 			"address": data[i].client_info[0]['address'],
				// 			"first_name": data[i].client_info[0]['first_name'],
				// 			"last_name": data[i].client_info[0]['last_name'],
				// 			"image": data[i].client_info[0]['image'],
				// 			"isBlocked": data[i].client_info[0]['isBlocked'],
				// 			"payment_info":data[i].payment_info,
				// 			"isPayment" : data[i].isPayment,
				// 			"push_token" : push_tokki,
				// 			"start_date" : data[i].client_info[0].start_date,
				// 			"PAID" : data[i].client_info[0].PAID,
				// 			"payment_type" : data[i].client_info[0].payment_type,

				// 		})
				// 	} else {
				// 		if (!data[i].client_info[0]['isBlocked']) {
				// 			data[i].client_info[0]['isBlocked'] = '0'
				// 		}
				// 		if (data[i].client_info[0]['payment'] == 0) {
				// 			if (!data[i].client_info[0]['per_session_fee']) {
				// 				data[i].client_info[0]['per_session_fee'] = ''
				// 			}
				// 			if (!data[i].client_info[0]['session_length']) {
				// 				data[i].client_info[0]['session_length'] = ''
				// 			}
				// 			dat.push({
				// 				"id": req.body.client_id,
				// 				"last_session": last,
				// 				"next_session": next,
				// 				"payment": data[i].client_info[0]['payment'],
				// 				"current_trainer" : data[i]['current_trainer'],
				// 				"per_session_fee": data[i].client_info[0]['per_session_fee'],
				// 				"session_length": data[i].client_info[0]['session_length'],
				// 				"user_id": data[i].client_info[0]['user_id'],
				// 				"phone": data[i].client_info[0]['phone'],
				// 				"address": data[i].client_info[0]['address'],
				// 				"first_name": data[i].client_info[0]['first_name'],
				// 				"last_name": data[i].client_info[0]['last_name'],
				// 				"image": data[i].client_info[0]['image'],
				// 				"isBlocked": data[i].client_info[0]['isBlocked'],
				// 				"payment_info":data[i].payment_info,
				// 				"isPayment" : data[i].isPayment,
				// 				"push_token" : push_tokki,
				// 				"start_date" : data[i].client_info[0].start_date,
				// 				"PAID" : data[i].client_info[0].PAID,
				// 				"payment_type" : data[i].client_info[0].payment_type,
				// 			})
				// 		} else if (data[i].client_info[0]['payment'] == 1) {
				// 			if (!data[i].client_info[0]['no_of_sessions']) {
				// 				data[i].client_info[0]['no_of_sessions'] = ''
				// 			}
				// 			if (!data[i].client_info[0]['punchcard_price']) {
				// 				data[i].client_info[0]['punchcard_price'] = ''
				// 			}
				// 			dat.push({
				// 				"id": req.body.client_id,
				// 				"last_session": last,
				// 				"next_session": next,
				// 				"payment": data[i].client_info[0]['payment'],
				// 				"current_trainer" : data[i]['current_trainer'],
				// 				"punchcard_price": data[i].client_info[0]['punchcard_price'],
				// 				"no_of_sessions": data[i].client_info[0]['no_of_sessions'],
				// 				"user_id": data[i].client_info[0]['user_id'],
				// 				"phone": data[i].client_info[0]['phone'],
				// 				"address": data[i].client_info[0]['address'],
				// 				"first_name": data[i].client_info[0]['first_name'],
				// 				"last_name": data[i].client_info[0]['last_name'],
				// 				"image": data[i].client_info[0]['image'],
				// 				"isBlocked": data[i].client_info[0]['isBlocked'],
				// 				"payment_info":data[i].payment_info,
				// 				"isPayment" : data[i].isPayment,
				// 				"push_token" : push_tokki,
				// 				"start_date" : data[i].client_info[0].start_date,
				// 				"PAID" : data[i].client_info[0].PAID,
				// 				"payment_type" : data[i].client_info[0].payment_type,
				// 			})
				// 		} else if (data[i].client_info[0]['payment'] == 2) {
				// 			if (!data[i]['no_of_sessions_week']) {
				// 				data[i]['no_of_sessions_week'] = ''
				// 			}
				// 			if (!data[i]['monthly_fee']) {
				// 				data[i]['monthly_fee'] = ''
				// 			}
				// 			dat.push({
				// 				"id": req.body.client_id,
				// 				"last_session": last,
				// 				"next_session": next,
				// 				"payment": data[i].client_info[0]['payment'],
				// 				"current_trainer" : data[i]['current_trainer'],
				// 				"no_of_sessions_week": data[i].client_info[0]['no_of_sessions_week'],
				// 				"monthly_fee": data[i].client_info[0]['monthly_fee'],
				// 				"user_id": data[i].client_info[0]['user_id'],
				// 				"phone": data[i].client_info[0]['phone'],
				// 				"address": data[i].client_info[0]['address'],
				// 				"first_name": data[i].client_info[0]['first_name'],
				// 				"last_name": data[i].client_info[0]['last_name'],
				// 				"image": data[i].client_info[0]['image'],
				// 				"isBlocked": data[i].client_info[0]['isBlocked'],
				// 				"payment_info":data[i].payment_info,
				// 				"isPayment" : data[i].isPayment,
				// 				"push_token" : push_tokki,
				// 				"start_date" : data[i].client_info[0].start_date,
				// 				"PAID" : data[i].client_info[0].PAID,
				// 				"payment_type" : data[i].client_info[0].payment_type,
				// 			})
				// 		}
				// 	}

				// }

			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}
	});
}



exports.client_details = async function (req, res) {
	const {
		user_id,
		client_id
	} = req.body;
	if (!user_id || !client_id) {
		res.send({
			"success": false,
			"message": "user_id and client_id is required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	console.log(req.body)
	// dbo.collection('TBL_CLIENTS').aggregate([{
	// 		$match: {
	// 			_id: ObjectId(req.body.client_id)
	// 		}
	// 	},
	dbo.collection('TBL_CLIENTS').aggregate([
		{
			$match: {
				_id: ObjectId(req.body.client_id),
				//trainer_id: ObjectId(req.body.user_id)
			}
		},
		{
			$lookup: {
				from: 'TBL_SESSIONS',
				localField: '_id',
				foreignField: 'client_id',
				as: 'sessions'
			}
		},
		// {
		// 	$lookup: {
		// 		from: 'TBL_CLIENTS',
		// 		localField: 'client_id',
		// 		foreignField: '_id',
		// 		as: 'client_info'
		// 	}
		// },
		// ,
		// {
		// 	$lookup: {
		// 		from: 'TBL_CLIENT_INFO',
		// 		localField: '_id',
		// 		foreignField: 'client_id',
		// 		as: 'client_info'
		// 	}
		// },
		{
			$lookup: {
				from: 'TBL_CARDS',
				localField: 'client_id',
				foreignField: 'trainer_id',
				as: 'payment_info'
			}
		},
		// {
		// 	$lookup: {
		// 		from: 'TBL_PUSH_TOKENS',
		// 		localField: 'client_id',
		// 		foreignField: 'trainer_id',
		// 		as: 'client_push'
		// 	}
		// },
	]).toArray(function (err, resr) {
		console.log("###########################")
		console.log(resr)
		console.log("####################")
		//return res.json(resr)
		if (err) {
			throw err;
		} else {
			if (resr) {
				dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.client_id),
						trainer_id: ObjectId(req.body.user_id),
						status: { $in: [0, 1, 2] }
					}
				},]).toArray(function (err, resr_ses) {
					if (err) {
						throw err;
					} else {
						if (resr_ses) {
							var data_ses = JSON.parse(JSON.stringify(resr_ses));
							var total_sessions = data_ses.length
						}
						else {
							var total_sessions = 0
						}

						dbo.collection('TBL_CLIENT_PUNCH_CARDS').aggregate([
							{
								$match: {
									client_id: ObjectId(req.body.client_id),
									trainer_id: ObjectId(req.body.user_id),
								},
							},
							{
								$sort: {
									created_at: -1
								}
							},
							{

								$lookup: {
									from: 'TBL_TRAINERS',
									localField: 'trainer_id',
									foreignField: '_id',
									as: 'trainerdetails'
								}
							},
							{

								$lookup: {
									from: 'TBL_TRAINER_DETAILS',
									localField: 'trainer_id',
									foreignField: 'user_id',
									as: 'trainer_info_details'
								}
							}
						]).toArray(function (punch_err, client_punch) {
							var res_data = []
							var punch_card = []
							  //return res.json(resr_user)
							var data_user = JSON.parse(JSON.stringify(client_punch));

							for (var k = 0; k < data_user.length; k++) {
								if (!data_user[k]['trainerdetails']) {
									var name = ''
								}
								else {
									var name = data_user[k]['trainerdetails'][0] ? data_user[k]['trainerdetails'][0].name : ""
								}
								punch_card.push({
									"id": data_user[k]['_id'].toString(),
									"sessions": data_user[k]['total_sessions'].toString(),
									"pending": data_user[k]['sessions_available'].toString(),
									"price": data_user[k]['price'].toString(),
									"purchased_date": data_user[k]['created_at'].toString(),
									//"trainer_name": name,
									"first_name": data_user[k]['trainer_info_details'][0].first_name,
									"last_name": data_user[k]['trainer_info_details'][0].last_name,


								})
							}

							var data = JSON.parse(JSON.stringify(resr));
							var dat = [];
							console.log("------------------------->")
							console.log(data)
							//return res.json(data)
							console.log("<------------------------------")
							// return false
							if (!data || data.length == 0) {

							} else {
								for (var i = 0; i < data.length; i++) {
									var push_tokki = [];
									// if (data[i].client_push.length != 0) {
									// 	for (var kl = 0; kl < data[i].client_push.length; kl++) {
									// 		push_tokki.push(data[i].client_push[kl].token)
									// 	}
									// }
									// if (!data[i]) {
									// 	data[i] = []
									// 	data[i].start_date = ''
									// 	data[i].PAID = ''
									// 	data[i].payment_type = '' 
									// }
									if (!data[i].start_date) {
										data[i].start_date = ''
									}
									if (!data[i].PAID) {
										data[i].PAID = ''
									}
									if (!data[i].payment_type) {
										data[i].payment_type = ''
									}
									if (data[i].payment_info.length == 0) {
										data[i].payment_info = []
										data[i].isPayment = '0'
									} else {
										console.log('111')
										data[i].isPayment = '1'
										for (var j = 0; j < data[i].payment_info.length; j++) {
											data[i].payment_info[j].user_id = data[i].payment_info[j].trainer_id;
											data[i].payment_info[j].type = data[i].payment_info[j].payment_type;
											data[i].payment_info[j].id = data[i].payment_info[j]._id;
											if (!data[i].payment_info[j].primary) {
												data[i].payment_info[j].primary = 0
											} else {
												data[i].payment_info[j].primary = parseInt(data[i].payment_info[j].primary)
											}
											delete data[i].payment_info[j].payment_method;
											delete data[i].payment_info[j].trainer_id;
											delete data[i].payment_info[j].paypal_authorization;
											delete data[i].payment_info[j].paypal_email;
											delete data[i].payment_info[j].updated_at;
											delete data[i].payment_info[j].created_at;
											if (data[i].payment_info[j].payment_type == "0") {
												delete data[i].payment_info[j].account_number
												delete data[i].payment_info[j].routing_number
												delete data[i].payment_info[j].account_type
											} else {
												delete data[i].payment_info[j].customer_id
												delete data[i].payment_info[j].cvv
												delete data[i].payment_info[j].mm
												delete data[i].payment_info[j].number
												delete data[i].payment_info[j].number
												delete data[i].payment_info[j].yy
												delete data[i].payment_info[j].zip

											}
											delete data[i].payment_info[j].payment_type
											delete data[i].payment_info[j]._id
										}
										// conso
									}
									if (!data[i]['image']) {
										data[i]['image'] = ''
									}
									if (!data[i]['first_name']) {
										data[i]['first_name'] = ''
									}
									if (!data[i].sessions) {
										var last = ''
										var next = ''
										var last_session_timezone_str = ''
										var next_session_timezone_str = ''
									} else {
										var last = ''
										var next = ''
										var last_session_timezone_str = ''
										var next_session_timezone_str = ''
										var sessionloop = data[i].sessions
										var counts = []
										var session_timezone_str_arr = []
										for (var j = 0; j < sessionloop.length; j++) {
											var goal = getCurrentTime();
											if (sessionloop[j].status != 3 && sessionloop[j].status != 4 && sessionloop[j].status != 5 && req.body.user_id == sessionloop[j].trainer_id) {

												counts.push(parseInt(sessionloop[j].utc))
												session_timezone_str_arr.push(sessionloop[j].timezone_str)

											}

										}
										if (typeof counts != "undefined" && counts != null && counts.length != null && counts.length > 0) {
											counts = counts.sort();
											next = counts.find(e => e >= goal);
											var ses_time_next = arraySearch(counts, next)
											console.log(session_timezone_str_arr)
											var ses_fin_next = session_timezone_str_arr[ses_time_next]
											next_session_timezone_str = ses_fin_next
											console.log('next_session_timezone_str ' + next_session_timezone_str)
											console.log('session_timezone_str_arr ' + session_timezone_str_arr)
											console.log('ses_time_next ' + ses_time_next)
											if (!next_session_timezone_str) {
												next_session_timezone_str = ''
											}
											last = counts.reverse().find(e => e <= goal);
											// last = arrayMin(counts);
											if (!last) {
												last_session_timezone_str = ''
											}
											else {
												var ses_time_last = arraySearch(counts, last)
												var ses_fin_last = session_timezone_str_arr[ses_time_last]
												last_session_timezone_str = ses_fin_last
											}
											console.log('ses_time_last: ' + ses_time_last)
											console.log('ses_fin_last: ' + ses_fin_last)
											console.log('goal: ' + goal)
											console.log('last: ' + last)
											if (last >= goal) {
												last = ''
												last_session_timezone_str = ''
											}
										} else {
											last = ''
											last_session_timezone_str = ''
										}
									}
									if (!data[i]['payment']) {
										console.log('222')
										if (!data[i]['isBlocked']) {
											data[i]['isBlocked'] = '0'
										}
										data[i]['payment'] = -1
										dat.push({
											"id": req.body.client_id,
											"last_session": last,
											"next_session": next,
										//	"current_trainer": data[i].client_info[0]['current_trainer'],
											"payment": data[i]['payment'],
											"user_id": data[i]['user_id'],
											"phone": data[i]['phone_number'],
											"address": data[i]['address'],
											"first_name": data[i]['first_name'],
											"last_name": data[i]['last_name'],
											"image": data[i]['image'],
											"isBlocked": data[i]['isBlocked'],
											"payment_info": data[i].payment_info,
											"isPayment": data[i].isPayment,
											"timezone_str": data[i]['timezone_str'],
											"email": data[i]['email'],
											"push_token": push_tokki,
											"start_date": data[i].start_date,
											"PAID": data[i].PAID,
											"payment_type": data[i].payment_type,
											"no_of_scheduled_sessions": total_sessions.toString(),
											"next_session_timezone_str": next_session_timezone_str.toString(),
											"last_session_timezone_str": last_session_timezone_str.toString(),
											punch_card: punch_card

										})
									} else {
										console.log('333')
										if (!data[i]['isBlocked']) {
											data[i]['isBlocked'] = '0'
										}
										if (data[i]['payment'] == 0) {
											console.log('444')
											if (!data[i]['per_session_fee']) {
												data[i]['per_session_fee'] = ''
											}
											if (!data[i]['session_length']) {
												data[i]['session_length'] = ''
											}
											dat.push({
												"id": req.body.client_id,
												"last_session": last,
												"next_session": next,
												"payment": data[i]['payment'],
												//"current_trainer": data[i].client_info[0]['current_trainer'],
												"per_session_fee": data[i]['per_session_fee'],
												"session_length": data[i]['session_length'],
												"user_id": data[i]['user_id'],
												"phone": data[i]['phone_number'],
												"address": data[i]['address'],
												"first_name": data[i]['first_name'],
												"last_name": data[i]['last_name'],
												"image": data[i]['image'],
												"isBlocked": data[i]['isBlocked'],
												"payment_info": data[i].payment_info,
												"isPayment": data[i].isPayment,
												"timezone_str": data[i]['timezone_str'],
												"email": data[i]['email'],
												"push_token": push_tokki,
												"start_date": data[i].start_date,
												"PAID": data[i].PAID,
												"payment_type": data[i].payment_type,
												"no_of_scheduled_sessions": total_sessions.toString(),
												punch_card: punch_card,
												"next_session_timezone_str": next_session_timezone_str.toString(),
												"last_session_timezone_str": last_session_timezone_str.toString(),
											})
										} else if (data[i]['payment'] == 1) {
											console.log('555')
											if (!data[i]['no_of_sessions']) {
												data[i]['no_of_sessions'] = ''
											}
											if (!data[i]['punchcard_price']) {
												data[i]['punchcard_price'] = ''
											}
											dat.push({
												"id": req.body.client_id,
												"last_session": last,
												"next_session": next,
												"payment": data[i]['payment'],
											//	"current_trainer": data[i].client_info[0]['current_trainer'],
												"punchcard_price": data[i]['punchcard_price'],
												"no_of_sessions": data[i]['no_of_sessions'],
												"user_id": data[i]['user_id'],
												"phone": data[i]['phone_number'],
												"address": data[i]['address'],
												"first_name": data[i]['first_name'],
												"last_name": data[i]['last_name'],
												"timezone_str": data[i]['timezone_str'],
												"email": data[i]['email'],
												"image": data[i]['image'],
												"isBlocked": data[i]['isBlocked'],
												"payment_info": data[i].payment_info,
												"isPayment": data[i].isPayment,
												"push_token": push_tokki,
												"start_date": data[i].start_date,
												"PAID": data[i].PAID,
												"payment_type": data[i].payment_type,
												punch_card: punch_card,
												"no_of_scheduled_sessions": total_sessions.toString(),
												"next_session_timezone_str": next_session_timezone_str.toString(),
												"last_session_timezone_str": last_session_timezone_str.toString(),
											})
										} else if (data[i]['payment'] == 2) {
											console.log('666')
											if (!data[i]['no_of_sessions_week']) {
												data[i]['no_of_sessions_week'] = ''
											}
											if (!data[i]['monthly_fee']) {
												data[i]['monthly_fee'] = ''
											}
											dat.push({
												"id": req.body.client_id,
												"last_session": last,
												"next_session": next,
												"payment": data[i]['payment'],
												//"current_trainer": data[i].client_info[0]['current_trainer'],
												"no_of_sessions_week": data[i]['no_of_sessions_week'],
												"monthly_fee": data[i]['monthly_fee'],
												"user_id": data[i]['user_id'],
												"phone": data[i]['phone_number'],
												"address": data[i]['address'],
												"first_name": data[i]['first_name'],
												"timezone_str": data[i]['timezone_str'],
												"email": data[i]['email'],
												"last_name": data[i]['last_name'],
												"image": data[i]['image'],
												"isBlocked": data[i]['isBlocked'],
												"payment_info": data[i].payment_info,
												"isPayment": data[i].isPayment,
												"push_token": push_tokki,
												"start_date": data[i].start_date,
												"PAID": data[i].PAID,
												"payment_type": data[i].payment_type,
												punch_card: punch_card,
												"no_of_scheduled_sessions": total_sessions.toString(),
												"next_session_timezone_str": next_session_timezone_str.toString(),
												"last_session_timezone_str": last_session_timezone_str.toString(),
											})
										}
									}

								}
							}
							console.log(dat[0])
							res.send({
								"success": true,
								"message": "Success",
								"data": dat[0]
							});
							return false;
						})
						// }
					}
				});

				// for (var i = 0; i < data.length; i++) {
				// 	var push_tokki = [];
				// 	if (data[i].client_push.length != 0 ) {
				// 		for (var kl = 0; kl < data[i].client_push.length; kl++) {
				// 			push_tokki.push(data[i].client_push[kl].token)
				// 		}
				// 	}
				// 	if (!data[i].client_info) {
				// 		data[i].client_info = []
				// 		data[i].client_info[0].start_date = ''
				// 		data[i].client_info[0].PAID = ''
				// 		data[i].client_info[0].payment_type = '' 
				// 	}
				// 	if (!data[i].client_info[0].start_date) {
				// 		data[i].client_info[0].start_date = ''
				// 	}
				// 	if (!data[i].client_info[0].PAID){
				// 		data[i].client_info[0].PAID = ''
				// 	}
				// 	if (!data[i].client_info[0].payment_type){
				// 		data[i].client_info[0].payment_type = '' 
				// 	}
				// 	if(data[i].payment_info.length == 0){
				// 		data[i].payment_info = []
				// 		data[i].isPayment = '0'
				// 	}
				// 	else{
				// 		data[i].isPayment = '1'
				// 		for (var j = 0; j < data[i].payment_info.length; j++) {
				//           data[i].payment_info[j].user_id = data[i].payment_info[j].trainer_id;
				//           data[i].payment_info[j].type = data[i].payment_info[j].payment_type;
				//           data[i].payment_info[j].id = data[i].payment_info[j]._id;
				//           if (!data[i].payment_info[j].primary) {
				//             data[i].payment_info[j].primary = 0
				//           }
				//           else{
				//             data[i].payment_info[j].primary = 1
				//           }
				//           delete data[i].payment_info[j].payment_method;
				//           delete data[i].payment_info[j].trainer_id;
				//           delete data[i].payment_info[j].paypal_authorization;
				//           delete data[i].payment_info[j].paypal_email;
				//           delete data[i].payment_info[j].updated_at;
				//           delete data[i].payment_info[j].created_at;
				//           if (data[i].payment_info[j].payment_type == "0") {
				//             delete data[i].payment_info[j].account_number
				//             delete data[i].payment_info[j].routing_number
				//             delete data[i].payment_info[j].account_type
				//           }
				//           else{
				//             delete data[i].payment_info[j].customer_id
				//             delete data[i].payment_info[j].cvv
				//             delete data[i].payment_info[j].mm
				//             delete data[i].payment_info[j].number
				//             delete data[i].payment_info[j].number
				//             delete data[i].payment_info[j].yy
				//             delete data[i].payment_info[j].zip

				//           }
				//           delete data[i].payment_info[j].payment_type
				//           delete data[i].payment_info[j]._id
				//         }
				//         // conso
				// 	}
				// 	if (!data[i]['image']) {
				// 		data[i]['image'] = ''
				// 	}
				// 	if (!data[i]['first_name']) {
				// 		data[i]['first_name'] = ''
				// 	}
				// 	if (!data[i].sessions) {
				// 		var last = ''
				// 		var next = ''
				// 	} else {
				// 		var last = ''
				// 		var next = ''

				// 		var sessionloop = data[i].sessions
				// 		var counts = []
				// 		for (var j = 0; j < sessionloop.length; j++) {
				// 			var goal = getCurrentTime();
				// 			if (sessionloop[j].status != 3 && sessionloop[j].status != 4  && sessionloop[j].status != 5 && req.body.user_id == sessionloop[j].trainer_id) {
				// 				// console.log(sessionloop[j])
				// 				counts.push(parseInt(sessionloop[j].utc))
				// 				// if (parseInt(sessionloop[j].utc) > goal && next == '') {
				// 				// 	next = sessionloop[j].utc
				// 				// 	console.log('next_1:  '+next)
				// 				// }
				// 				// if (next > goal && next > parseInt(sessionloop[j].utc)) {
				// 				// 	next = sessionloop[j].utc
				// 				// 	console.log('next_2:  '+next)
				// 				// }
				// 			}

				// 		}
				// 		if (typeof counts != "undefined" && counts != null && counts.length != null && counts.length > 0) {
				// 			// var goal1 = getCurrentTime();
				// 			// last = counts.reduce((prev, curr) => Math.abs(curr - goal) < Math.abs(prev - goal) ? curr : prev);
				// 			counts = counts.sort(); 
				// 			next = counts.find(e => e >= goal);
				// 			last = counts.reverse().find(e => e <= goal);
				// 			// last = arrayMin(counts);
				// 			console.log('goal: '+goal)
				// 			console.log('last: '+last)
				// 			if (last >= goal) {
				// 				last = ''
				// 			}
				// 		} else {
				// 			last = ''
				// 		}
				// 	}
				// 	if (!data[i].client_info[0]['payment']) {
				// 		if (!data[i].client_info[0]['isBlocked']) {
				// 			data[i].client_info[0]['isBlocked'] = '0'
				// 		}
				// 		data[i].client_info[0]['payment'] = -1
				// 		dat.push({
				// 			"id": req.body.client_id,
				// 			"last_session": last,
				// 			"next_session": next,
				// 			"current_trainer" : data[i]['current_trainer'],
				// 			"payment": data[i].client_info[0]['payment'],
				// 			"user_id": data[i].client_info[0]['user_id'],
				// 			"phone": data[i].client_info[0]['phone'],
				// 			"address": data[i].client_info[0]['address'],
				// 			"first_name": data[i].client_info[0]['first_name'],
				// 			"last_name": data[i].client_info[0]['last_name'],
				// 			"image": data[i].client_info[0]['image'],
				// 			"isBlocked": data[i].client_info[0]['isBlocked'],
				// 			"payment_info":data[i].payment_info,
				// 			"isPayment" : data[i].isPayment,
				// 			"push_token" : push_tokki,
				// 			"start_date" : data[i].client_info[0].start_date,
				// 			"PAID" : data[i].client_info[0].PAID,
				// 			"payment_type" : data[i].client_info[0].payment_type,

				// 		})
				// 	} else {
				// 		if (!data[i].client_info[0]['isBlocked']) {
				// 			data[i].client_info[0]['isBlocked'] = '0'
				// 		}
				// 		if (data[i].client_info[0]['payment'] == 0) {
				// 			if (!data[i].client_info[0]['per_session_fee']) {
				// 				data[i].client_info[0]['per_session_fee'] = ''
				// 			}
				// 			if (!data[i].client_info[0]['session_length']) {
				// 				data[i].client_info[0]['session_length'] = ''
				// 			}
				// 			dat.push({
				// 				"id": req.body.client_id,
				// 				"last_session": last,
				// 				"next_session": next,
				// 				"payment": data[i].client_info[0]['payment'],
				// 				"current_trainer" : data[i]['current_trainer'],
				// 				"per_session_fee": data[i].client_info[0]['per_session_fee'],
				// 				"session_length": data[i].client_info[0]['session_length'],
				// 				"user_id": data[i].client_info[0]['user_id'],
				// 				"phone": data[i].client_info[0]['phone'],
				// 				"address": data[i].client_info[0]['address'],
				// 				"first_name": data[i].client_info[0]['first_name'],
				// 				"last_name": data[i].client_info[0]['last_name'],
				// 				"image": data[i].client_info[0]['image'],
				// 				"isBlocked": data[i].client_info[0]['isBlocked'],
				// 				"payment_info":data[i].payment_info,
				// 				"isPayment" : data[i].isPayment,
				// 				"push_token" : push_tokki,
				// 				"start_date" : data[i].client_info[0].start_date,
				// 				"PAID" : data[i].client_info[0].PAID,
				// 				"payment_type" : data[i].client_info[0].payment_type,
				// 			})
				// 		} else if (data[i].client_info[0]['payment'] == 1) {
				// 			if (!data[i].client_info[0]['no_of_sessions']) {
				// 				data[i].client_info[0]['no_of_sessions'] = ''
				// 			}
				// 			if (!data[i].client_info[0]['punchcard_price']) {
				// 				data[i].client_info[0]['punchcard_price'] = ''
				// 			}
				// 			dat.push({
				// 				"id": req.body.client_id,
				// 				"last_session": last,
				// 				"next_session": next,
				// 				"payment": data[i].client_info[0]['payment'],
				// 				"current_trainer" : data[i]['current_trainer'],
				// 				"punchcard_price": data[i].client_info[0]['punchcard_price'],
				// 				"no_of_sessions": data[i].client_info[0]['no_of_sessions'],
				// 				"user_id": data[i].client_info[0]['user_id'],
				// 				"phone": data[i].client_info[0]['phone'],
				// 				"address": data[i].client_info[0]['address'],
				// 				"first_name": data[i].client_info[0]['first_name'],
				// 				"last_name": data[i].client_info[0]['last_name'],
				// 				"image": data[i].client_info[0]['image'],
				// 				"isBlocked": data[i].client_info[0]['isBlocked'],
				// 				"payment_info":data[i].payment_info,
				// 				"isPayment" : data[i].isPayment,
				// 				"push_token" : push_tokki,
				// 				"start_date" : data[i].client_info[0].start_date,
				// 				"PAID" : data[i].client_info[0].PAID,
				// 				"payment_type" : data[i].client_info[0].payment_type,
				// 			})
				// 		} else if (data[i].client_info[0]['payment'] == 2) {
				// 			if (!data[i]['no_of_sessions_week']) {
				// 				data[i]['no_of_sessions_week'] = ''
				// 			}
				// 			if (!data[i]['monthly_fee']) {
				// 				data[i]['monthly_fee'] = ''
				// 			}
				// 			dat.push({
				// 				"id": req.body.client_id,
				// 				"last_session": last,
				// 				"next_session": next,
				// 				"payment": data[i].client_info[0]['payment'],
				// 				"current_trainer" : data[i]['current_trainer'],
				// 				"no_of_sessions_week": data[i].client_info[0]['no_of_sessions_week'],
				// 				"monthly_fee": data[i].client_info[0]['monthly_fee'],
				// 				"user_id": data[i].client_info[0]['user_id'],
				// 				"phone": data[i].client_info[0]['phone'],
				// 				"address": data[i].client_info[0]['address'],
				// 				"first_name": data[i].client_info[0]['first_name'],
				// 				"last_name": data[i].client_info[0]['last_name'],
				// 				"image": data[i].client_info[0]['image'],
				// 				"isBlocked": data[i].client_info[0]['isBlocked'],
				// 				"payment_info":data[i].payment_info,
				// 				"isPayment" : data[i].isPayment,
				// 				"push_token" : push_tokki,
				// 				"start_date" : data[i].client_info[0].start_date,
				// 				"PAID" : data[i].client_info[0].PAID,
				// 				"payment_type" : data[i].client_info[0].payment_type,
				// 			})
				// 		}
				// 	}

				// }

			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}
	});
}


exports.profile = async function (req, res) {
	const {
		user_id
	} = req.body;
	if (!user_id) {
		res.send({
			"success": false,
			"message": "user_id is required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_TRAINERS').aggregate([{
		$match: {
			_id: ObjectId(user_id)
		}
	},
	{
		$lookup: {
			from: 'TBL_TRAINER_DETAILS',
			localField: '_id',
			foreignField: 'user_id',
			as: 'userdetails'
		}
	},
	{
		$lookup: {
			from: 'TBL_SERVICES',
			localField: 'services.id',
			foreignField: '_id',
			as: 'services'
		}
	},
	{
		$lookup: {
			from: 'TBL_PUSH_TOKENS',
			localField: '_id',
			foreignField: 'trainer_id',
			as: 'trainer_push'
		}
	},

	]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {
			if (resr) {
				//	return res.json(resr)

				var data = JSON.parse(JSON.stringify(resr));
				// if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
				// 	var gov_id_verified = true;
				// } else {
				var gov_id_verified = false;
				// }
				var push_tokki = [];
				if (data[0].trainer_push.length != 0) {
					for (var kl = 0; kl < data[0].trainer_push.length; kl++) {
						push_tokki.push(data[0].trainer_push[kl].token)
					}
				}
				data = {
					"user_id": data[0]['_id'],
					"first_name": data[0]['userdetails'][0]['first_name'],
					"last_name": data[0]['userdetails'][0]['last_name'],
					"phone_number": data[0]['userdetails'][0]['phone_number'],
					"phone_verified": data[0]['userdetails'][0]['phone_verified'],
					"email_verified": data[0]['userdetails'][0]['email_verified'],
					"goverment_id": data[0]['userdetails'][0]['goverment_id'],
					"gov_id_verified": gov_id_verified,
					"selfie": data[0]['userdetails'][0]['selfie'],
					"image": data[0]['userdetails'][0]['image'],
					"status": data[0]['status'],
					"email": data[0]['email'],
					"type": data[0]['type'],
					"social": data[0]['social_id'],
					"services": data[0]['services'],
					"bio": data[0]['userdetails'][0]['bio'],
					"timezone": data[0]['timezone'],
					"timezone_str": data[0]['timezone_str'],
					"user_type": data[0]['user_type'],
					"push_token": push_tokki,

				}
				res.send({
					"success": true,
					"message": "Success",
					"data": data
				});
				return false;
			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}

	});
}
exports.remove_client = async function (req, res) {
	if (!req.body.user_id || !req.body.client_id) {
		res.send({
			"success": false,
			"message": "user_id or client_id empty",
			"data": []
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	var myquery = {
		_id: ObjectId(req.body.client_id)
	};
	// dbo.collection('TBL_CLIENTS').updateOne({
	dbo.collection('TBL_CLIENT_INFO').updateOne({
		client_id: ObjectId(req.body.client_id),
		trainer_id: ObjectId(req.body.user_id)
		// _id: ObjectId(req.body.client_id)
	}, {
		$set: {
			'disabled': 1
		},
		// $unset: {'phone_check':1},
	}, function (err, rese) {
		if (err) {
			res.send({
				"success": true,
				"message": "Unable to save data.",
				"data": {}
			});
			return false;
		} else {
			// dbo.collection('TBL_CLIENT_INFO').updateMany({
			// 	client_id: ObjectId(req.body.client_id)
			// }, {
			// 	$set: {
			// 		'disabled': 1
			// 	}
			// })
			res.send({
				"success": true,
				"message": 'We have successfully deleted the requested client',
				"data": []
			});
		}
	})
	// dbo.collection("TBL_CLIENTS").deleteOne(myquery, function (err, obj) {
	// 	if (err) throw err;
	// 	res.send({
	// 		"success": true,
	// 		"message": 'We have successfully deleted the requested client',
	// 		"data": []
	// 	});
	// });
}
exports.client_profile = async function (req, res) {
	if (!req.body.user_id) {
		res.send({
			"success": false,
			"message": "user_id empty",
			"data": []
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_CLIENTS').aggregate([{
		$match: {
			_id: ObjectId(req.body.user_id),
		}
	},]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {
			if (!req.body.trainer_id) {
				var data = JSON.parse(JSON.stringify(resr));
				if (data[0]['goverment_id'] != undefined) {
					var gov_id_verified = true;
				} else {
					var gov_id_verified = false;
				}
				if (!data[0]['current_trainer']) {
					data[0]['current_trainer'] = ''
				}
				data = {
					"user_id": data[0]['_id'],
					"first_name": data[0]['first_name'],
					"last_name": data[0]['last_name'],
					"phone_number": data[0]['phone'],
					"email": data[0]['email'],
					"user_type": data[0]['user_type'].toString(),
					"trainer_id": data[0]['current_trainer'],
					// "phone_verified": data[0]['phone_verified'],
					// "email_verified": data[0]['email_verified'],
					"goverment_id": data[0]['goverment_id'],
					// "gov_id_verified": gov_id_verified,
					"selfie": data[0]['selfie'],
					"image": data[0]['image'],
					"status": data[0]['status'],
					"email": data[0]['email'],
					"social_id": data[0]['social_id'],
					// "services": data[0]['services'],
					"bio": data[0]['bio'],
					"timezone": data[0]['timezone'],
					"timezone_str": data[0]['timezone_str'],
					"type": data[0]['type']
				}
				res.send({
					"success": true,
					"message": "Success",
					"data": data
				});
			} else {
				dbo.collection('TBL_CLIENTS_DETAILS').aggregate([{
					$match: {
						user_id: ObjectId(req.body.user_id),
						//trainer_id: ObjectId(req.body.trainer_id),
					}
				},]).toArray(function (err, resr1) {
					if (err) {
						throw err;
					} else {
						var data = JSON.parse(JSON.stringify(resr));
						console.log(resr1)
						if (data[0]['goverment_id'] != undefined) {
							var gov_id_verified = true;
						} else {
							var gov_id_verified = false;
						}
						if (!data[0]['current_trainer']) {
							data[0]['current_trainer'] = ''
						}
						data = {
							"user_id": data[0]['_id'],
							"first_name": resr1[0]['first_name'],
							"last_name": resr1[0]['last_name'],
							"phone_number": data[0]['phone'],
							"email": data[0]['email'],
							"user_type": data[0]['user_type'].toString(),
							"trainer_id": data[0]['current_trainer'],
							// "phone_verified": data[0]['phone_verified'],
							// "email_verified": data[0]['email_verified'],
							"goverment_id": data[0]['goverment_id'],
							// "gov_id_verified": gov_id_verified,
							"selfie": data[0]['selfie'],
							"image": resr1[0]['image'],
							"status": data[0]['status'],
							"email": data[0]['email'],
							"social_id": data[0]['social_id'],
							// "services": data[0]['services'],
							"bio": data[0]['bio'],
							"timezone": data[0]['timezone'],
							"timezone_str": data[0]['timezone_str'],
							"type": data[0]['type']
						}
						res.send({
							"success": true,
							"message": "Success",
							"data": data
						});
					}
				});

			}

		}
	});
}
exports.client_trainer = async function (req, res) {
	if (!req.body.client_id) {
		res.send({
			"success": false,
			"message": "client_id empty",
			"data": []
		});
		return false;
	}
	var myquery = {
		_id: ObjectId(req.body.client_id)
	};
	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_CLIENTS').aggregate([{
		$match: {
			_id: ObjectId(req.body.client_id),
		}
	},]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {
			if (!resr[0].current_trainer) {
				var trainer_id = ''
			} else {
				var trainer_id = resr[0].current_trainer
			}
			var dat = {}
			dat = {
				'trainer_id': trainer_id,
				'client_id': req.body.client_id
			}
			res.send({
				"success": true,
				"message": "Success",
				"data": dat
			});
		}
	});
}

exports.trainer_connect = async function (req, res) {
	if (!req.body.trainer_id || !req.body.client_id) {
		res.send({
			"success": false,
			"message": "trainer_id or client_id empty",
			"data": []
		});
		return false;
	}
	// current_client_id
	let dbo = await mongodbutil.Get();
	var client_ids = req.body.client_id
	var old_client = req.body.current_client_id
	req.body.updated_at = getCurrentTime()
	delete req.body.client_id
	delete req.body.current_client_id
	// req.body.phone = req.body.phone.replace(/\D/g, '');

	var query = {
		'_id': ObjectId(client_ids)
	};
	var update = {
		$set: {
			current_trainer: ObjectId(req.body.trainer_id),
			disabled: 0,
			isSignup: 1
		}
	};
	var options = {
		upsert: true
	};
	dbo.collection('TBL_CLIENTS').findOneAndUpdate(query, update, options, function (err, resv) {
		if (err) {
			throw err;
		} else {
			if (resv.lastErrorObject.updatedExisting == true) {
				var user_id1 = resv.value._id
			} else {
				var user_id1 = resv.lastErrorObject.upserted
			}
			dbo.collection("TBL_CLIENTS").deleteOne({
				client_id: ObjectId(old_client)
			}, function (err, obj) {
				console.log(obj)
			})
			dbo.collection('TBL_CLIENT_INFO').updateMany({
				client_id: ObjectId(old_client)
			}, {
				$set: {
					client_id: ObjectId(client_ids)
				}
			})
			dbo.collection('TBL_SESSIONS').updateMany({
				client_id: ObjectId(old_client)
			}, {
				$set: {
					client_id: ObjectId(client_ids)
				}
			})
			dbo.collection('TBL_CLIENTS').aggregate([{
				$match: {
					_id: ObjectId(user_id1)
				}
			},]).toArray(function (err, resr) {
				if (err) {
					throw err;
				} else {
					if (resr) {
						var dat = {}
						var data = JSON.parse(JSON.stringify(resr));
						console.log(data)
						if (!data[0]['phone']) {
							data[0]['phone'] = ''
						}
						dat = {
							"user_id": data[0]['_id'],
							"first_name": data[0]['first_name'],
							"last_name": data[0]['last_name'],
							"phone": data[0]['phone'],
							"email": data[0]['email'],
							"user_type": data[0]['user_type'].toString(),
							"image": data[0]['image'],
							"status": data[0]['status'],
							"email": data[0]['email'],
							"bio": data[0]['bio'],
							"timezone": data[0]['timezone'],
							"timezone_str": data[0]['timezone_str'],
							"type": data[0]['type']
						}
						res.send({
							"success": true,
							"message": "Client connected successfully!",
							"data": dat
						});
						return false;
					} else {
						res.send({
							"success": false,
							"message": "something went wrong",
							"data": {}
						});
						return false;
					}
				}

			});
		}
	});

}
exports.trainer_client_list_info = async function (req, res) {
	const {
		trainer_id
	} = req.body;
	if (!trainer_id) {
		res.send({
			"success": false,
			"message": "trainer_id is required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();

	dbo.collection('TBL_CLIENT_INFO').aggregate([

		{
			$lookup: {
				from: 'TBL_CLIENTS',
				localField: 'client_id',
				foreignField: '_id',
				as: 'client_info'
			}
		},
		{
			$lookup: {
				from: 'TBL_PUSH_TOKENS',
				localField: 'client_id',
				foreignField: 'trainer_id',
				as: 'client_push'
			}
		},
		{
			$match: {
				trainer_id: ObjectId(req.body.trainer_id),
				client_id: ObjectId(req.body.client_id),
			}
		},
		// {
		// 	"$unwind": "$client_info"
		// },
		// {
		// 	"$match": {
		// 		"client_info.trainer_id": ObjectId(req.body.trainer_id),
		// 		"client_info._id": ObjectId(req.body.client_id),
		// 	}
		// },
	]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {
			if (resr) {
				var data = JSON.parse(JSON.stringify(resr));
				var dat = [];

				if (!data[0]) {
					data = []
				} else {
					data = data
				}

				for (var i = 0; i < data.length; i++) {
					var push_tokki = [];

					if (!data[i].client_info) {

					} else {
						var client_info2 = data[i]['client_info'];
						// data[i]['client_info'] = []
						// data[i]['client_info'].push({
						// 	first_name: client_info2.first_name,
						// 	last_name: client_info2.last_name,
						// 	image: client_info2.image,
						// 	timezone: client_info2.timezone,
						// 	isSignup: client_info2.isSignup,
						// })

						if (!data[i]['image']) {
							data[i]['image'] = ''
						}
						if (!data[i]['first_name']) {
							data[i]['first_name'] = ''
						}
						if (!data[i].client_info[0]['isSignup']) {
							data[i].client_info[0]['isSignup'] = 0
						} else {
							data[i].client_info[0]['isSignup'] = 1
						}
						if (!data[i]['isBlocked']) {
							data[i]['isBlocked'] = '0'
						} else {
							data[i]['isBlocked'] = data[i]['isBlocked'];
						}
						if (data[i].client_push.length != 0) {
							for (var kl = 0; kl < data[i].client_push.length; kl++) {
								push_tokki.push(data[i].client_push[kl].token)
							}
						}

						dat.push({
							"id": data[i]['client_id'],
							"user_id": data[i]['user_id'],
							"phone": data[i]['phone'],
							"address": data[i]['address'],
							"first_name": data[i]['first_name'],
							"last_name": data[i]['last_name'],
							"image": data[i]['image'],
							"isSignup": data[i].client_info[0]['isSignup'],
							"current_trainer": data[i].client_info[0]['current_trainer'],
							"isBlocked": data[i]['isBlocked'],
							"push_token": push_tokki
						})


					}

					// }

				}
				res.send({
					"success": true,
					"message": "Success",
					"data": dat[0]
				});
				return false;
			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}
	});
}

exports.chat_user_info = async function (req, res) {
	if (!req.body.client_id || !req.body.trainer_id) {
		res.send({
			"success": false,
			"message": "client_id or trainer_id empty",
			"data": []
		});
		return false;
	}

	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_CLIENT_INFO').aggregate([{
		$match: {
			client_id: ObjectId(req.body.client_id),
			trainer_id: ObjectId(req.body.trainer_id),
		}
	},
	{
		$lookup: {
			from: 'TBL_TRAINER_DETAILS',
			localField: 'trainer_id',
			foreignField: 'user_id',
			as: 'trainer'
		}
	},
	]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {
			if (!resr[0].image) {
				resr[0].image = ''
			}
			if (!resr[0].trainer[0].image) {
				resr[0].trainer[0].image = ''
			}
			data = {
				'client_name': resr[0].first_name + ' ' + resr[0].last_name,
				'client_image': resr[0].image,
				'trainer_name': resr[0].trainer[0].first_name + ' ' + resr[0].trainer[0].last_name,
				'trainer_image': resr[0].trainer[0].image

			}
			res.send({
				"success": true,
				"message": "Success",
				"data": data
			});
			return false;
		}
	});
}
// API Params:
// client_id
// trainer_id

// Response:
async function unsubscribe_authorize(subscriptionId) {

	var merchantAuthenticationType = new ApiContracts.MerchantAuthenticationType();
	merchantAuthenticationType.setName(constants.apiLoginKey);
	merchantAuthenticationType.setTransactionKey(constants.transactionKey);

	var cancelRequest = new ApiContracts.ARBCancelSubscriptionRequest();
	cancelRequest.setMerchantAuthentication(merchantAuthenticationType);
	cancelRequest.setSubscriptionId(subscriptionId);

	// console.log(JSON.stringify(cancelRequest.getJSON(), null, 2));

	var ctrl = new ApiControllers.ARBCancelSubscriptionController(cancelRequest.getJSON());

	ctrl.execute(function () {

		var apiResponse = ctrl.getResponse();

		var response = new ApiContracts.ARBCancelSubscriptionResponse(apiResponse);

		// console.log(JSON.stringify(response, null, 2));

		if (response != null) {
			if (response.getMessages().getResultCode() == ApiContracts.MessageTypeEnum.OK) {
				console.log('Message Code : ' + response.getMessages().getMessage()[0].getCode());
				console.log('Message Text : ' + response.getMessages().getMessage()[0].getText());
				return '123'
			}
			else {
				console.log('Result Code: ' + response.getMessages().getResultCode());
				console.log('Error Code: ' + response.getMessages().getMessage()[0].getCode());
				console.log('Error message: ' + response.getMessages().getMessage()[0].getText());

				return '321'
			}
		}
		else {
			console.log('Null Response.');

			return '321'
		}

		return '321'
		// callback(response);
		// console.log(response)


	});
}
function getCurrentTime() {
	var d = new Date();
	var n = d.toUTCString();
	var date = new Date(n);
	var seconds = date.getTime() / 1000; //1440516958
	return seconds;
}

function arrayMin(array) {
	return Math.min.apply(Math, array);
};
function arraySearch(arr, val) {
	for (var i = 0; i < arr.length; i++)
		if (arr[i] === val)
			return i;
	return false;
}