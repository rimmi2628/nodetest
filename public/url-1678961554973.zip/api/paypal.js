var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
var braintree = require("braintree");


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);

 var gateway = braintree.connect({
  environment: braintree.Environment.Sandbox,
  merchantId: "8vth6dk6nd73mq4v",
  publicKey: "569v88wmkphh5k4d",
  privateKey: "c1e0991931c219069f06d36b67a28ee3"
});

exports.paypal = function(req, res) { 

	var fName = req.body.first_name;
	var lName = req.body.last_name;
	var email = req.body.email;
	var phone = req.body.phone;
	gateway.customer.create({
	  firstName: fName,
	  lastName: lName,
	  // company: "enact",
	  email: email,
	  phone: phone,
	  // fax: "614.555.5678",
	  // website: "www.example.com"
	}, function (err, result) {
	  // result.success;
	  // true
	  // res.send({"success":false,"message":"Payment type empty","data":{}});
	  console.log(result)
	  gateway.clientToken.generate({
		  customerId: result.customer.id
		}, function (err, response) {
		  var clientToken = response.clientToken
		  // console.log(response)
		});
	});

}
exports.withcardPaypal = function(req,res){
	var fName = req.body.first_name;
	var lName = req.body.last_name;
	var email = req.body.email;
	var phone = req.body.phone;
	var price = req.body.amount;
	gateway.customer.create({
	  firstName: fName,
	  lastName: lName,
	  // company: "enact",
	  email: email,
	  phone: phone,
	  // paymentMethodNonce: "3a8e9c3e-b609-012f-5ce2-6a6badc38815",
	  paymentMethodNonce: "fake-valid-nonce",

	}, function (err, result) {
	  // result.success;
	  // true
	  console.log(result)
	  console.log(result.customer.paymentMethods[0])
	  	gateway.transaction.sale({
		  amount: price,
		  // paymentMethodToken: result.customer.paymentMethods[0].token,
		  paymentMethodToken: '6t4j276',
		  transactionSource: "recurring",
		  options: {
		    submitForSettlement: true,
		  }
		}, function(err, data) {
			console.log(data)
			res.send({"data":data});
		});
	  // result.customer.id;
	  // e.g 160923
	  
	  // result.customer.paymentMethods[0].token;

	  // e.g f28wm
	});
}
exports.transactionPaypal = function(req,res){

}