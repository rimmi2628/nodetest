var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";




var sourceFile = require('./register.js');
// console.log(sourceFile)
var db = mongo.connect("mongodb://localhost:27017/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
   if(err){ console.log( err); }  
   else{ //console.log('Connected to ' + db, ' + ', response); 
    }  
});  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);


var mongodbutil = require( './mongodbutil' );

 exports.upload_id = async function(req, res) {
//  app.post('/api/upload_id', (req, res) => {
  // console.log(req.files);return;
  console.log('--------upload---->')
  console.log(req.body,req.files)
  console.log('<--------upload----')
  const {user_id,type} = req.body;
  if (!type || !user_id) {
    res.send({"success":false,"message":"Please enter all fields","data":{}});
    return false;
  }
  if(req.files != undefined ){ 
        var sampleFile = req.files.image;
         var location = path.join(__dirname, '../../uploads/images'); 
        sampleFile.mv(location + "/" + sampleFile.md5+"."+req.files.image.mimetype.split('/')[1], function(err) {
          if (err){
            res.send({"success":false,"message":"Unable to fetch image","data":{}});
            return false;
          }
          else{
            var image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];

            console.log('------------>',image,'<-------------')

   
            sourceFile.TBL_TRAINER_DETAILS.findOne({user_id: ObjectId(user_id) }).then(async user => {
              //console.log(user)
              if(type==0){
                var ttt ={goverment_id:image};
              }
              else{
                var ttt ={selfie:image};
              }
              if (user) {
                sourceFile.TBL_TRAINER_DETAILS.findOneAndUpdate({_id: user._id}, {$set: ttt}, {upsert: true}, async function(err,doc) {
                  if (err) {
                    console.log(err)
                    res.send({"success":false,"message":"Failed to update User","data":[]});
                    return false;
                    }
                  else {
                    sourceFile.TBL_TRAINERS.findOne({ _id: user_id }).then(async user => {
                      if (user) {
                        // MongoClient.connect(url, function(err, db) {
                          let dbo =  await mongodbutil.Get();
                          // if (err) throw err;
                          // var dbo = db.db("gymtraining");
                          var query = { _id: user_id };
                          dbo.collection('TBL_TRAINERS').aggregate([
                            { $match : { _id : ObjectId(user_id) } } ,
                            { 
                              $lookup:
                              {
                                from: 'TBL_TRAINER_DETAILS',
                                localField: '_id',
                                foreignField: 'user_id',
                                as: 'userdetails'
                              }
                            },
                            {
                              $lookup : 
                              {
                                from : 'TBL_SERVICES', 
                                localField: 'services.id', 
                                foreignField: '_id', 
                                as : 'services'
                              }
                             },
                            
                            
                            ]).toArray(function(err, resr) {
                            if (err){
                              throw err;
                            }
                            else{
                              if(resr){
                                
                                var data = JSON.parse(JSON.stringify(resr));
                                if(data[0]['userdetails'][0]['goverment_id'] != undefined){
                                  var gov_id_verified = true;
                                }
                                else{
                                  var gov_id_verified = false;
                                }
                                  data={
                                        "user_id":data[0]['_id'],
                                        "first_name":data[0]['userdetails'][0]['first_name'],
                                        "last_name":data[0]['userdetails'][0]['last_name'],
                                        "phone_number":data[0]['userdetails'][0]['phone_number'],
                                        "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                                        "email_verified":data[0]['userdetails'][0]['email_verified'],
                                        "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                                        "gov_id_verified":gov_id_verified,
                                        "selfie":data[0]['userdetails'][0]['selfie'],
                                        "image":data[0]['userdetails'][0]['image'],
                                        "status":data[0]['status'],
                                        "services":data[0]['services']
                                    }


                                  // delete resr[0].password
                                  // delete resr[0].__v
                                  res.send({"success":true,"message":"id uploaded successfull","data":data});
                                  return false;
                              }
                              else{
                                res.send({"success":false,"message":"something went wrong","data":{}});
                                return false;
                              }
                            }
                            
                          });
                        // });
                      }
                      else{
                        res.send({"success":false,"message":"Something went wrong","data":{}});
                        return false;
                      } 
                    })
                    }
                });
              } 
              else {
                res.send({"success":false,"message":"User not found","data":{}});
                return false;
              }
            }) 

          } 
        });
  }
  else{
    res.send({"success":false,"message":"Unable to fetch image","data":[]});
    return false;
  }
};