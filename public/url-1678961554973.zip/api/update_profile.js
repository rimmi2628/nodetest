
var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
var nodemailer = require('nodemailer');


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());




var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;
var transporter = nodemailer.createTransport({
	service: 'outlook',
	auth: {
		user: 'ravikantenact@gmail.com',
		pass: 'Panda999$'
	}
});


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.update_profile = async function (req, res) {
	//console.log(req.body)
	//return 

	if (req.body.user_type == '0') {
		if (!(req.body.user_id && req.body.first_name && req.body.last_name && req.body.bio && req.body.services && req.body.email)) {
			res.send({ "success": false, "message": "Please send all fields", "data": [] });
			return false;
		}
		console.log("user_id", req.body.user_id)
		// MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
		// if (err) throw err;
		let dbo = await mongodbutil.Get();
		dbo.collection('TBL_TRAINERS').aggregate([
			{
				$match: {
					_id: ObjectId(req.body.user_id)
				}
			}
		]).toArray(function (err, resr) {
			if (err) {
				throw err;
			}
			else {
				if (resr) {
					var setVar = {}
					user_id = req.body.user_id;
					user = resr[0];
					var image = '';
					if (user.email != req.body.email) {
						dbo.collection('TBL_TRAINERS').findOne({ email: req.body.email, _id: { $ne: ObjectId(req.body.user_id) } }).then(user => {
							if (user) {
								res.send({ "success": false, "message": "Email already taken", "data": {} });
								return false;
							}
						});
					}
					// var sampleFile = req.files.image;
					var location = path.join(__dirname, '../../uploads/images');
					if (req.files != undefined || req.files != null) {
						var sampleFile = req.files.image;
						sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1], function (err) {
							if (err) {
								res.send({ "success": false, "message": "Unable to fetch image", "data": {} });
								return false;
							}
							else {
								image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
								console.log("image", image)
							}
						})
						image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
					}

					// image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
					var serv = [];
					if (req.body.services) {
						var array = req.body.services.split(',');
						for (var i = 0; i < array.length; i++) {
							serv.push({ id: ObjectId(array[i]) });
						}
					}
					//console.log(serv);return
					//var service =[{id:ObjectId("5e5e0fa8f03a4e713238c562")},{id:ObjectId("5e5e0ff4f03a4e713238c563")}];

					var service_error = 0;
					var detail_error = 0;
					// var image_error = 0;
					var message = "Data updated successfully";
					//var setVar = { services: serv, bio: req.body.bio };
					if (user.email != req.body.email) {
						var verifyEmailId = makeid(20);
						setVar = { email: req.body.email, email_verification_id: verifyEmailId };
					}
					if (req.body.price) {
						setVar.price = parseFloat(req.body.price)
					}
					if (req.body.bio) {
						setVar.bio = req.body.bio
					}
					if (req.body.services) {
						setVar.services = serv
					}


					if (req.body.latitude && req.body.longitude) {
						setVar.latitude = parseFloat(req.body.latitude)
						setVar.longitude = parseFloat(req.body.longitude)
						setVar.location = {
							"type": "Point",
							"coordinates": [parseFloat(req.body.longitude), parseFloat(req.body.latitude)
							]
						}

					}
					if (req.body.formatted_address) {
						setVar.formatted_address = req.body.formatted_address

					}
					console.log('setvar', setVar)
					setVar.email = req.body.email
					setVar.timezone = req.body.timezone
					setVar.timezone_str = req.body.timezone_str
					//return res.json(setVar)


					dbo.collection('TBL_TRAINERS').updateOne({ _id: ObjectId(user_id) }, { $set: setVar }, function (err, rese) {
						if (err) {
							res.send({ "success": true, "message": "Unable to save data.", "data": {} });
							return false;
						}
						else {
							if (req.body.latitude && req.body.longitude) {
								dbo.collection('TBL_TRAINERS').createIndex({ location: "2dsphere" })
							}

							if (user.email != req.body.email) {
								var mailOptions = {
									from: 'ravikantenact@gmail.com',
									to: req.body.email,
									subject: 'HourfulApp',
									html: `Hi ` + req.body.first_name + `, we have received email change request.
												Please click this link below to verify your mail <br> <a href="http://13.56.225.168:8088/api?id`+ verifyEmailId + `"></a>`
									// html: '<h1>Hi Smartherd</h1><p>Your Messsage</p>'        
								};
								transporter.sendMail(mailOptions, function (error, info) {
									/* const userDetails = {
										user_id:user._id,
										first_name:req.body.first_name,
										last_name:req.body.last_name,
										email:req.body.email,
										social_id:req.body.social_id,
										image: req.body['image'],
										type:user.type,
									}
									// console.log("sdsds"); 
									if (error) {	
										// console.log("sdsds"); 
										res.send({"success":true,"message":"Mail Not sent","data":userDetails});
										return false;
									} else {
										// console.log(userDetails);
										res.send({"success":true,"message":"registered","data":userDetails});
										return false;
									} */
								});

							}

							var detailVar = { first_name: req.body.first_name, last_name: req.body.last_name };
							if (req.body.bio) {
								detailVar.bio = req.body.bio

							}
							if (image != "") {
								detailVar = { first_name: req.body.first_name, last_name: req.body.last_name, image: image };
							}
							if (user.email != req.body.email) {
								detailVar['email_verified'] = false;
							}
							dbo.collection('TBL_TRAINER_DETAILS').updateOne({ user_id: ObjectId(user_id) }, { $set: detailVar }, function (err, rese) {
								if (err) {
									res.send({ "success": true, "message": "Unable to save data.", "data": {} });
									return false;
								}
								else {

									dbo.collection('TBL_TRAINERS').aggregate([
										{ $match: { _id: ObjectId(user._id) } },
										{
											$lookup:
											{
												from: 'TBL_TRAINER_DETAILS',
												localField: '_id',
												foreignField: 'user_id',
												as: 'userdetails'
											}
										},
										{
											$lookup:
											{
												from: 'TBL_SERVICES',
												localField: 'services.id',
												foreignField: '_id',
												as: 'services'
											}
										},
									]).toArray(function (err, resr) {
										if (err) {
											throw err;
										}
										else {
											if (resr) {

												var data = JSON.parse(JSON.stringify(resr));
												console.log('---->', data[0])
												if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
													var gov_id_verified = true;
												}
												else {
													var gov_id_verified = false;
												}
												data = {
													"user_id": data[0]['_id'],
													"first_name": data[0]['first_name'],
													"last_name": data[0]['userdetails'][0]['last_name'],
													"phone_number": data[0]['userdetails'][0]['phone_number'],
													"phone_verified": data[0]['userdetails'][0]['phone_verified'],
													"email_verified": data[0]['userdetails'][0]['email_verified'],
													"location": data[0]['location'] ? data[0]['location'] : "",
													"formatted_address": data[0]['formatted_address'] ? data[0]['formatted_address'] : "",
													"goverment_id": data[0]['userdetails'][0]['goverment_id'],
													"gov_id_verified": gov_id_verified,
													"selfie": data[0]['userdetails'][0]['selfie'],
													"image": data[0]['userdetails'][0]['image'],
													"status": data[0]['status'],
													"timezone": data[0]['timezone'] ? data[0]['timezone'] : "",
													"timezone_str": data[0]['timezone_str'] ? data[0]['timezone_str'] : "",
													"email": data[0]['email'],
													"price": data[0]['price'],
													"latitude": data[0]['latitude'] ? String(data[0]['latitude']) : "",
													"longitude": data[0]['longitude'] ? String(data[0]['longitude']) : "",
													"social": data[0]['social_id'],
													"services": data[0]['services'],
													"bio": data[0]['userdetails'][0]['bio'],
													"social_image": data[0]['userdetails'][0]['social_image']



												}
												// delete resr[0].password
												// delete resr[0].__v
												res.send({ "success": true, "message": "Your profile has been updated successfully.", "data": data });
												return false;
											}
										}
									});
								}
							});
						}
					});


				}
				else {
					res.send({ "success": false, "message": "something went wrong", "data": [] });
					return false;
				}
			}
			// console.log(data)
		});
	}
	else {
		if (!(req.body.user_id && req.body.first_name && req.body.last_name && req.body.timezone && req.body.timezone_str && req.body.email)) {
			res.send({ "success": false, "message": "Please send all fields", "data": [] });
			return false;
		}
		let dbo = await mongodbutil.Get();
		//TBL_TRAINERS TBL_CLIENTS
		dbo.collection('TBL_CLIENTS').aggregate([
			{
				$match: {
					_id: ObjectId(req.body.user_id)
				}
			}
		]).toArray(function (client_err, client_resr) {
			if (client_err) {
				throw client_err;
			}
			else {
				if (client_resr) {
					var setVar = {}
					user_id = req.body.user_id;
					user = client_resr[0];
					console.log(user)
					//return
					var location = path.join(__dirname, '../../uploads/images');
					if (req.files != undefined || req.files != null) {
						var sampleFile = req.files.image;
						sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1], function (err) {
							if (err) {
								res.send({ "success": false, "message": "Unable to fetch image", "data": {} });
								return false;
							}
							else {
								image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
								console.log("image", image)
							}
						})
						image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
						setVar.image = image

					}
					if (user.email != req.body.email) {
						if (user.email != req.body.email) {
							var verifyEmailId = makeid(20);
							console.log(verifyEmailId)
							setVar = { email: req.body.email, email_verification_id: verifyEmailId };
						}
						var mailOptions = {
							from: 'ravikantenact@gmail.com',
							to: req.body.email,
							subject: 'HourfulApp',
							html: `Hi ` + req.body.first_name + `, we have received email change request.
										Please click this link below to verify your mail <br> <a href="http://13.56.225.168:8088/api?id`+ verifyEmailId + `"></a>`
							// html: '<h1>Hi Smartherd</h1><p>Your Messsage</p>'        
						};
						transporter.sendMail(mailOptions, function (email_error, info) {
							if (email_error) {
								console.log(email_error)

							}

						});

					}

					setVar.first_name = req.body.first_name
					setVar.last_name = req.body.last_name
					setVar.timezone = req.body.timezone
					setVar.timezone_str = req.body.timezone_str

					// console.log('----------->',setVar)
					dbo.collection('TBL_CLIENTS').updateOne({ _id: ObjectId(user_id) },
						{ $set: setVar }, function (update_err, rese) {
							if (update_err) {
								res.send({ "success": true, "message": "Unable to save data.", "data": {} });
								return false;
							}
							else {
								//dbo.collection('TBL_CLIENTS').find()
								dbo.collection("TBL_CLIENTS").find({ "_id": ObjectId(req.body.user_id) })
									.toArray(async function (find_err, clients_details) {
										if (find_err) {
											console.log(find_err)
										}
										else {
											res.send({ "success": true, "message": "Profile updated successfully", "data": clients_details });
										}
									})

							}

						})
				}
				else {
					res.send({ "success": false, "message": "something went wrong", "data": [] });
					return false;

				}



			}
		})



	}
	// });  
}

function makeid(length) {
	var result = '';
	var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	var charactersLength = characters.length;
	for (var i = 0; i < length; i++) {
		result += characters.charAt(Math.floor(Math.random() * charactersLength));
	}
	return result;
}