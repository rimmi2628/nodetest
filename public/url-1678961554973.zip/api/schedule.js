var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
const Utill = require('../helper/Constant')


const bcrypt = require('bcrypt')
var app = express();
const {
    admin
} = require('./firebaseConfig.js');
var emailTemp = require('./emails');

app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'info@hourful.io',
        pass: 'Panda999$'
    }
});



var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;
var options = {
    priority: "high",
    timeToLive: 60 * 60 * 24
};

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.schedule = async function (req, res) {

    const {
        user_id,
        gym_id,
        payment_method,
        transaction_id,
        slot_id,
        date,
        time,
        schedule_time,
        instantBooking,
        amount
    } = req.body;
    console.log(req.body)
    if (!user_id || !gym_id || !payment_method || !transaction_id || !slot_id || !date || !time || !schedule_time) {
        res.send({
            "success": false,
            "message": "Please enter all fields",
            "data": {}
        });
        return false;
    }
    // MongoClient.connect(url, function(err, db) {
    // if (err) throw err;
    let dbo = await mongodbutil.Get();
    console.log(req.body);
    // return;
    if (instantBooking == true) {
        var status = 2;
    } else {
        var status = 0;
    }

    var gymID = ObjectId(gym_id)
    var userID = ObjectId(user_id)
    var gymName

    dbo.collection('TBL_PUSH_TOKENS').find({
        trainer_id: userID
    })
        .toArray(function (err, tokens) {
            var dTokens = []
            for (let e = 0; e < tokens.length; e++) {
                dTokens[e] = tokens[e].token;
            }
            if (instantBooking == true) {
                var payload = {
                    notification: {
                        title: "Booking Accepted",
                        body: "Your booking has been accepted."
                    },
                    data: {
                        // booking_id: booking_id,
                        user_id: user_id,
                        gym_id: gym_id,
                    }
                };
            } else {
                var payload = {
                    notification: {
                        title: "Booking Request Sent",
                        body: "Your booking request has been sent."
                    },
                    data: {
                        // booking_id: booking_id,
                        user_id: user_id,
                        gym_id: gym_id,
                    }
                };
            }

            var registrationToken = dTokens;
            if (tokens.length != 0) {
                admin.messaging().sendToDevice(registrationToken, payload, options)
                    .then(function (response) {
                        console.log("Successfully sent message:", response);
                    })
                    .catch(function (error) {
                        console.log("Error sending message:", error);
                    });
            }

        });

    var myobj = {
        user_id: userID,
        price: parseInt(amount),
        gym_id: gymID,
        slot_id: ObjectId(slot_id),
        date: date,
        time: time,
        schedule_time: parseInt(schedule_time),
        status: status,
        transaction_id: transaction_id,
        payment_method: payment_method
    };
    var myobj2 = {
        transaction_id: transaction_id,
        payment_method: payment_method,
        user_id: userID,
        gym_id: gymID
    };
    if (req.body.duration != undefined) {
        myobj.duration = req.body.duration
    }
    if (req.body.client_name != undefined) {
        myobj.client_name = req.body.client_name
    }
    var gym_name
    dbo.collection("TBL_BOOKINS").insertOne(myobj, function (err, rese) {
        if (err) throw err;
        //console.log(res.insertedId);
        myobj2.booking_id = ObjectId(rese.insertedId)
        dbo.collection("TBL_PAYMENT_LOGS").insertOne(myobj2, function (err, resee) {
            if (err) {
                res.send({
                    "success": false,
                    "message": "Something went wrong!",
                    "data": {}
                });
            } else {

                dbo.collection("TBL_AVAILABILITY_SLOTS").find({
                    "_id": ObjectId(slot_id)
                }).toArray(function (err, result) {
                    // console.log("1",parseInt(result[0].availableSlots) - 1)
                    if (instantBooking == true) {
                        dbo.collection("TBL_AVAILABILITY_SLOTS").updateOne({
                            _id: ObjectId(slot_id)
                        }, {
                            $set: {
                                availableSlots: parseInt(result[0].availableSlots) - 1
                            }
                        }, function (err, resv) { })
                    }


                    const gyymdetails = dbo.collection('TBL_GYMS').find({
                        _id: gymID
                    })
                        .toArray(function (err, data) {
                            if (err) {
                                throw err;
                            } else {
                                // console.log(data[0].logo) 
                                if (instantBooking == true) {
                                    var typeee = "0";
                                } else {
                                    var typeee = "1";
                                }
                                console.log("11111111111111111111");
                                gymName = data[0].name

                                console.log('--------gym name-----', gymName);
                                var NotiObj = {
                                    trainer_id: userID,
                                    date: date,
                                    time: time,
                                    gym_id: gymID,
                                    gym_name: data[0].name,
                                    logo: data[0].logo,
                                    text: "",
                                    type: typeee,
                                    status: '0',
                                    date_time: schedule_time,
                                    created_at: getCurrentTime(),
                                    updated: getCurrentTime()
                                };
                                dbo.collection("TBL_NOTIFICATIONS").insertOne(NotiObj, function (err, resr) {
                                    if (err) {
                                        throw err;
                                    } else {

                                    }
                                });

                                dbo.collection('TBL_TRAINER_DETAILS').find({
                                    user_id: userID
                                })
                                    .toArray(function (err, data1) {
                                        if (err) {
                                            throw err;
                                        } else {
                                            if (instantBooking == true) {
                                                var actionInstant = 0
                                                var type = 1;
                                            } else {
                                                var actionInstant = 1
                                                var type = 0;
                                            }

                                            // console.log(instantBooking,type)
                                            // return;
                                            var gymNotiObj = {
                                                trainer_id: userID,
                                                date: date,
                                                time: time,
                                                user_id: ObjectId(data[0].space_owner),
                                                trainer_name: data1[0].first_name + " " + data1[0].last_name,
                                                gym_id: gymID,
                                                gym_name: data[0].name,
                                                price: '' + parseInt(amount) + '',
                                                text: "",
                                                action: actionInstant,
                                                status: 0,
                                                type: type,
                                                date_time: schedule_time,
                                                created_at: getCurrentTime(),
                                                updated: getCurrentTime(),
                                                booking_id: ObjectId(myobj2.booking_id)
                                            };
                                            dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(gymNotiObj, function (err, resr) {
                                                if (err) {
                                                    throw err;
                                                } else {
                                                    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                                                    var date_split = date.split("-");

                                                    var time_split = time.split(":");
                                                    var time_Hr = parseInt(time_split[0]) + 1;
                                                    var time_till = time_Hr.toString() + ':' + time_split[1];


                                                    dbo.collection('TBL_GYM_AVAILABILITY').find({
                                                        _id: result[0].gym_availability_id
                                                    })
                                                        .toArray(function (err, dataAV) {
                                                            if (err) {
                                                                throw err;
                                                            } else {
                                                                // var monthBB = monthNames[dataAV[0].month];
                                                                var monthBB = monthNames[date_split[1] - 1];
                                                                console.log(date_split)
                                                                console.log('date')
                                                                console.log(time_till)
                                                                console.log(monthBB)
                                                                var spID = ''
                                                                if (data[0].space_owner != '' || data[0].space_owner != null) {

                                                                    dbo.collection('TBL_SPACE_OWNER').find({
                                                                        _id: data[0].space_owner
                                                                    })
                                                                        .toArray(function (err, dataSS) {
                                                                            if (err) {
                                                                                throw err;
                                                                            } else {

                                                                                if (instantBooking == true) {
                                                                                    if (data1[0].avg_rating == null || data1[0].avg_rating == undefined || data1[0].avg_rating == '') {
                                                                                        var ratingsss = 0
                                                                                    } else {
                                                                                        var ratingsss = data1[0].avg_rating
                                                                                    }
                                                                                    var amountCut = 0.2 * parseInt(amount)
                                                                                    var totalAmountToGYM = parseInt(amount) - amountCut
                                                                                    var dddd = date + " " + time
                                                                                    const dateyy = new Date(dddd);
                                                                                    dateyy.toISOString() // '2017-05-31T11:46:54.216Z'
                                                                                    dateyy.toJSON() // '2017-05-31T11:46:54.216Z'
                                                                                    console.log(formatDateTimeNEW(dateyy))
                                                                                    var stuff = [];
                                                                                    stuff['first_name'] = data1[0].first_name
                                                                                    stuff['last_name'] = data1[0].last_name
                                                                                    stuff['dateyy'] = formatDateTimeNEW(dateyy)
                                                                                    stuff['name'] = data[0].name
                                                                                    stuff['email'] = dataSS[0].email
                                                                                    stuff['ratingsss'] = ratingsss
                                                                                    stuff['monthBB'] = monthBB
                                                                                    stuff['date_split2'] = date_split[2]
                                                                                    stuff['date_split0'] = date_split[0]
                                                                                    stuff['time'] = tConvert(time)
                                                                                    stuff['totalAmountToGYM'] = totalAmountToGYM
                                                                                    stuff['chat'] = Utill.IMAGE_BASE_URL + 'gymapp/#/?gymId=' + gym_id + '&trainerid=' + user_id + '&message=true'
                                                                                    // stuff['chat']= 'hourful://openapp?type=chat&sid='+dataSS[0]._id+'&gid='+gym_id+''
                                                                                    spID = dataSS[0]._id
                                                                                    console.log(stuff['chat'])
                                                                                    // if (dataSS[0].email == 'nayakacp@gmail.com') {
                                                                                    var email = emailTemp.bookingEmails.instantGymBook(stuff)
                                                                                    // console.log(stuff)
                                                                                    console.log(email)
                                                                                    // }


                                                                                } else {
                                                                                    if (data1[0].avg_rating == null || data1[0].avg_rating == undefined || data1[0].avg_rating == '') {
                                                                                        var ratingsss = 0
                                                                                    } else {
                                                                                        var ratingsss = data1[0].avg_rating
                                                                                    }
                                                                                    var amountCut = 0.2 * parseInt(amount)
                                                                                    var totalAmountToGYM = parseInt(amount) - amountCut

                                                                                    var stuff = [];
                                                                                    stuff['first_name'] = data1[0].first_name
                                                                                    stuff['last_name'] = data1[0].last_name
                                                                                    // stuff['dateyy']= formatDateTimeNEW(dateyy)
                                                                                    stuff['name'] = data[0].name
                                                                                    stuff['email'] = dataSS[0].email
                                                                                    stuff['ratingsss'] = ratingsss
                                                                                    stuff['monthBB'] = monthBB
                                                                                    stuff['date_split2'] = date_split[2]
                                                                                    stuff['date_split0'] = date_split[0]
                                                                                    stuff['time'] = tConvert(time)
                                                                                    stuff['time_till'] = tConvert(time_till)
                                                                                    stuff['totalAmountToGYM'] = totalAmountToGYM
                                                                                    // stuff['chat']= 'hourful://openapp?type=chat&sid='+dataSS[0]._id+'&gid='+gym_id+''
                                                                                    stuff['chat'] = Utill.IMAGE_BASE_URL + 'gymapp/#/?gymId=' + gym_id + '&trainerid=' + user_id + '&message=true'
                                                                                    stuff['decline'] = Utill.IMAGE_BASE_URL + 'gymapi/api/updateBooking?id=' + myobj2.booking_id + '&status=3&user_id=' + dataSS[0]._id + ''
                                                                                    stuff['accept'] = Utill.IMAGE_BASE_URL + 'gymapi/api/updateBooking?id=' + myobj2.booking_id + '&status=1&user_id=' + dataSS[0]._id + ''
                                                                                    // if (dataSS[0].email == 'nayakacp@gmail.com') {
                                                                                    var email = emailTemp.bookingEmails.regularGymBook(stuff)
                                                                                    console.log(email)
                                                                                    console.log(stuff['chat'])
                                                                                    // }

                                                                                }
                                                                                dbo.collection('TBL_TRAINERS').find({
                                                                                    _id: userID
                                                                                })
                                                                                    .toArray(function (err, dataTT) {
                                                                                        if (err) {
                                                                                            throw err;
                                                                                        } else {

                                                                                            if (instantBooking == true) {
                                                                                                var stuff = [];

                                                                                                stuff['name'] = data[0].name
                                                                                                stuff['email'] = dataTT[0].email
                                                                                                stuff['monthBB'] = monthBB
                                                                                                stuff['date_split2'] = date_split[2]
                                                                                                stuff['date_split0'] = date_split[0]
                                                                                                stuff['time'] = tConvert(time)
                                                                                                stuff['time_till'] = tConvert(time_till)
                                                                                                stuff['amount'] = amount
                                                                                                // stuff['chat']= 'hourful://openapp?type=chat&sid='+spID+'&gid='+gym_id+''
                                                                                                // stuff['chat']= 'https://hourful.io/redirect.html?type=chat&gid='+dataSS[0]._id+'_'+gym_id+''
                                                                                                // stuff['chat']= 'https://hourful.io/redirect.html?type=chat&gid='+gym_id+'&logo='+data[0].logo+'&name='+encodeURI(data[0].name) +'&space_owner='+dataSS[0]._id+''
                                                                                                if (data[0].logo.indexOf("http") != -1 || data[0].logo.indexOf("https") != -1) {
                                                                                                    stuff['chat'] = Utill.IMAGE_BASE_URL + 'redirect.html?type=chat&gid=' + gym_id + '&logo=' + data[0].logo + '&name=' + encodeURI(data[0].name) + '&space_owner=' + dataSS[0]._id + ''
                                                                                                }
                                                                                                else {
                                                                                                    var logo = data[0].logo.replace("uploads/images/", "");
                                                                                                    stuff['chat'] = Utill.IMAGE_BASE_URL + 'redirect.html?type=chat&gid=' + gym_id + '&logo=' + logo + '&name=' + encodeURI(data[0].name) + '&space_owner=' + dataSS[0]._id + ''
                                                                                                }
                                                                                                console.log(stuff)
                                                                                                // if (dataTT[0].email == 'mohitsetia@gmail.com') {
                                                                                                var email = emailTemp.bookingEmails.instantTrainerBook(stuff)
                                                                                                console.log(email)
                                                                                                // }


                                                                                            } else {
                                                                                                var stuff = [];

                                                                                                stuff['name'] = data[0].name
                                                                                                stuff['email'] = dataTT[0].email
                                                                                                stuff['monthBB'] = monthBB
                                                                                                stuff['date_split2'] = date_split[2]
                                                                                                stuff['date_split0'] = date_split[0]
                                                                                                stuff['time'] = tConvert(time)
                                                                                                stuff['time_till'] = tConvert(time_till)
                                                                                                stuff['amount'] = amount
                                                                                                // stuff['chat']= 'hourful://openapp?type=chat&sid='+dataSS[0]._id+'&gid='+gym_id+''
                                                                                                // hourful://openapp?type=chat&gid=5ec38a821a9ca845e0831a8f&logo=image.png&name=Ozy&space_owner=4434rdr435refer543trtrt
                                                                                                if (data[0].logo.indexOf("http") != -1 || data[0].logo.indexOf("https") != -1) {
                                                                                                    stuff['chat'] = Utill.IMAGE_BASE_URL + 'redirect.html?type=chat&gid=' + gym_id + '&logo=' + data[0].logo + '&name=' + encodeURI(data[0].name) + '&space_owner=' + dataSS[0]._id + ''
                                                                                                }
                                                                                                else {
                                                                                                    var logo = data[0].logo.replace("uploads/images/", "");
                                                                                                    stuff['chat'] = Utill.IMAGE_BASE_URL + 'redirect.html?type=chat&gid=' + gym_id + '&logo=' + logo + '&name=' + encodeURI(data[0].name) + '&space_owner=' + dataSS[0]._id + ''
                                                                                                }
                                                                                                // stuff['chat']= 'https://hourful.io/redirect.html?type=chat&gid='+gym_id+'&logo='+data[0].logo+'&name='+ encodeURI(data[0].name) +'&space_owner='+dataSS[0]._id+''
                                                                                                console.log(stuff)
                                                                                                // if (dataTT[0].email == 'mohitsetia@gmail.com') {
                                                                                                var email = emailTemp.bookingEmails.regularTrainerBook(stuff)
                                                                                                console.log(email)
                                                                                                // }

                                                                                            }
                                                                                        }
                                                                                    });
                                                                            }
                                                                        });
                                                                }

                                                            }
                                                        })
                                                }
                                            });
                                        }
                                    });
                            }
                        });


                    // '//res.send({"success":true,"message":"success","data":result});

                })

                if (instantBooking == true) {
                    res.send({
                        "success": true,
                        "message": "Thank you, Your request is accepted.",
                        "data": {
                            "booking_id": myobj2.booking_id
                        }
                    });
                } else {
                    const gyymdetails = dbo.collection('TBL_GYMS').find({
                        _id: gymID
                    })
                        .toArray(function (err, data) {
                            if (err) {
                                throw err;
                            } else {
                              
                                gymName = data[0].name
                            }
                
                            res.send({
                                "success": true,
                                "message": `Thank you, we have received your booking request. You shall receive updates from  the ${gymName}  when request is accepted.`,
                                "data": {
                                    "booking_id": myobj2.booking_id
                                }
                            });
                        })

                  
                }

                // dbo.collection("TBL_BOOKINS").updateOne({_id:ObjectId(slot_id)},{$set:myobj}, function(err, resv) {

                // })


                // dbo.collection("TBL_AVAILABILITY_SLOTS").insertOne(myobj2, function(err, resee) {
                //   if (err){
                //     res.send({"success":false,"message":"Something went wrong!","data":{} });
                //   } 
                //   else{

                // res.send({"success":true,"message":"Thank you, we have received your booking request. You shall receive updates from Gym when request is confirmed.","data":{"booking_id":myobj2.booking_id}});
                // db.close();
                //return false;
                // }



                // res.send({"success":true,"message":"Thank you, we have received your booking request. You shall receive updates from Gym when request is confirmed.","data":{"booking_id":myobj2.booking_id}});
                // return false;
            }

        });
        // db.close();
    });
    // })
}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}

function formatDateTime(datetime) {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const d = new Date(datetime * 1000);
    var month = monthNames[d.getMonth()];
    var date = d.getDate();
    var year = d.getFullYear();

    var hours = d.getHours();
    var minutes = d.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    // February 10, 2020 at 10:15 AM
    return month + " " + date + "," + year + " at " + strTime
}

function formatDateTimeNEW(date) {
    const year = date.getUTCFullYear();
    const month = pad(date.getUTCMonth() + 1);
    const day = pad(date.getUTCDate());
    const hour = pad(date.getUTCHours());
    const minute = pad(date.getUTCMinutes());
    const second = pad(date.getUTCSeconds());
    return `${year}${month}${day}T${hour}${minute}${second}Z`;
}

function pad(i) {
    return i < 10 ? `0${i}` : `${i}`;
}
function tConvert(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
        time = time.slice(1);  // Remove full string match value
        time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
        time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join(''); // return adjusted time or original string
}