var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = require('mongodb').ObjectID
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
var mongodbutil = require('./mongodbutil');
const {
	admin
} = require('./firebaseConfig.js');
var options = {
	priority: "high",
	timeToLive: 60 * 60 * 24
};
var moment = require('moment'); // require
const { json } = require('express');

exports.view_sessions_history = async function (req, res) {
	const {
		user_id,
		user_type,
		page_no
	} = req.body;
	let errors = [];
	if (!user_id || !user_type || !page_no) {
		res.send({
			"success": false,
			"message": "user_id, page_no and user_type required.",
			"data": {}
		});
		return false;
	}
	if (Object.keys(req.body).length === 0) {
		cPage = 1
	} else {
		cPage = req.body.page_no
	}
	var pageNo = parseInt(cPage)
	var size = 10
	var query = {}
	if (pageNo < 0 || pageNo === 0) {
		response = {
			"error": true,
			"message": "invalid page number, should start with 1"
		};
		return res.json(response)
	}
	query.skip = size * (pageNo - 1)
	query.limit = size
	console.log('pagination---->', query)
	let dbo = await mongodbutil.Get();
	console.log('---------------------req.body')
	console.log(req.body)
	//var date_now = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');

	//var seconds = getCurrentTime() - 3600
	var seconds = getCurrentTime()

	console.log(seconds)


	if (req.body.user_type == 0) {
		if (!req.body.month) {
			var qq = {
				"trainer_id": ObjectId(req.body.user_id),

			}
		} else {
			var qq = {
				"trainer_id": ObjectId(req.body.user_id),

				"month": req.body.month
			}
		}
		dbo.collection("TBL_SESSIONS").count(qq, function (err, totalCount) {
			if (err) {
				response = {
					"error": true,
					"message": "Error fetching data"
				}
				return false;
			}

			var totalPages = Math.ceil(totalCount / size)
			// console.log('totalPages '+ totalPages)
			// console.log('totalCount '+ totalCount)
			if (!req.body.month) {
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([
					{
						$match: {
							"trainer_id": ObjectId(req.body.user_id),
							"$or": [

								{
									"utc": {
										$lte: seconds.toString()
									},
									"status": 1

								},
								{
									"status": {
										$in: [2, 3, 4, 5, 6]
									},

								}
							],
							// "client_info.trainer_id": ObjectId(req.body.user_id),
							// "status":{$ne : 3}

						}
					},

					{
						$lookup: {
							from: 'TBL_CLIENTS',
							localField: 'client_id',
							foreignField: '_id',
							as: 'client'
						}
					},
					{
						$addFields: {
							utc: { $toInt: "$utc" },
							//	convertedQty: { $toInt: "$qty" },
						}
					},

					{
						$sort: { "utc": -1 }
					},
					{
						$skip: query.skip
					},
					{
						$limit: query.limit
					},

				]);
			} else {
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([
					{
						$match: {
							"trainer_id": ObjectId(req.body.user_id),
							// "client_info.trainer_id": ObjectId(req.body.user_id),
							"month": req.body.month,
							"$or": [

								{
									"utc": {
										$lte: seconds.toString()
									},
									"status": 1

								},
								{
									"status": {
										$in: [2, 3, 4, 5, 6]
									},

								}
							],
							// "status":{$ne : 3}

						}
					},

					{
						$lookup: {
							from: 'TBL_CLIENTS',
							localField: 'client_id',
							foreignField: '_id',
							as: 'client'
						}
					},
					{
						$addFields: {
							utc: { $toInt: "$utc" },
							//	convertedQty: { $toInt: "$qty" },
						}
					},

					{
						$sort: { "utc": -1 }
					},
					{
						$skip: query.skip
					},
					{
						$limit: query.limit
					},
				]);
			}
			Query_m.toArray(function (err, resr) {
				if (err) {
					throw err;
				} else {
					if (resr) {
						var data = JSON.parse(JSON.stringify(resr));
						//return res.send(data)
						// console.log(data[0]['clientdetails'])

						//return res.json(data)
						var dat = [];
						for (var i = 0; i < data.length; i++) {
							if (!data[i]['client'][0]) {
								data[i]['client'] = []
								data[i]['client'].push({
									timezone: '',
									timezone_str: ''
								})
								// data[i]['client'][0]['timezone'] = ''
								// data[i]['client'][0]['timezone_str'] = ''

							} else {
								if (data[i]['client'][0]['timezone'] == undefined) {
									data[i]['client'][0]['timezone'] = ''
								}
								if (data[i]['client'][0]['timezone_str'] == undefined) {
									data[i]['client'][0]['timezone_str'] = ''
								}
							}
							if (!data[i]['client_info']) {
								data[i]['client_info'] = []
								data[i]['client_info'].push({
									first_name: '',
									last_name: '',
									image: '',
									timezone: ''
								})
							} else {

								var client_info2 = data[i]['client_info'];
								data[i]['client_info'] = []
								data[i]['client_info'].push({
									first_name: client_info2.first_name,
									last_name: client_info2.last_name,
									image: client_info2.image,
									timezone: client_info2.timezone
								})
							}

							if (data[i]['day'] == undefined) {
								data[i]['day'] = ''
							}
							if (data[i]['month'] == undefined) {
								data[i]['month'] = ''
							}
							if (data[i]['year'] == undefined) {
								data[i]['year'] = ''
							}
							if (data[i]['date_str'] == undefined) {
								data[i]['date_str'] = ''
							}
							if (data[i]['time_str'] == undefined) {
								data[i]['time_str'] = ''
							}
							if (data[i]['timezone_str'] == undefined) {
								data[i]['timezone_str'] = data[i]['client'][0]['timezone_str']
							}
							if (data[i]['gym_name'] == undefined) {
								data[i]['gym_name'] = ''
							}
							if (data[i]['time'] == undefined) {
								data[i]['time'] = ''
							}
							if (data[i]['session_end_date'] == undefined) {
								data[i]['session_end_date'] = ''
							}
							dat.push({
								"id": data[i]['_id'],
								"trainer_id": data[i]['trainer_id'],
								"client_id": data[i]['client_id'],
								"user_type": data[i]['user_type'],
								"gym_name": data[i]['gym_name'],
								"utc": String(data[i]['utc']),
								"time": data[i]['time'],
								"repeat": data[i]['repeat'],
								"location": data[i]['location'],
								"duration": data[i]['duration'],
								"first_name": data[i]['client'][0]['first_name'],
								"last_name": data[i]['client'][0]['last_name'],
								"image": data[i]['client'][0]['image'],
								"timezone": data[i]['client'][0]['timezone'],
								"timezone_str": data[i]['timezone_str'],
								"status": data[i]['status'],
								"day": data[i]['day'],
								"month": data[i]['month'],
								"year": data[i]['year'],
								"date_str": data[i]['date_str'],
								"time_str": data[i]['time_str'],
								"slot_id": data[i]['slot_id'],
								"session_end_date": data[i]['session_end_date'].toString()
							})
						}
						res.send({
							"success": true,
							"message": "Success!",
							"data": dat,
							"total_pages": totalPages
						});
						return false;
					} else {
						res.send({
							"success": false,
							"message": "something went wrong",
							"data": {}
						});
						return false;
					}
				}

			});
		})

	} else {
		if (!req.body.month) {
			var qq = {
				"client_id": ObjectId(req.body.user_id),

			}
		} else {
			var qq = {
				"client_id": ObjectId(req.body.user_id),

				"month": req.body.month
			}
		}
		dbo.collection("TBL_SESSIONS").count(qq, function (err, totalCount) {
			if (err) {
				response = {
					"error": true,
					"message": "Error fetching data"
				}
				return false;
			}

			var totalPages = Math.ceil(totalCount / size)
			if (!req.body.month) {
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.user_id),
						"$or": [

							{
								"utc": {
									$lte: seconds.toString()
								},
								"status": 1

							},
							{
								"status": {
									$in: [2, 3, 4, 5, 6]
								},

							}
						],
						// status:{$ne : 3}

					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINERS',
						localField: 'trainer_id',
						foreignField: '_id',
						as: 'trainer'
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINER_DETAILS',
						localField: 'trainer_id',
						foreignField: 'user_id',
						as: 'trainerdetails'
					}
				},
				{
					$lookup: {
						from: 'TBL_CLIENT_TRAINER_RATINGS',
						localField: '_id',
						foreignField: 'session_id',
						as: 'ratings'
					}
				},

				{
					"$addFields": {
						"ratings": {
							"$arrayElemAt": [
								{
									"$filter": {
										"input": "$ratings",
										"as": "out",
										"cond": {
											"$eq": ["$$out.client_id", ObjectId(req.body.user_id)]
										},
									}
								}, 0
							]
						},
					}
				},
				{
					$addFields: {
						utc: { $toInt: "$utc" },
						//	convertedQty: { $toInt: "$qty" },
					}
				},

				{
					$sort: { "utc": -1 }
				},
				{
					$skip: query.skip
				},
				{
					$limit: query.limit
				},

				]);
			} else {
				console.log("hiiii-------->", seconds)
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.user_id),
						"month": req.body.month,
						"$or": [

							{
								"utc": {
									$lte: seconds.toString()
								},
								"status": 1

							},
							{
								"status": {
									$in: [2, 3, 4, 5, 6]
								},

							}




						],


					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINERS',
						localField: 'trainer_id',
						foreignField: '_id',
						as: 'trainer'
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINER_DETAILS',
						localField: 'trainer_id',
						foreignField: 'user_id',
						as: 'trainerdetails'
					}
				},
				{
					$lookup: {
						from: 'TBL_CLIENT_TRAINER_RATINGS',
						localField: '_id',
						foreignField: 'session_id',
						as: 'ratings'
					}
				},

				{
					"$addFields": {
						"ratings": {
							"$arrayElemAt": [
								{
									"$filter": {
										"input": "$ratings",
										"as": "out",
										"cond": {
											"$eq": ["$$out.client_id", ObjectId(req.body.user_id)]
										}
									}
								}, 0
							]
						},
					}
				},
				{
					$addFields: {
						utc: { $toInt: "$utc" },
						//	convertedQty: { $toInt: "$qty" },
					}
				},

				{
					$sort: { "utc": -1 }
				},
				{
					$skip: query.skip
				},
				{
					$limit: query.limit
				},


				])
			}
			Query_m.toArray(function (err, resr) {
				if (err) {
					throw err;
				} else {
					//return res.json(resr)
					if (resr) {
						var data = JSON.parse(JSON.stringify(resr));
						// console.log(data[0]['clientdetails'])
						// console.log(data)
						var dat = [];
						for (var i = 0; i < data.length; i++) {
							if (data[i]['trainer'][0]['timezone'] == undefined) {
								data[i]['trainer'][0]['timezone'] = ''
							}
							if (data[i]['trainer'][0]['timezone_str'] == undefined) {
								data[i]['trainer'][0]['timezone_str'] = ''
							}
							if (data[i]['day'] == undefined) {
								data[i]['day'] = ''
							}
							if (data[i]['month'] == undefined) {
								data[i]['month'] = ''
							}
							if (data[i]['year'] == undefined) {
								data[i]['year'] = ''
							}
							if (data[i]['date_str'] == undefined) {
								data[i]['date_str'] = ''
							}
							if (data[i]['time_str'] == undefined) {
								data[i]['time_str'] = ''
							}
							if (data[i]['timezone_str'] == undefined) {
								data[i]['timezone_str'] = data[i]['trainer'][0]['timezone_str'];
							}
							if (data[i]['gym_name'] == undefined) {
								data[i]['gym_name'] = ''
							}
							if (data[i]['session_end_date'] == undefined) {
								data[i]['session_end_date'] = ''
							}
							dat.push({
								"id": data[i]['_id'],
								"client_id": data[i]['client_id'],
								"trainer_id": data[i]['trainer_id'],
								"user_type": data[i]['user_type'],
								"gym_name": data[i]['gym_name'],
								"utc": String(data[i]['utc']),
								"time": data[i]['time'],
								"repeat": data[i]['repeat'],
								"location": data[i]['location'],
								"duration": data[i]['duration'],
								"first_name": data[i]['trainerdetails'][0]['first_name'],
								"last_name": data[i]['trainerdetails'][0]['last_name'],
								"image": data[i]['trainerdetails'][0]['image'],
								"timezone": data[i]['trainer'][0]['timezone'],
								"timezone_str": data[i]['timezone_str'],
								"status": data[i]['status'],
								"day": data[i]['day'],
								"month": data[i]['month'],
								"year": data[i]['year'],
								"date_str": data[i]['date_str'],
								"time_str": data[i]['time_str'],
								"slot_id": data[i]['slot_id'],
								"ratings": data[i]['ratings'],
								"is_rated": data[i]['ratings'] && Object.keys(data[i]['ratings']).length > 0 ? true : false,
								"session_end_date": data[i]['session_end_date'].toString()
							})
						}
						res.send({
							"success": true,
							"message": "Success!",
							"data": dat,
							"total_pages": totalPages
						});
						return false;
					} else {
						res.send({
							"success": false,
							"message": "something went wrong",
							"data": {}
						});
						return false;
					}
				}

			});
		})
	}
}

function getCurrentTime() {
	var d = new Date();
	var n = d.toUTCString();
	var date = new Date(n);
	var seconds = date.getTime() / 1000; //1440516958
	return seconds;
}