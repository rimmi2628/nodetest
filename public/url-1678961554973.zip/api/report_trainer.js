var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);


var mongodbutil = require('./mongodbutil');

exports.block_trainer = async function (req, res) {

  //blocked_by 0 means  client-----blocked--->trainer    trainer----blocked--client-->1
  const { client_id, trainer_id, blocked_by, type } = req.body;
  if (!client_id) {
    res.send({ "success": false, "message": "client_id empty", "data": {} });
    return false;
  }
  else if (!trainer_id) {
    res.send({ "success": false, "message": "trainer_id empty", "data": {} });
    return false;
  }
  else if (!blocked_by) {
    res.send({ "success": false, "message": "type empty", "data": {} });
    return false;
  }
  //type -->0---->blocked,1->unblocked(delte entry)
  else if (!type) {
    res.send({ "success": false, "message": "type empty", "data": {} }); // 0->unblocked,1->blocked
    return false;
  }

  let dbo = await mongodbutil.Get();

  if (type == 1) {
    var deleteQuery = {
      'client_id': ObjectId(client_id),
      'trainer_id': ObjectId(trainer_id),

    };

    dbo.collection("TBL_BLOCKED").deleteOne(deleteQuery, function (delerr, del_data) {
      if (delerr) throw delerr;
      console.log(del_data.deletedCount)
      if(!del_data.deletedCount){
        res.send({
          "success": true,
          "message": `Failed To Unblock  ${blocked_by==0?'trainer':'client'} `,
          "data": []
        });
        
      }
      res.send({
        "success": true,
        "message": `We have successfully unblocked the ${blocked_by==0?'trainer':'client'} `,
        "data": []
      });
    });

  }

  else {
    var query = {
      'client_id': ObjectId(client_id),
      'trainer_id': ObjectId(trainer_id),
      blocked_by: parseInt(blocked_by)
    };


    dbo.collection('TBL_BLOCKED').insertOne(query, function (err, resv) {
      if (err) {
        throw err;
      } else {
        if (resv) {
          res.send({ "success": true, "message": "We have taken your request. Our team will look into this." });
          return false;
        }
        else {
          res.send({ "success": false, "message": "something went wrong" });
          return false;
        }
      }
    });
  }
}




exports.report_trainer = async function (req, res) {
  const { trainer_id, client_id, type } = req.body;
  if (!trainer_id) {
    res.send({ "success": false, "message": "trainer_id empty", "data": {} });
    return false;
  }
  else if (!client_id) {
    res.send({ "success": false, "message": "client_id empty", "data": {} });
    return false;
  }

  // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
  //     if (err) throw err;
  let dbo = await mongodbutil.Get();
  data = { "user_id": ObjectId(trainer_id), "client_id": ObjectId(client_id), "type": 1, 'created_at': getCurrentTime(), 'updated_at': getCurrentTime() }

  dbo.collection("TBL_REPORT").insertOne(data, function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      if (resr) {

        res.send({ "success": true, "message": "We have taken your request. Our team will look into this." });
        return false;
      }
      else {
        res.send({ "success": false, "message": "something went wrong", "data": [] });
        return false;
      }
    }
  });
  //});
}

exports.report_trainer2 = async function (req, res) {
  const { user_id, trainer_id, type } = req.body;
  if (!user_id) {
    res.send({ "success": false, "message": "user_id empty", "data": {} });
    return false;
  }
  else if (!trainer_id) {
    res.send({ "success": false, "message": "trainer_id empty", "data": {} });
    return false;
  }

  // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
  //     if (err) throw err;
  let dbo = await mongodbutil.Get();
  data = { "user_id": ObjectId(user_id), "trainer_id": ObjectId(trainer_id), "type": parseInt(type), 'created_at': getCurrentTime(), 'updated_at': getCurrentTime() }

  dbo.collection("TBL_REPORT").insertOne(data, function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      if (resr) {

        res.send({ "success": true, "message": "We have taken your request. Our team will look into this." });
        return false;
      }
      else {
        res.send({ "success": false, "message": "something went wrong", "data": [] });
        return false;
      }
    }
  });
  //});
}

function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}

