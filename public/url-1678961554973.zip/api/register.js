var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

var emailTemp = require('./emails');

const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'outlook',
  auth: {
    user: 'info@hourful.io',
    pass: 'Panda999$'
  }
});











var db = mongo.connect("mongodb://localhost:27017/gymtraining", { useNewUrlParser: true, useUnifiedTopology: true }, function (err, response) {
  if (err) { console.log(err); }
  else { //console.log('Connected to ' + db, ' + ', response); 
  }
});
const ObjectId = mongo.Types.ObjectId;
const Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;

const TBL_TRAINER = new Schema({

  social_id: String,
  email: String,
  password: String,
  details_id: String,
  type: String,
  services: Array,
  email_verification_id: String,
  favourites: String,
  status: String,
  location: {
    type: { type: String },
    coordinates: []
  },
  formatted_address: String,
  latitude: String,
  longitude: String,
  price: Number,
  created_at: Number,
  updated_at: Number,
});

const TBL_TRAINER_DETAIL = new Schema({
  first_name: String,
  last_name: String,
  bio: String,
  phone_number: String,
  phone_verified: String,
  email_verified: Array,
  image: String,
  goverment_id: String,
  selfie: String,
  created_at: Number,
  updated_at: Number,
});
const TBL_CLIENT = new Schema({

  type: String,
  password: String,
  social_id: String,
  email: String,
  email_verification_id: String,
  goal_id: String,
  training_ids: Array,
  bio: String,
  avg_rating: Number,
  ratings: Number


})

TBL_TRAINER.index({ location: "2dsphere" })
var TBL_TRAINERS = mongo.model('TBL_TRAINERS', TBL_TRAINER, 'TBL_TRAINERS');
var TBL_TRAINER_DETAILS = mongo.model('TBL_TRAINER_DETAILS', TBL_TRAINER_DETAIL, 'TBL_TRAINER_DETAILS');
var TBL_CLIENTS = mongo.model('TBL_CLIENTS', TBL_CLIENT, 'TBL_CLIENTS');
exports.TBL_TRAINERS = TBL_TRAINERS;
exports.TBL_TRAINER_DETAILS = TBL_TRAINER_DETAILS;
exports.TBL_CLIENTS = TBL_CLIENTS
// module.exports = {
//   TBL_TRAINERS,
//   TBL_TRAINER_DETAILS
// }

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
mongo.set('useCreateIndex', true);
var mongodbutil = require('./mongodbutil');
const { Double } = require('mongodb');
exports.register = async function (req, res) {
  // console.log(window.location.origin);return;
  const { email, first_name, last_name, password, social_id, image, type, user_type, latitude, longitude, formatted_address, price } = req.body;
  let errors = [];
   console.log('regsiter----------->',req.body,'<--------------------');
  if (!first_name || (!email && !social_id) || !last_name || (!password && !social_id) || !type) {
    res.send({ "success": false, "message": "Please enter all fields", "data": {} });
    return false;
  }

  // return 
  if (password) {
    if (password.length < 6) {
      res.send({ "success": false, "message": "Password must be atleast 6 chracter long", "data": {} });
      return false;
    }

  }
  else {
    req.body.password = makeid(10);
  }
  console.log(req.body)
  //  console.log(req.files); //return;
  if (req.files != undefined || req.files != null) {
    var sampleFile = req.files.image;
    var location = path.join(__dirname, '../../uploads/images');
    sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1], function (err) {
      if (err) {
        res.send({ "success": false, "message": "Unable to fetch image", "data": [] });
        return false;
      }
      else {
        req.body['image'] = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
      }
    })
  }
  else {
    req.body['image'] = ""
  }
  //trainer signup
  if (user_type == 0) {
    if (type == 0 || type == '0') {
      //trainer signup
      TBL_TRAINERS.findOne({ email: email }).then(async user => {
        if (user) {
          res.send({ "success": false, "message": "Email already taken", "data": {} });
          return false;
        }
        else {

          const newUser = new TBL_TRAINERS(req.body);
          // console.log(newUser)
          //  res.send(newUser.save());
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newUser.password, salt, (err, hash) => {
              if (err) throw err;
              newUser.password = hash;
              var verifyEmailId = makeid(20);
              newUser.email_verification_id = verifyEmailId
              newUser.latitude = latitude
              newUser.longitude = longitude
              newUser.price = price
              newUser.formatted_address = formatted_address
              newUser.created_at= getCurrentTime()
              newUser.updated= getCurrentTime()
              newUser.joining_year=getCurrentYear()
              if (longitude && latitude) {
                newUser.location = {
                  "type": "Point",
                  "coordinates": [parseFloat(req.body.longitude), parseFloat(req.body.latitude)
                  ]
                }
              }
              //console.log(newUser)
              //newUser.image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
              newUser
                .save()
                .then(async user => {
                  // const TBL_TRAINER_DETAILS = new TBL_TRAINER_DETAILS(req.body);
                  // MongoClient.connect(url, function(err, db) {
                  //   if (err) throw err;
                  let dbo = await mongodbutil.Get();
                  var myobj = { user_id: newUser._id, first_name: req.body.first_name, last_name: req.body.last_name, image: req.body['image'], created_at: getCurrentTime(), updated: getCurrentTime() };
                  dbo.collection("TBL_TRAINER_DETAILS").insertOne(myobj, function (err, resv) {
                    if (err) {
                      throw err;
                    }
                    else {
                      var stuff = [];
                      stuff['email'] = req.body.email
                      var email = emailTemp.bookingEmails.registerMailT(stuff)
                      console.log(email)
                      // transporter.sendMail(mailOptions, function(error, info) {
                      //     if (error) {
                      //         // res.send({"success":true,"message":"Mail Not sent","data":{}});
                      //         console.log(error)
                      //     } else {
                      //         console.log('mail sent b signup')
                      //     }
                      // });
                      ///console.log(newUser)                   
                      // var mailOptions = {
                      //   from: 'ravikantenact@gmail.com',
                      //   to: newUser.email,
                      //   subject: 'HourfulApp',
                      //   html: '<h1>Hi '+req.body.first_name+'</h1><p>Please click this link below to verify your mail </p><a href="http://13.56.225.168:8088/api/emailConfirm?id='+verifyEmailId+'>Click</a>'        

                      //   // html: '<h1>Hi Smartherd</h1><p>Your Messsage</p>'        
                      // };
                      // transporter.sendMail(mailOptions, function(error, info){
                      const userDetails = {
                        user_id: newUser._id,
                        first_name: req.body.first_name,
                        location: newUser.location,
                        latitude: newUser.latitude,
                        longitude: newUser.longitude,
                        formatted_address: newUser.formatted_address,
                        price: newUser.price,
                        last_name: req.body.last_name,
                        email: req.body.email,
                        social_id: req.body.social_id,
                        image: req.body['image'],
                        type: newUser.type,
                      }
                      // console.log("sdsds"); 
                      // if (error) {	
                      //   // console.log("sdsds"); 
                      //   res.send({"success":true,"message":"Mail Not sent","data":userDetails});
                      //   return false;
                      // } else {
                      // console.log(userDetails);
                      console.log({ "success": true, "message": "registered", "data": userDetails })
                      res.send({ "success": true, "message": "registered", "data": userDetails });
                      return false;
                      // }
                      //});
                    }

                    // db.close();
                  });
                  // });
                })
                .catch(err => console.log(err));
            });
          });
        }
      });
    }
    else {
      TBL_TRAINERS.findOne({ social_id: social_id }).then(async user => {
        if (user) {
          res.send({ "success": false, "message": "Social Id already exists", "data": {} });
          return false;
        }
        else {

          const newUser = new TBL_TRAINERS(req.body);
          // console.log(newUser)
          //  res.send(newUser.save());
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newUser.password, salt, (err, hash) => {
              if (err) throw err;
              newUser.password = hash;
              var verifyEmailId = makeid(20);
              newUser.latitude = latitude
              newUser.longitude = longitude
              newUser.price = price
              newUser.formatted_address = formatted_address,
              newUser.created_at= getCurrentTime()
              newUser.updated= getCurrentTime()
              newUser.joining_year=getCurrentYear()
              if (longitude && latitude) {
                console.log("locationgggggs")
                newUser.location = {
                  "type": "Point",
                  "coordinates": [parseFloat(req.body.longitude), parseFloat(req.body.latitude)
                  ]
                }
              }
              newUser.email_verification_id = verifyEmailId
              //console.log(newUser)
              //newUser.image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
              newUser
                .save()
                .then(async user => {
                  // const TBL_TRAINER_DETAILS = new TBL_TRAINER_DETAILS(req.body);
                  // MongoClient.connect(url, function(err, db) {
                  // if (err) throw err;
                  let dbo = await mongodbutil.Get();
                  var myobj = { user_id: newUser._id, first_name: req.body.first_name, last_name: req.body.last_name, image: req.body['image'], created_at: getCurrentTime(), updated: getCurrentTime() };
                  dbo.collection("TBL_TRAINER_DETAILS").insertOne(myobj, function (err, resv) {
                    if (err) {
                      throw err;
                    }
                    else {
                      var stuff = [];
                      stuff['email'] = req.body.email
                      var email = emailTemp.bookingEmails.registerMailT(stuff)
                      console.log(email)
                      ///console.log(newUser)                   
                      // var mailOptions = {
                      //   from: 'ravikantenact@gmail.com',
                      //   to: newUser.email,
                      //   subject: 'HourfulApp',
                      //   // text: `Hi `+req.body.first_name+`, thank you for registering with us.
                      //   //         Please click this link below to verify your mail <br> `
                      //   html: '<h1>Hi '+req.body.first_name+'</h1><p>Please click this link below to verify your mail </p><a href="http://13.56.225.168:8088/api/emailConfirm?id='+verifyEmailId+'>Click</a>'        

                      // };
                      // transporter.sendMail(mailOptions, function(error, info){
                      const userDetails = {
                        user_id: newUser._id,
                        type: newUser.type,
                        location: newUser.location,
                        latitude: newUser.latitude,
                        longitude: newUser.longitude,
                        formatted_address: newUser.formatted_address,
                        price: newUser.price,
                        first_name: req.body.first_name,
                        last_name: req.body.last_name,
                        email: req.body.email,
                        social_id: req.body.social_id,
                        image: req.body['image'],
                      }
                      // console.log("sdsds"); 
                      //if (error) {	
                      // console.log("sdsds"); 
                      //res.send({"success":true,"message":"Mail Not sent","data":userDetails});
                      //return false;
                      //} else {
                      // console.log(userDetails);
                      res.send({ "success": true, "message": "registered", "data": userDetails });
                      return false;
                      //}
                      // });
                    }

                    // db.close();
                  });
                  // });
                })
                .catch(err => console.log(err));
            });
          });
        }
      });
    }

  }
  else {
    //user signup

    if (type == 0) {
      TBL_TRAINERS.findOne({
        email: email
      }).then(async user1 => {
        if (user1) {
          res.send({
            "success": false,
            "message": "Email already taken",
            "data": {}
          });
          return false;
        } else {
          TBL_CLIENTS.findOne({
            email: email
          }).then(async user => {
            if (user) {
              res.send({
                "success": false,
                "message": "Email already taken",
                "data": {}
              });
              return false;
            } else {
              let dbo = await mongodbutil.Get();

              const newUser = new TBL_CLIENTS(req.body);
              bcrypt.genSalt(10, (err, salt) => {
                bcrypt.hash(newUser.password, salt, (err, hash) => {
                  if (err) throw err;
                  // newUser.password = hash;
                  // req.body.phone = req.body.phone.replace(/\D/g,'');
                  // req.body.phone_orignal = req.body.phone;
                  req.body.password = hash
                  req.body.disabled = 0
                  req.body.isSignup = 1
                  var verifyEmailId = makeid(20);
                  // newUser.email_verification_id = verifyEmailId
                  // var query = {'phone':req.body.phone };
                  if (!req.body.client_id) {
                    dbo.collection('TBL_CLIENTS').insertOne(req.body, function (err, resv) {
                      if (err) {
                        throw err;
                      } else {
                        // console.log(resv)
                        // return false
                        var stuff = [];
                        stuff['email'] = req.body.email
                        var email = emailTemp.bookingEmails.registerMailT(stuff)

                        var user_id1 = resv.insertedId


                        const userDetails = {
                          user_id: user_id1,
                          first_name: req.body.first_name,
                          last_name: req.body.last_name,
                          email: req.body.email,
                          timezone: req.body.timezone,
                          timezone_str: req.body.timezone_str,
                          user_type: req.body.user_type,
                          social_id: req.body.social_id,
                          image: req.body['image'],
                          type: req.body.type,
                          // phone: req.body.phone,
                        }
                        res.send({
                          "success": true,
                          "message": "registered",
                          "data": userDetails
                        });
                        return false;
                      }
                    });
                  }
                  else {
                    var query = { '_id': ObjectId(req.body.client_id) };
                    var update = { $set: req.body };
                    var options = { upsert: true };
                    dbo.collection('TBL_CLIENTS').findOneAndUpdate(query, update, options, function (err, resv) {
                      if (err) {
                        throw err;
                      } else {
                        var stuff = [];
                        stuff['email'] = req.body.email
                        var email = emailTemp.bookingEmails.registerMailT(stuff)
                        if (resv.lastErrorObject.updatedExisting == true) {
                          var user_id1 = resv.value._id
                        }
                        else {
                          var user_id1 = resv.lastErrorObject.upserted
                        }
                        const userDetails = {
                          user_id: user_id1,
                          first_name: req.body.first_name,
                          last_name: req.body.last_name,
                          email: req.body.email,
                          timezone: req.body.timezone,
                          timezone_str: req.body.timezone_str,
                          user_type: req.body.user_type,
                          social_id: req.body.social_id,
                          image: req.body['image'],
                          type: req.body.type,
                          // phone: req.body.phone,
                        }
                        res.send({
                          "success": true,
                          "message": "registered",
                          "data": userDetails
                        });
                        return false;
                      }
                    });
                  }



                  // newUser
                  //   .save()
                  //   .then(async user => {
                  //     var stuff = [];
                  //     stuff['email'] = req.body.email
                  //     var email = emailTemp.bookingEmails.registerMailT(stuff)
                  //     const userDetails = {
                  //           user_id: newUser._id,
                  //           first_name: req.body.first_name,
                  //           last_name: req.body.last_name,
                  //           email: req.body.email,
                  //           timezone: req.body.timezone,
                  //           timezone_str: req.body.timezone_str,
                  //           user_type: req.body.user_type,
                  //           social_id: req.body.social_id,
                  //           image: req.body['image'],
                  //           type: newUser.type,
                  //         }
                  //         res.send({
                  //           "success": true,
                  //           "message": "registered",
                  //           "data": userDetails
                  //         });
                  //         return false;
                  // let dbo = await mongodbutil.Get();
                  // var myobj = {
                  //   user_id: newUser._id,
                  //   first_name: req.body.first_name,
                  //   last_name: req.body.last_name,
                  //   image: req.body['image'],
                  //   created_at: getCurrentTime(),
                  //   updated: getCurrentTime()
                  // };
                  // dbo.collection("TBL_CLIENT_DETAILS").insertOne(myobj, function (err, resv) {
                  //   if (err) {
                  //     throw err;
                  //   } else {
                  //     var stuff = [];
                  //     stuff['email'] = req.body.email
                  //     var email = emailTemp.bookingEmails.registerMailT(stuff)
                  //     // console.log(email)
                  //     const userDetails = {
                  //       user_id: newUser._id,
                  //       first_name: req.body.first_name,
                  //       last_name: req.body.last_name,
                  //       email: req.body.email,
                  //       timezone: req.body.timezone,
                  //       timezone_str: req.body.timezone_str,
                  //       user_type: req.body.user_type,
                  //       social_id: req.body.social_id,
                  //       image: req.body['image'],
                  //       type: newUser.type,
                  //     }
                  //     res.send({
                  //       "success": true,
                  //       "message": "registered",
                  //       "data": userDetails
                  //     });
                  //     return false;
                  //   }
                  // });
                  // })
                  // .catch(err => console.log(err));
                });
              });
            }
          });
        }
      });

    } else {
      TBL_CLIENTS.findOne({
        social_id: social_id
      }).then(async user => {
        if (user) {
          res.send({
            "success": false,
            "message": "Social Id already exists",
            "data": {}
          });
          return false;
        } else {

          const newUser = new TBL_CLIENTS(req.body);
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newUser.password, salt, (err, hash) => {
              if (err) throw err;
              newUser.password = hash;
              var verifyEmailId = makeid(20);
              newUser.email_verification_id = verifyEmailId
              newUser
                .save()
                .then(async user => {
                  var stuff = [];
                  stuff['email'] = req.body.email
                  var email = emailTemp.bookingEmails.registerMailT(stuff)
                  const userDetails = {
                    user_id: newUser._id,
                    type: newUser.type,
                    first_name: req.body.first_name,
                    last_name: req.body.last_name,
                    email: req.body.email,
                    timezone: req.body.timezone,
                    timezone_str: req.body.timezone_str,
                    user_type: req.body.user_type,
                    social_id: req.body.social_id,
                    image: req.body['image'],
                    created_at: getCurrentTime(),
                    updated: getCurrentTime()
                  }
                  res.send({
                    "success": true,
                    "message": "registered",
                    "data": userDetails
                  });
                  return false;
                  // let dbo = await mongodbutil.Get();
                  // var myobj = {
                  //   user_id: newUser._id,
                  //   first_name: req.body.first_name,
                  //   last_name: req.body.last_name,
                  //   image: req.body['image'],
                  //   created_at: getCurrentTime(),
                  //   updated: getCurrentTime()
                  // };
                  // dbo.collection("TBL_CLIENT_DETAILS").insertOne(myobj, function (err, resv) {
                  //   if (err) {
                  //     throw err;
                  //   } else {
                  //     var stuff = [];
                  //     stuff['email'] = req.body.email
                  //     var email = emailTemp.bookingEmails.registerMailT(stuff)
                  //     // console.log(email)
                  //     const userDetails = {
                  //       user_id: newUser._id,
                  //       type: newUser.type,
                  //       first_name: req.body.first_name,
                  //       last_name: req.body.last_name,
                  //       email: req.body.email,
                  //       timezone: req.body.timezone,
                  //       timezone_str: req.body.timezone_str,
                  //       user_type: req.body.user_type,
                  //       social_id: req.body.social_id,
                  //       image: req.body['image'],
                  //     }
                  //     res.send({
                  //       "success": true,
                  //       "message": "registered",
                  //       "data": userDetails
                  //     });
                  //     return false;
                  //   }
                  // });
                })
                .catch(err => console.log(err));
            });
          });
        }
      });
    }

  }


}

function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}
function getCurrentYear(){
  return new Date().getFullYear()
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
