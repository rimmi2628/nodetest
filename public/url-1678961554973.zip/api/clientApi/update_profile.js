var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.update_profile = async function (req, res) {
    console.log(req.body)
    if (req.body.user_type == 0) {
        if (!(req.body.user_id)) {
            res.send({
                "success": false,
                "message": "user_id required",
                "data": []
            });
            return false;
        }
        if (!(req.body.first_name )) {
            res.send({
                "success": false,
                "message": "first_name required",
                "data": []
            });
            return false;
        }
        if (!(req.body.timezone )) {
            res.send({
                "success": false,
                "message": "timezone required",
                "data": []
            });
            return false;
        }
        if (!(req.body.timezone_str )) {
            res.send({
                "success": false,
                "message": "timezone_str required",
                "data": []
            });
            return false;
        }
        if (!(req.body.last_name)) {
            res.send({
                "success": false,
                "message": "last_name required",
                "data": []
            });
            return false;
        }
        if (!(req.body.email )) {
            res.send({
                "success": false,
                "message": "email required",
                "data": []
            });
            return false;
        }
        if (!(req.body.user_type)) {
            res.send({
                "success": false,
                "message": "req.body.user_type required",
                "data": []
            });
            return false;
        }
    }
    else{
        if (!(req.body.user_id)) {
            res.send({
                "success": false,
                "message": "user_id required",
                "data": []
            });
            return false;
        }
        if (!(req.body.first_name )) {
            res.send({
                "success": false,
                "message": "first_name required",
                "data": []
            });
            return false;
        }
        if (!(req.body.timezone )) {
            res.send({
                "success": false,
                "message": "timezone required",
                "data": []
            });
            return false;
        }
        if (!(req.body.timezone_str )) {
            res.send({
                "success": false,
                "message": "timezone_str required",
                "data": []
            });
            return false;
        }
        if (!(req.body.last_name)) {
            res.send({
                "success": false,
                "message": "last_name required",
                "data": []
            });
            return false;
        }
        if (!(req.body.email )) {
            res.send({
                "success": false,
                "message": "email required",
                "data": []
            });
            return false;
        }
        if (!(req.body.user_type)) {
            res.send({
                "success": false,
                "message": "req.body.user_type required",
                "data": []
            });
            return false;
        }
        // if (!(req.body.user_id && req.body.first_name && req.body.timezone && req.body.timezone_str && req.body.last_name && req.body.email && req.body.user_type)) {
        //     res.send({
        //         "success": false,
        //         "message": "Please send all fields",
        //         "data": []
        //     });
        //     return false;
        // }
    }
    console.log("user_id", req.files)
    let dbo = await mongodbutil.Get();
    if (req.body.user_type == 0) {
        dbo.collection('TBL_TRAINERS').aggregate([{
            $match: {
                _id: ObjectId(req.body.user_id)
            }
        }]).toArray(function (err, resr) {
            if (err) {
                throw err;
            } else {
                if (resr) {
                    user_id = req.body.user_id;
                    user = resr[0];
                    var image = '';
                    if (user.email != req.body.email) {
                        dbo.collection('TBL_TRAINERS').findOne({
                            email: req.body.email,
                            _id: {
                                $ne: ObjectId(req.body.user_id)
                            }
                        }).then(user => {
                            if (user) {
                                res.send({
                                    "success": false,
                                    "message": "Email already taken",
                                    "data": {}
                                });
                                return false;
                            }
                        });
                    }
                    var location = path.join(__dirname, '../../uploads/images');
                    if (req.files != undefined || req.files != null) {
                        var sampleFile = req.files.image;
                        sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1], function (err) {
                            if (err) {
                                res.send({
                                    "success": false,
                                    "message": "Unable to fetch image",
                                    "data": {}
                                });
                                return false;
                            } else {
                                image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
                                console.log("image", image)
                            }
                        })
                        image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
                    }
                    if (!req.body.services) {
                        var array = [];
                    }
                    else{
                        var array = req.body.services.split(',');
                    }
                    var serv = [];
                    for (var i = 0; i < array.length; i++) {
                        serv.push({
                            id: ObjectId(array[i])
                        });
                    }

                    var service_error = 0;
                    var detail_error = 0;
                    var message = "Data updated successfully";
                    var setVar = {
                        services: serv,
                        // bio: req.body.bio,
                        timezone_str: req.body.timezone_str,
                        timezone: req.body.timezone,
                        user_type: 0,
                    };
                    if (user.email != req.body.email) {
                        var verifyEmailId = makeid(20);
                        setVar = {
                            services: serv,
                            email: req.body.email,
                            email_verification_id: verifyEmailId,
                            timezone_str: req.body.timezone_str,
                            timezone: req.body.timezone,
                            user_type: 0,
                        };
                    }
                    dbo.collection('TBL_TRAINERS').updateOne({
                        _id: ObjectId(user_id)
                    }, {
                        $set: setVar
                    }, function (err, rese) {
                        if (err) {
                            res.send({
                                "success": true,
                                "message": "Unable to save data.",
                                "data": {}
                            });
                            return false;
                        } else {

                            if (user.email != req.body.email) {
                                var mailOptions = {
                                    from: 'ravikantenact@gmail.com',
                                    to: req.body.email,
                                    subject: 'HourfulApp',
                                    html: `Hi ` + req.body.first_name + `, we have received email change request.
                                                Please click this link below to verify your mail <br> <a href="'+Utill.IMAGE_BASE_URL+'/api?id` + verifyEmailId + `"></a>`
                                };
                                transporter.sendMail(mailOptions, function (error, info) {});
                            }
                            var detailVar = {
                                first_name: req.body.first_name,
                                last_name: req.body.last_name,
                                bio: req.body.bio
                            };
                            if (image != "") {
                                detailVar = {
                                    first_name: req.body.first_name,
                                    last_name: req.body.last_name,
                                    image: image,
                                    // bio: req.body.bio
                                };
                            }
                            if (user.email != req.body.email) {
                                detailVar['email_verified'] = false;
                            }
                            dbo.collection('TBL_TRAINER_DETAILS').updateOne({
                                user_id: ObjectId(user_id)
                            }, {
                                $set: detailVar
                            }, function (err, rese) {
                                if (err) {
                                    res.send({
                                        "success": true,
                                        "message": "Unable to save data.",
                                        "data": {}
                                    });
                                    return false;
                                } else {

                                    dbo.collection('TBL_TRAINERS').aggregate([{
                                            $match: {
                                                _id: ObjectId(user._id)
                                            }
                                        },
                                        {
                                            $lookup: {
                                                from: 'TBL_TRAINER_DETAILS',
                                                localField: '_id',
                                                foreignField: 'user_id',
                                                as: 'userdetails'
                                            }
                                        },
                                        {
                                            $lookup: {
                                                from: 'TBL_SERVICES',
                                                localField: 'services.id',
                                                foreignField: '_id',
                                                as: 'services'
                                            }
                                        },
                                    ]).toArray(function (err, resr) {
                                        if (err) {
                                            throw err;
                                        } else {
                                            if (resr) {

                                                var data = JSON.parse(JSON.stringify(resr));
                                                if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
                                                    var gov_id_verified = true;
                                                } else {
                                                    var gov_id_verified = false;
                                                }
                                                data = {
                                                    "user_id": data[0]['_id'],
                                                    "first_name": data[0]['userdetails'][0]['first_name'],
                                                    "last_name": data[0]['userdetails'][0]['last_name'],
                                                    "phone_number": data[0]['userdetails'][0]['phone_number'],
                                                    "phone_verified": data[0]['userdetails'][0]['phone_verified'],
                                                    "email_verified": data[0]['userdetails'][0]['email_verified'],
                                                    "goverment_id": data[0]['userdetails'][0]['goverment_id'],
                                                    "gov_id_verified": gov_id_verified,
                                                    "selfie": data[0]['userdetails'][0]['selfie'],
                                                    "image": data[0]['userdetails'][0]['image'],
                                                    "status": data[0]['status'],
                                                    "email": data[0]['email'],
                                                    "social": data[0]['social_id'],
                                                    "services": data[0]['services'],
                                                    "bio": data[0]['userdetails'][0]['bio'],
                                                    "social_image": data[0]['userdetails'][0]['social_image'],
                                                    "timezone": data[0]['timezone'],
                                                    "timezone_str": data[0]['timezone_str'],
                                                    "user_type": data[0]['user_type']
                                                }
                                                res.send({
                                                    "success": true,
                                                    "message": "Your profile has been updated successfully.",
                                                    "data": data
                                                });
                                                return false;
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    });
                } else {
                    res.send({
                        "success": false,
                        "message": "something went wrong",
                        "data": []
                    });
                    return false;
                }
            }
        });
    } else {
        dbo.collection('TBL_CLIENTS').aggregate([{
            $match: {
                _id: ObjectId(req.body.user_id)
            }
        }]).toArray(function (err, resr) {
            if (err) {
                throw err;
            } else {
                if (resr) {
                    user_id = req.body.user_id;
                    user = resr[0];
                    var image = '';
                    if (user.email != req.body.email) {
                        dbo.collection('TBL_CLIENTS').findOne({
                            email: req.body.email,
                            _id: {
                                $ne: ObjectId(req.body.user_id)
                            }
                        }).then(user => {
                            if (user) {
                                res.send({
                                    "success": false,
                                    "message": "Email already taken",
                                    "data": {}
                                });
                                return false;
                            }
                        });
                    }
                    var location = path.join(__dirname, '../../uploads/images');
                    if (req.files != undefined || req.files != null) {
                        var sampleFile = req.files.image;
                        sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1], function (err) {
                            if (err) {
                                res.send({
                                    "success": false,
                                    "message": "Unable to fetch image",
                                    "data": {}
                                });
                                return false;
                            } else {
                                image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
                                console.log("image", image)
                            }
                        })
                        image = sampleFile.md5 + "." + req.files.image.mimetype.split('/')[1];
                    }
                    // if (!req.body.services) {
                    //     var array = [];
                    // }
                    // else{
                    //     var array = req.body.services.split(',');
                    // }
                    // var serv = [];
                    // for (var i = 0; i < array.length; i++) {
                    //     serv.push({
                    //         id: ObjectId(array[i])
                    //     });
                    // }

                    var service_error = 0;
                    var detail_error = 0;
                    var message = "Data updated successfully";
                    var setVar = {
                        // services: serv,
                        // bio: req.body.bio,
                        timezone_str: req.body.timezone_str,
                        timezone: req.body.timezone,
                        user_type: 1,
                    };
                    if (user.email != req.body.email) {
                        var verifyEmailId = makeid(20);
                        setVar = {
                            services: serv,
                            email: req.body.email,
                            timezone_str: req.body.timezone_str,
                            timezone: req.body.timezone,
                            user_type: 1,
                            email_verification_id: verifyEmailId
                        };
                    }
                    dbo.collection('TBL_CLIENTS').updateOne({
                        _id: ObjectId(user_id)
                    }, {
                        $set: setVar
                    }, function (err, rese) {
                        if (err) {
                            res.send({
                                "success": true,
                                "message": "Unable to save data.",
                                "data": {}
                            });
                            return false;
                        } else {

                            if (user.email != req.body.email) {
                                var mailOptions = {
                                    from: 'ravikantenact@gmail.com',
                                    to: req.body.email,
                                    subject: 'HourfulApp',
                                    html: `Hi ` + req.body.first_name + `, we have received email change request.
                                                Please click this link below to verify your mail <br> <a href="'+Utill.IMAGE_BASE_URL+'/api?id` + verifyEmailId + `"></a>`
                                };
                                // transporter.sendMail(mailOptions, function (error, info) {});
                            }
                            var detailVar = {
                                first_name: req.body.first_name,
                                last_name: req.body.last_name,
                                // bio: req.body.bio
                            };
                            if (image != "") {
                                detailVar = {
                                    first_name: req.body.first_name,
                                    last_name: req.body.last_name,
                                    image: image,
                                    // bio: req.body.bio
                                };
                            }
                            console.log(detailVar)
                            // if (user.email != req.body.email) {
                            //     detailVar['email_verified'] = false;
                            // }
                            dbo.collection('TBL_CLIENTS').updateOne({
                                _id: ObjectId(req.body.user_id)
                            }, {
                                $set: detailVar
                            }, function (err, rese) {
                                if (err) {
                                    res.send({
                                        "success": true,
                                        "message": "Unable to save data.",
                                        "data": {}
                                    });
                                    return false;
                                } else {

                                    dbo.collection('TBL_CLIENTS').aggregate([{
                                            $match: {
                                                _id: ObjectId(user._id)
                                            }
                                        }
                                    ]).toArray(function (err, resr) {
                                        if (err) {
                                            throw err;
                                        } else {
                                            if (resr) {

                                                var data = JSON.parse(JSON.stringify(resr));
                                                if (data[0]['goverment_id'] != undefined) {
                                                    var gov_id_verified = true;
                                                } else {
                                                    var gov_id_verified = false;
                                                }
                                                if (!data[0]['current_trainer']) {
                                                    data[0]['current_trainer'] = ''
                                                }
                                                data = {
                                                    "user_id": data[0]['_id'],
                                                    "first_name": data[0]['first_name'],
                                                    "last_name": data[0]['last_name'],
                                                    "phone_number": data[0]['phone_number'],
                                                    "trainer_id":data[0]['current_trainer'],
                                                    // "phone_verified": data[0]['phone_verified'],
                                                    // "email_verified": data[0]['email_verified'],
                                                    // "goverment_id": data[0]['goverment_id'],
                                                    // "gov_id_verified": gov_id_verified,
                                                    "selfie": data[0]['selfie'],
                                                    "image": data[0]['image'],
                                                    "status": data[0]['status'],
                                                    "email": data[0]['email'],
                                                    "social": data[0]['social_id'],
                                                    // "services": data[0]['services'],
                                                    "bio": data[0]['bio'],
                                                    "social_image": data[0]['social_image'],
                                                    "timezone": data[0]['timezone'],
                                                    "timezone_str": data[0]['timezone_str'],
                                                    "user_type": data[0]['user_type'].toString()
                                                }
                                                res.send({
                                                    "success": true,
                                                    "message": "Your profile has been updated successfully.",
                                                    "data": data
                                                });
                                                return false;
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    });
                } else {
                    res.send({
                        "success": false,
                        "message": "something went wrong",
                        "data": []
                    });
                    return false;
                }
            }
        });
    }

}

function makeid(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}