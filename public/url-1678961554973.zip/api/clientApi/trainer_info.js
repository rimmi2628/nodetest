var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = require('mongodb').ObjectID
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
var mongodbutil = require('./mongodbutil');
var sourceFile = require('../register.js');

exports.trainer_info = async function (req, res) {
	const {
		user_id,
		trainer_id,
		//0 for blocked 1 for unblocked
	} = req.body;
	let errors = [];
	if (!user_id || !trainer_id) {
		res.send({
			"success": false,
			"message": "user_id and trainer_id are required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_TRAINERS').aggregate([{
		$match: {
			_id: ObjectId(req.body.trainer_id),

		}
	},
	{
		$lookup: {
			from: 'TBL_TRAINER_DETAILS',
			localField: '_id',
			foreignField: 'user_id',
			as: 'userdetails'
		}
	},
	{
		$lookup: {
			from: 'TBL_SERVICES',
			localField: 'services.id',
			foreignField: '_id',
			as: 'services'
		}
	},
	{
		$lookup: {
			from: 'TBL_BLOCKED',
			localField: '_id',
			foreignField: 'trainer_id',
			as: 'blocked_by'
		}
	},
	{
		$project: {
			"trainer_id": 1,
			"email": 1,
			"timezone": 1,
			"formatted_address": 1,
			"timezone_str": 1,
			"status": 1,
			"social": 1,
			"services": 1,
			"price": 1,
			"avg_ratings":1,
			"ratings":1,
			"joining_year":1,
			"userdetails": "$userdetails",



		}
	}
	]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {
			if (resr) {
				
				var data = JSON.parse(JSON.stringify(resr));

				if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
					var gov_id_verified = true;
				} else {
					var gov_id_verified = false;
				}
				if (!data[0]['formatted_address']) {
					data[0]['formatted_address'] = ''
				}
				var push_tokki = [];
				if (data[0]['is_blocked'] && client_blocked == 1) {
					is_blocked = data[0]['is_blocked']

				}
				else {
					is_blocked = 0
				}

				data = { 
					"trainer_id": data[0]['_id'],
					"first_name": data[0]['userdetails'][0]['first_name'],
					"last_name": data[0]['userdetails'][0]['last_name'],
					"phone_number": data[0]['userdetails'][0]['phone_number']?parseInt(data[0]['userdetails'][0]['phone_number']):0,
					"phone_verified": data[0]['userdetails'][0]['phone_verified']? parseInt(data[0]['userdetails'][0]['phone_verified']):0,
					"email_verified": data[0]['userdetails'][0]['email_verified']?parseInt(data[0]['userdetails'][0]['email_verified']):0,
					"goverment_id": data[0]['userdetails'][0]['goverment_id']?parseInt(data[0]['userdetails'][0]['goverment_id']):0,
					"gov_id_verified": gov_id_verified,
					"selfie": data[0]['userdetails'][0]['selfie']?data[0]['userdetails'][0]['selfie']:"",
					"image": data[0]['userdetails'][0]['image']?data[0]['userdetails'][0]['image']:"",
					"status": data[0]['status']?data[0]['status']:"",
					"email": data[0]['email']?data[0]['email']:"",
					"social": data[0]['social_id']?data[0]['social_id']:"",
					"services": data[0]['services']?data[0]['services']:"",
					"bio": data[0]['userdetails'][0]['bio']?data[0]['userdetails'][0]['bio']:"",
					"timezone": data[0]['timezone']?data[0]['timezone']:"",
					"address": data[0]['formatted_address']?data[0]['formatted_address']:"",
					"timezone_str": data[0]['timezone_str']?data[0]['timezone_str']:"",
					"avg_rating": data[0]['avg_ratings']?data[0]['avg_ratings']:0,
					"ratings": data[0]['ratings']?data[0]['ratings']:0,
					"price": data[0]['price'] ? data[0]['price'] : "",
					"joinedDate":data[0]['joining_year'] ? data[0]['joining_year'] : 2022,

				}
				res.send({
					"success": true,
					"message": "Sucess",
					"data": data
				});
				return false;




			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}

	});


}