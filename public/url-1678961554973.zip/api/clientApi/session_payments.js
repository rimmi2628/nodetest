var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var sourceFile = require('../register.js');
var db = mongo.connect("mongodb://localhost:27017/gymtraining", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}, function (err, response) {
    if (err) {
        console.log(err);
    } else { //console.log('Connected to ' + db, ' + ', response); 
    }
});
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');

exports.payment_history = async function (req, res) {

    if (!req.body.user_id) {
        res.send({
            "success": false,
            "message": "user_id missing",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    dbo.collection('TBL_TRAINER_PAYMENTS').aggregate([{
        $match: {
            "client_id": ObjectId(req.body.user_id),

        }
    },
    {
        $lookup: {
            from: 'TBL_TRAINERS',
            localField: 'trainer_id',
            foreignField: '_id',
            as: 'trainer'
        }
    },
    {
        $lookup: {
            from: 'TBL_TRAINER_DETAILS',
            localField: 'trainer_id',
            foreignField: 'user_id',
            as: 'trainerdetails'
        }
    },
    ]).toArray(function (err, resr) {
        if (err) {
            throw err;
        } else {
            if (resr) {
              
                var data = JSON.parse(JSON.stringify(resr));
                var dat = [];
                for (var i = 0; i < data.length; i++) {

                    dat.push({
                        "id": data[i]['_id'],
                        "first_name": data[i]['trainerdetails'][0]['first_name'],
                        "last_name": data[i]['trainerdetails'][0]['last_name'],
                        "date": data[i]['created_at'],
                        "amount": data[i]['amount'],
                        "is_punch_card":data[i]["is_punch_card"],
                        "punch_card_id":data[i]["punch_card_id"],
                        "session_id":data[i]["session_id"]
                    })
                }
                res.send({
                    "success": true,
                    "message": "Success!",
                    "data": dat
                });
                return false;
            } else {
                res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": {}
                });
                return false;
            }
        }

    });
}

exports.account = async function (req, res) {

    if (!req.body.user_id) {
        res.send({
            "success": false,
            "message": "user_id missing",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    dbo.collection('TBL_SESSION_PAYMENTS').aggregate([
        {
            $sort: { "created_at": -1 }
        },
        {
            $match: {
                "trainer_id": ObjectId(req.body.user_id),
                // "status":1
            }
        },
        {
            $lookup: {
                from: 'TBL_CLIENTS',
                localField: 'client_id',
                foreignField: '_id',
                as: 'client'
            }
        }
        // ,
        // {
        //     $lookup: {
        //         from: 'TBL_TRAINER_DETAILS',
        //         localField: 'client_id',
        //         foreignField: 'user_id',
        //         as: 'trainerdetails'
        //     }
        // },
        ,
        {
            $group: {
                _id: null, sum: {
                    "$sum": {
                        "$switch": {
                            "branches": [
                                {
                                    "case": { "$eq": ["$status", 1] },
                                    "then": "$amount"
                                }
                            ],
                            "default": 0
                        }
                    }
                },
                data: { $push: '$$ROOT' }
            }
        }
    ]).toArray(function (err, resr) {
        if (err) {
            throw err;
        } else {
            // console.log(resr[0]['data'])
            // return
            if (resr) {
                if (!resr[0]) {
                    res.send({
                        "success": true,
                        "message": "Success!",
                        "data": {}
                    });
                    return false
                }
                var data = JSON.parse(JSON.stringify(resr[0]['data']));
                var dat = [];
                var last_payment = []
                var sum = resr[0]['sum']
                for (var i = 0; i < data.length; i++) {
                    // && data[i]['status'] == 1

                    if (data[i]['client'][0]) {
                        dat.push({
                            "id": data[i]['_id'],
                            "first_name": data[i]['client'][0]['first_name'],
                            "last_name": data[i]['client'][0]['last_name'],
                            "notes": '',
                            "amount": data[i]['amount'],
                            "date": data[i]['created_at'],
                        })
                        if (data[i].status == 1) {
                            last_payment.push(data[i]['created_at'])
                        }
                    }
                    else {
                        if (data[i].status == 2) {
                            dat.push({
                                "id": data[i]['_id'],
                                "first_name": 'Withdrawal',
                                "last_name": 'Pending',
                                "notes": '',
                                "amount": data[i]['amount'],
                                "date": data[i]['created_at'],
                            })
                        }
                        else if (data[i].status == 3) {
                            dat.push({
                                "id": data[i]['_id'],
                                "first_name": 'Withdrawal',
                                "last_name": 'Approved',
                                "notes": data[i]['notes'],
                                "amount": data[i]['amount'],
                                "date": data[i]['created_at'],
                                "payment_ref_id": data[i]['payment_ref_id'],
                            })
                        }
                        else if (data[i].status == 4) {
                            dat.push({
                                "id": data[i]['_id'],
                                "first_name": 'Withdrawal',
                                "last_name": 'Rejected',
                                "notes": '',
                                "amount": data[i]['amount'],
                                "date": data[i]['created_at'],
                                "payment_ref_id": data[i]['payment_ref_id'],
                            })
                        }
                        // if (data[i].status == 1) {
                        //    last_payment.push(data[i]['created_at'])
                        // }
                        sum = sum + data[i]['amount']
                    }

                }
                console.log(last_payment)
                var finalArr = {}
                finalArr['balance'] = sum
                // finalArr['balance'] = resr[0]['sum']
                if (!last_payment) {
                    finalArr['last_payment'] = ''
                }
                else {
                    finalArr['last_payment'] = last_payment[0]
                }
                finalArr['history'] = dat

                res.send({
                    "success": true,
                    "message": "Success!",
                    "data": finalArr
                });
                return false;
            } else {
                res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": {}
                });
                return false;
            }
        }

    });
}
