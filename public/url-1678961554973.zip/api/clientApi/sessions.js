var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = require('mongodb').ObjectID
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
var mongodbutil = require('./mongodbutil');
const {
	admin
} = require('../firebaseConfig.js');
var options = {
	priority: "high",
	timeToLive: 60 * 60 * 24
};
var moment = require('moment'); // require

exports.requestSessions = async function (req, res) {
	const {
		user_id,
		user_type,
		startDate,
		endDate
	} = req.body;
	let errors = [];
	if (!user_id || !user_type || !startDate || !endDate) {
		res.send({
			"success": false,
			"message": "user_id, user_type, startDate, endDate required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	if (req.body.user_type == 0) {
		var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
				$match: {
					"trainer_id": ObjectId(req.body.user_id),
					// "status":{$ne : 3},
					"status": {
						$nin: [3, 4, 5]
					},
					"utc": {
						$gte: req.body.startDate,
						$lt: req.body.endDate
					}
				}
			},
			{
				$lookup: {
					from: 'TBL_CLIENTS',
					localField: 'client_id',
					foreignField: '_id',
					as: 'client'
				}
			},
			{
				$lookup: {
					from: 'TBL_CLIENT_INFO',
					localField: 'client_id',
					foreignField: 'client_id',
					as: 'client_info'
				}
			},
			// {
			// 	$lookup: {
			// 		from: 'TBL_CLIENT_DETAILS',
			// 		localField: 'client_id',
			// 		foreignField: 'user_id',
			// 		as: 'clientdetails'
			// 	}
			// },
			{
				"$unwind": "$client_info"
			},
			{
				"$match": {
					"client_info.trainer_id": ObjectId(req.body.user_id)
				}
			},
		]);

		Query_m.toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					var data = JSON.parse(JSON.stringify(resr));
					// console.log(data[0]['clientdetails'])
					console.log(data)
					// return
					var dat = [];
					for (var i = 0; i < data.length; i++) {
						if (data[i]['client'][0]['timezone'] == undefined) {
							data[i]['client'][0]['timezone'] = ''
						}
						if (data[i]['client'][0]['timezone_str'] == undefined) {
							data[i]['client'][0]['timezone_str'] = ''
						}
						if (data[i]['day'] == undefined) {
							data[i]['day'] = ''
						}
						if (data[i]['month'] == undefined) {
							data[i]['month'] = ''
						}
						if (data[i]['year'] == undefined) {
							data[i]['year'] = ''
						}
						if (data[i]['date_str'] == undefined) {
							data[i]['date_str'] = ''
						}
						if (data[i]['time_str'] == undefined) {
							data[i]['time_str'] = ''
						}
						if (data[i]['gym_name'] == undefined) {
							data[i]['gym_name'] = ''
						}
						if (data[i]['time'] == undefined) {
							data[i]['time'] = ''
						}
						if (data[i]['session_end_date'] == undefined) {
							data[i]['session_end_date'] = ''
						}
						if (!data[i]['client_info']) {
							data[i]['client_info'] = []
							data[i]['client_info'].push({
								first_name: '',
								last_name: '',
								image: '',
								timezone: ''
							})
						} else {
							var client_info2 = data[i]['client_info'];
							data[i]['client_info'] = []
							data[i]['client_info'].push({
								first_name: client_info2.first_name,
								last_name: client_info2.last_name,
								image: client_info2.image,
								timezone: client_info2.timezone
							})
						}
						dat.push({
							"id": data[i]['_id'],
							"trainer_id": data[i]['trainer_id'],
							"client_id": data[i]['client_id'],
							"user_type": data[i]['user_type'],
							"gym_name": data[i]['gym_name'],
							"utc": data[i]['utc'],
							"time": data[i]['time'],
							"repeat": data[i]['repeat'],
							"location": data[i]['location'],
							"duration": data[i]['duration'],
							"first_name": data[i]['client_info'][0]['first_name'],
							"last_name": data[i]['client_info'][0]['last_name'],
							"image": data[i]['client_info'][0]['image'],
							"timezone": data[i]['client_info'][0]['timezone'],
							"timezone_str": data[i]['timezone_str'],
							"status": data[i]['status'],
							"day": data[i]['day'],
							"month": data[i]['month'],
							"year": data[i]['year'],
							"date_str": data[i]['date_str'],
							"time_str": data[i]['time_str'],
							"session_end_date": data[i]['session_end_date'].toString()
						})
					}
					res.send({
						"success": true,
						"message": "Success!",
						"data": dat
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	} else {
		var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
				$match: {
					client_id: ObjectId(req.body.user_id),
					status: {
						// $ne: 3
						$nin: [3, 4, 5]
					},
					utc: {
						$gte: req.body.startDate,
						$lt: req.body.endDate
					}

				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINERS',
					localField: 'trainer_id',
					foreignField: '_id',
					as: 'trainer'
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINER_DETAILS',
					localField: 'trainer_id',
					foreignField: 'user_id',
					as: 'trainerdetails'
				}
			},

		]);

		Query_m.toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					var data = JSON.parse(JSON.stringify(resr));
					// console.log(data[0]['clientdetails'])
					// console.log(data)
					var dat = [];
					for (var i = 0; i < data.length; i++) {
						if (data[i]['trainer'][0]['timezone'] == undefined) {
							data[i]['trainer'][0]['timezone'] = ''
						}
						if (data[i]['trainer'][0]['timezone_str'] == undefined) {
							data[i]['trainer'][0]['timezone_str'] = ''
						}
						if (data[i]['day'] == undefined) {
							data[i]['day'] = ''
						}
						if (data[i]['month'] == undefined) {
							data[i]['month'] = ''
						}
						if (data[i]['year'] == undefined) {
							data[i]['year'] = ''
						}
						if (data[i]['date_str'] == undefined) {
							data[i]['date_str'] = ''
						}
						if (data[i]['time_str'] == undefined) {
							data[i]['time_str'] = ''
						}
						if (data[i]['gym_name'] == undefined) {
							data[i]['gym_name'] = ''
						}
						if (data[i]['session_end_date'] == undefined) {
							data[i]['session_end_date'] = ''
						}
						dat.push({
							"id": data[i]['_id'],
							"client_id": data[i]['client_id'],
							"trainer_id": data[i]['trainer_id'],
							"user_type": data[i]['user_type'],
							"gym_name": data[i]['gym_name'],
							"utc": data[i]['utc'],
							"time": data[i]['time'],
							"repeat": data[i]['repeat'],
							"location": data[i]['location'],
							"duration": data[i]['duration'],
							"first_name": data[i]['trainerdetails'][0]['first_name'],
							"last_name": data[i]['trainerdetails'][0]['last_name'],
							"image": data[i]['trainerdetails'][0]['image'],
							"timezone": data[i]['trainer'][0]['timezone'],
							"timezone_str": data[i]['trainer'][0]['timezone_str'],
							"status": data[i]['status'],
							"day": data[i]['day'],
							"month": data[i]['month'],
							"year": data[i]['year'],
							"date_str": data[i]['date_str'],
							"time_str": data[i]['time_str'],
							"session_end_date": data[i]['session_end_date'].toString()
						})
					}
					res.send({
						"success": true,
						"message": "Success!",
						"data": dat
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	}
}

exports.view_sessions = async function (req, res) {
	const {
		user_id,
		user_type,
	} = req.body;
	let errors = [];
	if (!user_id || !user_type) {
		res.send({
			"success": false,
			"message": "user_id and user_type required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	console.log('---------------------req.body')
	console.log(req.body)
	if (req.body.user_type == 0) {
		if (!req.body.month) {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([

				{
					$lookup: {
						from: 'TBL_CLIENTS',
						localField: 'client_id',
						foreignField: '_id',
						as: 'client'
					}
				},
				{
					$lookup: {
						from: 'TBL_CLIENT_INFO',
						localField: 'client_id',
						foreignField: 'client_id',
						as: 'client_info'
					}
				},
				// {
				// 	$lookup: {
				// 		from: 'TBL_CLIENT_DETAILS',
				// 		localField: 'client_id',
				// 		foreignField: 'user_id',
				// 		as: 'clientdetails'
				// 	}
				// },
				{
					$match: {
						"trainer_id": ObjectId(req.body.user_id),
						// "client_info.trainer_id": ObjectId(req.body.user_id),
						// "status":{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
				{
					"$unwind": "$client_info"
				},
				{
					"$match": {
						"client_info.trainer_id": ObjectId(req.body.user_id)
					}
				},
				// 	{$group: {
				//       _id: "$_id",
				//       client_info: {$push: "$client_info"}
				//   }}
			]);
		} else {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([

				{
					$lookup: {
						from: 'TBL_CLIENTS',
						localField: 'client_id',
						foreignField: '_id',
						as: 'client'
					}
				},
				{
					$lookup: {
						from: 'TBL_CLIENT_INFO',
						localField: 'client_id',
						foreignField: 'client_id',
						as: 'client_info'
					}
				},
				{
					$match: {
						"trainer_id": ObjectId(req.body.user_id),
						// "client_info.trainer_id": ObjectId(req.body.user_id),
						"month": req.body.month,
						// "status":{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
				{
					"$unwind": "$client_info"
				},
				{
					"$match": {
						"client_info.trainer_id": ObjectId(req.body.user_id)
						// "client_info.client_id":ObjectId(req.body.user_id)
					}
				},
			]);
		}
		Query_m.toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					var data = JSON.parse(JSON.stringify(resr));
					// console.log(data[0]['clientdetails'])

					// return
					var dat = [];
					for (var i = 0; i < data.length; i++) {
						if (!data[i]['client'][0]) {
							data[i]['client'] = []
							data[i]['client'].push({
								timezone: '',
								timezone_str: ''
							})
							// data[i]['client'][0]['timezone'] = ''
							// data[i]['client'][0]['timezone_str'] = ''

						} else {
							if (data[i]['client'][0]['timezone'] == undefined) {
								data[i]['client'][0]['timezone'] = ''
							}
							if (data[i]['client'][0]['timezone_str'] == undefined) {
								data[i]['client'][0]['timezone_str'] = ''
							}
						}
						if (!data[i]['client_info']) {
							data[i]['client_info'] = []
							data[i]['client_info'].push({
								first_name: '',
								last_name: '',
								image: '',
								timezone: ''
							})
						} else {
							// console.log('data---------------------')
							// console.log(data[i].client_info.first_name)
							// console.log('data---------------------')
							var client_info2 = data[i]['client_info'];
							data[i]['client_info'] = []
							data[i]['client_info'].push({
								first_name: client_info2.first_name,
								last_name: client_info2.last_name,
								image: client_info2.image,
								timezone: client_info2.timezone
							})
						}
						// console.log('data---------------------')
						// console.log(data[i]['client_info'])
						// console.log('data---------------------')
						// console.log(data[i].client_info.last_name)
						if (data[i]['day'] == undefined) {
							data[i]['day'] = ''
						}
						if (data[i]['month'] == undefined) {
							data[i]['month'] = ''
						}
						if (data[i]['year'] == undefined) {
							data[i]['year'] = ''
						}
						if (data[i]['date_str'] == undefined) {
							data[i]['date_str'] = ''
						}
						if (data[i]['time_str'] == undefined) {
							data[i]['time_str'] = ''
						}
						if (data[i]['timezone_str'] == undefined) {
							data[i]['timezone_str'] = data[i]['client'][0]['timezone_str']
						}
						if (data[i]['gym_name'] == undefined) {
							data[i]['gym_name'] = ''
						}
						if (data[i]['time'] == undefined) {
							data[i]['time'] = ''
						}
						if (data[i]['session_end_date'] == undefined) {
							data[i]['session_end_date'] = ''
						}
						dat.push({
							"id": data[i]['_id'],
							"trainer_id": data[i]['trainer_id'],
							"client_id": data[i]['client_id'],
							"user_type": data[i]['user_type'],
							"gym_name": data[i]['gym_name'],
							"utc": data[i]['utc'],
							"time": data[i]['time'],
							"repeat": data[i]['repeat'],
							"location": data[i]['location'],
							"duration": data[i]['duration'],
							"first_name": data[i]['client_info'][0]['first_name'],
							"last_name": data[i]['client_info'][0]['last_name'],
							"image": data[i]['client_info'][0]['image'],
							"timezone": data[i]['client_info'][0]['timezone'],
							"timezone_str": data[i]['timezone_str'],
							"status": data[i]['status'],
							"day": data[i]['day'],
							"month": data[i]['month'],
							"year": data[i]['year'],
							"date_str": data[i]['date_str'],
							"time_str": data[i]['time_str'],
							"slot_id": data[i]['slot_id'],
							"session_end_date": data[i]['session_end_date'].toString()
						})
					}
					res.send({
						"success": true,
						"message": "Success!",
						"data": dat
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	} else {
		if (!req.body.month) {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.user_id),
						// status:{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINERS',
						localField: 'trainer_id',
						foreignField: '_id',
						as: 'trainer'
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINER_DETAILS',
						localField: 'trainer_id',
						foreignField: 'user_id',
						as: 'trainerdetails'
					}
				},

			]);
		} else {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.user_id),
						"month": req.body.month,
						// "status":{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINERS',
						localField: 'trainer_id',
						foreignField: '_id',
						as: 'trainer'
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINER_DETAILS',
						localField: 'trainer_id',
						foreignField: 'user_id',
						as: 'trainerdetails'
					}
				},

			])
		}
		Query_m.toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					var data = JSON.parse(JSON.stringify(resr));
					// console.log(data[0]['clientdetails'])
					// console.log(data)
					var dat = [];
					for (var i = 0; i < data.length; i++) {
						if (data[i]['trainer'][0]['timezone'] == undefined) {
							data[i]['trainer'][0]['timezone'] = ''
						}
						if (data[i]['trainer'][0]['timezone_str'] == undefined) {
							data[i]['trainer'][0]['timezone_str'] = ''
						}
						if (data[i]['day'] == undefined) {
							data[i]['day'] = ''
						}
						if (data[i]['month'] == undefined) {
							data[i]['month'] = ''
						}
						if (data[i]['year'] == undefined) {
							data[i]['year'] = ''
						}
						if (data[i]['date_str'] == undefined) {
							data[i]['date_str'] = ''
						}
						if (data[i]['time_str'] == undefined) {
							data[i]['time_str'] = ''
						}
						if (data[i]['timezone_str'] == undefined) {
							data[i]['timezone_str'] = data[i]['trainer'][0]['timezone_str'];
						}
						if (data[i]['gym_name'] == undefined) {
							data[i]['gym_name'] = ''
						}
						if (data[i]['session_end_date'] == undefined) {
							data[i]['session_end_date'] = ''
						}
						dat.push({
							"id": data[i]['_id'],
							"client_id": data[i]['client_id'],
							"trainer_id": data[i]['trainer_id'],
							"user_type": data[i]['user_type'],
							"gym_name": data[i]['gym_name'],
							"utc": data[i]['utc'],
							"time": data[i]['time'],
							"repeat": data[i]['repeat'],
							"location": data[i]['location'],
							"duration": data[i]['duration'],
							"first_name": data[i]['trainerdetails'][0]['first_name'],
							"last_name": data[i]['trainerdetails'][0]['last_name'],
							"image": data[i]['trainerdetails'][0]['image'],
							"timezone": data[i]['trainer'][0]['timezone'],
							"timezone_str": data[i]['timezone_str'],
							"status": data[i]['status'],
							"day": data[i]['day'],
							"month": data[i]['month'],
							"year": data[i]['year'],
							"date_str": data[i]['date_str'],
							"time_str": data[i]['time_str'],
							"slot_id": data[i]['slot_id'],
							"session_end_date": data[i]['session_end_date'].toString()
						})
					}
					res.send({
						"success": true,
						"message": "Success!",
						"data": dat
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	}
}

exports.view_sessions_new = async function (req, res) {
	const {
		user_id,
		user_type,
	} = req.body;
	let errors = [];
	if (!user_id || !user_type) {
		res.send({
			"success": false,
			"message": "user_id and user_type required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	console.log('---------------------req.body')
	console.log(req.body)
	if (req.body.user_type == 0) {

		var date_now = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
		var seconds = date_now.getTime() / 1000
		console.log(seconds)
		dbo.collection('TBL_SESSIONS').aggregate([

			{
				$lookup: {
					from: 'TBL_CLIENTS',
					localField: 'client_id',
					foreignField: '_id',
					as: 'client'
				}
			},
			{
				$lookup: {
					from: 'TBL_CLIENT_INFO',
					localField: 'client_id',
					foreignField: 'client_id',
					as: 'client_info'
				}
			},

			{
				$match: {
					"trainer_id": ObjectId(req.body.user_id),
					"utc": {
						$gte: seconds.toString()
					},
					// "client_info.trainer_id": ObjectId(req.body.user_id),
					// "status":{$ne : 3}
					"repeat": '0',
					"status": {
						$nin: [3, 4, 5 , 6]
					},
				}
			},
			{
				"$unwind": "$client_info"
			},
			{
				"$match": {
					"client_info.trainer_id": ObjectId(req.body.user_id)
				}
			},
			{
				$limit: 10
			},

		]).toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					dbo.collection('TBL_SESSIONS').aggregate([

						{
							$lookup: {
								from: 'TBL_CLIENTS',
								localField: 'client_id',
								foreignField: '_id',
								as: 'client'
							}
						},
						{
							$lookup: {
								from: 'TBL_CLIENT_INFO',
								localField: 'client_id',
								foreignField: 'client_id',
								as: 'client_info'
							}
						},

						{
							$match: {
								"trainer_id": ObjectId(req.body.user_id),
								// "client_info.trainer_id": ObjectId(req.body.user_id),
								// "status":{$ne : 3}
								"repeat": {
									$in: ['1', '2']
								},
								"status": {
									$nin: [3, 4, 5]
								},
							}
						},
						{
							"$unwind": "$client_info"
						},
						{
							"$match": {
								"client_info.trainer_id": ObjectId(req.body.user_id)
							}
						},

					]).toArray(function (err, resr_repeat) {
						if (err) {
							throw err;
						} else {
							// if (resr_repeat) {
							var data = JSON.parse(JSON.stringify(resr));
							var data_repeat = JSON.parse(JSON.stringify(resr_repeat));
							var dat = [];
							var datR = [];
							var datN = [];


							for (var i = 0; i < data.length; i++) {
								if (!data[i]['client'][0]) {
									data[i]['client'] = []
									data[i]['client'].push({
										timezone: '',
										timezone_str: ''
									})
									// data[i]['client'][0]['timezone'] = ''
									// data[i]['client'][0]['timezone_str'] = ''

								} else {
									if (data[i]['client'][0]['timezone'] == undefined) {
										data[i]['client'][0]['timezone'] = ''
									}
									if (data[i]['client'][0]['timezone_str'] == undefined) {
										data[i]['client'][0]['timezone_str'] = ''
									}
								}
								if (!data[i]['client_info']) {
									data[i]['client_info'] = []
									data[i]['client_info'].push({
										first_name: '',
										last_name: '',
										image: '',
										timezone: ''
									})
								} else {

									var client_info2 = data[i]['client_info'];
									data[i]['client_info'] = []
									data[i]['client_info'].push({
										first_name: client_info2.first_name,
										last_name: client_info2.last_name,
										image: client_info2.image,
										timezone: client_info2.timezone
									})
								}

								if (data[i]['day'] == undefined) {
									data[i]['day'] = ''
								}
								if (data[i]['month'] == undefined) {
									data[i]['month'] = ''
								}
								if (data[i]['year'] == undefined) {
									data[i]['year'] = ''
								}
								if (data[i]['date_str'] == undefined) {
									data[i]['date_str'] = ''
								}
								if (data[i]['time_str'] == undefined) {
									data[i]['time_str'] = ''
								}
								if (data[i]['timezone_str'] == undefined) {
									data[i]['timezone_str'] = data[i]['client'][0]['timezone_str']
								}
								if (data[i]['gym_name'] == undefined) {
									data[i]['gym_name'] = ''
								}
								if (data[i]['time'] == undefined) {
									data[i]['time'] = ''
								}
								if (data[i]['session_end_date'] == undefined) {
									data[i]['session_end_date'] = ''
								}
								datR.push({
									"id": data[i]['_id'],
									"trainer_id": data[i]['trainer_id'],
									"client_id": data[i]['client_id'],
									"user_type": data[i]['user_type'],
									"gym_name": data[i]['gym_name'],
									"utc": data[i]['utc'],
									"time": data[i]['time'],
									"repeat": data[i]['repeat'],
									"location": data[i]['location'],
									"duration": data[i]['duration'],
									"first_name": data[i]['client_info'][0]['first_name'],
									"last_name": data[i]['client_info'][0]['last_name'],
									"image": data[i]['client_info'][0]['image'],
									"timezone": data[i]['client_info'][0]['timezone'],
									"timezone_str": data[i]['timezone_str'],
									"status": data[i]['status'],
									"day": data[i]['day'],
									"month": data[i]['month'],
									"year": data[i]['year'],
									"date_str": data[i]['date_str'],
									"time_str": data[i]['time_str'],
									"slot_id": data[i]['slot_id'],
									"session_end_date": data[i]['session_end_date'].toString()
								})
								// datN[i][data[i]['utc']] = dat[i]
								// var utccc = data[i]['utc']
								// datN.push({[utccc]:dat[i]})
							}
							// console.log('data_repeat.length----' + data_repeat.length)

							for (var f = 0; f < data_repeat.length; f++) {
								// console.log('data_repeat----' + data_repeat[f]['repeat'])
								// console.log('data_repeat[f][utc]----' + data_repeat[f]['utc'])

								if (!data_repeat[f]['client'][0]) {
									data_repeat[f]['client'] = []
									data_repeat[f]['client'].push({
										timezone: '',
										timezone_str: ''
									})

								} else {
									if (data_repeat[f]['client'][0]['timezone'] == undefined) {
										data_repeat[f]['client'][0]['timezone'] = ''
									}
									if (data_repeat[f]['client'][0]['timezone_str'] == undefined) {
										data_repeat[f]['client'][0]['timezone_str'] = ''
									}
								}
								if (!data_repeat[f]['client_info']) {
									data_repeat[f]['client_info'] = []
									data_repeat[f]['client_info'].push({
										first_name: '',
										last_name: '',
										image: '',
										timezone: ''
									})
								} else {

									var client_info2 = data_repeat[f]['client_info'];
									data_repeat[f]['client_info'] = []
									data_repeat[f]['client_info'].push({
										first_name: client_info2.first_name,
										last_name: client_info2.last_name,
										image: client_info2.image,
										timezone: client_info2.timezone
									})
								}

								if (data_repeat[f]['day'] == undefined) {
									data_repeat[f]['day'] = ''
								}
								if (data_repeat[f]['month'] == undefined) {
									data_repeat[f]['month'] = ''
								}
								if (data_repeat[f]['year'] == undefined) {
									data_repeat[f]['year'] = ''
								}
								if (data_repeat[f]['date_str'] == undefined) {
									data_repeat[f]['date_str'] = ''
								}
								if (data_repeat[f]['time_str'] == undefined) {
									data_repeat[f]['time_str'] = ''
								}
								if (data_repeat[f]['timezone_str'] == undefined) {
									data_repeat[f]['timezone_str'] = data_repeat[f]['client'][0]['timezone_str']
								}
								if (data_repeat[f]['gym_name'] == undefined) {
									data_repeat[f]['gym_name'] = ''
								}
								if (data_repeat[f]['time'] == undefined) {
									data_repeat[f]['time'] = ''
								}
								if (data_repeat[f]['session_end_date'] == undefined) {
									data_repeat[f]['session_end_date'] = ''
								}
								if (data_repeat[f]['repeat'] == '1') {
									console.log("data_repeat[f]['repeat'] == '1'")
									var current_utc_add = new Date(Number(data_repeat[f]['utc'] * 1000))
									current_utc_add.setYear(Number(req.body.year))

									var req_utc_date = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');


									var differ = dateDiffInDays(current_utc_add, req_utc_date);
									// console.log(differ + '-------------differ')
									if (differ > 0) {
										current_utc_add.setDate(current_utc_add.getDate() + Number(differ))
										// console.log('current_utc_add_11 ---'+ current_utc_add)
										current_utc_add.setMonth(Number(req.body.month) - 1)
									}
									
									// console.log('current_utc_add ---'+ current_utc_add)
									// if (Number(req.body.year) != Number(data_repeat[f]['year']) || Number(req.body.month) != Number(data_repeat[f]['month']) ) {
									// 	current_utc_add.setDate(Number(req.body.day))
									// 	current_utc_add.setMonth(Number(req.body.month) - 1)
									// }

									var current_utc = current_utc_add.getTime() / 1000
									var end_utc = data_repeat[f]['session_end_date']
									var next_utc = ''

									for (var l = 0; l < 10; l++) {
										// var new_utc = Number(current_utc) + (7 * 24 * 60 * 60)
										if (next_utc == '') {
											var current_date = new Date(Number(current_utc) * 1000)
											// current_date.setDate(current_date.getDate() + 7);
											var new_utc = current_date.getTime() / 1000
											next_utc = new_utc
										} else {
											var current_date = new Date(Number(next_utc) * 1000)
											current_date.setDate(current_date.getDate() + 7);
											var new_utc = current_date.getTime() / 1000
											next_utc = new_utc

										}


										if (end_utc != '' && new_utc > end_utc) {
											break;
										}
										if (differ % 7 != 0) {
											break;
										}
										// if (current_date.getDate() == 28) {
										// console.log('--------------------------------------******')
										// 	console.log("new_utc",new_utc)
										// 	console.log('current_date',current_date)
										// 	console.log("differ",differ)
										// 	console.log('******--------------------------------------')
										// }

										var date = new Date(new_utc * 1000)
										var date_number = date.getDate()
										var month_number = date.getMonth() + 1
										var year_number = date.getFullYear();

										if (date_number < 10) {
											date_number = '0' + date_number
										}
										if (month_number < 10) {
											month_number = '0' + month_number
										}

										
										datR.push({
											"id": data_repeat[f]['_id'],
											"trainer_id": data_repeat[f]['trainer_id'],
											"client_id": data_repeat[f]['client_id'],
											"user_type": data_repeat[f]['user_type'],
											"gym_name": data_repeat[f]['gym_name'],
											"utc": new_utc.toString(),
											"time": data_repeat[f]['time'],
											"repeat": data_repeat[f]['repeat'],
											"location": data_repeat[f]['location'],
											"duration": data_repeat[f]['duration'],
											"first_name": data_repeat[f]['client_info'][0]['first_name'],
											"last_name": data_repeat[f]['client_info'][0]['last_name'],
											"image": data_repeat[f]['client_info'][0]['image'],
											"timezone": data_repeat[f]['client_info'][0]['timezone'],
											"timezone_str": data_repeat[f]['timezone_str'],
											"status": data_repeat[f]['status'],
											"day": date_number.toString(),
											"month": month_number.toString(),
											"year": year_number.toString(),
											"date_str": month_number + '.' + date_number + '.' + year_number,
											"time_str": data_repeat[f]['time_str'],
											"slot_id": data_repeat[f]['slot_id'],
											"session_end_date": data_repeat[f]['session_end_date'].toString()
										})
										// var utccc = new_utc
										// datN.push({[utccc]:datR[l]})
									}
								} else if (data_repeat[f]['repeat'] == '2') {
									console.log("data_repeat[f]['repeat'] == '2'")
									var original_utc_date = moment(Number(data_repeat[f]['utc'] * 1000));
									original_utc_date.set('year', Number(req.body.year))
									// var current_utc_add = new Date(Number(data_repeat[f]['utc'] * 1000))
									// current_utc_add.setYear(Number(req.body.year))
									var current_utc_add = moment(Number(data_repeat[f]['utc'] * 1000));
									current_utc_add.set('year', Number(req.body.year))

									// var req_utc_date = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
									// var req_utc_moment = moment('' + req.body.year + '-' + req.body.month + '-' + req.body.day + '');

									// var a = current_utc_add;
									// var b = req_utc_moment;


									// var differ = monthBetween(current_utc_add, req_utc_date);
									// var differ = b.diff(a, 'months') // 1
									// // var differ = a.diff(b, 'months') // 1
									// console.log('Differ 2---------------- ' + differ)
									// if (differ > 0) {
									// 	current_utc_add.set('month',Number(req.body.month) - 1)
									// 	// current_utc_add.setMonth(Number(req.body.month) - 1)
									// }
									if (req.body.page_no != 1) {
										current_utc_add.set('month', Number(req.body.month) - 1)
										// current_utc_add.set('month',Number(req.body.month) - 1)
									}
									var current_utc = current_utc_add.valueOf() / 1000
									var end_utc = data_repeat[f]['session_end_date']
									var next_utc = ''
									for (var l = 0; l < 10; l++) {

										// var new_utc = Number(current_utc) + (7 * 24 * 60 * 60)

										if (next_utc == '') {
											var current_date = moment(Number(current_utc) * 1000)
											var new_utc = current_date.valueOf() / 1000
											next_utc = new_utc
										} else {
											var current_date = moment(Number(next_utc) * 1000)
											// current_date.setMonth(current_date.getMonth() + 1);
											// current_date.set('month',Number(current_date.month() ) + 1)
											// console.log('current_date1 '+ current_date)
											current_date.add(1, 'months');
											var endOfMonth = current_date.clone().endOf('month').date();
											// console.log('current_date '+ current_date)
											// console.log('original_utc_date.date() '+ original_utc_date.date())
											// console.log('endOfMonth '+ endOfMonth)

											if (Number(original_utc_date.date()) > Number(endOfMonth)) {
												current_date.set('date', Number(endOfMonth))

											} else {
												current_date.set('date', Number(original_utc_date.date()))
												// current_date.add(1, 'months');
											}
											// else{

											// }	
											// console.log('current_date2 '+ current_date)
											// console.log('--------------- ')
											// current_date =  current_date.add(l, 'month')
											// console.log(current_date)
											// current_date.set('date',Number(current_utc_add.date() ) )
											// console.log('current_date '+current_date)
											var new_utc = current_date.valueOf() / 1000
											next_utc = new_utc
										}

										if (end_utc != '' && new_utc > end_utc) {
											console.log('BREAK ONE')
											break;
										}

										var date = moment(new_utc * 1000)
										// if (date.date() < current_utc_add.date()) {
										// 	date.date(current_utc_add.date())
										// }

										// date.set('date',Number(current_utc_add.date() ) )
										var date_number = date.date()
										var month_number = date.month() + 1
										var year_number = date.year();

										// console.log('new_utc.toString() '+ new_utc)
										// console.log('date '+ date)
										// // console.log('date '+ date)
										// console.log('date_number '+ date_number)
										// console.log('month_number '+ month_number)
										// console.log('year_number '+ year_number)
										if (date_number < 10) {
											date_number = '0' + date_number
										}
										if (month_number < 10) {
											month_number = '0' + month_number
										}


										datR.push({
											"id": data_repeat[f]['_id'],
											"trainer_id": data_repeat[f]['trainer_id'],
											"client_id": data_repeat[f]['client_id'],
											"user_type": data_repeat[f]['user_type'],
											"gym_name": data_repeat[f]['gym_name'],
											"utc": new_utc.toString(),
											"time": data_repeat[f]['time'],
											"repeat": data_repeat[f]['repeat'],
											"location": data_repeat[f]['location'],
											"duration": data_repeat[f]['duration'],
											"first_name": data_repeat[f]['client_info'][0]['first_name'],
											"last_name": data_repeat[f]['client_info'][0]['last_name'],
											"image": data_repeat[f]['client_info'][0]['image'],
											"timezone": data_repeat[f]['client_info'][0]['timezone'],
											"timezone_str": data_repeat[f]['timezone_str'],
											"status": data_repeat[f]['status'],
											"day": date_number.toString(),
											"month": month_number.toString(),
											"year": year_number.toString(),
											"date_str": month_number + '.' + date_number + '.' + year_number,
											"time_str": data_repeat[f]['time_str'],
											"slot_id": data_repeat[f]['slot_id'],
											"session_end_date": data_repeat[f]['session_end_date'].toString()
										})
										// var utccc = new_utc
										// datN.push({[utccc]:datR[l]})
									}
								}

								// datN[f][data_repeat[f]['utc']] = dat[f]

							}
							// }
						}
						// console.log(dat)
						// console.log(datR)
						if (!datR || datR.datR == 0) {
							res.send({
								"success": true,
								"message": "no_data",
								"data": datR,
							});
							return false;
						} else {
							datR.sort((a, b) => (a.utc > b.utc) ? 1 : ((b.utc > a.utc) ? -1 : 0))

							const slicedArray = datR.slice(0, 10);
							// console.log(datR)
							// return false
							// console.log(slicedArray)
							// return false
							if (!slicedArray || slicedArray.length == 0) {
								res.send({
									"success": true,
									"message": "no_data",
									"data": slicedArray,
								});
								return false;
							} else {
								res.send({
									"success": true,
									"message": "Success!",
									"data": slicedArray,
								});
								return false;
							}
						}


					})


				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	} else {
		var date_now = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
		var seconds = date_now.getTime() / 1000
		// console.log(seconds)
		dbo.collection('TBL_SESSIONS').aggregate([{
				$match: {
					client_id: ObjectId(req.body.user_id),
					// status:{$ne : 3}
					"status": {
						$nin: [3, 4, 5, 6]
					},
					"utc": {
						$gte: seconds.toString()
					},
					"repeat": '0',
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINERS',
					localField: 'trainer_id',
					foreignField: '_id',
					as: 'trainer'
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINER_DETAILS',
					localField: 'trainer_id',
					foreignField: 'user_id',
					as: 'trainerdetails'
				}
			},
			{
				$limit: 10
			},
		]).toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					dbo.collection('TBL_SESSIONS').aggregate([

						{
							$lookup: {
								from: 'TBL_TRAINERS',
								localField: 'trainer_id',
								foreignField: '_id',
								as: 'trainer'
							}
						},
						{
							$lookup: {
								from: 'TBL_TRAINER_DETAILS',
								localField: 'trainer_id',
								foreignField: 'user_id',
								as: 'trainerdetails'
							}
						},

						{
							$match: {
								client_id: ObjectId(req.body.user_id),
								// "client_info.trainer_id": ObjectId(req.body.user_id),
								// "status":{$ne : 3}
								"repeat": {
									$in: ['1', '2']
								},
								"status": {
									$nin: [3, 4, 5]
								},
							}
						},


					]).toArray(function (err, resr_repeat) {
						if (err) {
							throw err;
						} else {
							var data = JSON.parse(JSON.stringify(resr));
							var data_repeat = JSON.parse(JSON.stringify(resr_repeat));
							var dat = [];
							var datR = [];
							var datN = [];


							for (var i = 0; i < data.length; i++) {
								if (data[i]['trainer'][0]['timezone'] == undefined) {
									data[i]['trainer'][0]['timezone'] = ''
								}
								if (data[i]['trainer'][0]['timezone_str'] == undefined) {
									data[i]['trainer'][0]['timezone_str'] = ''
								}
								if (data[i]['day'] == undefined) {
									data[i]['day'] = ''
								}
								if (data[i]['month'] == undefined) {
									data[i]['month'] = ''
								}
								if (data[i]['year'] == undefined) {
									data[i]['year'] = ''
								}
								if (data[i]['date_str'] == undefined) {
									data[i]['date_str'] = ''
								}
								if (data[i]['time_str'] == undefined) {
									data[i]['time_str'] = ''
								}
								if (data[i]['timezone_str'] == undefined) {
									data[i]['timezone_str'] = data[i]['trainer'][0]['timezone_str'];
								}
								if (data[i]['gym_name'] == undefined) {
									data[i]['gym_name'] = ''
								}
								if (data[i]['session_end_date'] == undefined) {
									data[i]['session_end_date'] = ''
								}
								datR.push({
									"id": data[i]['_id'],
									"client_id": data[i]['client_id'],
									"trainer_id": data[i]['trainer_id'],
									"user_type": data[i]['user_type'],
									"gym_name": data[i]['gym_name'],
									"utc": data[i]['utc'],
									"time": data[i]['time'],
									"repeat": data[i]['repeat'],
									"location": data[i]['location'],
									"duration": data[i]['duration'],
									"first_name": data[i]['trainerdetails'][0]['first_name'],
									"last_name": data[i]['trainerdetails'][0]['last_name'],
									"image": data[i]['trainerdetails'][0]['image'],
									"timezone": data[i]['trainer'][0]['timezone'],
									"timezone_str": data[i]['timezone_str'],
									"status": data[i]['status'],
									"day": data[i]['day'],
									"month": data[i]['month'],
									"year": data[i]['year'],
									"date_str": data[i]['date_str'],
									"time_str": data[i]['time_str'],
									"slot_id": data[i]['slot_id'],
									"session_end_date": data[i]['session_end_date'].toString()
								})
							}

							for (var f = 0; f < data_repeat.length; f++) {

								if (data_repeat[f]['trainer'][0]['timezone'] == undefined) {
									data_repeat[f]['trainer'][0]['timezone'] = ''
								}
								if (data_repeat[f]['trainer'][0]['timezone_str'] == undefined) {
									data_repeat[f]['trainer'][0]['timezone_str'] = ''
								}
								if (data_repeat[f]['day'] == undefined) {
									data_repeat[f]['day'] = ''
								}
								if (data_repeat[f]['month'] == undefined) {
									data_repeat[f]['month'] = ''
								}
								if (data_repeat[f]['year'] == undefined) {
									data_repeat[f]['year'] = ''
								}
								if (data_repeat[f]['date_str'] == undefined) {
									data_repeat[f]['date_str'] = ''
								}
								if (data_repeat[f]['time_str'] == undefined) {
									data_repeat[f]['time_str'] = ''
								}
								if (data_repeat[f]['timezone_str'] == undefined) {
									data_repeat[f]['timezone_str'] = data_repeat[f]['trainer'][0]['timezone_str'];
								}
								if (data_repeat[f]['gym_name'] == undefined) {
									data_repeat[f]['gym_name'] = ''
								}
								if (data_repeat[f]['session_end_date'] == undefined) {
									data_repeat[f]['session_end_date'] = ''
								}
								if (data_repeat[f]['repeat'] == '1') {
									var current_utc_add = new Date(Number(data_repeat[f]['utc'] * 1000))
									current_utc_add.setYear(Number(req.body.year))

									var req_utc_date = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');


									var differ = dateDiffInDays(current_utc_add, req_utc_date);
									console.log(differ + '-------------differ')
									if (differ > 0) {
										current_utc_add.setDate(current_utc_add.getDate() + Number(differ))
										// console.log('current_utc_add_11 ---'+ current_utc_add)
										current_utc_add.setMonth(Number(req.body.month) - 1)
									}
									// console.log('current_utc_add ---'+ current_utc_add)
									// if (Number(req.body.year) != Number(data_repeat[f]['year']) || Number(req.body.month) != Number(data_repeat[f]['month']) ) {
									// 	current_utc_add.setDate(Number(req.body.day))
									// 	current_utc_add.setMonth(Number(req.body.month) - 1)
									// }

									var current_utc = current_utc_add.getTime() / 1000
									var end_utc = data_repeat[f]['session_end_date']
									var next_utc = ''
									for (var l = 0; l < 10; l++) {
										// var new_utc = Number(current_utc) + (7 * 24 * 60 * 60)
										if (next_utc == '') {
											var current_date = new Date(Number(current_utc) * 1000)
											// current_date.setDate(current_date.getDate() + 7);
											var new_utc = current_date.getTime() / 1000
											next_utc = new_utc
										} else {
											var current_date = new Date(Number(next_utc) * 1000)
											current_date.setDate(current_date.getDate() + 7);
											var new_utc = current_date.getTime() / 1000
											next_utc = new_utc

										}


										if (end_utc != '' && new_utc > end_utc) {
											break;
										}
										if (differ % 7 != 0) {
											break;
										}
										var date = new Date(new_utc * 1000)
										var date_number = date.getDate()
										var month_number = date.getMonth() + 1
										var year_number = date.getFullYear();

										if (date_number < 10) {
											date_number = '0' + date_number
										}
										if (month_number < 10) {
											month_number = '0' + month_number
										}
										datR.push({
											"id": data_repeat[f]['_id'],
											"client_id": data_repeat[f]['client_id'],
											"trainer_id": data_repeat[f]['trainer_id'],
											"user_type": data_repeat[f]['user_type'],
											"gym_name": data_repeat[f]['gym_name'],
											"utc": new_utc.toString(),
											"time": data_repeat[f]['time'],
											"repeat": data_repeat[f]['repeat'],
											"location": data_repeat[f]['location'],
											"duration": data_repeat[f]['duration'],
											"first_name": data_repeat[f]['trainerdetails'][0]['first_name'],
											"last_name": data_repeat[f]['trainerdetails'][0]['last_name'],
											"image": data_repeat[f]['trainerdetails'][0]['image'],
											"timezone": data_repeat[f]['trainer'][0]['timezone'],
											"timezone_str": data_repeat[f]['timezone_str'],
											"status": data_repeat[f]['status'],
											"day": date_number.toString(),
											"month": month_number.toString(),
											"year": year_number.toString(),
											"date_str": month_number + '.' + date_number + '.' + year_number,
											"time_str": data_repeat[f]['time_str'],
											"slot_id": data_repeat[f]['slot_id'],
											"session_end_date": data_repeat[f]['session_end_date'].toString()
										})


									}
								} else if (data_repeat[f]['repeat'] == '2') {
									var original_utc_date = moment(Number(data_repeat[f]['utc'] * 1000));
									original_utc_date.set('year', Number(req.body.year))
									// var current_utc_add = new Date(Number(data_repeat[f]['utc'] * 1000))
									// current_utc_add.setYear(Number(req.body.year))
									var current_utc_add = moment(Number(data_repeat[f]['utc'] * 1000));
									current_utc_add.set('year', Number(req.body.year))

									// var req_utc_date = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
									// var req_utc_moment = moment('' + req.body.year + '-' + req.body.month + '-' + req.body.day + '');

									// var a = current_utc_add;
									// var b = req_utc_moment;


									// var differ = monthBetween(current_utc_add, req_utc_date);
									// var differ = b.diff(a, 'months') // 1
									// // var differ = a.diff(b, 'months') // 1
									// console.log('Differ 2---------------- ' + differ)
									// if (differ > 0) {
									// 	current_utc_add.set('month',Number(req.body.month) - 1)
									// 	// current_utc_add.setMonth(Number(req.body.month) - 1)
									// }
									if (req.body.page_no != 1) {
										current_utc_add.set('month', Number(req.body.month) - 1)
										// current_utc_add.set('month',Number(req.body.month) - 1)
									}
									var current_utc = current_utc_add.valueOf() / 1000
									var end_utc = data_repeat[f]['session_end_date']
									var next_utc = ''
									for (var l = 0; l < 10; l++) {

										// var new_utc = Number(current_utc) + (7 * 24 * 60 * 60)

										if (next_utc == '') {
											var current_date = moment(Number(current_utc) * 1000)
											var new_utc = current_date.valueOf() / 1000
											next_utc = new_utc
										} else {
											var current_date = moment(Number(next_utc) * 1000)
											// current_date.setMonth(current_date.getMonth() + 1);
											// current_date.set('month',Number(current_date.month() ) + 1)
											// console.log('current_date1 '+ current_date)
											current_date.add(1, 'months');
											var endOfMonth = current_date.clone().endOf('month').date();
											// console.log('current_date '+ current_date)
											// console.log('original_utc_date.date() '+ original_utc_date.date())
											// console.log('endOfMonth '+ endOfMonth)

											if (Number(original_utc_date.date()) > Number(endOfMonth)) {
												current_date.set('date', Number(endOfMonth))

											} else {
												current_date.set('date', Number(original_utc_date.date()))
												// current_date.add(1, 'months');
											}
											// else{

											// }	
											// console.log('current_date2 '+ current_date)
											// console.log('--------------- ')
											// current_date =  current_date.add(l, 'month')
											// console.log(current_date)
											// current_date.set('date',Number(current_utc_add.date() ) )
											// console.log('current_date '+current_date)
											var new_utc = current_date.valueOf() / 1000
											next_utc = new_utc
										}

										if (end_utc != '' && new_utc > end_utc) {
											console.log('BREAK ONE')
											break;
										}

										var date = moment(new_utc * 1000)
										// if (date.date() < current_utc_add.date()) {
										// 	date.date(current_utc_add.date())
										// }

										// date.set('date',Number(current_utc_add.date() ) )
										var date_number = date.date()
										var month_number = date.month() + 1
										var year_number = date.year();

										// console.log('new_utc.toString() '+ new_utc)
										// console.log('date '+ date)
										// // console.log('date '+ date)
										// console.log('date_number '+ date_number)
										// console.log('month_number '+ month_number)
										// console.log('year_number '+ year_number)
										if (date_number < 10) {
											date_number = '0' + date_number
										}
										if (month_number < 10) {
											month_number = '0' + month_number
										}

										datR.push({
											"id": data_repeat[f]['_id'],
											"client_id": data_repeat[f]['client_id'],
											"trainer_id": data_repeat[f]['trainer_id'],
											"user_type": data_repeat[f]['user_type'],
											"gym_name": data_repeat[f]['gym_name'],
											"utc": new_utc.toString(),
											"time": data_repeat[f]['time'],
											"repeat": data_repeat[f]['repeat'],
											"location": data_repeat[f]['location'],
											"duration": data_repeat[f]['duration'],
											"first_name": data_repeat[f]['trainerdetails'][0]['first_name'],
											"last_name": data_repeat[f]['trainerdetails'][0]['last_name'],
											"image": data_repeat[f]['trainerdetails'][0]['image'],
											"timezone": data_repeat[f]['trainer'][0]['timezone'],
											"timezone_str": data_repeat[f]['timezone_str'],
											"status": data_repeat[f]['status'],
											"day": date_number.toString(),
											"month": month_number.toString(),
											"year": year_number.toString(),
											"date_str": month_number + '.' + date_number + '.' + year_number,
											"time_str": data_repeat[f]['time_str'],
											"slot_id": data_repeat[f]['slot_id'],
											"session_end_date": data_repeat[f]['session_end_date'].toString()
										})

									}
								}

							}
						}
						if (!datR || datR.datR == 0) {
							res.send({
								"success": true,
								"message": "no_data",
								"data": datR,
							});
							return false;
						} else {
							datR.sort((a, b) => (a.utc > b.utc) ? 1 : ((b.utc > a.utc) ? -1 : 0))

							const slicedArray = datR.slice(0, 10);
							// console.log(data_repeat)
							// return false
							if (!slicedArray || slicedArray.length == 0) {
								res.send({
									"success": true,
									"message": "no_data",
									"data": slicedArray,
								});
								return false;
							} else {
								res.send({
									"success": true,
									"message": "Success!",
									"data": slicedArray,
								});
								return false;
							}
						}
					})


				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	}
}
exports.view_sessions_calander_new = async function (req, res) {
	const {
		user_id,
		user_type,
	} = req.body;
	let errors = [];
	if (!user_id || !user_type) {
		res.send({
			"success": false,
			"message": "user_id and user_type required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	console.log('---------------------req.body')
	console.log(req.body)
	if (req.body.user_type == 0) {
		// var date_now = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
		// var seconds = date_now.getTime() / 1000
		// console.log(seconds)
		dbo.collection('TBL_SESSIONS').aggregate([

			{
				$lookup: {
					from: 'TBL_CLIENTS',
					localField: 'client_id',
					foreignField: '_id',
					as: 'client'
				}
			},
			{
				$lookup: {
					from: 'TBL_CLIENT_INFO',
					localField: 'client_id',
					foreignField: 'client_id',
					as: 'client_info'
				}
			},

			{
				$match: {
					"trainer_id": ObjectId(req.body.user_id),
					// "utc":{ $gte: seconds.toString() },
					"month": req.body.month,
					"year": req.body.year,
					// "client_info.trainer_id": ObjectId(req.body.user_id),
					// "status":{$ne : 3}
					"repeat": '0',
					"status": {
						$nin: [3, 4, 5]
					},
				}
			},
			{
				"$unwind": "$client_info"
			},
			{
				"$match": {
					"client_info.trainer_id": ObjectId(req.body.user_id)
				}
			}

		]).toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					dbo.collection('TBL_SESSIONS').aggregate([

						{
							$lookup: {
								from: 'TBL_CLIENTS',
								localField: 'client_id',
								foreignField: '_id',
								as: 'client'
							}
						},
						{
							$lookup: {
								from: 'TBL_CLIENT_INFO',
								localField: 'client_id',
								foreignField: 'client_id',
								as: 'client_info'
							}
						},

						{
							$match: {
								"trainer_id": ObjectId(req.body.user_id),
								// "client_info.trainer_id": ObjectId(req.body.user_id),
								// "status":{$ne : 3}
								"repeat": {
									$in: ['1', '2']
								},
								"status": {
									$nin: [3, 4, 5]
								},
							}
						},
						{
							"$unwind": "$client_info"
						},
						{
							"$match": {
								"client_info.trainer_id": ObjectId(req.body.user_id)
							}
						},

					]).toArray(function (err, resr_repeat) {
						if (err) {
							throw err;
						} else {
							// if (resr_repeat) {
							var data = JSON.parse(JSON.stringify(resr));
							var data_repeat = JSON.parse(JSON.stringify(resr_repeat));
							var dat = [];
							var datR = [];
							var datN = [];


							for (var i = 0; i < data.length; i++) {
								if (!data[i]['client'][0]) {
									data[i]['client'] = []
									data[i]['client'].push({
										timezone: '',
										timezone_str: ''
									})
									// data[i]['client'][0]['timezone'] = ''
									// data[i]['client'][0]['timezone_str'] = ''

								} else {
									if (data[i]['client'][0]['timezone'] == undefined) {
										data[i]['client'][0]['timezone'] = ''
									}
									if (data[i]['client'][0]['timezone_str'] == undefined) {
										data[i]['client'][0]['timezone_str'] = ''
									}
								}
								if (!data[i]['client_info']) {
									data[i]['client_info'] = []
									data[i]['client_info'].push({
										first_name: '',
										last_name: '',
										image: '',
										timezone: ''
									})
								} else {

									var client_info2 = data[i]['client_info'];
									data[i]['client_info'] = []
									data[i]['client_info'].push({
										first_name: client_info2.first_name,
										last_name: client_info2.last_name,
										image: client_info2.image,
										timezone: client_info2.timezone
									})
								}

								if (data[i]['day'] == undefined) {
									data[i]['day'] = ''
								}
								if (data[i]['month'] == undefined) {
									data[i]['month'] = ''
								}
								if (data[i]['year'] == undefined) {
									data[i]['year'] = ''
								}
								if (data[i]['date_str'] == undefined) {
									data[i]['date_str'] = ''
								}
								if (data[i]['time_str'] == undefined) {
									data[i]['time_str'] = ''
								}
								if (data[i]['timezone_str'] == undefined) {
									data[i]['timezone_str'] = data[i]['client'][0]['timezone_str']
								}
								if (data[i]['gym_name'] == undefined) {
									data[i]['gym_name'] = ''
								}
								if (data[i]['time'] == undefined) {
									data[i]['time'] = ''
								}
								if (data[i]['session_end_date'] == undefined) {
									data[i]['session_end_date'] = ''
								}
								datR.push({
									"id": data[i]['_id'],
									"trainer_id": data[i]['trainer_id'],
									"client_id": data[i]['client_id'],
									"user_type": data[i]['user_type'],
									"gym_name": data[i]['gym_name'],
									"utc": data[i]['utc'],
									"time": data[i]['time'],
									"repeat": data[i]['repeat'],
									"location": data[i]['location'],
									"duration": data[i]['duration'],
									"first_name": data[i]['client_info'][0]['first_name'],
									"last_name": data[i]['client_info'][0]['last_name'],
									"image": data[i]['client_info'][0]['image'],
									"timezone": data[i]['client_info'][0]['timezone'],
									"timezone_str": data[i]['timezone_str'],
									"status": data[i]['status'],
									"day": data[i]['day'],
									"month": data[i]['month'],
									"year": data[i]['year'],
									"date_str": data[i]['date_str'],
									"time_str": data[i]['time_str'],
									"slot_id": data[i]['slot_id'],
									"session_end_date": data[i]['session_end_date'].toString()
								})
								// datN[i][data[i]['utc']] = dat[i]
								// var utccc = data[i]['utc']
								// datN.push({[utccc]:dat[i]})
							}

							// console.log('data_repeat.length '+data_repeat.length)
							for (var f = 0; f < data_repeat.length; f++) {
								// console.log('data_repeat.repeat '+data_repeat[f]['repeat'])
								// console.log('data_repeat.utc '+data_repeat[f]['utc'])
								if (!data_repeat[f]['client'][0]) {
									data_repeat[f]['client'] = []
									data_repeat[f]['client'].push({
										timezone: '',
										timezone_str: ''
									})

								} else {
									if (data_repeat[f]['client'][0]['timezone'] == undefined) {
										data_repeat[f]['client'][0]['timezone'] = ''
									}
									if (data_repeat[f]['client'][0]['timezone_str'] == undefined) {
										data_repeat[f]['client'][0]['timezone_str'] = ''
									}
								}
								if (!data_repeat[f]['client_info']) {
									data_repeat[f]['client_info'] = []
									data_repeat[f]['client_info'].push({
										first_name: '',
										last_name: '',
										image: '',
										timezone: ''
									})
								} else {

									var client_info2 = data_repeat[f]['client_info'];
									data_repeat[f]['client_info'] = []
									data_repeat[f]['client_info'].push({
										first_name: client_info2.first_name,
										last_name: client_info2.last_name,
										image: client_info2.image,
										timezone: client_info2.timezone
									})
								}

								if (data_repeat[f]['day'] == undefined) {
									data_repeat[f]['day'] = ''
								}
								if (data_repeat[f]['month'] == undefined) {
									data_repeat[f]['month'] = ''
								}
								if (data_repeat[f]['year'] == undefined) {
									data_repeat[f]['year'] = ''
								}
								if (data_repeat[f]['date_str'] == undefined) {
									data_repeat[f]['date_str'] = ''
								}
								if (data_repeat[f]['time_str'] == undefined) {
									data_repeat[f]['time_str'] = ''
								}
								if (data_repeat[f]['timezone_str'] == undefined) {
									data_repeat[f]['timezone_str'] = data_repeat[f]['client'][0]['timezone_str']
								}
								if (data_repeat[f]['gym_name'] == undefined) {
									data_repeat[f]['gym_name'] = ''
								}
								if (data_repeat[f]['time'] == undefined) {
									data_repeat[f]['time'] = ''
								}
								if (data_repeat[f]['session_end_date'] == undefined) {
									data_repeat[f]['session_end_date'] = ''
								}
								if (data_repeat[f]['repeat'] == '1') {
									console.log("data_repeat[f]['repeat'] == '1'")

									var loop_start_date = new Date(Number(data_repeat[f]['utc']) * 1000)
									// var session_end_date_db = new Date(Number(data_repeat[f]['session_end_date']) * 1000)

									if (data_repeat[f]['session_end_date'] == '') {
										var session_end_date_db = ''
									} else {
										var session_end_date_db = new Date(Number(data_repeat[f]['session_end_date']) * 1000)
									}

									var date = new Date('' + req.body.year + '/' + Number(req.body.month) + '/01');
									var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
									var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

									if (session_end_date_db != '' && firstDay > session_end_date_db) {

										continue;
									}
									if (session_end_date_db == '') {

										continue;
									}
									var end_loop_date = lastDay
									end_loop_date.setHours(loop_start_date.getHours())
									var current_date_glob = loop_start_date
									// var new_glob = loop_start_date

									while (current_date_glob.getTime() <= end_loop_date.getTime() && current_date_glob.getTime() <= session_end_date_db.getTime()) {
										// if (current_date_glob.getDate() == 28) {
										// 	console.log('continuing----------------')
										// 	console.log('current_date_glob',current_date_glob)
										// 	console.log('firstDay',firstDay)
										// 	console.log('end_loop_date',end_loop_date)
										// 	console.log('session_end_date_db',session_end_date_db)
										// 	console.log('date1',current_date_glob)
										// 	console.log('---------------continuing')
										// }
										// console.log('current_date_glob.getTime() '+ current_date_glob.getTime())
										// console.log('end_loop_date.getTime() '+ end_loop_date.getTime())
										if (current_date_glob >= firstDay) {
																				

											var date1 = current_date_glob
											var date_number = date1.getDate()
											var month_number = date1.getMonth() + 1
											var year_number = date1.getFullYear();
											var new_utc = date1.getTime() / 1000

											if (date_number < 10) {
												date_number = '0' + date_number
											}
											if (month_number < 10) {
												month_number = '0' + month_number
											}
											
											datR.push({
												"id": data_repeat[f]['_id'],
												"trainer_id": data_repeat[f]['trainer_id'],
												"client_id": data_repeat[f]['client_id'],
												"user_type": data_repeat[f]['user_type'],
												"gym_name": data_repeat[f]['gym_name'],
												"utc": new_utc.toString(),
												"time": data_repeat[f]['time'],
												"repeat": data_repeat[f]['repeat'],
												"location": data_repeat[f]['location'],
												"duration": data_repeat[f]['duration'],
												"first_name": data_repeat[f]['client_info'][0]['first_name'],
												"last_name": data_repeat[f]['client_info'][0]['last_name'],
												"image": data_repeat[f]['client_info'][0]['image'],
												"timezone": data_repeat[f]['client_info'][0]['timezone'],
												"timezone_str": data_repeat[f]['timezone_str'],
												"status": data_repeat[f]['status'],
												"day": date_number.toString(),
												"month": month_number.toString(),
												"year": year_number.toString(),
												"date_str": month_number + '.' + date_number + '.' + year_number,
												"time_str": data_repeat[f]['time_str'],
												"slot_id": data_repeat[f]['slot_id'],
												"session_end_date": data_repeat[f]['session_end_date'].toString()
											})
										}
										// console.log('current_date_glob '+ current_date_glob)
										// console.log('end_loop_date '+ end_loop_date)
										// console.log('new_glob '+ new_glob)
										// console.log('-------------')
										current_date_glob.setDate(current_date_glob.getDate() + 7)


										// new_glob.setDate(new_glob.getDate() + 7)
										// new_glob.setHours(0, 0, 0, 0);

									}

								} else if (data_repeat[f]['repeat'] == '2') {
									console.log("data_repeat[f]['repeat'] == '2'")
									var loop_start_date = new Date(Number(data_repeat[f]['utc']) * 1000)
									var loop_start_date_orig = new Date(Number(data_repeat[f]['utc']) * 1000)
									if (data_repeat[f]['session_end_date'] == '') {
										var session_end_date_db = ''
									} else {
										var session_end_date_db = new Date(Number(data_repeat[f]['session_end_date']) * 1000)
									}


									var mon = Number(req.body.month)
									var date = new Date('' + req.body.year + '/' + mon + '/01');
									var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

									var lastDay_loop_date = new Date(Number(req.body.year), Number(req.body.month), 0);
									// console.log('loop_start_date.getMonth() '+ lastDay_loop_date)
									// console.log('lastDay_loop_date '+ lastDay_loop_date.getDate())
									// console.log('lastDay_loop_dateMonth '+ lastDay_loop_date.getMonth())
									// console.log('loop_start_date_orig '+ loop_start_date_orig.getDate())
									// console.log('loop_start_date_origMonth '+ loop_start_date_orig.getMonth())
									// console.log('loop_start_date_origMonth-------------------------')
									if (Number(loop_start_date_orig.getDate()) > Number(lastDay_loop_date.getDate())) {
										loop_start_date.setDate(lastDay_loop_date.getDate())
										console.log('if')
									} else {
										loop_start_date.setDate(loop_start_date_orig.getDate())
										console.log('else')
									}
									loop_start_date.setMonth(Number(req.body.month) - 1)
									loop_start_date.setYear(req.body.year)

									// console.log('loop_start_date '+ loop_start_date)
									// console.log('date '+ date)
									// console.log('lastDay '+ lastDay)
									console.log('session_end_date_db ' + session_end_date_db)
									console.log('loop_start_date ' + loop_start_date)


									var loop_start_2 = loop_start_date_orig
									loop_start_2.setDate(1)
									loop_start_2.setHours(0, 0, 0, 0);

									// console.log(date+ ' date')
									// console.log(loop_start_2+ ' loop_start_2')
									// console.log(date+ ' date' < 'loop_start_2 '+loop_start_2)

									if (session_end_date_db != '' && loop_start_date > session_end_date_db) {
										console.log('continue ')
										continue;
									}
									if (date < loop_start_2) {
										continue;
									}

									var end_loop_date = lastDay

									var current_date_glob = loop_start_date

									var date1 = current_date_glob
									var date_number = date1.getDate()
									var month_number = date1.getMonth() + 1
									var year_number = date1.getFullYear();
									var new_utc = date1.getTime() / 1000

									if (date_number < 10) {
										date_number = '0' + date_number
									}
									if (month_number < 10) {
										month_number = '0' + month_number
									}
									datR.push({
										"id": data_repeat[f]['_id'],
										"trainer_id": data_repeat[f]['trainer_id'],
										"client_id": data_repeat[f]['client_id'],
										"user_type": data_repeat[f]['user_type'],
										"gym_name": data_repeat[f]['gym_name'],
										"utc": new_utc.toString(),
										"time": data_repeat[f]['time'],
										"repeat": data_repeat[f]['repeat'],
										"location": data_repeat[f]['location'],
										"duration": data_repeat[f]['duration'],
										"first_name": data_repeat[f]['client_info'][0]['first_name'],
										"last_name": data_repeat[f]['client_info'][0]['last_name'],
										"image": data_repeat[f]['client_info'][0]['image'],
										"timezone": data_repeat[f]['client_info'][0]['timezone'],
										"timezone_str": data_repeat[f]['timezone_str'],
										"status": data_repeat[f]['status'],
										"day": date_number.toString(),
										"month": month_number.toString(),
										"year": year_number.toString(),
										"date_str": month_number + '.' + date_number + '.' + year_number,
										"time_str": data_repeat[f]['time_str'],
										"slot_id": data_repeat[f]['slot_id'],
										"session_end_date": data_repeat[f]['session_end_date'].toString()
									})

								}

								// datN[f][data_repeat[f]['utc']] = dat[f]

							}
							// }
						}
						// console.log(dat)
						// console.log(datR)
						if (!datR || datR.datR == 0) {
							res.send({
								"success": true,
								"message": "no_data",
								"data": datR,
							});
							return false;
						} else {
							datR.sort((a, b) => (a.utc > b.utc) ? 1 : ((b.utc > a.utc) ? -1 : 0))

							const slicedArray = datR;
							// const slicedArray = datR.slice(0, 10);
							// console.log(data_repeat)
							// return false
							if (!slicedArray || slicedArray.length == 0) {
								res.send({
									"success": true,
									"message": "no_data",
									"data": slicedArray,
								});
								return false;
							} else {
								res.send({
									"success": true,
									"message": "Success!",
									"data": slicedArray,
								});
								return false;
							}
						}


					})


				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	} else {

		dbo.collection('TBL_SESSIONS').aggregate([{
				$match: {
					client_id: ObjectId(req.body.user_id),
					// status:{$ne : 3}
					"status": {
						$nin: [3, 4, 5]
					},
					"month": req.body.month,
					"year": req.body.year,
					"repeat": '0',
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINERS',
					localField: 'trainer_id',
					foreignField: '_id',
					as: 'trainer'
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINER_DETAILS',
					localField: 'trainer_id',
					foreignField: 'user_id',
					as: 'trainerdetails'
				}
			},

		]).toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					dbo.collection('TBL_SESSIONS').aggregate([

						{
							$lookup: {
								from: 'TBL_TRAINERS',
								localField: 'trainer_id',
								foreignField: '_id',
								as: 'trainer'
							}
						},
						{
							$lookup: {
								from: 'TBL_TRAINER_DETAILS',
								localField: 'trainer_id',
								foreignField: 'user_id',
								as: 'trainerdetails'
							}
						},

						{
							$match: {
								"client_id": ObjectId(req.body.user_id),
								// "client_info.trainer_id": ObjectId(req.body.user_id),
								// "status":{$ne : 3}
								"repeat": {
									$in: ['1', '2']
								},
								"status": {
									$nin: [3, 4, 5]
								},
							}
						},


					]).toArray(function (err, resr_repeat) {
						if (err) {
							throw err;
						} else {
							// if (resr_repeat) {
							var data = JSON.parse(JSON.stringify(resr));
							var data_repeat = JSON.parse(JSON.stringify(resr_repeat));
							var dat = [];
							var datR = [];
							var datN = [];


							for (var i = 0; i < data.length; i++) {
								if (data[i]['trainer'][0]['timezone'] == undefined) {
									data[i]['trainer'][0]['timezone'] = ''
								}
								if (data[i]['trainer'][0]['timezone_str'] == undefined) {
									data[i]['trainer'][0]['timezone_str'] = ''
								}
								if (data[i]['day'] == undefined) {
									data[i]['day'] = ''
								}
								if (data[i]['month'] == undefined) {
									data[i]['month'] = ''
								}
								if (data[i]['year'] == undefined) {
									data[i]['year'] = ''
								}
								if (data[i]['date_str'] == undefined) {
									data[i]['date_str'] = ''
								}
								if (data[i]['time_str'] == undefined) {
									data[i]['time_str'] = ''
								}
								if (data[i]['timezone_str'] == undefined) {
									data[i]['timezone_str'] = data[i]['trainer'][0]['timezone_str'];
								}
								if (data[i]['gym_name'] == undefined) {
									data[i]['gym_name'] = ''
								}
								if (data[i]['session_end_date'] == undefined) {
									data[i]['session_end_date'] = ''
								}
								datR.push({
									"id": data[i]['_id'],
									"client_id": data[i]['client_id'],
									"trainer_id": data[i]['trainer_id'],
									"user_type": data[i]['user_type'],
									"gym_name": data[i]['gym_name'],
									"utc": data[i]['utc'],
									"time": data[i]['time'],
									"repeat": data[i]['repeat'],
									"location": data[i]['location'],
									"duration": data[i]['duration'],
									"first_name": data[i]['trainerdetails'][0]['first_name'],
									"last_name": data[i]['trainerdetails'][0]['last_name'],
									"image": data[i]['trainerdetails'][0]['image'],
									"timezone": data[i]['trainer'][0]['timezone'],
									"timezone_str": data[i]['timezone_str'],
									"status": data[i]['status'],
									"day": data[i]['day'],
									"month": data[i]['month'],
									"year": data[i]['year'],
									"date_str": data[i]['date_str'],
									"time_str": data[i]['time_str'],
									"slot_id": data[i]['slot_id'],
									"session_end_date": data[i]['session_end_date'].toString()
								})
								// datN[i][data[i]['utc']] = dat[i]
								// var utccc = data[i]['utc']
								// datN.push({[utccc]:dat[i]})
							}

							for (var f = 0; f < data_repeat.length; f++) {

								if (data_repeat[f]['trainer'][0]['timezone'] == undefined) {
									data_repeat[f]['trainer'][0]['timezone'] = ''
								}
								if (data_repeat[f]['trainer'][0]['timezone_str'] == undefined) {
									data_repeat[f]['trainer'][0]['timezone_str'] = ''
								}
								if (data_repeat[f]['day'] == undefined) {
									data_repeat[f]['day'] = ''
								}
								if (data_repeat[f]['month'] == undefined) {
									data_repeat[f]['month'] = ''
								}
								if (data_repeat[f]['year'] == undefined) {
									data_repeat[f]['year'] = ''
								}
								if (data_repeat[f]['date_str'] == undefined) {
									data_repeat[f]['date_str'] = ''
								}
								if (data_repeat[f]['time_str'] == undefined) {
									data_repeat[f]['time_str'] = ''
								}
								if (data_repeat[f]['timezone_str'] == undefined) {
									data_repeat[f]['timezone_str'] = data_repeat[f]['trainer'][0]['timezone_str'];
								}
								if (data_repeat[f]['gym_name'] == undefined) {
									data_repeat[f]['gym_name'] = ''
								}
								if (data_repeat[f]['session_end_date'] == undefined) {
									data_repeat[f]['session_end_date'] = ''
								}
								if (data_repeat[f]['repeat'] == '1') {
									console.log("data_repeat[f]['repeat'] == '1'")

									var loop_start_date = new Date(Number(data_repeat[f]['utc']) * 1000)
									// var session_end_date_db = new Date(Number(data_repeat[f]['session_end_date']) * 1000)

									if (data_repeat[f]['session_end_date'] == '') {
										var session_end_date_db = ''
									} else {
										var session_end_date_db = new Date(Number(data_repeat[f]['session_end_date']) * 1000)
									}

									var date = new Date('' + req.body.year + '/' + Number(req.body.month) + '/01');
									var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
									var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

									if (session_end_date_db != '' && firstDay > session_end_date_db) {
										continue;
									}

									var end_loop_date = lastDay
									end_loop_date.setHours(loop_start_date.getHours())
									var current_date_glob = loop_start_date
									// var new_glob = loop_start_date

									while (current_date_glob.getTime() <= end_loop_date.getTime()) {

										if (current_date_glob >= firstDay) {


											var date1 = current_date_glob
											var date_number = date1.getDate()
											var month_number = date1.getMonth() + 1
											var year_number = date1.getFullYear();
											var new_utc = date1.getTime() / 1000

											if (date_number < 10) {
												date_number = '0' + date_number
											}
											if (month_number < 10) {
												month_number = '0' + month_number
											}
											datR.push({
												"id": data_repeat[f]['_id'],
												"client_id": data_repeat[f]['client_id'],
												"trainer_id": data_repeat[f]['trainer_id'],
												"user_type": data_repeat[f]['user_type'],
												"gym_name": data_repeat[f]['gym_name'],
												"utc": new_utc.toString(),
												"time": data_repeat[f]['time'],
												"repeat": data_repeat[f]['repeat'],
												"location": data_repeat[f]['location'],
												"duration": data_repeat[f]['duration'],
												"first_name": data_repeat[f]['trainerdetails'][0]['first_name'],
												"last_name": data_repeat[f]['trainerdetails'][0]['last_name'],
												"image": data_repeat[f]['trainerdetails'][0]['image'],
												"timezone": data_repeat[f]['trainer'][0]['timezone'],
												"timezone_str": data_repeat[f]['timezone_str'],
												"status": data_repeat[f]['status'],
												"day": date_number.toString(),
												"month": month_number.toString(),
												"year": year_number.toString(),
												"date_str": month_number + '.' + date_number + '.' + year_number,
												"time_str": data_repeat[f]['time_str'],
												"slot_id": data_repeat[f]['slot_id'],
												"session_end_date": data_repeat[f]['session_end_date'].toString()
											})

										}
										current_date_glob.setDate(current_date_glob.getDate() + 7)
									}

								} else if (data_repeat[f]['repeat'] == '2') {
									console.log("data_repeat[f]['repeat'] == '2'")
									var loop_start_date = new Date(Number(data_repeat[f]['utc']) * 1000)
									var loop_start_date_orig = new Date(Number(data_repeat[f]['utc']) * 1000)
									if (data_repeat[f]['session_end_date'] == '') {
										var session_end_date_db = ''
									} else {
										var session_end_date_db = new Date(Number(data_repeat[f]['session_end_date']) * 1000)
									}


									var mon = Number(req.body.month)
									var date = new Date('' + req.body.year + '/' + mon + '/01');
									var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

									var lastDay_loop_date = new Date(Number(req.body.year), Number(req.body.month), 0);
									// console.log('loop_start_date.getMonth() '+ lastDay_loop_date)
									// console.log('lastDay_loop_date '+ lastDay_loop_date.getDate())
									// console.log('lastDay_loop_dateMonth '+ lastDay_loop_date.getMonth())
									// console.log('loop_start_date_orig '+ loop_start_date_orig.getDate())
									// console.log('loop_start_date_origMonth '+ loop_start_date_orig.getMonth())
									// console.log('loop_start_date_origMonth-------------------------')
									if (Number(loop_start_date_orig.getDate()) > Number(lastDay_loop_date.getDate())) {
										loop_start_date.setDate(lastDay_loop_date.getDate())
										console.log('if')
									} else {
										loop_start_date.setDate(loop_start_date_orig.getDate())
										console.log('else')
									}
									loop_start_date.setMonth(Number(req.body.month) - 1)
									loop_start_date.setYear(req.body.year)

									// console.log('loop_start_date '+ loop_start_date)
									// console.log('date '+ date)
									// console.log('lastDay '+ lastDay)
									console.log('session_end_date_db ' + session_end_date_db)
									console.log('loop_start_date ' + loop_start_date)


									var loop_start_2 = loop_start_date_orig
									loop_start_2.setDate(1)
									loop_start_2.setHours(0, 0, 0, 0);

									// console.log(date+ ' date')
									// console.log(loop_start_2+ ' loop_start_2')
									// console.log(date+ ' date' < 'loop_start_2 '+loop_start_2)

									if (session_end_date_db != '' && loop_start_date > session_end_date_db) {
										console.log('continue ')
										continue;
									}
									if (date < loop_start_2) {
										continue;
									}

									var end_loop_date = lastDay

									var current_date_glob = loop_start_date

									var date1 = current_date_glob
									var date_number = date1.getDate()
									var month_number = date1.getMonth() + 1
									var year_number = date1.getFullYear();
									var new_utc = date1.getTime() / 1000

									if (date_number < 10) {
										date_number = '0' + date_number
									}
									if (month_number < 10) {
										month_number = '0' + month_number
									}
									datR.push({
										"id": data_repeat[f]['_id'],
										"client_id": data_repeat[f]['client_id'],
										"trainer_id": data_repeat[f]['trainer_id'],
										"user_type": data_repeat[f]['user_type'],
										"gym_name": data_repeat[f]['gym_name'],
										"utc": new_utc.toString(),
										"time": data_repeat[f]['time'],
										"repeat": data_repeat[f]['repeat'],
										"location": data_repeat[f]['location'],
										"duration": data_repeat[f]['duration'],
										"first_name": data_repeat[f]['trainerdetails'][0]['first_name'],
										"last_name": data_repeat[f]['trainerdetails'][0]['last_name'],
										"image": data_repeat[f]['trainerdetails'][0]['image'],
										"timezone": data_repeat[f]['trainer'][0]['timezone'],
										"timezone_str": data_repeat[f]['timezone_str'],
										"status": data_repeat[f]['status'],
										"day": date_number.toString(),
										"month": month_number.toString(),
										"year": year_number.toString(),
										"date_str": month_number + '.' + date_number + '.' + year_number,
										"time_str": data_repeat[f]['time_str'],
										"slot_id": data_repeat[f]['slot_id'],
										"session_end_date": data_repeat[f]['session_end_date'].toString()
									})

								}

								// datN[f][data_repeat[f]['utc']] = dat[f]

							}
							// }
						}
						// console.log(dat)
						// console.log(datR)
						if (!datR || datR.datR == 0) {
							res.send({
								"success": true,
								"message": "no_data",
								"data": datR,
							});
							return false;
						} else {
							datR.sort((a, b) => (a.utc > b.utc) ? 1 : ((b.utc > a.utc) ? -1 : 0))

							// const slicedArray = datR.slice(0, 10);
							const slicedArray = datR;
							// console.log(data_repeat)
							// return false
							if (!slicedArray || slicedArray.length == 0) {
								res.send({
									"success": true,
									"message": "no_data",
									"data": slicedArray,
								});
								return false;
							} else {
								res.send({
									"success": true,
									"message": "Success!",
									"data": slicedArray,
								});
								return false;
							}
						}


					})

				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	}
}
exports.view_sessions_paging = async function (req, res) {
	const {
		user_id,
		user_type,
		page_no
	} = req.body;
	let errors = [];
	if (!user_id || !user_type || !page_no) {
		res.send({
			"success": false,
			"message": "user_id, page_no and user_type required.",
			"data": {}
		});
		return false;
	}
	if (Object.keys(req.body).length === 0) {
		cPage = 1
	} else {
		cPage = req.body.page_no
	}
	var pageNo = parseInt(cPage)
	var size = 10
	var query = {}
	if (pageNo < 0 || pageNo === 0) {
		response = {
			"error": true,
			"message": "invalid page number, should start with 1"
		};
		return res.json(response)
	}
	query.skip = size * (pageNo - 1)
	query.limit = size
	let dbo = await mongodbutil.Get();
	console.log('---------------------req.body')
	console.log(req.body)


	if (req.body.user_type == 0) {
		if (!req.body.month) {
			var qq = {
				"trainer_id": ObjectId(req.body.user_id),
				"status": {
					$nin: [3, 4, 5]
				}
			}
		} else {
			var qq = {
				"trainer_id": ObjectId(req.body.user_id),
				"status": {
					$nin: [3, 4, 5]
				},
				"month": req.body.month
			}
		}
		dbo.collection("TBL_SESSIONS").count(qq, function (err, totalCount) {
			if (err) {
				response = {
					"error": true,
					"message": "Error fetching data"
				}
				return false;
			}

			var totalPages = Math.ceil(totalCount / size)
			// console.log('totalPages '+ totalPages)
			// console.log('totalCount '+ totalCount)
			if (!req.body.month) {
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([

					{
						$lookup: {
							from: 'TBL_CLIENTS',
							localField: 'client_id',
							foreignField: '_id',
							as: 'client'
						}
					},
					{
						$lookup: {
							from: 'TBL_CLIENT_INFO',
							localField: 'client_id',
							foreignField: 'client_id',
							as: 'client_info'
						}
					},

					{
						$match: {
							"trainer_id": ObjectId(req.body.user_id),
							// "client_info.trainer_id": ObjectId(req.body.user_id),
							// "status":{$ne : 3}
							"status": {
								$nin: [3, 4, 5]
							},
						}
					},
					{
						"$unwind": "$client_info"
					},
					{
						"$match": {
							"client_info.trainer_id": ObjectId(req.body.user_id)
						}
					},
					{
						$skip: query.skip
					},
					{
						$limit: query.limit
					},

				]);
			} else {
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([

					{
						$lookup: {
							from: 'TBL_CLIENTS',
							localField: 'client_id',
							foreignField: '_id',
							as: 'client'
						}
					},
					{
						$lookup: {
							from: 'TBL_CLIENT_INFO',
							localField: 'client_id',
							foreignField: 'client_id',
							as: 'client_info'
						}
					},
					{
						$match: {
							"trainer_id": ObjectId(req.body.user_id),
							// "client_info.trainer_id": ObjectId(req.body.user_id),
							"month": req.body.month,
							// "status":{$ne : 3}
							"status": {
								$nin: [3, 4, 5]
							},
						}
					},
					{
						"$unwind": "$client_info"
					},
					{
						"$match": {
							"client_info.trainer_id": ObjectId(req.body.user_id)
							// "client_info.client_id":ObjectId(req.body.user_id)
						}
					},
					// {
					//              $skip: query.skip
					//          },
					//          {
					//              $limit: query.limit
					//          },
				]);
			}
			Query_m.toArray(function (err, resr) {
				if (err) {
					throw err;
				} else {
					if (resr) {
						var data = JSON.parse(JSON.stringify(resr));
						// console.log(data[0]['clientdetails'])

						// return
						var dat = [];
						for (var i = 0; i < data.length; i++) {
							if (!data[i]['client'][0]) {
								data[i]['client'] = []
								data[i]['client'].push({
									timezone: '',
									timezone_str: ''
								})
								// data[i]['client'][0]['timezone'] = ''
								// data[i]['client'][0]['timezone_str'] = ''

							} else {
								if (data[i]['client'][0]['timezone'] == undefined) {
									data[i]['client'][0]['timezone'] = ''
								}
								if (data[i]['client'][0]['timezone_str'] == undefined) {
									data[i]['client'][0]['timezone_str'] = ''
								}
							}
							if (!data[i]['client_info']) {
								data[i]['client_info'] = []
								data[i]['client_info'].push({
									first_name: '',
									last_name: '',
									image: '',
									timezone: ''
								})
							} else {

								var client_info2 = data[i]['client_info'];
								data[i]['client_info'] = []
								data[i]['client_info'].push({
									first_name: client_info2.first_name,
									last_name: client_info2.last_name,
									image: client_info2.image,
									timezone: client_info2.timezone
								})
							}

							if (data[i]['day'] == undefined) {
								data[i]['day'] = ''
							}
							if (data[i]['month'] == undefined) {
								data[i]['month'] = ''
							}
							if (data[i]['year'] == undefined) {
								data[i]['year'] = ''
							}
							if (data[i]['date_str'] == undefined) {
								data[i]['date_str'] = ''
							}
							if (data[i]['time_str'] == undefined) {
								data[i]['time_str'] = ''
							}
							if (data[i]['timezone_str'] == undefined) {
								data[i]['timezone_str'] = data[i]['client'][0]['timezone_str']
							}
							if (data[i]['gym_name'] == undefined) {
								data[i]['gym_name'] = ''
							}
							if (data[i]['time'] == undefined) {
								data[i]['time'] = ''
							}
							if (data[i]['session_end_date'] == undefined) {
								data[i]['session_end_date'] = ''
							}
							dat.push({
								"id": data[i]['_id'],
								"trainer_id": data[i]['trainer_id'],
								"client_id": data[i]['client_id'],
								"user_type": data[i]['user_type'],
								"gym_name": data[i]['gym_name'],
								"utc": data[i]['utc'],
								"time": data[i]['time'],
								"repeat": data[i]['repeat'],
								"location": data[i]['location'],
								"duration": data[i]['duration'],
								"first_name": data[i]['client_info'][0]['first_name'],
								"last_name": data[i]['client_info'][0]['last_name'],
								"image": data[i]['client_info'][0]['image'],
								"timezone": data[i]['client_info'][0]['timezone'],
								"timezone_str": data[i]['timezone_str'],
								"status": data[i]['status'],
								"day": data[i]['day'],
								"month": data[i]['month'],
								"year": data[i]['year'],
								"date_str": data[i]['date_str'],
								"time_str": data[i]['time_str'],
								"slot_id": data[i]['slot_id'],
								"session_end_date": data[i]['session_end_date'].toString()
							})
						}
						res.send({
							"success": true,
							"message": "Success!",
							"data": dat,
							"total_pages": totalPages
						});
						return false;
					} else {
						res.send({
							"success": false,
							"message": "something went wrong",
							"data": {}
						});
						return false;
					}
				}

			});
		})

	} else {
		if (!req.body.month) {
			var qq = {
				"client_id": ObjectId(req.body.user_id),
				"status": {
					$nin: [3, 4, 5]
				}
			}
		} else {
			var qq = {
				"client_id": ObjectId(req.body.user_id),
				"status": {
					$nin: [3, 4, 5]
				},
				"month": req.body.month
			}
		}
		dbo.collection("TBL_SESSIONS").count(qq, function (err, totalCount) {
			if (err) {
				response = {
					"error": true,
					"message": "Error fetching data"
				}
				return false;
			}

			var totalPages = Math.ceil(totalCount / size)
			if (!req.body.month) {
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
						$match: {
							client_id: ObjectId(req.body.user_id),
							// status:{$ne : 3}
							"status": {
								$nin: [3, 4, 5]
							},
						}
					},
					{
						$lookup: {
							from: 'TBL_TRAINERS',
							localField: 'trainer_id',
							foreignField: '_id',
							as: 'trainer'
						}
					},
					{
						$lookup: {
							from: 'TBL_TRAINER_DETAILS',
							localField: 'trainer_id',
							foreignField: 'user_id',
							as: 'trainerdetails'
						}
					},
					{
						$skip: query.skip
					},
					{
						$limit: query.limit
					},

				]);
			} else {
				var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
						$match: {
							client_id: ObjectId(req.body.user_id),
							"month": req.body.month,
							// "status":{$ne : 3}
							"status": {
								$nin: [3, 4, 5]
							},
						}
					},
					{
						$lookup: {
							from: 'TBL_TRAINERS',
							localField: 'trainer_id',
							foreignField: '_id',
							as: 'trainer'
						}
					},
					{
						$lookup: {
							from: 'TBL_TRAINER_DETAILS',
							localField: 'trainer_id',
							foreignField: 'user_id',
							as: 'trainerdetails'
						}
					},
					// {
					//              $skip: query.skip
					//          },
					//          {
					//              $limit: query.limit
					//          },

				])
			}
			Query_m.toArray(function (err, resr) {
				if (err) {
					throw err;
				} else {
					if (resr) {
						var data = JSON.parse(JSON.stringify(resr));
						// console.log(data[0]['clientdetails'])
						// console.log(data)
						var dat = [];
						for (var i = 0; i < data.length; i++) {
							if (data[i]['trainer'][0]['timezone'] == undefined) {
								data[i]['trainer'][0]['timezone'] = ''
							}
							if (data[i]['trainer'][0]['timezone_str'] == undefined) {
								data[i]['trainer'][0]['timezone_str'] = ''
							}
							if (data[i]['day'] == undefined) {
								data[i]['day'] = ''
							}
							if (data[i]['month'] == undefined) {
								data[i]['month'] = ''
							}
							if (data[i]['year'] == undefined) {
								data[i]['year'] = ''
							}
							if (data[i]['date_str'] == undefined) {
								data[i]['date_str'] = ''
							}
							if (data[i]['time_str'] == undefined) {
								data[i]['time_str'] = ''
							}
							if (data[i]['timezone_str'] == undefined) {
								data[i]['timezone_str'] = data[i]['trainer'][0]['timezone_str'];
							}
							if (data[i]['gym_name'] == undefined) {
								data[i]['gym_name'] = ''
							}
							if (data[i]['session_end_date'] == undefined) {
								data[i]['session_end_date'] = ''
							}
							dat.push({
								"id": data[i]['_id'],
								"client_id": data[i]['client_id'],
								"trainer_id": data[i]['trainer_id'],
								"user_type": data[i]['user_type'],
								"gym_name": data[i]['gym_name'],
								"utc": data[i]['utc'],
								"time": data[i]['time'],
								"repeat": data[i]['repeat'],
								"location": data[i]['location'],
								"duration": data[i]['duration'],
								"first_name": data[i]['trainerdetails'][0]['first_name'],
								"last_name": data[i]['trainerdetails'][0]['last_name'],
								"image": data[i]['trainerdetails'][0]['image'],
								"timezone": data[i]['trainer'][0]['timezone'],
								"timezone_str": data[i]['timezone_str'],
								"status": data[i]['status'],
								"day": data[i]['day'],
								"month": data[i]['month'],
								"year": data[i]['year'],
								"date_str": data[i]['date_str'],
								"time_str": data[i]['time_str'],
								"slot_id": data[i]['slot_id'],
								"session_end_date": data[i]['session_end_date'].toString()
							})
						}
						res.send({
							"success": true,
							"message": "Success!",
							"data": dat,
							"total_pages": totalPages
						});
						return false;
					} else {
						res.send({
							"success": false,
							"message": "something went wrong",
							"data": {}
						});
						return false;
					}
				}

			});
		})
	}
}

exports.session_details = async function (req, res) {
	const {
		user_id,
		user_type,
		session_id,
	} = req.body;
	let errors = [];
	if (!user_id || !user_type || !user_type) {
		res.send({
			"success": false,
			"message": "user_id, user_type and user_type required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	if (req.body.user_type == 0) {
		if (!req.body.month) {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([

				{
					$lookup: {
						from: 'TBL_CLIENTS',
						localField: 'client_id',
						foreignField: '_id',
						as: 'client'
					}
				},
				{
					$lookup: {
						from: 'TBL_CLIENT_INFO',
						localField: 'client_id',
						foreignField: 'client_id',
						as: 'client_info'
					}
				},
				// {
				// 	$lookup: {
				// 		from: 'TBL_CLIENT_DETAILS',
				// 		localField: 'client_id',
				// 		foreignField: 'user_id',
				// 		as: 'clientdetails'
				// 	}
				// },
				{
					$match: {
						"trainer_id": ObjectId(req.body.user_id),
						"_id": ObjectId(req.body.session_id),
						// "client_info.trainer_id": ObjectId(req.body.user_id),
						// "status":{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
				{
					"$unwind": "$client_info"
				},
				{
					"$match": {
						"client_info.trainer_id": ObjectId(req.body.user_id)
					}
				},
				// 	{$group: {
				//       _id: "$_id",
				//       client_info: {$push: "$client_info"}
				//   }}
			]);
		} else {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([

				{
					$lookup: {
						from: 'TBL_CLIENTS',
						localField: 'client_id',
						foreignField: '_id',
						as: 'client'
					}
				},
				{
					$lookup: {
						from: 'TBL_CLIENT_INFO',
						localField: 'client_id',
						foreignField: 'client_id',
						as: 'client_info'
					}
				},
				{
					$match: {
						"trainer_id": ObjectId(req.body.user_id),
						"_id": ObjectId(req.body.session_id),
						// "client_info.trainer_id": ObjectId(req.body.user_id),
						"month": req.body.month,
						// "status":{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
			]);
		}
		Query_m.toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					var data = JSON.parse(JSON.stringify(resr));
					// console.log(data[0]['clientdetails'])
					// console.log(data)
					// return
					var dat = [];
					for (var i = 0; i < data.length; i++) {
						if (!data[i]['client'][0]) {
							data[i]['client'] = []
							data[i]['client'].push({
								timezone: '',
								timezone_str: ''
							})
							// data[i]['client'][0]['timezone'] = ''
							// data[i]['client'][0]['timezone_str'] = ''

						} else {
							if (data[i]['client'][0]['timezone'] == undefined) {
								data[i]['client'][0]['timezone'] = ''
							}
							if (data[i]['client'][0]['timezone_str'] == undefined) {
								data[i]['client'][0]['timezone_str'] = ''
							}
						}
						if (!data[i]['client_info']) {
							data[i]['client_info'] = []
							data[i]['client_info'].push({
								first_name: '',
								last_name: '',
								image: '',
								timezone: ''
							})
						} else {
							var client_info2 = data[i]['client_info'];
							data[i]['client_info'] = []
							data[i]['client_info'].push({
								first_name: client_info2.first_name,
								last_name: client_info2.last_name,
								image: client_info2.image,
								timezone: client_info2.timezone
							})
						}
						// if (!data[i]['client_info'][0]) {
						// 	data[i]['client_info'] = []
						// 	data[i]['client_info'].push({
						// 		first_name: '',
						// 		last_name: '',
						// 		image: '',
						// 		timezone: ''
						// 	})
						// }
						if (data[i]['day'] == undefined) {
							data[i]['day'] = ''
						}
						if (data[i]['month'] == undefined) {
							data[i]['month'] = ''
						}
						if (data[i]['year'] == undefined) {
							data[i]['year'] = ''
						}
						if (data[i]['date_str'] == undefined) {
							data[i]['date_str'] = ''
						}
						if (data[i]['time_str'] == undefined) {
							data[i]['time_str'] = ''
						}
						if (data[i]['timezone_str'] == undefined) {
							data[i]['timezone_str'] = data[i]['client'][0]['timezone_str']
						}
						if (data[i]['gym_name'] == undefined) {
							data[i]['gym_name'] = ''
						}
						if (data[i]['time'] == undefined) {
							data[i]['time'] = ''
						}
						dat.push({
							"id": data[i]['_id'],
							"trainer_id": data[i]['trainer_id'],
							"client_id": data[i]['client_id'],
							"user_type": data[i]['user_type'],
							"gym_name": data[i]['gym_name'],
							"utc": data[i]['utc'],
							"time": data[i]['time'],
							"repeat": data[i]['repeat'],
							"location": data[i]['location'],
							"duration": data[i]['duration'],
							"first_name": data[i]['client_info'][0]['first_name'],
							"last_name": data[i]['client_info'][0]['last_name'],
							"image": data[i]['client_info'][0]['image'],
							"timezone": data[i]['client_info'][0]['timezone'],
							"timezone_str": data[i]['timezone_str'],
							"status": data[i]['status'],
							"day": data[i]['day'],
							"month": data[i]['month'],
							"year": data[i]['year'],
							"date_str": data[i]['date_str'],
							"time_str": data[i]['time_str'],
						})
					}
					if (dat.length > 0) {
						res.send({
							"success": true,
							"message": "Success!",
							"data": dat[0]
						});
					} else {
						res.send({
							"success": true,
							"message": "Success!",
							"data": []
						});
					}
					return false;
				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	} else {
		if (!req.body.month) {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.user_id),
						"_id": ObjectId(req.body.session_id),
						// status:{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINERS',
						localField: 'trainer_id',
						foreignField: '_id',
						as: 'trainer'
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINER_DETAILS',
						localField: 'trainer_id',
						foreignField: 'user_id',
						as: 'trainerdetails'
					}
				},

			]);
		} else {
			var Query_m = dbo.collection('TBL_SESSIONS').aggregate([{
					$match: {
						client_id: ObjectId(req.body.user_id),
						"_id": ObjectId(req.body.session_id),
						"month": req.body.month,
						// "status":{$ne : 3}
						"status": {
							$nin: [3, 4, 5]
						},
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINERS',
						localField: 'trainer_id',
						foreignField: '_id',
						as: 'trainer'
					}
				},
				{
					$lookup: {
						from: 'TBL_TRAINER_DETAILS',
						localField: 'trainer_id',
						foreignField: 'user_id',
						as: 'trainerdetails'
					}
				},

			])
		}
		Query_m.toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					var data = JSON.parse(JSON.stringify(resr));
					// console.log(data[0]['clientdetails'])
					// console.log(data)
					var dat = [];
					for (var i = 0; i < data.length; i++) {
						if (data[i]['trainer'][0]['timezone'] == undefined) {
							data[i]['trainer'][0]['timezone'] = ''
						}
						if (data[i]['trainer'][0]['timezone_str'] == undefined) {
							data[i]['trainer'][0]['timezone_str'] = ''
						}
						if (data[i]['day'] == undefined) {
							data[i]['day'] = ''
						}
						if (data[i]['month'] == undefined) {
							data[i]['month'] = ''
						}
						if (data[i]['year'] == undefined) {
							data[i]['year'] = ''
						}
						if (data[i]['date_str'] == undefined) {
							data[i]['date_str'] = ''
						}
						if (data[i]['time_str'] == undefined) {
							data[i]['time_str'] = ''
						}
						if (data[i]['timezone_str'] == undefined) {
							data[i]['timezone_str'] = data[i]['trainer'][0]['timezone_str'];
						}
						if (data[i]['gym_name'] == undefined) {
							data[i]['gym_name'] = ''
						}
						dat.push({
							"id": data[i]['_id'],
							"client_id": data[i]['client_id'],
							"trainer_id": data[i]['trainer_id'],
							"user_type": data[i]['user_type'],
							"gym_name": data[i]['gym_name'],
							"utc": data[i]['utc'],
							"time": data[i]['time'],
							"repeat": data[i]['repeat'],
							"location": data[i]['location'],
							"duration": data[i]['duration'],
							"first_name": data[i]['trainerdetails'][0]['first_name'],
							"last_name": data[i]['trainerdetails'][0]['last_name'],
							"image": data[i]['trainerdetails'][0]['image'],
							"timezone": data[i]['trainer'][0]['timezone'],
							"timezone_str": data[i]['timezone_str'],
							"status": data[i]['status'],
							"day": data[i]['day'],
							"month": data[i]['month'],
							"year": data[i]['year'],
							"date_str": data[i]['date_str'],
							"time_str": data[i]['time_str'],
						})
					}
					res.send({
						"success": true,
						"message": "Success!",
						"data": dat
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "something went wrong",
						"data": {}
					});
					return false;
				}
			}

		});
	}
}
exports.delete_one_session = async function (req, res) {
	let dbo = await mongodbutil.Get();
	if (!req.body.session_id) {
		res.send({
			"success": false,
			"message": 'session_id req',
			"data": []
		});
		return false
	}
	var myquery = {
		_id: ObjectId(req.body.session_id)
	};
	var myquery2 = {
		session_id: ObjectId(req.body.session_id)
	};
	dbo.collection("TBL_SESSIONS").deleteOne(myquery, function (err, obj) {
		if (err) throw err;
		dbo.collection("TBL_TRAINER_BOOKED_SLOTS").deleteOne(myquery2, function (err, resSlot) {
			console.log('success')
		})
		res.send({
			"success": true,
			"message": 'We have successfully deleted the requested session',
			"data": []
		});
	});
}
exports.create_session = async function (req, res) {
	const {
		user_id,
		client_id,
		user_type,
		utc,
		duration,
		location,
		repeat,
		time_str,
		trainer_id
	} = req.body;
	let errors = [];
	if (user_type == 0) {
		if (!user_id || !client_id || !utc || !duration || !location || !repeat || !time_str || !user_type) {
			res.send({
				"success": false,
				"message": "Please enter all fields",
				"data": {}
			});
			return false;
		}
	} else {
		if (!user_id || !client_id || !utc || !duration || !location || !repeat || !time_str || !user_type) {
			res.send({
				"success": false,
				"message": "Please enter all fields",
				"data": {}
			});
			return false;
		}
	}

	if (req.body.user_type == 0) {
		var sessionObj = {
			trainer_id: ObjectId(req.body.user_id),
			client_id: ObjectId(req.body.client_id),
			utc: req.body.utc,
			duration: req.body.duration,
			location: req.body.location,
			repeat: req.body.repeat,
			gym_name: req.body.gym_name,
			// time: req.body.time_str,
			user_type: req.body.user_type,
			status: 2,
			day: req.body.day,
			month: req.body.month,
			year: req.body.year,
			date_str: req.body.date_str,
			time_str: req.body.time_str,
			timezone_str: req.body.timezone_str,
			time: req.body.time,
			created_at: getCurrentTime(),
			updated: getCurrentTime()
		};
		var slotObj = {
			trainer_id: ObjectId(req.body.user_id),
			client_id: ObjectId(req.body.client_id),
			slot_id: ObjectId(req.body.slot_id),
			day: req.body.day.toString(),
			time: req.body.time.toString(),
			month: req.body.month.toString(),
			year: req.body.year.toString(),
			created_at: getCurrentTime(),
			updated: getCurrentTime(),
			status: '1',
		}
	} else {
		var sessionObj = {
			client_id: ObjectId(req.body.client_id),
			trainer_id: ObjectId(req.body.user_id),
			utc: req.body.utc,
			duration: req.body.duration,
			location: req.body.location,
			repeat: req.body.repeat,
			gym_name: req.body.gym_name,
			// time: req.body.time,
			user_type: req.body.user_type,
			status: 0,
			day: req.body.day,
			month: req.body.month,
			year: req.body.year,
			date_str: req.body.date_str,
			time_str: req.body.time_str,
			time: req.body.time,
			timezone_str: req.body.timezone_str,
			created_at: getCurrentTime(),
			updated: getCurrentTime()
		};
		var slotObj = {
			trainer_id: ObjectId(req.body.user_id),
			client_id: ObjectId(req.body.client_id),
			slot_id: ObjectId(req.body.slot_id),
			day: req.body.day.toString(),
			time: req.body.time.toString(),
			month: req.body.month.toString(),
			year: req.body.year.toString(),
			created_at: getCurrentTime(),
			updated: getCurrentTime(),
			status: '0',
		}
	}

	let dbo = await mongodbutil.Get();

	dbo.collection('TBL_CLIENT_INFO').findOne({
		'client_id': ObjectId(req.body.client_id),
		'trainer_id': ObjectId(req.body.user_id)
	}, function (err, resv1) {
		if (err) {
			throw err;
		} else {
			// console.log(resv1)
			// 	return false
			if (!resv1.isBlocked || resv1.isBlocked == '0') {
				var Date_month = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
				var week_month = getWeekNumber(new Date(Date_month))
				console.log(getWeekNumber(new Date(Date_month)))
				sessionObj.week_month = week_month[1]

				var sessions_repeat_utc = []
				var sessions_repeat = []
				// console.log(resv1.payment)
				// return false
				if (resv1.payment == '2') {
					dbo.collection("TBL_SESSIONS").find({
						trainer_id: ObjectId(req.body.user_id),
						client_id: ObjectId(req.body.client_id),
						week_month: week_month[1],
						status: {
							$in: [0, 1, 2, 6]
						},
					}).toArray(async function (err, result_count) {
						var data_count = JSON.parse(JSON.stringify(result_count));
						// console.log(data_count.length)
						// console.log(data_count)

						dbo.collection("TBL_SESSIONS").find({
							trainer_id: ObjectId(req.body.user_id),
							client_id: ObjectId(req.body.client_id),
							// week_month: week_month[1],
							status: {
								$in: [0, 1, 2, 6]
							},
						}).toArray(async function (err, result_count1) {
							var data_count1 = JSON.parse(JSON.stringify(result_count1));
							console.log(data_count1.length)
							console.log('-----------')
							console.log(data_count1)
							for (var l = 0; l < data_count1.length; l++) {
								if (data_count1[l].repeat == '1') {
									var d = new Date(Number(data_count1[l].utc) * 1000);
									d.setMonth(req.body.month);
									var miliseconds = d.getTime() / 1000

									// var lastDay = new Date(req.body.year, req.body.month + 1, 0);
									// var miliseconds = lastDay.getTime() / 1000;
									// loop_res[l].session_end_date = lastDay;
									// console.log(miliseconds)
									// return false;
									var total_week = weeksBetween(new Date(Number(data_count1[l].utc) * 1000), new Date(Number(miliseconds) * 1000)) + 1
									// console.log('total_week')
									// console.log(total_week)
									for (var k = 0; k < total_week; k++) {
										var date = new Date(Number(data_count1[l].utc) * 1000)
										var week = (k)
										date.setDate(date.getDate() + week * 7);
										var end_date = date.getTime() / 1000;
										var date_number = date.getDate()
										var month_number = date.getMonth() + 1
										var week_dat = date.getDay();
										var time = date.getHours()
										var year = date.getFullYear();

										var Date_month = new Date(Number(end_date) * 1000);
										var week_month_1 = getWeekNumber(new Date(Date_month))
										sessions_repeat_utc.push(week_month_1[1])
									}
								} else if (data_count1[l].repeat == '2') {
									var d = new Date(Number(data_count1[l].utc) * 1000);
									d.setMonth(req.body.month);
									var miliseconds = d.getTime() / 1000
									// var lastDay = new Date(req.body.year, req.body.month , 0);
									// var miliseconds = lastDay.getTime() / 1000;
									// console.log(miliseconds)
									// return false;
									var total_week = monthBetween(new Date(Number(data_count1[l].utc) * 1000), new Date(Number(miliseconds) * 1000)) + 1
									for (var k = 0; k < total_week; k++) {
										var date = new Date(Number(data_count1[l].utc) * 1000)
										var months = (k)
										var d = date.getDate();
										date.setMonth(date.getMonth() + +months);
										if (date.getDate() != d) {
											date.setDate(0);
										}
										var end_date = date.getTime() / 1000;

										var date_number = date.getDate()
										var month_number = date.getMonth() + 1
										var week_dat = date.getDay();
										var time = date.getHours()
										var year = date.getFullYear();

										var Date_month = new Date(Number(end_date) * 1000);
										var week_month_1 = getWeekNumber(new Date(Date_month))
										sessions_repeat_utc.push(week_month_1[1])
									}
								}
							}

							var repeat_session_flag = false
							// console.log(sessions_repeat_utc)
							// console.log('sessions_repeat_utc')
							if (sessions_repeat_utc.length != 0) {

								var future_sessions = countDubli(sessions_repeat_utc)
								console.log('future_sessions')
								console.log(future_sessions)
								// console.log('week_month[1]')
								// console.log(week_month[1])
								if (future_sessions && future_sessions[week_month[1]] != undefined) {
									if (resv1.no_of_sessions_week.toString() <= future_sessions[week_month[1]].toString()) {
										repeat_session_flag = true
									}

								}
							}


							// for (var m = 0; m < sessions_repeat_utc.length + 4; m++) {
							// 	var Date_month = new Date(Number(sessions_repeat_utc[m])*1000);
							// 	var week_month = getWeekNumber(new Date(Date_month))
							// 	sessions_repeat.push({'week_month':})
							// }
							// week_month = 
							if (!req.body.force) {
								var force = '0'
							} else {
								var force = req.body.force
							}
							console.log((resv1.no_of_sessions_week.toString() + '<=' + data_count.length.toString() + ' &&' + force + '==' + '0') + '||' + (repeat_session_flag + '==' + true + '&&' + force + '==' + '0'))
							if ((resv1.no_of_sessions_week.toString() <= data_count.length.toString() && force == '0') || (repeat_session_flag == true && force == '0')) {
								if (req.body.user_type == 0) {
									res.send({
										"success": false,
										"message": "" + resv1.first_name + " " + resv1.last_name + " has already scheduled or exhausted all the sessions available per week. Would you like to proceed ?",
										"error_status": "1",
										"data": {}
									});
								} else {
									res.send({
										"success": false,
										"message": "You have already scheduled or exhausted all the sessions available per week. Please contact your trainer.",
										"error_status": "1",
										"data": {}
									});
								}

								return false;
							} else {
								dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
									if (err) {
										throw err;
									} else {
										// console.log(resv)
										// return
										slotObj.session_id = ObjectId(resv.insertedId);
										dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
											console.log('success')
										})
										if (req.body.user_type == 0) {
											// sendNotification(req.body.client_id,resv.insertedId)
											dbo.collection('TBL_SESSIONS').aggregate([{
													$match: {
														_id: ObjectId(resv.insertedId)
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENTS',
														localField: 'client_id',
														foreignField: '_id',
														as: 'client'
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENT_INFO',
														localField: 'client_id',
														foreignField: 'client_id',
														as: 'client_info'
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINERS',
														localField: 'user_id',
														foreignField: '_id',
														as: 'trainer'
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINER_DETAILS',
														localField: 'user_id',
														foreignField: 'user_id',
														as: 'trainerdetails'
													}
												},
												{
													"$unwind": "$client_info"
												},
												{
													"$match": {
														"client_info.trainer_id": ObjectId(req.body.user_id)
													}
												},
											]).toArray(function (err, resr) {
												if (err) {
													throw err;
												} else {
													if (resr) {
														var data = JSON.parse(JSON.stringify(resr));
														// console.log(data[0]['clientdetails'])
														// console.log(data)
														if (data[0]['client'][0]['timezone'] == undefined) {
															data[0]['client'][0]['timezone'] = ''
														}
														if (data[0]['client'][0]['timezone_str'] == undefined) {
															data[0]['client'][0]['timezone_str'] = ''
														}
														if (data[0]['gym_name'] == undefined) {
															data[0]['gym_name'] = ''
														}
														dat = {
															"id": data[0]['_id'],
															"trainer_id": data[0]['trainer_id'],
															"client_id": data[0]['client_id'],
															"user_type": data[0]['user_type'],
															"utc": data[0]['utc'],
															"time": data[0]['time'],
															"repeat": data[0]['repeat'],
															"location": data[0]['location'],
															"duration": data[0]['duration'],
															"gym_name": data[0]['gym_name'],
															"first_name": data[0].client_info.first_name,
															"last_name": data[0].client_info.last_name,
															"image": data[0]['image'],
															"timezone": data[0]['timezone'],
															"timezone_str": data[0]['timezone_str'],
															"status": data[0]['status'],
															"day": data[0]['day'],
															"month": data[0]['month'],
															"year": data[0]['year'],
															"date_str": data[0]['date_str'],
															"time_str": data[0]['time_str'],


														}
														res.send({
															"success": true,
															"message": "Session created succesfully!",
															"data": dat
														});
														return false;
													} else {
														res.send({
															"success": false,
															"message": "something went wrong",
															"data": {}
														});
														return false;
													}
												}

											});
										} else {
											// sendNotification(req.body.trainer_id,resv.insertedId)
											dbo.collection('TBL_SESSIONS').aggregate([{
													$match: {
														_id: ObjectId(resv.insertedId)
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENTS',
														localField: 'user_id',
														foreignField: '_id',
														as: 'client'
													}
												},
												// {
												// 	$lookup: {
												// 		from: 'TBL_CLIENT_DETAILS',
												// 		localField: 'user_id',
												// 		foreignField: 'user_id',
												// 		as: 'clientdetails'
												// 	}
												// },
												{
													$lookup: {
														from: 'TBL_TRAINERS',
														localField: 'trainer_id',
														foreignField: '_id',
														as: 'trainer'
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINER_DETAILS',
														localField: 'trainer_id',
														foreignField: 'user_id',
														as: 'trainerdetails'
													}
												},

											]).toArray(function (err, resr) {
												if (err) {
													throw err;
												} else {
													if (resr) {
														var data = JSON.parse(JSON.stringify(resr));
														// console.log(data[0]['clientdetails'])
														// console.log(data)
														if (data[0]['trainer'][0]['timezone'] == undefined) {
															data[0]['trainer'][0]['timezone'] = ''
														}
														if (data[0]['trainer'][0]['timezone_str'] == undefined) {
															data[0]['trainer'][0]['timezone_str'] = ''
														}
														if (data[0]['gym_name'] == undefined) {
															data[0]['gym_name'] = ''
														}
														dat = {
															"id": data[0]['_id'],
															"client_id": data[0]['client_id'],
															"trainer_id": data[0]['trainer_id'],
															"user_type": data[0]['user_type'],
															"utc": data[0]['utc'],
															"time": data[0]['time'],
															"repeat": data[0]['repeat'],
															"location": data[0]['location'],
															"duration": data[0]['duration'],
															"gym_name": data[0]['gym_name'],
															"first_name": data[0]['trainerdetails'][0]['first_name'],
															"last_name": data[0]['trainerdetails'][0]['last_name'],
															"image": data[0]['trainerdetails'][0]['image'],
															"timezone": data[0]['timezone'],
															"timezone_str": data[0]['timezone_str'],
															"status": data[0]['status'],
															"day": data[0]['day'],
															"month": data[0]['month'],
															"year": data[0]['year'],
															"date_str": data[0]['date_str'],
															"time_str": data[0]['time_str'],
														}
														res.send({
															"success": true,
															"message": "Session created",
															"data": dat
														});
														return false;
													} else {
														res.send({
															"success": false,
															"message": "something went wrong",
															"data": {}
														});
														return false;
													}
												}

											});
										}
									}
								});
							}
						})

					});
				} else if (resv1.payment == '1') {
					dbo.collection("TBL_SESSIONS").find({
						trainer_id: ObjectId(req.body.user_id),
						client_id: ObjectId(req.body.client_id),
						status: {
							$in: [0, 1, 2]
						},
					}).sort({
						utc: 1
					}).toArray(async function (err, result_count1) {
						var data_count = JSON.parse(JSON.stringify(result_count1));
						// console.log('data_count.length '+data_count.length)
						// console.log('result_count1 ')
						// console.log(result_count1)
						// console.log('resv1.no_of_sessions '+ resv1.no_of_sessions)
						// return false
						var total_no_of_sessions = Number(resv1.no_of_sessions)
						var total_sessions = result_count1
						var counter = -1
						var arr_sess = []
						var loopCount = total_sessions.length
						var onlyOne = false
						var ignore_no_repeat = false
						var j = 0

						var repeat_W_isPresent = total_sessions.some(function (el) {
							// return el.repeat === '1'
							return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
						});
						var repeat_M_isPresent = total_sessions.some(function (el) {
							// return el.repeat === '2'
							return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
						});

						// console.log('repeat_W_isPresent '+repeat_W_isPresent)
						// console.log('repeat_M_isPresent '+repeat_M_isPresent)
						// return false
						// console.log(total_sessions);
						// console.log(loopCount)
						// return false
						for (var f = 0; f < loopCount; f++) {
							// console.log('I am f One '+ f)
							if (ignore_no_repeat == false) {
								arr_sess.push({
									'session_id': total_sessions[f]._id,
									"start_date": total_sessions[f].utc,
									"session_type": total_sessions[f].repeat
								})

								if (loopCount == f + 1) {
									console.log('1st Loop Fin check')
									ignore_no_repeat = true
									f = -1
									// if (loopCount == 1) {
									// 	f--
									// }
									if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
										break;
									}
								}
								continue;
							}
							// else{
							// console.log('I am f '+ f)
							// console.log('total_sessions[f].repeat CHECK')
							// console.log(total_sessions[f])

							if (arr_sess.length >= total_no_of_sessions) {
								console.log('Loop completed check')
								break;
							}

							if (total_sessions[f].repeat == '0') {
								// console.log('continue repeat')
								// continue;
							} else if (total_sessions[f].repeat == '1') { //weekly

								arr_sess.push({
									'session_id': total_sessions[f]._id,
									"start_date": total_sessions[f].utc,
									"session_type": total_sessions[f].repeat
								})
							} else if (total_sessions[f].repeat == '2') { //Monthly
								arr_sess.push({
									'session_id': total_sessions[f]._id,
									"start_date": total_sessions[f].utc,
									"session_type": total_sessions[f].repeat
								})
							}

							// counter = arr_sess.length
							if (loopCount == f + 1) {
								// console.log(total_no_of_sessions)
								// console.log(arr_sess.length)
								// return 
								// if (arr_sess.length < total_no_of_sessions ) {
								f = -1
								// if (loopCount == 1) {
								// 	f--
								// }
								console.log('Loop Repeating Now check')
								// console.log('I am f two '+ f)
								// }
								continue;
							}
							// }


						}
						console.log('arr_sess.length ' + arr_sess.length)
						console.log('total_no_of_sessions ' + total_no_of_sessions)
						if (!req.body.force) {
							var force = '0'
						} else {
							var force = req.body.force
						}
						if (arr_sess.length >= total_no_of_sessions && force == '0') {
							if (req.body.user_type == 0) {
								res.send({
									"success": false,
									"message": "" + resv1.first_name + " " + resv1.last_name + " has already scheduled or exhausted all the sessions available. Would you like to proceed?",
									"error_status": "1",
									"data": {}
								});
							} else {
								res.send({
									"success": false,
									"message": "You have already scheduled or exhausted all the sessions. Please contact your trainer.",
									"error_status": "1",
									"data": {}
								});
							}
							// res.send({
							// 	"success": false,
							// 	"error_status": '1', // Force yes/no button on app side
							// 	"message": "All available Sessions have been scheduled or exhausted. Do you want to continue?",
							// 	"data": {}
							// });
							// return false
						} else {
							// console.log('else')
							// return false
							dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
								if (err) {
									throw err;
								} else {
									// console.log(resv)
									// return
									slotObj.session_id = ObjectId(resv.insertedId);
									dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
										console.log('success')
									})
									dbo.collection("TBL_SESSIONS").find({
										trainer_id: ObjectId(req.body.user_id),
										client_id: ObjectId(req.body.client_id),
										status: {
											$in: [0, 1, 2]
										},
										utc: {
											$gt: getCurrentTime().toString()
										}
									}).sort({
										utc: 1
									}).toArray(async function (err, result_count) {
										console.log(result_count)
										// console.log(resv1)
										var total_no_of_sessions = Number(resv1.no_of_sessions)
										var total_sessions = result_count
										var counter = -1
										var arr_sess = []
										// if (total_sessions.length + 1 > total_no_of_sessions) {
										// 	var desc_total_sessions = total_sessions.reverse();
										// 	var count_session_repeat = 0
										// 	console.log(desc_total_sessions)
										// 	for (var f = 0; f < desc_total_sessions.length; f++) {
										// 		if (total_sessions[f].repeat != '0') {
										// 			if(!total_sessions[f].end_date){
										// 				console.log(++count_session_repeat)
										// 			}
										// 		}
										// 	}
										// 	return false
										// }
										// else{
										// var loopCount = Math.max(total_sessions.length,total_no_of_sessions)
										var loopCount = total_sessions.length
										var onlyOne = false
										var ignore_no_repeat = false
										var j = 0

										var repeat_W_isPresent = total_sessions.some(function (el) {
											// return el.repeat === '1'
											return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
										});
										var repeat_M_isPresent = total_sessions.some(function (el) {
											// return el.repeat === '2'
											return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
										});
										for (var f = 0; f < loopCount; f++) {
											if (ignore_no_repeat == false) {
												arr_sess.push({
													'session_id': total_sessions[f]._id,
													"start_date": total_sessions[f].utc,
													"session_type": total_sessions[f].repeat
												})

												if (loopCount == f + 1) {
													console.log('1st Loop Fin')
													ignore_no_repeat = true
													f = -1
													// if (loopCount == 1) {
													// 	f--
													// }
													if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
														break;
													}
												}
												continue;
											}
											// console.log(arr_sess)
											if (arr_sess.length >= total_no_of_sessions) {
												console.log('Loop completed')
												break;
											}

											if (total_sessions[f].repeat == '0') {
												// console.log('continue repeat')
												// continue;
												// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
											} else if (total_sessions[f].repeat == '1') { //weekly

												arr_sess.push({
													'session_id': total_sessions[f]._id,
													"start_date": total_sessions[f].utc,
													"session_type": total_sessions[f].repeat
												})
											} else if (total_sessions[f].repeat == '2') { //Monthly
												arr_sess.push({
													'session_id': total_sessions[f]._id,
													"start_date": total_sessions[f].utc,
													"session_type": total_sessions[f].repeat
												})
											}
											// counter = arr_sess.length
											if (loopCount == f + 1) {
												// if (arr_sess.length < total_no_of_sessions ) {
												f = -1
												// if (loopCount == 1) {
												// 	f--
												// }
												console.log('Loop Repeating Now')
												continue;
												// }
											}

										}

										var result = arr_sess.reduce(function (r, a) {
											if (a.session_type != '0') {
												r[a.session_id] = r[a.session_id] || [];
												r[a.session_id].push(a);

											}
											return r;
										}, {});

										var final_arr = []
										for (key in result) {
											if (result.hasOwnProperty(key)) {
												var value = result[key];
												console.log(value.length)
												console.log(value[0].start_date)


												if (value[0].session_type == '1') {
													// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
													var date = new Date(Number(value[0].start_date) * 1000)
													var week = (value.length - 1)
													date.setDate(date.getDate() + week * 7);
													var end_date = date.getTime() / 1000;
												} else if (value[0].session_type == '2') {
													var date = new Date(Number(value[0].start_date) * 1000)
													var months = (value.length - 1)
													var d = date.getDate();
													date.setMonth(date.getMonth() + +months);
													if (date.getDate() != d) {
														date.setDate(0);
													}
													var end_date = date.getTime() / 1000;
												}
												final_arr.push({
													'session_id': value[0].session_id,
													'end_date': end_date,
													'type': value[0].session_type,
													'start_date': value[0].start_date
												})
											}
										}
										let promise = Promise.resolve();
										const posts = final_arr;
										posts.forEach(post => {
											promise = promise.then(() => {
												var dataIn = post
												// for (var p = 0; p < final_arr.length; p++) {
												var slotObj = {
													'session_end_date': dataIn.end_date
												}
												dbo.collection("TBL_SESSIONS").updateOne({
													_id: ObjectId(dataIn.session_id)
												}, {
													$set: slotObj
												}, function (err, rese) {
													console.log('success')
												})
												// }
											})
										})

										promise.then(() => {
											setTimeout(function () {
												response()
											}, 150);

										})

										// console.log(final_arr)
										function response() {
											if (req.body.user_type == 0) {
												dbo.collection('TBL_SESSIONS').aggregate([{
														$match: {
															_id: ObjectId(resv.insertedId)
														}
													},
													{
														$lookup: {
															from: 'TBL_CLIENTS',
															localField: 'client_id',
															foreignField: '_id',
															as: 'client'
														}
													},
													{
														$lookup: {
															from: 'TBL_CLIENT_INFO',
															localField: 'client_id',
															foreignField: 'client_id',
															as: 'client_info'
														}
													},
													{
														$lookup: {
															from: 'TBL_TRAINERS',
															localField: 'user_id',
															foreignField: '_id',
															as: 'trainer'
														}
													},
													{
														$lookup: {
															from: 'TBL_TRAINER_DETAILS',
															localField: 'user_id',
															foreignField: 'user_id',
															as: 'trainerdetails'
														}
													},
													{
														"$unwind": "$client_info"
													},
													{
														"$match": {
															"client_info.trainer_id": ObjectId(req.body.user_id)
														}
													},
													// {$group: {
													//      _id: "$_id",
													//      client_info: {$push: "$client_info"}
													//  }},

												]).toArray(function (err, resr) {
													if (err) {
														throw err;
													} else {
														if (resr) {
															var data = JSON.parse(JSON.stringify(resr));
															// console.log(data[0]['clientdetails'])
															// console.log(data)
															if (data[0]['client'][0]['timezone'] == undefined) {
																data[0]['client'][0]['timezone'] = ''
															}
															if (data[0]['client'][0]['timezone_str'] == undefined) {
																data[0]['client'][0]['timezone_str'] = ''
															}
															if (data[0]['gym_name'] == undefined) {
																data[0]['gym_name'] = ''
															}
															if (data[0]['session_end_date'] == undefined) {
																data[0]['session_end_date'] = ''
															}
															dat = {
																"id": data[0]['_id'],
																"trainer_id": data[0]['trainer_id'],
																"client_id": data[0]['client_id'],
																"user_type": data[0]['user_type'],
																"utc": data[0]['utc'],
																"time": data[0]['time'],
																"repeat": data[0]['repeat'],
																"location": data[0]['location'],
																"duration": data[0]['duration'],
																"gym_name": data[0]['gym_name'],
																"first_name": data[0].client_info.first_name,
																"last_name": data[0].client_info.last_name,
																"image": data[0]['image'],
																"timezone": data[0]['timezone'],
																"timezone_str": data[0]['timezone_str'],
																"status": data[0]['status'],
																"day": data[0]['day'],
																"month": data[0]['month'],
																"year": data[0]['year'],
																"date_str": data[0]['date_str'],
																"time_str": data[0]['time_str'],
																"session_end_date": data[0]['session_end_date'].toString(),


															}
															res.send({
																"success": true,
																"message": "Session created succesfully!",
																"data": dat
															});
															return false;
														} else {
															res.send({
																"success": false,
																"message": "something went wrong",
																"data": {}
															});
															return false;
														}
													}

												});
											} else {
												// sendNotification(req.body.trainer_id,resv.insertedId)
												dbo.collection('TBL_SESSIONS').aggregate([{
														$match: {
															_id: ObjectId(resv.insertedId)
														}
													},
													{
														$lookup: {
															from: 'TBL_CLIENTS',
															localField: 'user_id',
															foreignField: '_id',
															as: 'client'
														}
													},
													// {
													// 	$lookup: {
													// 		from: 'TBL_CLIENT_DETAILS',
													// 		localField: 'user_id',
													// 		foreignField: 'user_id',
													// 		as: 'clientdetails'
													// 	}
													// },
													{
														$lookup: {
															from: 'TBL_TRAINERS',
															localField: 'trainer_id',
															foreignField: '_id',
															as: 'trainer'
														}
													},
													{
														$lookup: {
															from: 'TBL_TRAINER_DETAILS',
															localField: 'trainer_id',
															foreignField: 'user_id',
															as: 'trainerdetails'
														}
													},

												]).toArray(function (err, resr) {
													if (err) {
														throw err;
													} else {
														if (resr) {
															var data = JSON.parse(JSON.stringify(resr));
															// console.log(data[0]['clientdetails'])
															// console.log(data)
															if (data[0]['trainer'][0]['timezone'] == undefined) {
																data[0]['trainer'][0]['timezone'] = ''
															}
															if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																data[0]['trainer'][0]['timezone_str'] = ''
															}
															if (data[0]['gym_name'] == undefined) {
																data[0]['gym_name'] = ''
															}
															if (data[0]['session_end_date'] == undefined) {
																data[0]['session_end_date'] = ''
															}
															dat = {
																"id": data[0]['_id'],
																"client_id": data[0]['client_id'],
																"trainer_id": data[0]['trainer_id'],
																"user_type": data[0]['user_type'],
																"utc": data[0]['utc'],
																"time": data[0]['time'],
																"repeat": data[0]['repeat'],
																"location": data[0]['location'],
																"duration": data[0]['duration'],
																"gym_name": data[0]['gym_name'],
																"first_name": data[0]['trainerdetails'][0]['first_name'],
																"last_name": data[0]['trainerdetails'][0]['last_name'],
																"image": data[0]['trainerdetails'][0]['image'],
																"timezone": data[0]['timezone'],
																"timezone_str": data[0]['timezone_str'],
																"status": data[0]['status'],
																"day": data[0]['day'],
																"month": data[0]['month'],
																"year": data[0]['year'],
																"date_str": data[0]['date_str'],
																"time_str": data[0]['time_str'],
																"session_end_date": data[0]['session_end_date'].toString(),
															}
															res.send({
																"success": true,
																"message": "Session created",
																"data": dat
															});
															return false;
														} else {
															res.send({
																"success": false,
																"message": "something went wrong",
																"data": {}
															});
															return false;
														}
													}

												});
											}
										}

									})
								}
							})
						}


					})


				} else {
					dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
						if (err) {
							throw err;
						} else {
							// console.log(resv)
							// return
							slotObj.session_id = ObjectId(resv.insertedId);
							dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
								console.log('success')
							})
							if (req.body.user_type == 0) {
								// sendNotification(req.body.client_id,resv.insertedId)
								dbo.collection('TBL_SESSIONS').aggregate([{
										$match: {
											_id: ObjectId(resv.insertedId)
										}
									},
									{
										$lookup: {
											from: 'TBL_CLIENTS',
											localField: 'client_id',
											foreignField: '_id',
											as: 'client'
										}
									},
									{
										$lookup: {
											from: 'TBL_CLIENT_INFO',
											localField: 'client_id',
											foreignField: 'client_id',
											as: 'client_info'
										}
									},
									{
										$lookup: {
											from: 'TBL_TRAINERS',
											localField: 'user_id',
											foreignField: '_id',
											as: 'trainer'
										}
									},
									{
										$lookup: {
											from: 'TBL_TRAINER_DETAILS',
											localField: 'user_id',
											foreignField: 'user_id',
											as: 'trainerdetails'
										}
									},
									{
										"$unwind": "$client_info"
									},
									{
										"$match": {
											"client_info.trainer_id": ObjectId(req.body.user_id)
										}
									},
									// {$group: {
									//      _id: "$_id",
									//      client_info: {$push: "$client_info"}
									//  }},

								]).toArray(function (err, resr) {
									if (err) {
										throw err;
									} else {
										if (resr) {
											var data = JSON.parse(JSON.stringify(resr));
											// console.log(data[0]['clientdetails'])
											console.log(data)
											if (data[0]['client'][0]['timezone'] == undefined) {
												data[0]['client'][0]['timezone'] = ''
											}
											if (data[0]['client'][0]['timezone_str'] == undefined) {
												data[0]['client'][0]['timezone_str'] = ''
											}
											if (data[0]['gym_name'] == undefined) {
												data[0]['gym_name'] = ''
											}

											dat = {
												"id": data[0]['_id'],
												"trainer_id": data[0]['trainer_id'],
												"client_id": data[0]['client_id'],
												"user_type": data[0]['user_type'],
												"utc": data[0]['utc'],
												"time": data[0]['time'],
												"repeat": data[0]['repeat'],
												"location": data[0]['location'],
												"duration": data[0]['duration'],
												"gym_name": data[0]['gym_name'],
												"first_name": data[0].client_info.first_name,
												"last_name": data[0].client_info.last_name,
												"image": data[0]['image'],
												"timezone": data[0]['timezone'],
												"timezone_str": data[0]['timezone_str'],
												"status": data[0]['status'],
												"day": data[0]['day'],
												"month": data[0]['month'],
												"year": data[0]['year'],
												"date_str": data[0]['date_str'],
												"time_str": data[0]['time_str'],


											}
											res.send({
												"success": true,
												"message": "Session created succesfully!",
												"data": dat
											});
											return false;
										} else {
											res.send({
												"success": false,
												"message": "something went wrong",
												"data": {}
											});
											return false;
										}
									}

								});
							} else {
								// sendNotification(req.body.trainer_id,resv.insertedId)
								dbo.collection('TBL_SESSIONS').aggregate([{
										$match: {
											_id: ObjectId(resv.insertedId)
										}
									},
									{
										$lookup: {
											from: 'TBL_CLIENTS',
											localField: 'user_id',
											foreignField: '_id',
											as: 'client'
										}
									},
									// {
									// 	$lookup: {
									// 		from: 'TBL_CLIENT_DETAILS',
									// 		localField: 'user_id',
									// 		foreignField: 'user_id',
									// 		as: 'clientdetails'
									// 	}
									// },
									{
										$lookup: {
											from: 'TBL_TRAINERS',
											localField: 'trainer_id',
											foreignField: '_id',
											as: 'trainer'
										}
									},
									{
										$lookup: {
											from: 'TBL_TRAINER_DETAILS',
											localField: 'trainer_id',
											foreignField: 'user_id',
											as: 'trainerdetails'
										}
									},

								]).toArray(function (err, resr) {
									if (err) {
										throw err;
									} else {
										if (resr) {
											var data = JSON.parse(JSON.stringify(resr));
											// console.log(data[0]['clientdetails'])
											// console.log(data)
											if (data[0]['trainer'][0]['timezone'] == undefined) {
												data[0]['trainer'][0]['timezone'] = ''
											}
											if (data[0]['trainer'][0]['timezone_str'] == undefined) {
												data[0]['trainer'][0]['timezone_str'] = ''
											}
											if (data[0]['gym_name'] == undefined) {
												data[0]['gym_name'] = ''
											}
											dat = {
												"id": data[0]['_id'],
												"client_id": data[0]['client_id'],
												"trainer_id": data[0]['trainer_id'],
												"user_type": data[0]['user_type'],
												"utc": data[0]['utc'],
												"time": data[0]['time'],
												"repeat": data[0]['repeat'],
												"location": data[0]['location'],
												"duration": data[0]['duration'],
												"gym_name": data[0]['gym_name'],
												"first_name": data[0]['trainerdetails'][0]['first_name'],
												"last_name": data[0]['trainerdetails'][0]['last_name'],
												"image": data[0]['trainerdetails'][0]['image'],
												"timezone": data[0]['timezone'],
												"timezone_str": data[0]['timezone_str'],
												"status": data[0]['status'],
												"day": data[0]['day'],
												"month": data[0]['month'],
												"year": data[0]['year'],
												"date_str": data[0]['date_str'],
												"time_str": data[0]['time_str'],
											}
											res.send({
												"success": true,
												"message": "Session created",
												"data": dat
											});
											return false;
										} else {
											res.send({
												"success": false,
												"message": "something went wrong",
												"data": {}
											});
											return false;
										}
									}

								});
							}
						}
					});
				}
				// console.log(resv1.no_of_sessions_week)
				// return false

			} else if (resv1.isBlocked != undefined && resv1.isBlocked == '1') {
				if (req.body.user_type == 0) {
					res.send({
						"success": false,
						"message": "This client is blocked.",
						"data": {}
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "You have been blocked by the Trainer",
						"data": {}
					});
					return false;
				}

			}


		}
	})


}

exports.update_session = async function (req, res) {
	const {
		user_id,
		user_type,
		utc,
		duration,
		location,
		repeat,
		time,
		session_id,
		date_str,
		time_str,
		day,
		month,
		year
	} = req.body;
	let errors = [];
	if (!user_id || !session_id || !utc || !duration || !location || !repeat || !user_type || !date_str || !time_str || !day || !month || !year) {
		res.send({
			"success": false,
			"message": "Please enter all fields",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	var session_id_b = req.body.session_id
	delete req.body.session_id;
	req.body.client_id = ObjectId(req.body.client_id)
	dbo.collection('TBL_CLIENT_INFO').findOne({
		'client_id': ObjectId(req.body.client_id),
		'trainer_id': ObjectId(req.body.user_id)
	}, function (err, resv1) {
		if (err) {
			throw err;
		} else {
			if (!resv1.isBlocked || resv1.isBlocked == '0') {
				var Date_month = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
				var week_month = getWeekNumber(new Date(Date_month))
				req.body.week_month = week_month[1]
				if (resv1.payment == '2') {
					dbo.collection("TBL_SESSIONS").find({
						"_id": ObjectId(session_id_b)
					}).toArray(async function (err, same_week) {
						var same_week = JSON.parse(JSON.stringify(same_week));
						if (same_week[0].week_month.toString() == week_month[1].toString()) {
							var bypass = '1';
						} else {
							var bypass = '0';
						}
						dbo.collection("TBL_SESSIONS").find({
							trainer_id: ObjectId(req.body.user_id),
							client_id: ObjectId(req.body.client_id),
							week_month: week_month[1],
							status: {
								$in: [0, 1, 2, 6]
							},
						}).toArray(async function (err, result_count) {
							var data_count = JSON.parse(JSON.stringify(result_count));
							console.log(data_count.length)
							if (!req.body.force) {
								var force = '0'
							} else {
								var force = req.body.force
							}

							if (resv1.no_of_sessions_week.toString() <= data_count.length.toString() && bypass == '0') {
								if (req.body.user_type == 0) {
									res.send({
										"success": false,
										"message": "" + resv1.first_name + " " + resv1.last_name + " has already scheduled or exhausted all the sessions available per week. Would you like to proceed ?",
										"error_status": "1",
										"data": {}
									});
								} else {
									res.send({
										"success": false,
										"message": "You have already scheduled or exhausted all the sessions available per week. Please contact your trainer.",
										"error_status": "1",
										"data": {}
									});
								}

								return false;
							} else {

								dbo.collection('TBL_SESSIONS').updateOne({
									_id: ObjectId(session_id_b)
								}, {
									$set: req.body
								}, function (err, rese) {
									if (err) {
										res.send({
											"success": false,
											"message": "Something went wrong!"
										});
										return false;
									} else {
										var slotObj = {
											trainer_id: ObjectId(req.body.user_id),
											client_id: ObjectId(req.body.client_id),
											slot_id: ObjectId(req.body.slot_id),
											day: req.body.day.toString(),
											time: req.body.time.toString(),
											month: req.body.month.toString(),
											year: req.body.year.toString(),
											created_at: getCurrentTime(),
											updated: getCurrentTime()

										}

										dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
											session_id: ObjectId(session_id_b)
										}, {
											$set: slotObj
										}, function (err, rese) {
											console.log('success')
										})
										if (req.body.user_type == 0) {
											dbo.collection('TBL_SESSIONS').aggregate([{
													$match: {
														"_id": ObjectId(session_id_b)
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENTS',
														localField: 'client_id',
														foreignField: '_id',
														as: 'client'
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENT_INFO',
														localField: 'client_id',
														foreignField: 'client_id',
														as: 'client_info'
													}
												},
												{
													"$unwind": "$client_info"
												},
												{
													"$match": {
														"client_info.trainer_id": ObjectId(req.body.user_id)
													}
												},
											]).toArray(function (err, resr) {
												if (err) {
													throw err;
												} else {
													if (resr) {
														console.log(resr)
														console.log('resr')

														var data = JSON.parse(JSON.stringify(resr));
														// console.log(data[0]['clientdetails'])
														console.log(data)
														// return
														var dat = [];
														for (var i = 0; i < data.length; i++) {
															if (data[i]['timezone'] == undefined) {
																data[i]['timezone'] = ''
															}
															if (data[i]['timezone_str'] == undefined) {
																data[i]['timezone_str'] = ''
															}
															if (data[i]['gym_name'] == undefined) {
																data[i]['gym_name'] = ''
															}
															if (data[i]['session_end_date'] == undefined) {
																data[i]['session_end_date'] = ''
															}
															// gym_name: req.body.gym_name,
															dat.push({
																"id": data[i]['_id'],
																"trainer_id": data[i]['trainer_id'],
																"client_id": data[i]['client_id'],
																"user_type": data[i]['user_type'],
																"gym_name": data[i]['gym_name'],
																"utc": data[i]['utc'],
																"time": data[i]['time'],
																"repeat": data[i]['repeat'],
																"location": data[i]['location'],
																"duration": data[i]['duration'],
																"first_name": data[i].client_info.first_name,
																"last_name": data[i].client_info.last_name,
																"image": data[i]['image'],
																"timezone": data[i]['timezone'],
																"timezone_str": data[i]['timezone_str'],
																"status": data[i]['status'],
																"date_str": data[i]['date_str'],
																"time_str": data[i]['time_str'],
																"day": data[i]['day'],
																"month": data[i]['month'],
																"year": data[i]['year'],
																"session_end_date": data[i]['session_end_date'].toString()
															})
														}
														res.send({
															"success": true,
															"message": "Session Updated",
															"data": dat[0]
														});
														return false;
													} else {
														res.send({
															"success": false,
															"message": "something went wrong",
															"data": {}
														});
														return false;
													}
												}

											});
										} else {
											dbo.collection('TBL_SESSIONS').aggregate([{
													$match: {
														_id: ObjectId(session_id_b)
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINERS',
														localField: 'trainer_id',
														foreignField: '_id',
														as: 'trainer'
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINER_DETAILS',
														localField: 'trainer_id',
														foreignField: 'user_id',
														as: 'trainerdetails'
													}
												},

											]).toArray(function (err, resr) {
												if (err) {
													throw err;
												} else {
													if (resr) {
														var data = JSON.parse(JSON.stringify(resr));
														var dat = [];
														for (var i = 0; i < data.length; i++) {
															if (data[i]['timezone'] == undefined) {
																data[i]['timezone'] = ''
															}
															if (data[i]['timezone_str'] == undefined) {
																data[i]['timezone_str'] = ''
															}
															if (data[i]['gym_name'] == undefined) {
																data[i]['gym_name'] = ''
															}
															if (data[i]['session_end_date'] == undefined) {
																data[i]['session_end_date'] = ''
															}
															dat.push({
																"id": data[i]['_id'],
																"client_id": data[i]['client_id'],
																"trainer_id": data[i]['trainer_id'],
																"user_type": data[i]['user_type'],
																"gym_name": data[i]['gym_name'],
																"utc": data[i]['utc'],
																"time": data[i]['time'],
																"repeat": data[i]['repeat'],
																"location": data[i]['location'],
																"duration": data[i]['duration'],
																"first_name": data[i]['trainerdetails'][0]['first_name'],
																"last_name": data[i]['trainerdetails'][0]['last_name'],
																"image": data[i]['trainerdetails'][0]['image'],
																"timezone": data[i]['timezone'],
																"timezone_str": data[i]['timezone_str'],
																"status": data[i]['status'],
																"date_str": data[i]['date_str'],
																"time_str": data[i]['time_str'],
																"day": data[i]['day'],
																"month": data[i]['month'],
																"year": data[i]['year'],
																"session_end_date": data[i]['session_end_date'].toString()
															})
														}
														res.send({
															"success": true,
															"message": "Session updated",
															"data": dat[0]
														});
														return false;
													} else {
														res.send({
															"success": false,
															"message": "something went wrong",
															"data": {}
														});
														return false;
													}
												}

											});
										}
									}
								});

							}
						});
					})

				} else if (resv1.payment == '1') {

					dbo.collection('TBL_SESSIONS').updateOne({
						_id: ObjectId(session_id_b)
					}, {
						$set: req.body
					}, function (err, rese) {
						if (err) {
							throw err;
						} else {
							var slotObj = {
								trainer_id: ObjectId(req.body.user_id),
								client_id: ObjectId(req.body.client_id),
								slot_id: ObjectId(req.body.slot_id),
								day: req.body.day.toString(),
								time: req.body.time.toString(),
								month: req.body.month.toString(),
								year: req.body.year.toString(),
								created_at: getCurrentTime(),
								updated: getCurrentTime()

							}

							dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
								session_id: ObjectId(session_id_b)
							}, {
								$set: slotObj
							}, function (err, rese) {
								console.log('success')
							})

							dbo.collection("TBL_SESSIONS").find({
								trainer_id: ObjectId(req.body.user_id),
								client_id: ObjectId(req.body.client_id),
								status: {
									$in: [0, 1, 2]
								},
								utc: {
									$gt: getCurrentTime().toString()
								}
							}).sort({
								utc: 1
							}).toArray(async function (err, result_count) {
								console.log(result_count)
								// console.log(resv1)
								var total_no_of_sessions = Number(resv1.no_of_sessions)
								var total_sessions = result_count
								var counter = -1
								var arr_sess = []

								var loopCount = total_sessions.length
								var onlyOne = false
								var ignore_no_repeat = false
								var j = 0

								var repeat_W_isPresent = total_sessions.some(function (el) {
									// return el.repeat === '1'
									return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
								});
								var repeat_M_isPresent = total_sessions.some(function (el) {
									// return el.repeat === '2'
									return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
								});
								for (var f = 0; f < loopCount; f++) {
									if (ignore_no_repeat == false) {
										arr_sess.push({
											'session_id': total_sessions[f]._id,
											"start_date": total_sessions[f].utc,
											"session_type": total_sessions[f].repeat
										})

										if (loopCount == f + 1) {
											console.log('1st Loop Fin')
											ignore_no_repeat = true
											f = -1
											if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
												break;
											}
										}
										continue;
									}
									console.log(arr_sess)
									if (arr_sess.length >= total_no_of_sessions) {
										console.log('Loop completed')
										break;
									}

									if (total_sessions[f].repeat == '0') {
										// console.log('continue repeat')
										// continue;
										// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
									} else if (total_sessions[f].repeat == '1') { //weekly

										arr_sess.push({
											'session_id': total_sessions[f]._id,
											"start_date": total_sessions[f].utc,
											"session_type": total_sessions[f].repeat
										})
									} else if (total_sessions[f].repeat == '2') { //Monthly
										arr_sess.push({
											'session_id': total_sessions[f]._id,
											"start_date": total_sessions[f].utc,
											"session_type": total_sessions[f].repeat
										})
									}
									// counter = arr_sess.length
									if (loopCount == f + 1) {
										f = -1
										console.log('Loop Repeating Now')
										continue;
									}

								}

								var result = arr_sess.reduce(function (r, a) {
									if (a.session_type != '0') {
										r[a.session_id] = r[a.session_id] || [];
										r[a.session_id].push(a);

									}
									return r;
								}, {});

								var final_arr = []
								for (key in result) {
									if (result.hasOwnProperty(key)) {
										var value = result[key];
										console.log(value.length)
										console.log(value[0].start_date)


										if (value[0].session_type == '1') {
											// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
											var date = new Date(Number(value[0].start_date) * 1000)
											var week = (value.length - 1)
											date.setDate(date.getDate() + week * 7);
											var end_date = date.getTime() / 1000;
										} else if (value[0].session_type == '2') {
											var date = new Date(Number(value[0].start_date) * 1000)
											var months = (value.length - 1)
											var d = date.getDate();
											date.setMonth(date.getMonth() + +months);
											if (date.getDate() != d) {
												date.setDate(0);
											}
											var end_date = date.getTime() / 1000;
										}
										final_arr.push({
											'session_id': value[0].session_id,
											'end_date': end_date,
											'type': value[0].session_type,
											'start_date': value[0].start_date
										})
									}
								}
								let promise = Promise.resolve();
								const posts = final_arr;
								posts.forEach(post => {
									promise = promise.then(() => {
										var dataIn = post
										// for (var p = 0; p < final_arr.length; p++) {
										var slotObj = {
											'session_end_date': dataIn.end_date
										}
										dbo.collection("TBL_SESSIONS").updateOne({
											_id: ObjectId(dataIn.session_id)
										}, {
											$set: slotObj
										}, function (err, rese) {
											console.log('success')
										})
										// }
									})
								})

								promise.then(() => {
									setTimeout(function () {
										response()
									}, 150);

								})

								// console.log(final_arr)
								function response() {
									if (req.body.user_type == 0) {
										dbo.collection('TBL_SESSIONS').aggregate([{
												$match: {
													"_id": ObjectId(session_id_b)
												}
											},
											{
												$lookup: {
													from: 'TBL_CLIENTS',
													localField: 'client_id',
													foreignField: '_id',
													as: 'client'
												}
											},
											{
												$lookup: {
													from: 'TBL_CLIENT_INFO',
													localField: 'client_id',
													foreignField: 'client_id',
													as: 'client_info'
												}
											},
											{
												$lookup: {
													from: 'TBL_TRAINERS',
													localField: 'user_id',
													foreignField: '_id',
													as: 'trainer'
												}
											},
											{
												$lookup: {
													from: 'TBL_TRAINER_DETAILS',
													localField: 'user_id',
													foreignField: 'user_id',
													as: 'trainerdetails'
												}
											},
											{
												"$unwind": "$client_info"
											},
											{
												"$match": {
													"client_info.trainer_id": ObjectId(req.body.user_id)
												}
											},
											// {$group: {
											//      _id: "$_id",
											//      client_info: {$push: "$client_info"}
											//  }},

										]).toArray(function (err, resr) {
											if (err) {
												throw err;
											} else {
												if (resr) {
													var data = JSON.parse(JSON.stringify(resr));
													// console.log(data[0]['clientdetails'])
													// console.log(data)
													if (data[0]['timezone'] == undefined) {
														data[0]['timezone'] = ''
													}
													if (data[0]['timezone_str'] == undefined) {
														data[0]['timezone_str'] = ''
													}
													if (data[0]['gym_name'] == undefined) {
														data[0]['gym_name'] = ''
													}
													if (data[0]['session_end_date'] == undefined) {
														data[0]['session_end_date'] = ''
													}
													dat = {
														"id": data[0]['_id'],
														"trainer_id": data[0]['trainer_id'],
														"client_id": data[0]['client_id'],
														"user_type": data[0]['user_type'],
														"utc": data[0]['utc'],
														"time": data[0]['time'],
														"repeat": data[0]['repeat'],
														"location": data[0]['location'],
														"duration": data[0]['duration'],
														"gym_name": data[0]['gym_name'],
														"first_name": data[0].client_info.first_name,
														"last_name": data[0].client_info.last_name,
														"image": data[0]['image'],
														"timezone": data[0]['timezone'],
														"timezone_str": data[0]['timezone_str'],
														"status": data[0]['status'],
														"day": data[0]['day'],
														"month": data[0]['month'],
														"year": data[0]['year'],
														"date_str": data[0]['date_str'],
														"time_str": data[0]['time_str'],
														"session_end_date": data[0]['session_end_date'].toString(),


													}
													res.send({
														"success": true,
														"message": "Session updated succesfully!",
														"data": dat
													});
													return false;
												} else {
													res.send({
														"success": false,
														"message": "something went wrong",
														"data": {}
													});
													return false;
												}
											}

										});
									} else {
										// sendNotification(req.body.trainer_id,resv.insertedId)
										dbo.collection('TBL_SESSIONS').aggregate([{
												$match: {
													"_id": ObjectId(session_id_b)
												}
											},
											{
												$lookup: {
													from: 'TBL_CLIENTS',
													localField: 'user_id',
													foreignField: '_id',
													as: 'client'
												}
											},
											// {
											// 	$lookup: {
											// 		from: 'TBL_CLIENT_DETAILS',
											// 		localField: 'user_id',
											// 		foreignField: 'user_id',
											// 		as: 'clientdetails'
											// 	}
											// },
											{
												$lookup: {
													from: 'TBL_TRAINERS',
													localField: 'trainer_id',
													foreignField: '_id',
													as: 'trainer'
												}
											},
											{
												$lookup: {
													from: 'TBL_TRAINER_DETAILS',
													localField: 'trainer_id',
													foreignField: 'user_id',
													as: 'trainerdetails'
												}
											},

										]).toArray(function (err, resr) {
											if (err) {
												throw err;
											} else {
												if (resr) {
													var data = JSON.parse(JSON.stringify(resr));
													// console.log(data[0]['clientdetails'])
													// console.log(data)
													if (data[0]['timezone'] == undefined) {
														data[0]['timezone'] = ''
													}
													if (data[0]['timezone_str'] == undefined) {
														data[0]['timezone_str'] = ''
													}
													if (data[0]['gym_name'] == undefined) {
														data[0]['gym_name'] = ''
													}
													if (data[0]['session_end_date'] == undefined) {
														data[0]['session_end_date'] = ''
													}
													dat = {
														"id": data[0]['_id'],
														"client_id": data[0]['client_id'],
														"trainer_id": data[0]['trainer_id'],
														"user_type": data[0]['user_type'],
														"utc": data[0]['utc'],
														"time": data[0]['time'],
														"repeat": data[0]['repeat'],
														"location": data[0]['location'],
														"duration": data[0]['duration'],
														"gym_name": data[0]['gym_name'],
														"first_name": data[0]['trainerdetails'][0]['first_name'],
														"last_name": data[0]['trainerdetails'][0]['last_name'],
														"image": data[0]['trainerdetails'][0]['image'],
														"timezone": data[0]['timezone'],
														"timezone_str": data[0]['timezone_str'],
														"status": data[0]['status'],
														"day": data[0]['day'],
														"month": data[0]['month'],
														"year": data[0]['year'],
														"date_str": data[0]['date_str'],
														"time_str": data[0]['time_str'],
														"session_end_date": data[0]['session_end_date'].toString(),
													}
													res.send({
														"success": true,
														"message": "Session updated",
														"data": dat
													});
													return false;
												} else {
													res.send({
														"success": false,
														"message": "something went wrong",
														"data": {}
													});
													return false;
												}
											}

										});
									}
								}

							})
						}
					})
				} else {
					dbo.collection('TBL_SESSIONS').updateOne({
						_id: ObjectId(session_id_b)
					}, {
						$set: req.body
					}, function (err, rese) {
						if (err) {
							res.send({
								"success": false,
								"message": "Something went wrong!"
							});
							return false;
						} else {
							var slotObj = {
								trainer_id: ObjectId(req.body.user_id),
								client_id: ObjectId(req.body.client_id),
								slot_id: ObjectId(req.body.slot_id),
								day: req.body.day.toString(),
								time: req.body.time.toString(),
								month: req.body.month.toString(),
								year: req.body.year.toString(),
								created_at: getCurrentTime(),
								updated: getCurrentTime()

							}

							dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
								session_id: ObjectId(session_id_b)
							}, {
								$set: slotObj
							}, function (err, rese) {
								console.log('success')
							})
							if (req.body.user_type == 0) {
								dbo.collection('TBL_SESSIONS').aggregate([{
										$match: {
											"_id": ObjectId(session_id_b)
										}
									},
									{
										$lookup: {
											from: 'TBL_CLIENTS',
											localField: 'client_id',
											foreignField: '_id',
											as: 'client'
										}
									},
									{
										$lookup: {
											from: 'TBL_CLIENT_INFO',
											localField: 'client_id',
											foreignField: 'client_id',
											as: 'client_info'
										}
									},
									{
										"$unwind": "$client_info"
									},
									{
										"$match": {
											"client_info.trainer_id": ObjectId(req.body.user_id)
										}
									},
								]).toArray(function (err, resr) {
									if (err) {
										throw err;
									} else {
										if (resr) {
											console.log(resr)

											var data = JSON.parse(JSON.stringify(resr));
											// console.log(data[0]['clientdetails'])
											console.log(data)
											// return
											var dat = [];
											for (var i = 0; i < data.length; i++) {
												if (data[i]['timezone'] == undefined) {
													data[i]['timezone'] = ''
												}
												if (data[i]['timezone_str'] == undefined) {
													data[i]['timezone_str'] = ''
												}
												if (data[i]['gym_name'] == undefined) {
													data[i]['gym_name'] = ''
												}
												if (data[i]['session_end_date'] == undefined) {
													data[i]['session_end_date'] = ''
												}
												// gym_name: req.body.gym_name,
												dat.push({
													"id": data[i]['_id'],
													"trainer_id": data[i]['trainer_id'],
													"client_id": data[i]['client_id'],
													"user_type": data[i]['user_type'],
													"gym_name": data[i]['gym_name'],
													"utc": data[i]['utc'],
													"time": data[i]['time'],
													"repeat": data[i]['repeat'],
													"location": data[i]['location'],
													"duration": data[i]['duration'],
													"first_name": data[i].client_info.first_name,
													"last_name": data[i].client_info.last_name,
													"image": data[i]['image'],
													"timezone": data[i]['timezone'],
													"timezone_str": data[i]['timezone_str'],
													"status": data[i]['status'],
													"date_str": data[i]['date_str'],
													"time_str": data[i]['time_str'],
													"day": data[i]['day'],
													"month": data[i]['month'],
													"year": data[i]['year'],
													"session_end_date": data[i]['session_end_date'].toString()
												})
											}
											res.send({
												"success": true,
												"message": "Session Updated",
												"data": dat[0]
											});
											return false;
										} else {
											res.send({
												"success": false,
												"message": "something went wrong",
												"data": {}
											});
											return false;
										}
									}

								});
							} else {
								dbo.collection('TBL_SESSIONS').aggregate([{
										$match: {
											_id: ObjectId(session_id_b)
										}
									},
									{
										$lookup: {
											from: 'TBL_TRAINERS',
											localField: 'trainer_id',
											foreignField: '_id',
											as: 'trainer'
										}
									},
									{
										$lookup: {
											from: 'TBL_TRAINER_DETAILS',
											localField: 'trainer_id',
											foreignField: 'user_id',
											as: 'trainerdetails'
										}
									},

								]).toArray(function (err, resr) {
									if (err) {
										throw err;
									} else {
										if (resr) {
											var data = JSON.parse(JSON.stringify(resr));
											var dat = [];
											for (var i = 0; i < data.length; i++) {
												if (data[i]['timezone'] == undefined) {
													data[i]['timezone'] = ''
												}
												if (data[i]['timezone_str'] == undefined) {
													data[i]['timezone_str'] = ''
												}
												if (data[i]['gym_name'] == undefined) {
													data[i]['gym_name'] = ''
												}
												if (data[i]['session_end_date'] == undefined) {
													data[i]['session_end_date'] = ''
												}
												dat.push({
													"id": data[i]['_id'],
													"client_id": data[i]['client_id'],
													"trainer_id": data[i]['trainer_id'],
													"user_type": data[i]['user_type'],
													"gym_name": data[i]['gym_name'],
													"utc": data[i]['utc'],
													"time": data[i]['time'],
													"repeat": data[i]['repeat'],
													"location": data[i]['location'],
													"duration": data[i]['duration'],
													"first_name": data[i]['trainerdetails'][0]['first_name'],
													"last_name": data[i]['trainerdetails'][0]['last_name'],
													"image": data[i]['trainerdetails'][0]['image'],
													"timezone": data[i]['timezone'],
													"timezone_str": data[i]['timezone_str'],
													"status": data[i]['status'],
													"date_str": data[i]['date_str'],
													"time_str": data[i]['time_str'],
													"day": data[i]['day'],
													"month": data[i]['month'],
													"year": data[i]['year'],
													"session_end_date": data[i]['session_end_date'].toString()
												})
											}
											res.send({
												"success": true,
												"message": "Session updated",
												"data": dat[0]
											});
											return false;
										} else {
											res.send({
												"success": false,
												"message": "something went wrong",
												"data": {}
											});
											return false;
										}
									}

								});
							}
						}
					});
				}
				// console.log(resv1.no_of_sessions_week)
				// return false

			} else if (resv1.isBlocked != undefined && resv1.isBlocked == '1') {
				if (req.body.user_type == 0) {
					res.send({
						"success": false,
						"message": "This client is blocked.",
						"data": {}
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "You have been blocked by the Trainer",
						"data": {}
					});
					return false;
				}

			}


		}
	})
	// dbo.collection('TBL_SESSIONS').updateOne({
	// 	_id: ObjectId(session_id_b)
	// }, {
	// 	$set: req.body
	// }, function (err, rese) {
	// 	if (err) {
	// 		res.send({
	// 			"success": false,
	// 			"message": "Something went wrong!"
	// 		});
	// 		return false;
	// 	} else {
	// 		var slotObj = {
	// 			trainer_id: ObjectId(req.body.user_id),
	// 			client_id: ObjectId(req.body.client_id),
	// 			slot_id: ObjectId(req.body.slot_id),
	// 			day: req.body.day.toString(),
	// 			time: req.body.time.toString(),
	// 			month: req.body.month.toString(),
	// 			year: req.body.year.toString(),
	// 			created_at: getCurrentTime(),
	// 			updated: getCurrentTime()

	// 		}

	// 		dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
	// 			session_id: ObjectId(session_id_b)
	// 		}, {
	// 			$set: slotObj
	// 		}, function (err, rese) {
	// 			console.log('success')
	// 		})
	// 		if (req.body.user_type == 0) {
	// 			dbo.collection('TBL_SESSIONS').aggregate([{
	// 					$match: {
	// 						"_id": ObjectId(session_id_b)
	// 					}
	// 				},
	// 				{
	// 					$lookup: {
	// 						from: 'TBL_CLIENTS',
	// 						localField: 'client_id',
	// 						foreignField: '_id',
	// 						as: 'client'
	// 					}
	// 				},
	// 				// {
	// 				// 	$lookup: {
	// 				// 		from: 'TBL_CLIENT_DETAILS',
	// 				// 		localField: 'client_id',
	// 				// 		foreignField: 'user_id',
	// 				// 		as: 'clientdetails'
	// 				// 	}
	// 				// },
	// 			]).toArray(function (err, resr) {
	// 				if (err) {
	// 					throw err;
	// 				} else {
	// 					if (resr) {
	// 						console.log(resr)

	// 						var data = JSON.parse(JSON.stringify(resr));
	// 						// console.log(data[0]['clientdetails'])
	// 						console.log(data)
	// 						// return
	// 						var dat = [];
	// 						for (var i = 0; i < data.length; i++) {
	// 							if (!data[i]['client'] || data[i]['client'][0]['timezone'] == undefined) {
	// 								data[i]['client'][0]['timezone'] = ''
	// 							}
	// 							if (!data[i]['client'] || data[i]['client'][0]['timezone_str'] == undefined) {
	// 								data[i]['client'][0]['timezone_str'] = ''
	// 							}
	// 							if (data[i]['gym_name'] == undefined) {
	// 								data[i]['gym_name'] = ''
	// 							}
	// 							// gym_name: req.body.gym_name,
	// 							dat.push({
	// 								"id": data[i]['_id'],
	// 								"user_id": data[i]['user_id'],
	// 								"client_id": data[i]['client_id'],
	// 								"user_type": data[i]['user_type'],
	// 								"gym_name": data[i]['gym_name'],
	// 								"utc": data[i]['utc'],
	// 								"time": data[i]['time'],
	// 								"repeat": data[i]['repeat'],
	// 								"location": data[i]['location'],
	// 								"duration": data[i]['duration'],
	// 								"first_name": data[i]['first_name'],
	// 								"last_name": data[i]['last_name'],
	// 								"image": data[i]['image'],
	// 								"timezone": data[i]['client'][0]['timezone'],
	// 								"timezone_str": data[i]['client'][0]['timezone_str'],
	// 								"status": data[i]['status'],
	// 								"date_str": data[i]['date_str'],
	// 								"time_str": data[i]['time_str'],
	// 								"day": data[i]['day'],
	// 								"month": data[i]['month'],
	// 								"year": data[i]['year']
	// 							})
	// 						}
	// 						res.send({
	// 							"success": true,
	// 							"message": "Session Updated",
	// 							"data": dat[0]
	// 						});
	// 						return false;
	// 					} else {
	// 						res.send({
	// 							"success": false,
	// 							"message": "something went wrong",
	// 							"data": {}
	// 						});
	// 						return false;
	// 					}
	// 				}

	// 			});
	// 		} else {
	// 			dbo.collection('TBL_SESSIONS').aggregate([{
	// 					$match: {
	// 						_id: ObjectId(session_id_b)
	// 					}
	// 				},
	// 				{
	// 					$lookup: {
	// 						from: 'TBL_TRAINERS',
	// 						localField: 'trainer_id',
	// 						foreignField: '_id',
	// 						as: 'trainer'
	// 					}
	// 				},
	// 				{
	// 					$lookup: {
	// 						from: 'TBL_TRAINER_DETAILS',
	// 						localField: 'trainer_id',
	// 						foreignField: 'user_id',
	// 						as: 'trainerdetails'
	// 					}
	// 				},

	// 			]).toArray(function (err, resr) {
	// 				if (err) {
	// 					throw err;
	// 				} else {
	// 					if (resr) {
	// 						var data = JSON.parse(JSON.stringify(resr));
	// 						var dat = [];
	// 						for (var i = 0; i < data.length; i++) {
	// 							if (data[i]['trainer'][0]['timezone'] == undefined) {
	// 								data[i]['trainer'][0]['timezone'] = ''
	// 							}
	// 							if (data[i]['trainer'][0]['timezone_str'] == undefined) {
	// 								data[i]['trainer'][0]['timezone_str'] = ''
	// 							}
	// 							if (data[i]['gym_name'] == undefined) {
	// 								data[i]['gym_name'] = ''
	// 							}
	// 							dat.push({
	// 								"id": data[i]['_id'],
	// 								"user_id": data[i]['user_id'],
	// 								"trainer_id": data[i]['trainer_id'],
	// 								"user_type": data[i]['user_type'],
	// 								"gym_name": data[i]['gym_name'],
	// 								"utc": data[i]['utc'],
	// 								"time": data[i]['time'],
	// 								"repeat": data[i]['repeat'],
	// 								"location": data[i]['location'],
	// 								"duration": data[i]['duration'],
	// 								"first_name": data[i]['trainerdetails'][0]['first_name'],
	// 								"last_name": data[i]['trainerdetails'][0]['last_name'],
	// 								"image": data[i]['trainerdetails'][0]['image'],
	// 								"timezone": data[i]['trainer'][0]['timezone'],
	// 								"timezone_str": data[i]['trainer'][0]['timezone_str'],
	// 								"status": data[i]['status'],
	// 								"date_str": data[i]['date_str'],
	// 								"time_str": data[i]['time_str'],
	// 								"day": data[i]['day'],
	// 								"month": data[i]['month'],
	// 								"year": data[i]['year']
	// 							})
	// 						}
	// 						res.send({
	// 							"success": true,
	// 							"message": "Session updated",
	// 							"data": dat[0]
	// 						});
	// 						return false;
	// 					} else {
	// 						res.send({
	// 							"success": false,
	// 							"message": "something went wrong",
	// 							"data": {}
	// 						});
	// 						return false;
	// 					}
	// 				}

	// 			});
	// 		}
	// 	}
	// });
}

exports.update_session_stage = async function (req, res) {
	const {
		user_id,
		user_type,
		utc,
		duration,
		location,
		repeat,
		time,
		session_id,
		date_str,
		time_str,
		day,
		month,
		year
	} = req.body;
	let errors = [];
	if (!user_id || !session_id || !utc || !duration || !location || !repeat || !user_type || !date_str || !time_str || !day || !month || !year) {
		res.send({
			"success": false,
			"message": "Please enter all fields",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	var session_id_b = req.body.session_id
	delete req.body.session_id;
	req.body.client_id = ObjectId(req.body.client_id)
	dbo.collection('TBL_CLIENT_INFO').findOne({
		'client_id': ObjectId(req.body.client_id),
		'trainer_id': ObjectId(req.body.user_id)
	}, function (err, resv1) {
		if (err) {
			throw err;
		} else {
			if (!resv1.isBlocked || resv1.isBlocked == '0') {
				var Date_month = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
				var week_month = getWeekNumber(new Date(Date_month))
				req.body.week_month = week_month[1]
				if (resv1.payment == '2') {
					dbo.collection("TBL_SESSIONS").find({
						"_id": ObjectId(session_id_b)
					}).toArray(async function (err, same_week) {
						var same_week = JSON.parse(JSON.stringify(same_week));
						if (same_week[0].week_month.toString() == week_month[1].toString()) {
							var bypass = '1';
						} else {
							var bypass = '0';
						}
						dbo.collection("TBL_SESSIONS").find({
							trainer_id: ObjectId(req.body.user_id),
							client_id: ObjectId(req.body.client_id),
							week_month: week_month[1],
							status: {
								$in: [0, 1, 2, 6]
							},
						}).toArray(async function (err, result_count) {
							var data_count = JSON.parse(JSON.stringify(result_count));
							console.log(data_count.length)
							if (!req.body.force) {
								var force = '0'
							} else {
								var force = req.body.force
							}

							if (resv1.no_of_sessions_week.toString() <= data_count.length.toString() && bypass == '0') {
								if (req.body.user_type == 0) {
									res.send({
										"success": false,
										"message": "" + resv1.first_name + " " + resv1.last_name + " has already scheduled or exhausted all the sessions available per week. Would you like to proceed ?",
										"error_status": "1",
										"data": {}
									});
								} else {
									res.send({
										"success": false,
										"message": "You have already scheduled or exhausted all the sessions available per week. Please contact your trainer.",
										"error_status": "1",
										"data": {}
									});
								}

								return false;
							} else {
								if (req.body.reschedule_utc && req.body.reschedule_utc != '' && req.body.reschedule_all && req.body.reschedule_all != '') {


									dbo.collection("TBL_SESSIONS").find({
										"_id": ObjectId(session_id_b)

									}).toArray(async function (err, result_count) {
										if (req.body.user_type == 0) {
											var sessionObj = {
												trainer_id: ObjectId(req.body.user_id),
												client_id: ObjectId(req.body.client_id),
												utc: req.body.utc.toString(),
												duration: req.body.duration,
												location: req.body.location,
												repeat: req.body.repeat,
												gym_name: req.body.gym_name,
												// time: req.body.time_str,
												user_type: req.body.user_type,
												status: 2,
												day: req.body.day,
												month: req.body.month,
												year: req.body.year,
												date_str: req.body.date_str,
												time_str: req.body.time_str,
												timezone_str: req.body.timezone_str,
												time: req.body.time,
												created_at: getCurrentTime(),
												updated: getCurrentTime()
											};
											var slotObj = {
												trainer_id: ObjectId(req.body.user_id),
												client_id: ObjectId(req.body.client_id),
												slot_id: ObjectId(req.body.slot_id),
												day: req.body.day.toString(),
												time: req.body.time.toString(),
												month: req.body.month.toString(),
												year: req.body.year.toString(),
												created_at: getCurrentTime(),
												updated: getCurrentTime(),
												status: '1',
											}
										} else {
											var sessionObj = {
												client_id: ObjectId(req.body.client_id),
												trainer_id: ObjectId(req.body.user_id),
												utc: req.body.utc.toString(),
												duration: req.body.duration,
												location: req.body.location,
												repeat: req.body.repeat,
												gym_name: req.body.gym_name,
												// time: req.body.time,
												user_type: req.body.user_type,
												status: 1,
												day: req.body.day,
												month: req.body.month,
												year: req.body.year,
												date_str: req.body.date_str,
												time_str: req.body.time_str,
												time: req.body.time,
												timezone_str: req.body.timezone_str,
												created_at: getCurrentTime(),
												updated: getCurrentTime()
											};
											var slotObj = {
												trainer_id: ObjectId(req.body.user_id),
												client_id: ObjectId(req.body.client_id),
												slot_id: ObjectId(req.body.slot_id),
												day: req.body.day.toString(),
												time: req.body.time.toString(),
												month: req.body.month.toString(),
												year: req.body.year.toString(),
												created_at: getCurrentTime(),
												updated: getCurrentTime(),
												status: '0',
											}
										}
										if (result_count[0].repeat == '1') {
											if (req.body.reschedule_all == 0) {

												var session_date_time = Number(result_count[0].utc)
												var end_date_time = new Date(req.body.reschedule_utc * 1000)
												end_date_time.setDate(end_date_time.getDate() - 7);

												var start_date_time = new Date(req.body.reschedule_utc * 1000)
												start_date_time.setDate(start_date_time.getDate() + 7);

												var seconds = end_date_time.getTime() / 1000

												var seconds_start = start_date_time.getTime() / 1000

												var start_date = start_date_time.getDate()
												var start_year = start_date_time.getFullYear()
												var start_month = start_date_time.getMonth() + 1

												if (start_date < 10) {
													start_date = '0' + start_date
												}
												if (start_month < 10) {
													start_month = '0' + start_month
												}


												if (Number(seconds) < Number(session_date_time)) {
													var Date_month = new Date(req.body.reschedule_utc * 1000);
													var week_month = getWeekNumber(new Date(Date_month))

													var start_date_time = new Date(req.body.reschedule_utc * 1000)
													start_date_time.setDate(start_date_time.getDate() + 7);
													var seconds_start = start_date_time.getTime() / 1000

													var utc = new Date(result_count[0].utc * 1000)
													utc.setDate(utc.getDate() + 7);
													sessionObj.utc = utc.getTime() / 1000
													console.log('THEREEEEEE22 44')

													var start_date_time_reschedule = new Date(req.body.reschedule_utc * 1000)
													// start_date_time_reschedule.setDate(start_date_time_reschedule.getDate());
													var seconds_start_reschedule = start_date_time_reschedule.getTime() / 1000

													var start_date = start_date_time_reschedule.getDate()
													var start_year = start_date_time_reschedule.getFullYear()
													var start_month = start_date_time_reschedule.getMonth() + 1

													// logic here
													if (req.body.user_type == 0) {
														var sessionObj1 = {
															trainer_id: ObjectId(result_count[0].trainer_id),
															client_id: ObjectId(result_count[0].client_id),
															utc: seconds_start_reschedule.toString(),
															duration: result_count[0].duration,
															location: result_count[0].location,
															repeat: '0',
															gym_name: result_count[0].gym_name,
															user_type: result_count[0].user_type,
															status: 2,
															day: start_date.toString(),
															month: start_month.toString(),
															year: start_year.toString(),
															date_str: start_month + '.' + start_date + '.' + start_year,
															time_str: result_count[0].time_str,
															timezone_str: result_count[0].timezone_str,
															time: result_count[0].time,
															created_at: getCurrentTime(),
															updated: getCurrentTime(),
															week_month: week_month[1],
															session_end_date: result_count[0].session_end_date
														};
													}
													else{
														var sessionObj1 = {
															trainer_id: ObjectId(result_count[0].trainer_id),
															client_id: ObjectId(result_count[0].client_id),
															utc: seconds_start_reschedule.toString(),
															duration: result_count[0].duration,
															location: result_count[0].location,
															repeat: '0',
															gym_name: result_count[0].gym_name,
															user_type: result_count[0].user_type,
															status: result_count[0].status,
															day: start_date.toString(),
															month: start_month.toString(),
															year: start_year.toString(),
															date_str: start_month + '.' + start_date + '.' + start_year,
															time_str: result_count[0].time_str,
															timezone_str: result_count[0].timezone_str,
															time: result_count[0].time,
															created_at: getCurrentTime(),
															updated: getCurrentTime(),
															week_month: week_month[1],
															session_end_date: result_count[0].session_end_date
														};
													}
													dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {

													})


													// sessionObj.session_end_date = result_count[0].session_end_date

													req.body.utc = utc.getTime() / 1000
													req.body.utc = req.body.utc.toString()
													req.body.session_end_date = result_count[0].session_end_date
													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: req.body
													}, function (err, rese) {
														if (err) {
															throw err;
														} else {
															var slotObj = {
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																slot_id: ObjectId(req.body.slot_id),
																day: req.body.day.toString(),
																time: req.body.time.toString(),
																month: req.body.month.toString(),
																year: req.body.year.toString(),
																created_at: getCurrentTime(),
																updated: getCurrentTime()

															}

															dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
																session_id: ObjectId(session_id_b)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})

															dbo.collection("TBL_SESSIONS").find({
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																status: {
																	$in: [0, 1, 2]
																},
																utc: {
																	$gt: getCurrentTime().toString()
																}
															}).sort({
																utc: 1
															}).toArray(async function (err, result_count) {
																console.log(result_count)
																// console.log(resv1)
																var total_no_of_sessions = Number(resv1.no_of_sessions)
																var total_sessions = result_count
																var counter = -1
																var arr_sess = []

																var loopCount = total_sessions.length
																var onlyOne = false
																var ignore_no_repeat = false
																var j = 0

																var repeat_W_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '1'
																	return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																});
																var repeat_M_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '2'
																	return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																});
																for (var f = 0; f < loopCount; f++) {
																	if (ignore_no_repeat == false) {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})

																		if (loopCount == f + 1) {
																			console.log('1st Loop Fin')
																			ignore_no_repeat = true
																			f = -1
																			if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																				break;
																			}
																		}
																		continue;
																	}
																	console.log(arr_sess)
																	if (arr_sess.length >= total_no_of_sessions) {
																		console.log('Loop completed')
																		break;
																	}

																	if (total_sessions[f].repeat == '0') {
																		// console.log('continue repeat')
																		// continue;
																		// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																	} else if (total_sessions[f].repeat == '1') { //weekly

																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	} else if (total_sessions[f].repeat == '2') { //Monthly
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	}
																	// counter = arr_sess.length
																	if (loopCount == f + 1) {
																		f = -1
																		console.log('Loop Repeating Now')
																		continue;
																	}

																}

																var result = arr_sess.reduce(function (r, a) {
																	if (a.session_type != '0') {
																		r[a.session_id] = r[a.session_id] || [];
																		r[a.session_id].push(a);

																	}
																	return r;
																}, {});

																var final_arr = []
																for (key in result) {
																	if (result.hasOwnProperty(key)) {
																		var value = result[key];
																		// console.log(value.length)
																		// console.log(value[0].start_date)


																		if (value[0].session_type == '1') {
																			// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var week = (value.length - 1)
																			date.setDate(date.getDate() + week * 7);
																			var end_date = date.getTime() / 1000;
																		} else if (value[0].session_type == '2') {
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var months = (value.length - 1)
																			var d = date.getDate();
																			date.setMonth(date.getMonth() + +months);
																			if (date.getDate() != d) {
																				date.setDate(0);
																			}
																			var end_date = date.getTime() / 1000;
																		}
																		final_arr.push({
																			'session_id': value[0].session_id,
																			'end_date': end_date,
																			'type': value[0].session_type,
																			'start_date': value[0].start_date
																		})
																	}
																}
																let promise = Promise.resolve();
																const posts = final_arr;
																posts.forEach(post => {
																	promise = promise.then(() => {
																		var dataIn = post
																		// for (var p = 0; p < final_arr.length; p++) {
																		var slotObj = {
																			'session_end_date': dataIn.end_date
																		}
																		dbo.collection("TBL_SESSIONS").updateOne({
																			_id: ObjectId(dataIn.session_id)
																		}, {
																			$set: slotObj
																		}, function (err, rese) {
																			console.log('success')
																		})
																		// }
																	})
																})

																promise.then(() => {
																	setTimeout(function () {
																		response()
																	}, 150);

																})

																// console.log(final_arr)
																function response() {
																	if (req.body.user_type == 0) {
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'client_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENT_INFO',
																					localField: 'client_id',
																					foreignField: 'client_id',
																					as: 'client_info'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'user_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},
																			{
																				"$unwind": "$client_info"
																			},
																			{
																				"$match": {
																					"client_info.trainer_id": ObjectId(req.body.user_id)
																				}
																			},
																			// {$group: {
																			//      _id: "$_id",
																			//      client_info: {$push: "$client_info"}
																			//  }},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"client_id": data[0]['client_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0].client_info.first_name,
																						"last_name": data[0].client_info.last_name,
																						"image": data[0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),


																					}
																					res.send({
																						"success": true,
																						"message": "Session updated succesfully!",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	} else {
																		// sendNotification(req.body.trainer_id,resv.insertedId)
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},
																			// {
																			// 	$lookup: {
																			// 		from: 'TBL_CLIENT_DETAILS',
																			// 		localField: 'user_id',
																			// 		foreignField: 'user_id',
																			// 		as: 'clientdetails'
																			// 	}
																			// },
																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'trainer_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'trainer_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"client_id": data[0]['client_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0]['trainerdetails'][0]['first_name'],
																						"last_name": data[0]['trainerdetails'][0]['last_name'],
																						"image": data[0]['trainerdetails'][0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),
																					}
																					res.send({
																						"success": true,
																						"message": "Session updated",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	}
																}

															})
														}
													})

													// }
													// });


												} else {

													var Date_month = new Date(req.body.reschedule_utc * 1000);
													var week_month = getWeekNumber(new Date(Date_month))

													var start_date_time = new Date(req.body.reschedule_utc * 1000)
													start_date_time.setDate(start_date_time.getDate() + 7);
													var seconds_start = start_date_time.getTime() / 1000

													var utc = new Date(req.body.utc * 1000)
													// utc.setDate(utc.getDate() + 7);
													sessionObj.utc = utc.getTime() / 1000
													sessionObj.utc = sessionObj.utc.toString()
													sessionObj.repeat = '0'
													console.log('THEREEEEEE TEST ONE THIS ONLY')
													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: {
															'session_end_date': Number(seconds),
															'ignore': 1
														}
													}, function (err, rese) {
														if (err) {
															res.send({
																"success": false,
																"message": "Something went wrong!",
																"data": {}
															});
															return false;
														} else {
															console.log('logic here 11--------------------------------------------')
															// logic here
															if (req.body.user_type == 0) {
																var sessionObj1 = {
																	trainer_id: ObjectId(result_count[0].trainer_id),
																	client_id: ObjectId(result_count[0].client_id),
																	utc: seconds_start.toString(),
																	duration: result_count[0].duration,
																	location: result_count[0].location,
																	repeat: result_count[0].repeat,
																	gym_name: result_count[0].gym_name,
																	user_type: result_count[0].user_type,
																	status: 2,
																	day: start_date.toString(),
																	month: start_month.toString(),
																	year: start_year.toString(),
																	date_str: start_month + '.' + start_date + '.' + start_year,
																	time_str: result_count[0].time_str,
																	timezone_str: result_count[0].timezone_str,
																	time: result_count[0].time,
																	created_at: getCurrentTime(),
																	updated: getCurrentTime(),
																	week_month: week_month[1],
																	session_end_date: result_count[0].session_end_date
																};
															}
															else{
																var sessionObj1 = {
																	trainer_id: ObjectId(result_count[0].trainer_id),
																	client_id: ObjectId(result_count[0].client_id),
																	utc: seconds_start.toString(),
																	duration: result_count[0].duration,
																	location: result_count[0].location,
																	repeat: result_count[0].repeat,
																	gym_name: result_count[0].gym_name,
																	user_type: result_count[0].user_type,
																	status: result_count[0].status,
																	day: start_date.toString(),
																	month: start_month.toString(),
																	year: start_year.toString(),
																	date_str: start_month + '.' + start_date + '.' + start_year,
																	time_str: result_count[0].time_str,
																	timezone_str: result_count[0].timezone_str,
																	time: result_count[0].time,
																	created_at: getCurrentTime(),
																	updated: getCurrentTime(),
																	week_month: week_month[1],
																	session_end_date: result_count[0].session_end_date
																};
															}
															dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {
																sessionObj.session_end_date = result_count[0].session_end_date
																dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
																	if (err) {
																		throw err;
																	} else {
																		slotObj.session_id = ObjectId(resv.insertedId);
																		dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
																			console.log('success')
																		})
																		dbo.collection("TBL_SESSIONS").find({
																			trainer_id: ObjectId(req.body.user_id),
																			client_id: ObjectId(req.body.client_id),
																			status: {
																				$in: [0, 1, 2]
																			},
																			utc: {
																				$gt: getCurrentTime().toString()
																			},
																			// ignore: {
																			// 	$ne: 1
																			// }
																		}).sort({
																			utc: 1
																		}).toArray(async function (err, result_count) {
																			console.log(result_count)
																			// console.log(resv1)
																			var total_no_of_sessions = Number(resv1.no_of_sessions)
																			var total_sessions = result_count
																			var counter = -1
																			var arr_sess = []
																			var arr_sess_ignore = []

																			var loopCount = total_sessions.length
																			var onlyOne = false
																			var ignore_no_repeat = false
																			var j = 0

																			var repeat_W_isPresent = total_sessions.some(function (el) {
																				// return el.repeat === '1'
																				return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																			});
																			var repeat_M_isPresent = total_sessions.some(function (el) {
																				// return el.repeat === '2'
																				return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																			});
																			for (var f = 0; f < loopCount; f++) {
																				if (!total_sessions[f].ignore) {
																					var is_ignore = 0;
																				} else {
																					var is_ignore = total_sessions[f].ignore;
																				}
																				if (!total_sessions[f].session_end_date) {
																					var is_session_end_date = '';
																				} else {
																					var is_session_end_date = total_sessions[f].session_end_date;
																				}
																				if (is_session_end_date != '') {
																					var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																					var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																				} else {
																					var weeks_btw = ''
																					var months_btw = ''
																				}

																				if (ignore_no_repeat == false) {
																					if (is_ignore == 1) {
																						arr_sess_ignore.push({
																							'session_id': total_sessions[f]._id,
																							"start_date": total_sessions[f].utc,
																							"session_type": total_sessions[f].repeat,
																							"is_session_end_date": is_session_end_date,
																							"weeks_btw": weeks_btw,
																							"months_btw": months_btw,
																						})
																					} else {
																						arr_sess.push({
																							"session_id": total_sessions[f]._id,
																							"start_date": total_sessions[f].utc,
																							"session_type": total_sessions[f].repeat,
																							"is_session_end_date": is_session_end_date,
																							"weeks_btw": weeks_btw,
																							"months_btw": months_btw,
																						})
																					}


																					if (loopCount == f + 1) {
																						console.log('1st Loop Fin')
																						ignore_no_repeat = true
																						f = -1

																						if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																							break;
																						}
																					}
																					continue;
																				}
																				// console.log(arr_sess)
																				if (arr_sess.length >= total_no_of_sessions) {
																					console.log('Loop completed')
																					break;
																				}

																				if (total_sessions[f].repeat == '0') {
																					// console.log('continue repeat')
																					// continue;
																					// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																				} else if (total_sessions[f].repeat == '1') { //weekly
																					if (is_ignore == 1) {
																						arr_sess_ignore.push({
																							'session_id': total_sessions[f]._id,
																							"start_date": total_sessions[f].utc,
																							"session_type": total_sessions[f].repeat,
																							"is_session_end_date": is_session_end_date,
																							"weeks_btw": weeks_btw,
																							"months_btw": months_btw,
																						})
																					} else {
																						arr_sess.push({
																							'session_id': total_sessions[f]._id,
																							"start_date": total_sessions[f].utc,
																							"session_type": total_sessions[f].repeat,
																							"is_session_end_date": is_session_end_date,
																							"weeks_btw": weeks_btw,
																							"months_btw": months_btw,
																						})
																					}

																				} else if (total_sessions[f].repeat == '2') { //Monthly
																					if (is_ignore == 1) {
																						arr_sess_ignore.push({
																							'session_id': total_sessions[f]._id,
																							"start_date": total_sessions[f].utc,
																							"session_type": total_sessions[f].repeat,
																							"is_session_end_date": is_session_end_date,
																							"weeks_btw": weeks_btw,
																							"months_btw": months_btw,
																						})
																					} else {
																						arr_sess.push({
																							'session_id': total_sessions[f]._id,
																							"start_date": total_sessions[f].utc,
																							"session_type": total_sessions[f].repeat,
																							"is_session_end_date": is_session_end_date,
																							"weeks_btw": weeks_btw,
																							"months_btw": months_btw,
																						})
																					}

																				}
																				// counter = arr_sess.length
																				if (loopCount == f + 1) {
																					// if (arr_sess.length < total_no_of_sessions ) {
																					f = -1
																					// if (loopCount == 1) {
																					// 	f--
																					// }
																					console.log('Loop Repeating Now')
																					continue;
																					// }
																				}

																			}

																			// NEW WEEK LOGIC
																			var result_final_ignore = [];
																			var total_sessions_in_ignore = 0
																			var total_sessions_in_ignore_month = 0

																			var seen = Object.create(null)
																			result_final_ignore = arr_sess_ignore.filter(o => {
																				var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																				if (!seen[key]) {
																					seen[key] = true;
																					return true;
																				}
																			});
																			for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																				if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																					result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																				}
																				if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																					result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																				}
																				total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																				result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																				total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																				result_final_ignore[loop_c].total = total_sessions_in_ignore
																			}

																			var result = arr_sess.reduce(function (r, a) {
																				if (a.session_type != '0') {
																					r[a.session_id] = r[a.session_id] || [];
																					r[a.session_id].push(a);

																				}
																				return r;
																			}, {});

																			var final_arr = []
																			for (key in result) {
																				if (result.hasOwnProperty(key)) {
																					var value = result[key];
																					console.log(value.length)
																					console.log(value[0].start_date)


																					if (value[0].session_type == '1') {
																						// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																						if (!result_final_ignore || result_final_ignore.length == 0) {
																							weeks_to_ignore = 0
																						} else {
																							var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																							if (isNaN(weeks_to_ignore)) {
																								weeks_to_ignore = 0
																							}
																						}

																						var date = new Date(Number(value[0].start_date) * 1000)
																						var week = (value.length - 1)
																						// date.setDate(date.getDate() + week * 7);
																						date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																						var end_date = date.getTime() / 1000;
																						if (Number(end_date) < Number(value[0].start_date)) {
																							var end_date = Number(value[0].start_date)
																						}
																					} else if (value[0].session_type == '2') {
																						if (!result_final_ignore || result_final_ignore.length == 0) {
																							weeks_to_ignore = 0
																						} else {
																							var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																							// weeks_to_ignore = weeks_to_ignore - 1
																							if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																								weeks_to_ignore = 0
																							}
																						}

																						var date = new Date(Number(value[0].start_date) * 1000)
																						var months = ((value.length - 1) - weeks_to_ignore)
																						var d = date.getDate();
																						date.setMonth(date.getMonth() + +months);
																						if (date.getDate() != d) {
																							date.setDate(0);
																						}
																						var end_date = date.getTime() / 1000;
																						// var date = new Date(Number(value[0].start_date) * 1000)
																						// var months = (value.length - 1)
																						// var d = date.getDate();
																						// date.setMonth(date.getMonth() + +months);
																						// if (date.getDate() != d) {
																						// 	date.setDate(0);
																						// }
																						// var end_date = date.getTime() / 1000;
																					}
																					final_arr.push({
																						'session_id': value[0].session_id,
																						'end_date': end_date,
																						'type': value[0].session_type,
																						'start_date': value[0].start_date
																					})
																				}
																			}
																			let promise = Promise.resolve();
																			const posts = final_arr;
																			posts.forEach(post => {
																				promise = promise.then(() => {
																					var dataIn = post
																					// for (var p = 0; p < final_arr.length; p++) {
																					var slotObj = {
																						'session_end_date': dataIn.end_date
																					}
																					dbo.collection("TBL_SESSIONS").updateOne({
																						_id: ObjectId(dataIn.session_id)
																					}, {
																						$set: slotObj
																					}, function (err, rese) {
																						console.log('success')
																					})
																					// }
																				})
																			})

																			promise.then(() => {
																				setTimeout(function () {
																					response()
																				}, 150);

																			})

																			// console.log(final_arr)
																			function response() {
																				if (req.body.user_type == 0) {
																					dbo.collection('TBL_SESSIONS').aggregate([{
																							$match: {
																								_id: ObjectId(resv.insertedId)
																							}
																						},
																						{
																							$lookup: {
																								from: 'TBL_CLIENTS',
																								localField: 'client_id',
																								foreignField: '_id',
																								as: 'client'
																							}
																						},
																						{
																							$lookup: {
																								from: 'TBL_CLIENT_INFO',
																								localField: 'client_id',
																								foreignField: 'client_id',
																								as: 'client_info'
																							}
																						},
																						{
																							$lookup: {
																								from: 'TBL_TRAINERS',
																								localField: 'user_id',
																								foreignField: '_id',
																								as: 'trainer'
																							}
																						},
																						{
																							$lookup: {
																								from: 'TBL_TRAINER_DETAILS',
																								localField: 'user_id',
																								foreignField: 'user_id',
																								as: 'trainerdetails'
																							}
																						},
																						{
																							"$unwind": "$client_info"
																						},
																						{
																							"$match": {
																								"client_info.trainer_id": ObjectId(req.body.user_id)
																							}
																						},

																					]).toArray(function (err, resr) {
																						if (err) {
																							throw err;
																						} else {
																							if (resr) {
																								var data = JSON.parse(JSON.stringify(resr));
																								if (data[0]['client'][0]['timezone'] == undefined) {
																									data[0]['client'][0]['timezone'] = ''
																								}
																								if (data[0]['client'][0]['timezone_str'] == undefined) {
																									data[0]['client'][0]['timezone_str'] = ''
																								}
																								if (data[0]['gym_name'] == undefined) {
																									data[0]['gym_name'] = ''
																								}
																								if (data[0]['session_end_date'] == undefined) {
																									data[0]['session_end_date'] = ''
																								}
																								dat = {
																									"id": data[0]['_id'],
																									"trainer_id": data[0]['trainer_id'],
																									"client_id": data[0]['client_id'],
																									"user_type": data[0]['user_type'],
																									"utc": data[0]['utc'],
																									"time": data[0]['time'],
																									"repeat": data[0]['repeat'],
																									"location": data[0]['location'],
																									"duration": data[0]['duration'],
																									"gym_name": data[0]['gym_name'],
																									"first_name": data[0].client_info.first_name,
																									"last_name": data[0].client_info.last_name,
																									"image": data[0]['image'],
																									"timezone": data[0]['timezone'],
																									"timezone_str": data[0]['timezone_str'],
																									"status": data[0]['status'],
																									"day": data[0]['day'],
																									"month": data[0]['month'],
																									"year": data[0]['year'],
																									"date_str": data[0]['date_str'],
																									"time_str": data[0]['time_str'],
																									"session_end_date": data[0]['session_end_date'].toString(),


																								}
																								res.send({
																									"success": true,
																									"message": "Session created succesfully!",
																									"data": dat
																								});
																								return false;
																							} else {
																								res.send({
																									"success": false,
																									"message": "something went wrong",
																									"data": {}
																								});
																								return false;
																							}
																						}

																					});
																				} else {
																					dbo.collection('TBL_SESSIONS').aggregate([{
																							$match: {
																								_id: ObjectId(resv.insertedId)
																							}
																						},
																						{
																							$lookup: {
																								from: 'TBL_CLIENTS',
																								localField: 'user_id',
																								foreignField: '_id',
																								as: 'client'
																							}
																						},

																						{
																							$lookup: {
																								from: 'TBL_TRAINERS',
																								localField: 'trainer_id',
																								foreignField: '_id',
																								as: 'trainer'
																							}
																						},
																						{
																							$lookup: {
																								from: 'TBL_TRAINER_DETAILS',
																								localField: 'trainer_id',
																								foreignField: 'user_id',
																								as: 'trainerdetails'
																							}
																						},

																					]).toArray(function (err, resr) {
																						if (err) {
																							throw err;
																						} else {
																							if (resr) {
																								var data = JSON.parse(JSON.stringify(resr));
																								// console.log(data[0]['clientdetails'])
																								// console.log(data)
																								if (data[0]['trainer'][0]['timezone'] == undefined) {
																									data[0]['trainer'][0]['timezone'] = ''
																								}
																								if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																									data[0]['trainer'][0]['timezone_str'] = ''
																								}
																								if (data[0]['gym_name'] == undefined) {
																									data[0]['gym_name'] = ''
																								}
																								if (data[0]['session_end_date'] == undefined) {
																									data[0]['session_end_date'] = ''
																								}
																								dat = {
																									"id": data[0]['_id'],
																									"client_id": data[0]['client_id'],
																									"trainer_id": data[0]['trainer_id'],
																									"user_type": data[0]['user_type'],
																									"utc": data[0]['utc'],
																									"time": data[0]['time'],
																									"repeat": data[0]['repeat'],
																									"location": data[0]['location'],
																									"duration": data[0]['duration'],
																									"gym_name": data[0]['gym_name'],
																									"first_name": data[0]['trainerdetails'][0]['first_name'],
																									"last_name": data[0]['trainerdetails'][0]['last_name'],
																									"image": data[0]['trainerdetails'][0]['image'],
																									"timezone": data[0]['timezone'],
																									"timezone_str": data[0]['timezone_str'],
																									"status": data[0]['status'],
																									"day": data[0]['day'],
																									"month": data[0]['month'],
																									"year": data[0]['year'],
																									"date_str": data[0]['date_str'],
																									"time_str": data[0]['time_str'],
																									"session_end_date": data[0]['session_end_date'].toString(),
																								}
																								res.send({
																									"success": true,
																									"message": "Session created",
																									"data": dat
																								});
																								return false;
																							} else {
																								res.send({
																									"success": false,
																									"message": "something went wrong",
																									"data": {}
																								});
																								return false;
																							}
																						}

																					});
																				}
																			}

																		})
																	}
																})
															})


														}
													});


												}
											} else {
												// console.log(sessionObj)
												// return
												var Date_month = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
												var week_month = getWeekNumber(new Date(Date_month))
												sessionObj.week_month = week_month[1]

												var session_date_time = Number(result_count[0].utc)

												var end_date_time = new Date(req.body.reschedule_utc * 1000)
												end_date_time.setDate(end_date_time.getDate() - 7);

												var seconds = end_date_time.getTime() / 1000

												// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
												// var week_month = getWeekNumber(new Date(Date_month))
												console.log('end_date_time ' + end_date_time)
												console.log('session_date_time ' + session_date_time)

												if (Number(seconds) < Number(session_date_time)) {
													console.log('HEREEEEEEE TEST ONE')

													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: req.body
													}, function (err, rese) {
														if (err) {
															throw err;
														} else {
															var slotObj = {
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																slot_id: ObjectId(req.body.slot_id),
																day: req.body.day.toString(),
																time: req.body.time.toString(),
																month: req.body.month.toString(),
																year: req.body.year.toString(),
																created_at: getCurrentTime(),
																updated: getCurrentTime()

															}

															dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
																session_id: ObjectId(session_id_b)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})

															dbo.collection("TBL_SESSIONS").find({
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																status: {
																	$in: [0, 1, 2]
																},
																utc: {
																	$gt: getCurrentTime().toString()
																}
															}).sort({
																utc: 1
															}).toArray(async function (err, result_count) {
																console.log(result_count)
																// console.log(resv1)
																var total_no_of_sessions = Number(resv1.no_of_sessions)
																var total_sessions = result_count
																var counter = -1
																var arr_sess = []

																var loopCount = total_sessions.length
																var onlyOne = false
																var ignore_no_repeat = false
																var j = 0

																var repeat_W_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '1'
																	return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																});
																var repeat_M_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '2'
																	return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																});
																for (var f = 0; f < loopCount; f++) {
																	if (ignore_no_repeat == false) {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})

																		if (loopCount == f + 1) {
																			console.log('1st Loop Fin')
																			ignore_no_repeat = true
																			f = -1
																			if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																				break;
																			}
																		}
																		continue;
																	}
																	console.log(arr_sess)
																	if (arr_sess.length >= total_no_of_sessions) {
																		console.log('Loop completed')
																		break;
																	}

																	if (total_sessions[f].repeat == '0') {
																		// console.log('continue repeat')
																		// continue;
																		// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																	} else if (total_sessions[f].repeat == '1') { //weekly

																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	} else if (total_sessions[f].repeat == '2') { //Monthly
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	}
																	// counter = arr_sess.length
																	if (loopCount == f + 1) {
																		f = -1
																		console.log('Loop Repeating Now')
																		continue;
																	}

																}

																var result = arr_sess.reduce(function (r, a) {
																	if (a.session_type != '0') {
																		r[a.session_id] = r[a.session_id] || [];
																		r[a.session_id].push(a);

																	}
																	return r;
																}, {});

																var final_arr = []
																for (key in result) {
																	if (result.hasOwnProperty(key)) {
																		var value = result[key];
																		console.log(value.length)
																		console.log(value[0].start_date)


																		if (value[0].session_type == '1') {
																			// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var week = (value.length - 1)
																			date.setDate(date.getDate() + week * 7);
																			var end_date = date.getTime() / 1000;
																		} else if (value[0].session_type == '2') {
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var months = (value.length - 1)
																			var d = date.getDate();
																			date.setMonth(date.getMonth() + +months);
																			if (date.getDate() != d) {
																				date.setDate(0);
																			}
																			var end_date = date.getTime() / 1000;
																		}
																		final_arr.push({
																			'session_id': value[0].session_id,
																			'end_date': end_date,
																			'type': value[0].session_type,
																			'start_date': value[0].start_date
																		})
																	}
																}
																let promise = Promise.resolve();
																const posts = final_arr;
																posts.forEach(post => {
																	promise = promise.then(() => {
																		var dataIn = post
																		// for (var p = 0; p < final_arr.length; p++) {
																		var slotObj = {
																			'session_end_date': dataIn.end_date
																		}
																		dbo.collection("TBL_SESSIONS").updateOne({
																			_id: ObjectId(dataIn.session_id)
																		}, {
																			$set: slotObj
																		}, function (err, rese) {
																			console.log('success')
																		})
																		// }
																	})
																})

																promise.then(() => {
																	setTimeout(function () {
																		response()
																	}, 150);

																})

																// console.log(final_arr)
																function response() {
																	if (req.body.user_type == 0) {
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'client_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENT_INFO',
																					localField: 'client_id',
																					foreignField: 'client_id',
																					as: 'client_info'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'user_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},
																			{
																				"$unwind": "$client_info"
																			},
																			{
																				"$match": {
																					"client_info.trainer_id": ObjectId(req.body.user_id)
																				}
																			},
																			// {$group: {
																			//      _id: "$_id",
																			//      client_info: {$push: "$client_info"}
																			//  }},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"client_id": data[0]['client_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0].client_info.first_name,
																						"last_name": data[0].client_info.last_name,
																						"image": data[0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),


																					}
																					res.send({
																						"success": true,
																						"message": "Session updated succesfully!",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	} else {
																		// sendNotification(req.body.trainer_id,resv.insertedId)
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},
																			// {
																			// 	$lookup: {
																			// 		from: 'TBL_CLIENT_DETAILS',
																			// 		localField: 'user_id',
																			// 		foreignField: 'user_id',
																			// 		as: 'clientdetails'
																			// 	}
																			// },
																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'trainer_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'trainer_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"client_id": data[0]['client_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0]['trainerdetails'][0]['first_name'],
																						"last_name": data[0]['trainerdetails'][0]['last_name'],
																						"image": data[0]['trainerdetails'][0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),
																					}
																					res.send({
																						"success": true,
																						"message": "Session updated",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	}
																}

															})
														}
													})
												} else {
													console.log('THEREEEEEE')
													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: {
															'session_end_date': Number(seconds),
															'ignore': 1
														}
													}, function (err, rese) {
														if (err) {
															res.send({
																"success": false,
																"message": "Something went wrong!",
																"data": {}
															});
															return false;
														} else {
															// logic here

															dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
																if (err) {
																	throw err;
																} else {
																	slotObj.session_id = ObjectId(resv.insertedId);
																	dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
																		console.log('success')
																	})
																	dbo.collection("TBL_SESSIONS").find({
																		trainer_id: ObjectId(req.body.user_id),
																		client_id: ObjectId(req.body.client_id),
																		status: {
																			$in: [0, 1, 2]
																		},
																		utc: {
																			$gt: getCurrentTime().toString()
																		},
																		// ignore: {
																		// 	$ne: 1
																		// }
																	}).sort({
																		utc: 1
																	}).toArray(async function (err, result_count) {
																		console.log(result_count)
																		// console.log(resv1)
																		var total_no_of_sessions = Number(resv1.no_of_sessions)
																		var total_sessions = result_count
																		var counter = -1
																		var arr_sess = []
																		var arr_sess_ignore = []

																		var loopCount = total_sessions.length
																		var onlyOne = false
																		var ignore_no_repeat = false
																		var j = 0

																		var repeat_W_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '1'
																			return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																		});
																		var repeat_M_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '2'
																			return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																		});
																		for (var f = 0; f < loopCount; f++) {
																			if (!total_sessions[f].ignore) {
																				var is_ignore = 0;
																			} else {
																				var is_ignore = total_sessions[f].ignore;
																			}
																			if (!total_sessions[f].session_end_date) {
																				var is_session_end_date = '';
																			} else {
																				var is_session_end_date = total_sessions[f].session_end_date;
																			}
																			if (is_session_end_date != '') {
																				var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																				var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																			} else {
																				var weeks_btw = ''
																				var months_btw = ''
																			}

																			if (ignore_no_repeat == false) {
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}


																				if (loopCount == f + 1) {
																					console.log('1st Loop Fin')
																					ignore_no_repeat = true
																					f = -1

																					if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																						break;
																					}
																				}
																				continue;
																			}
																			// console.log(arr_sess)
																			if (arr_sess.length >= total_no_of_sessions) {
																				console.log('Loop completed')
																				break;
																			}

																			if (total_sessions[f].repeat == '0') {

																			} else if (total_sessions[f].repeat == '1') { //weekly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			} else if (total_sessions[f].repeat == '2') { //Monthly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			}
																			// counter = arr_sess.length
																			if (loopCount == f + 1) {
																				// if (arr_sess.length < total_no_of_sessions ) {
																				f = -1
																				// if (loopCount == 1) {
																				// 	f--
																				// }
																				console.log('Loop Repeating Now')
																				continue;
																				// }
																			}

																		}

																		// NEW WEEK LOGIC
																		var result_final_ignore = [];
																		var total_sessions_in_ignore = 0
																		var total_sessions_in_ignore_month = 0

																		var seen = Object.create(null)
																		result_final_ignore = arr_sess_ignore.filter(o => {
																			var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																			if (!seen[key]) {
																				seen[key] = true;
																				return true;
																			}
																		});
																		for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																			if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																				result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																			}
																			if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																				result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																			}
																			total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																			result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																			total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																			result_final_ignore[loop_c].total = total_sessions_in_ignore
																		}

																		var result = arr_sess.reduce(function (r, a) {
																			if (a.session_type != '0') {
																				r[a.session_id] = r[a.session_id] || [];
																				r[a.session_id].push(a);

																			}
																			return r;
																		}, {});

																		var final_arr = []
																		for (key in result) {
																			if (result.hasOwnProperty(key)) {
																				var value = result[key];
																				// console.log(value.length)
																				// console.log(value[0].start_date)


																				if (value[0].session_type == '1') {
																					// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																						if (isNaN(weeks_to_ignore)) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var week = (value.length - 1)
																					// date.setDate(date.getDate() + week * 7);
																					date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																					var end_date = date.getTime() / 1000;
																					if (Number(end_date) < Number(value[0].start_date)) {
																						var end_date = Number(value[0].start_date)
																					}
																				} else if (value[0].session_type == '2') {
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																						// weeks_to_ignore = weeks_to_ignore - 1
																						if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var months = ((value.length - 1) - weeks_to_ignore)
																					var d = date.getDate();
																					date.setMonth(date.getMonth() + +months);
																					if (date.getDate() != d) {
																						date.setDate(0);
																					}
																					var end_date = date.getTime() / 1000;
																					// var date = new Date(Number(value[0].start_date) * 1000)
																					// var months = (value.length - 1)
																					// var d = date.getDate();
																					// date.setMonth(date.getMonth() + +months);
																					// if (date.getDate() != d) {
																					// 	date.setDate(0);
																					// }
																					// var end_date = date.getTime() / 1000;
																				}
																				final_arr.push({
																					'session_id': value[0].session_id,
																					'end_date': end_date,
																					'type': value[0].session_type,
																					'start_date': value[0].start_date
																				})
																			}
																		}
																		let promise = Promise.resolve();
																		const posts = final_arr;
																		posts.forEach(post => {
																			promise = promise.then(() => {
																				var dataIn = post
																				// for (var p = 0; p < final_arr.length; p++) {
																				var slotObj = {
																					'session_end_date': dataIn.end_date
																				}
																				dbo.collection("TBL_SESSIONS").updateOne({
																					_id: ObjectId(dataIn.session_id)
																				}, {
																					$set: slotObj
																				}, function (err, rese) {
																					console.log('success')
																				})
																				// }
																			})
																		})

																		promise.then(() => {
																			setTimeout(function () {
																				response()
																			}, 150);

																		})

																		// console.log(final_arr)
																		function response() {
																			if (req.body.user_type == 0) {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'client_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENT_INFO',
																							localField: 'client_id',
																							foreignField: 'client_id',
																							as: 'client_info'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'user_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},
																					{
																						"$unwind": "$client_info"
																					},
																					{
																						"$match": {
																							"client_info.trainer_id": ObjectId(req.body.user_id)
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							if (data[0]['client'][0]['timezone'] == undefined) {
																								data[0]['client'][0]['timezone'] = ''
																							}
																							if (data[0]['client'][0]['timezone_str'] == undefined) {
																								data[0]['client'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"client_id": data[0]['client_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0].client_info.first_name,
																								"last_name": data[0].client_info.last_name,
																								"image": data[0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),


																							}
																							res.send({
																								"success": true,
																								"message": "Session created succesfully!",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			} else {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},

																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'trainer_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'trainer_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							// console.log(data[0]['clientdetails'])
																							// console.log(data)
																							if (data[0]['trainer'][0]['timezone'] == undefined) {
																								data[0]['trainer'][0]['timezone'] = ''
																							}
																							if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																								data[0]['trainer'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"client_id": data[0]['client_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0]['trainerdetails'][0]['first_name'],
																								"last_name": data[0]['trainerdetails'][0]['last_name'],
																								"image": data[0]['trainerdetails'][0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),
																							}
																							res.send({
																								"success": true,
																								"message": "Session created",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			}
																		}

																	})
																}
															})

														}
													});
												}

											}
										} else if (result_count[0].repeat == '2') {
											if (req.body.reschedule_all == 0) {
												var session_end_date = Number(result_count[0].session_end_date)
												var session_date_time = Number(result_count[0].utc)
												var end_date_time = new Date(req.body.reschedule_utc * 1000)
												end_date_time.setMonth(end_date_time.getMonth() - 1);

												var start_date_time = new Date(req.body.reschedule_utc * 1000)
												start_date_time.setMonth(start_date_time.getMonth() + 1);


												var seconds = end_date_time.getTime() / 1000

												var seconds_start = start_date_time.getTime() / 1000

												var start_date = start_date_time.getDate()
												var start_year = start_date_time.getFullYear()
												var start_month = start_date_time.getMonth() + 1

												if (start_date < 10) {
													start_date = '0' + start_date
												}
												if (start_month < 10) {
													start_month = '0' + start_month
												}

												if (Number(seconds) < Number(session_date_time)) {


													var utc1 = new Date(result_count[0].utc * 1000)
													utc1.setMonth(utc1.getMonth() + 1);
													var new_utc = utc1.getTime() / 1000

													var start_date = utc1.getDate()
													var start_year = utc1.getFullYear()
													var start_month = utc1.getMonth() + 1

													if (start_date < 10) {
														start_date = '0' + start_date
													}
													if (start_month < 10) {
														start_month = '0' + start_month
													}

													var Date_month = new Date(utc1.getTime());
													var week_month = getWeekNumber(new Date(Date_month))
													// console.log('new_utc '+new_utc)
													// console.log('new Date(result_count[0].utc * 1000) '+start_month)
													// req.body.week_month = week_month[1]
													var sessionObj1 = {
														trainer_id: ObjectId(result_count[0].trainer_id),
														client_id: ObjectId(result_count[0].client_id),
														utc: new_utc.toString(),
														duration: result_count[0].duration,
														location: result_count[0].location,
														repeat: '2',
														gym_name: result_count[0].gym_name,
														user_type: result_count[0].user_type,
														status: 2,
														day: start_date.toString(),
														month: start_month.toString(),
														year: start_year.toString(),
														date_str: start_month + '.' + start_date + '.' + start_year,
														time_str: result_count[0].time_str,
														timezone_str: result_count[0].timezone_str,
														time: result_count[0].time,
														created_at: getCurrentTime(),
														updated: getCurrentTime(),
														week_month: week_month[1],
														session_end_date: result_count[0].session_end_date
													};
													// console.log(sessionObj1)
													// return
													dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {

													})
													console.log('HEREEEEEEE2222333333')

													req.body.repeat = '0'
													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: req.body
													}, function (err, rese) {
														if (err) {
															throw err;
														} else {
															var slotObj = {
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																slot_id: ObjectId(req.body.slot_id),
																day: req.body.day.toString(),
																time: req.body.time.toString(),
																month: req.body.month.toString(),
																year: req.body.year.toString(),
																created_at: getCurrentTime(),
																updated: getCurrentTime()

															}

															dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
																session_id: ObjectId(session_id_b)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})

															dbo.collection("TBL_SESSIONS").find({
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																status: {
																	$in: [0, 1, 2]
																},
																utc: {
																	$gt: getCurrentTime().toString()
																}
															}).sort({
																utc: 1
															}).toArray(async function (err, result_count) {
																console.log(result_count)
																// console.log(resv1)
																var total_no_of_sessions = Number(resv1.no_of_sessions)
																var total_sessions = result_count
																var counter = -1
																var arr_sess = []

																var loopCount = total_sessions.length
																var onlyOne = false
																var ignore_no_repeat = false
																var j = 0

																var repeat_W_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '1'
																	return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																});
																var repeat_M_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '2'
																	return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																});
																for (var f = 0; f < loopCount; f++) {
																	if (ignore_no_repeat == false) {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})

																		if (loopCount == f + 1) {
																			console.log('1st Loop Fin')
																			ignore_no_repeat = true
																			f = -1
																			if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																				break;
																			}
																		}
																		continue;
																	}
																	// console.log(arr_sess)
																	if (arr_sess.length >= total_no_of_sessions) {
																		console.log('Loop completed')
																		break;
																	}

																	if (total_sessions[f].repeat == '0') {
																		// console.log('continue repeat')
																		// continue;
																		// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																	} else if (total_sessions[f].repeat == '1') { //weekly

																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	} else if (total_sessions[f].repeat == '2') { //Monthly
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	}
																	// counter = arr_sess.length
																	if (loopCount == f + 1) {
																		f = -1
																		console.log('Loop Repeating Now')
																		continue;
																	}

																}

																var result = arr_sess.reduce(function (r, a) {
																	if (a.session_type != '0') {
																		r[a.session_id] = r[a.session_id] || [];
																		r[a.session_id].push(a);

																	}
																	return r;
																}, {});

																var final_arr = []
																for (key in result) {
																	if (result.hasOwnProperty(key)) {
																		var value = result[key];
																		// console.log(value.length)
																		// console.log(value[0].start_date)


																		if (value[0].session_type == '1') {
																			// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var week = (value.length - 1)
																			date.setDate(date.getDate() + week * 7);
																			var end_date = date.getTime() / 1000;
																		} else if (value[0].session_type == '2') {
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var months = (value.length - 1)
																			var d = date.getDate();
																			date.setMonth(date.getMonth() + +months);
																			if (date.getDate() != d) {
																				date.setDate(0);
																			}
																			var end_date = date.getTime() / 1000;
																		}
																		final_arr.push({
																			'session_id': value[0].session_id,
																			'end_date': end_date,
																			'type': value[0].session_type,
																			'start_date': value[0].start_date
																		})
																	}
																}
																let promise = Promise.resolve();
																const posts = final_arr;
																posts.forEach(post => {
																	promise = promise.then(() => {
																		var dataIn = post
																		// for (var p = 0; p < final_arr.length; p++) {
																		var slotObj = {
																			'session_end_date': dataIn.end_date
																		}
																		dbo.collection("TBL_SESSIONS").updateOne({
																			_id: ObjectId(dataIn.session_id)
																		}, {
																			$set: slotObj
																		}, function (err, rese) {
																			console.log('success')
																		})
																		// }
																	})
																})

																promise.then(() => {
																	setTimeout(function () {
																		response()
																	}, 150);

																})

																// console.log(final_arr)
																function response() {
																	if (req.body.user_type == 0) {
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'client_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENT_INFO',
																					localField: 'client_id',
																					foreignField: 'client_id',
																					as: 'client_info'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'user_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},
																			{
																				"$unwind": "$client_info"
																			},
																			{
																				"$match": {
																					"client_info.trainer_id": ObjectId(req.body.user_id)
																				}
																			},
																			// {$group: {
																			//      _id: "$_id",
																			//      client_info: {$push: "$client_info"}
																			//  }},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"client_id": data[0]['client_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0].client_info.first_name,
																						"last_name": data[0].client_info.last_name,
																						"image": data[0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),


																					}
																					res.send({
																						"success": true,
																						"message": "Session updated succesfully!",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	} else {
																		// sendNotification(req.body.trainer_id,resv.insertedId)
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},

																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'trainer_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'trainer_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"client_id": data[0]['client_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0]['trainerdetails'][0]['first_name'],
																						"last_name": data[0]['trainerdetails'][0]['last_name'],
																						"image": data[0]['trainerdetails'][0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),
																					}
																					res.send({
																						"success": true,
																						"message": "Session updated",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	}
																}

															})
														}
													})

												} else if (Number(seconds_start) > Number(session_end_date)) {


													// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
													var Date_month = new Date(seconds_start * 1000);
													var week_month = getWeekNumber(new Date(Date_month))


													console.log('THEREEEEEE2222333333 Number(seconds_start) > Number(session_end_date 111111')
													// var end_date_time1 = new Date(result_count[0].utc * 1000)
													// end_date_time1.setMonth(end_date_time1.getMonth() - 1);
													// var seconds1 = end_date_time1.getTime() / 1000

													var utc1 = new Date(req.body.reschedule_utc * 1000)
													utc1.setMonth(utc1.getMonth() + 1);
													var new_utc = utc1.getTime() / 1000


													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: {
															'session_end_date': Number(seconds),
															'ignore': 1
														}
													}, function (err, rese) {
														if (err) {
															res.send({
																"success": false,
																"message": "Something went wrong!",
																"data": {}
															});
															return false;
														} else {
															// logic here
															sessionObj.repeat = '0'
															dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
																if (err) {
																	throw err;
																} else {
																	slotObj.session_id = ObjectId(resv.insertedId);
																	dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
																		console.log('success')
																	})
																	dbo.collection("TBL_SESSIONS").find({
																		trainer_id: ObjectId(req.body.user_id),
																		client_id: ObjectId(req.body.client_id),
																		status: {
																			$in: [0, 1, 2]
																		},
																		utc: {
																			$gt: getCurrentTime().toString()
																		},
																		// ignore: {
																		// 	$ne: 1
																		// }
																	}).sort({
																		utc: 1
																	}).toArray(async function (err, result_count) {
																		console.log(result_count)
																		// console.log(resv1)
																		var total_no_of_sessions = Number(resv1.no_of_sessions)
																		var total_sessions = result_count
																		var counter = -1
																		var arr_sess = []
																		var arr_sess_ignore = []

																		var loopCount = total_sessions.length
																		var onlyOne = false
																		var ignore_no_repeat = false
																		var j = 0

																		var repeat_W_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '1'
																			return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																		});
																		var repeat_M_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '2'
																			return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																		});
																		for (var f = 0; f < loopCount; f++) {
																			if (!total_sessions[f].ignore) {
																				var is_ignore = 0;
																			} else {
																				var is_ignore = total_sessions[f].ignore;
																			}
																			if (!total_sessions[f].session_end_date) {
																				var is_session_end_date = '';
																			} else {
																				var is_session_end_date = total_sessions[f].session_end_date;
																			}
																			if (is_session_end_date != '') {
																				var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																				var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																			} else {
																				var weeks_btw = ''
																				var months_btw = ''
																			}

																			if (ignore_no_repeat == false) {
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}


																				if (loopCount == f + 1) {
																					console.log('1st Loop Fin')
																					ignore_no_repeat = true
																					f = -1
																					// if (loopCount == 1) {
																					// 	f--
																					// }
																					if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																						break;
																					}
																				}
																				continue;
																			}
																			// console.log(arr_sess)
																			if (arr_sess.length >= total_no_of_sessions) {
																				console.log('Loop completed')
																				break;
																			}

																			if (total_sessions[f].repeat == '0') {
																				// console.log('continue repeat')
																				// continue;
																				// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																			} else if (total_sessions[f].repeat == '1') { //weekly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			} else if (total_sessions[f].repeat == '2') { //Monthly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			}
																			// counter = arr_sess.length
																			if (loopCount == f + 1) {
																				// if (arr_sess.length < total_no_of_sessions ) {
																				f = -1

																				console.log('Loop Repeating Now')
																				continue;
																				// }
																			}

																		}

																		// NEW WEEK LOGIC
																		var result_final_ignore = [];
																		var total_sessions_in_ignore = 0
																		var total_sessions_in_ignore_month = 0

																		var seen = Object.create(null)
																		result_final_ignore = arr_sess_ignore.filter(o => {
																			var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																			if (!seen[key]) {
																				seen[key] = true;
																				return true;
																			}
																		});
																		for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																			if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																				result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																			}
																			if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																				result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																			}
																			total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																			result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																			total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																			result_final_ignore[loop_c].total = total_sessions_in_ignore
																		}

																		var result = arr_sess.reduce(function (r, a) {
																			if (a.session_type != '0') {
																				r[a.session_id] = r[a.session_id] || [];
																				r[a.session_id].push(a);

																			}
																			return r;
																		}, {});

																		var final_arr = []
																		for (key in result) {
																			if (result.hasOwnProperty(key)) {
																				var value = result[key];
																				// console.log(value.length)
																				// console.log(value[0].start_date)


																				if (value[0].session_type == '1') {
																					// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																						if (isNaN(weeks_to_ignore)) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var week = (value.length - 1)
																					// date.setDate(date.getDate() + week * 7);
																					date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																					var end_date = date.getTime() / 1000;
																					if (Number(end_date) < Number(value[0].start_date)) {
																						var end_date = Number(value[0].start_date)
																					}
																				} else if (value[0].session_type == '2') {
																					// var date = new Date(Number(value[0].start_date) * 1000)
																					// var months = (value.length - 1)
																					// var d = date.getDate();
																					// date.setMonth(date.getMonth() + +months);
																					// if (date.getDate() != d) {
																					// 	date.setDate(0);
																					// }
																					// var end_date = date.getTime() / 1000;
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																						// weeks_to_ignore = weeks_to_ignore - 1
																						if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var months = ((value.length - 1) - weeks_to_ignore)
																					var d = date.getDate();
																					date.setMonth(date.getMonth() + +months);
																					if (date.getDate() != d) {
																						date.setDate(0);
																					}
																					var end_date = date.getTime() / 1000;
																				}
																				final_arr.push({
																					'session_id': value[0].session_id,
																					'end_date': end_date,
																					'type': value[0].session_type,
																					'start_date': value[0].start_date
																				})
																			}
																		}
																		let promise = Promise.resolve();
																		const posts = final_arr;
																		posts.forEach(post => {
																			promise = promise.then(() => {
																				var dataIn = post
																				// for (var p = 0; p < final_arr.length; p++) {
																				var slotObj = {
																					'session_end_date': dataIn.end_date
																				}
																				dbo.collection("TBL_SESSIONS").updateOne({
																					_id: ObjectId(dataIn.session_id)
																				}, {
																					$set: slotObj
																				}, function (err, rese) {
																					console.log('success')
																				})
																				// }
																			})
																		})

																		promise.then(() => {
																			setTimeout(function () {
																				response()
																			}, 150);

																		})

																		// console.log(final_arr)
																		function response() {
																			if (req.body.user_type == 0) {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'client_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENT_INFO',
																							localField: 'client_id',
																							foreignField: 'client_id',
																							as: 'client_info'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'user_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},
																					{
																						"$unwind": "$client_info"
																					},
																					{
																						"$match": {
																							"client_info.trainer_id": ObjectId(req.body.user_id)
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							if (data[0]['client'][0]['timezone'] == undefined) {
																								data[0]['client'][0]['timezone'] = ''
																							}
																							if (data[0]['client'][0]['timezone_str'] == undefined) {
																								data[0]['client'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"client_id": data[0]['client_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0].client_info.first_name,
																								"last_name": data[0].client_info.last_name,
																								"image": data[0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),


																							}
																							res.send({
																								"success": true,
																								"message": "Session created succesfully!",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			} else {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},

																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'trainer_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'trainer_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							// console.log(data[0]['clientdetails'])
																							// console.log(data)
																							if (data[0]['trainer'][0]['timezone'] == undefined) {
																								data[0]['trainer'][0]['timezone'] = ''
																							}
																							if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																								data[0]['trainer'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"client_id": data[0]['client_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0]['trainerdetails'][0]['first_name'],
																								"last_name": data[0]['trainerdetails'][0]['last_name'],
																								"image": data[0]['trainerdetails'][0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),
																							}
																							res.send({
																								"success": true,
																								"message": "Session created",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			}
																		}

																	})
																}
															})

														}
													});
												} else {

													// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
													var Date_month = new Date(seconds_start * 1000);
													var week_month = getWeekNumber(new Date(Date_month))


													console.log('THEREEEEEE2222333333 OOONE')
													// var end_date_time1 = new Date(result_count[0].utc * 1000)
													// end_date_time1.setMonth(end_date_time1.getMonth() - 1);
													// var seconds1 = end_date_time1.getTime() / 1000

													var utc1 = new Date(req.body.reschedule_utc * 1000)
													utc1.setMonth(utc1.getMonth() + 1);
													var new_utc = utc1.getTime() / 1000


													var sessionObj1 = {
														trainer_id: ObjectId(result_count[0].trainer_id),
														client_id: ObjectId(result_count[0].client_id),
														utc: new_utc.toString(),
														duration: result_count[0].duration,
														location: result_count[0].location,
														repeat: '2',
														gym_name: result_count[0].gym_name,
														user_type: result_count[0].user_type,
														status: 2,
														day: start_date.toString(),
														month: start_month.toString(),
														year: start_year.toString(),
														date_str: start_month + '.' + start_date + '.' + start_year,
														time_str: result_count[0].time_str,
														timezone_str: result_count[0].timezone_str,
														time: result_count[0].time,
														created_at: getCurrentTime(),
														updated: getCurrentTime(),
														week_month: week_month[1],
														session_end_date: result_count[0].session_end_date,
														ignore: 1
													};
													dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {

													})

													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: {
															'session_end_date': Number(seconds),
															'ignore': 1
														}
													}, function (err, rese) {
														if (err) {
															res.send({
																"success": false,
																"message": "Something went wrong!",
																"data": {}
															});
															return false;
														} else {
															// logic here
															sessionObj.repeat = '0'
															dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
																if (err) {
																	throw err;
																} else {
																	slotObj.session_id = ObjectId(resv.insertedId);
																	dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
																		console.log('success')
																	})
																	dbo.collection("TBL_SESSIONS").find({
																		trainer_id: ObjectId(req.body.user_id),
																		client_id: ObjectId(req.body.client_id),
																		status: {
																			$in: [0, 1, 2]
																		},
																		utc: {
																			$gt: getCurrentTime().toString()
																		},
																		// ignore: {
																		// 	$ne: 1
																		// }
																	}).sort({
																		utc: 1
																	}).toArray(async function (err, result_count) {
																		console.log(result_count)
																		// console.log(resv1)
																		var total_no_of_sessions = Number(resv1.no_of_sessions)
																		var total_sessions = result_count
																		var counter = -1
																		var arr_sess = []
																		var arr_sess_ignore = []
																		var loopCount = total_sessions.length
																		var onlyOne = false
																		var ignore_no_repeat = false
																		var j = 0

																		var repeat_W_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '1'
																			return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																		});
																		var repeat_M_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '2'
																			return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																		});
																		for (var f = 0; f < loopCount; f++) {
																			if (!total_sessions[f].ignore) {
																				var is_ignore = 0;
																			} else {
																				var is_ignore = total_sessions[f].ignore;
																			}
																			if (!total_sessions[f].session_end_date) {
																				var is_session_end_date = '';
																			} else {
																				var is_session_end_date = total_sessions[f].session_end_date;
																			}
																			if (is_session_end_date != '') {
																				var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																				var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																			} else {
																				var weeks_btw = ''
																				var months_btw = ''
																			}

																			if (ignore_no_repeat == false) {
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}


																				if (loopCount == f + 1) {
																					console.log('1st Loop Fin')
																					ignore_no_repeat = true
																					f = -1

																					if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																						break;
																					}
																				}
																				continue;
																			}
																			// console.log(arr_sess)
																			if (arr_sess.length >= total_no_of_sessions) {
																				console.log('Loop completed')
																				break;
																			}

																			if (total_sessions[f].repeat == '0') {
																				// console.log('continue repeat')
																				// continue;
																				// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																			} else if (total_sessions[f].repeat == '1') { //weekly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			} else if (total_sessions[f].repeat == '2') { //Monthly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			}
																			// counter = arr_sess.length
																			if (loopCount == f + 1) {
																				// if (arr_sess.length < total_no_of_sessions ) {
																				f = -1
																				// if (loopCount == 1) {
																				// 	f--
																				// }
																				console.log('Loop Repeating Now')
																				continue;
																				// }
																			}

																		}

																		// NEW WEEK LOGIC
																		var result_final_ignore = [];
																		var total_sessions_in_ignore = 0
																		var total_sessions_in_ignore_month = 0

																		var seen = Object.create(null)
																		result_final_ignore = arr_sess_ignore.filter(o => {
																			var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																			if (!seen[key]) {
																				seen[key] = true;
																				return true;
																			}
																		});
																		for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																			if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																				result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																			}
																			if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																				result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																			}
																			total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																			result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																			total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																			result_final_ignore[loop_c].total = total_sessions_in_ignore
																		}

																		var result = arr_sess.reduce(function (r, a) {
																			if (a.session_type != '0') {
																				r[a.session_id] = r[a.session_id] || [];
																				r[a.session_id].push(a);

																			}
																			return r;
																		}, {});

																		var final_arr = []
																		for (key in result) {
																			if (result.hasOwnProperty(key)) {
																				var value = result[key];
																				console.log(value.length)
																				console.log(value[0].start_date)


																				if (value[0].session_type == '1') {
																					// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																						if (isNaN(weeks_to_ignore)) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var week = (value.length - 1)
																					// date.setDate(date.getDate() + week * 7);
																					date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																					var end_date = date.getTime() / 1000;
																					if (Number(end_date) < Number(value[0].start_date)) {
																						var end_date = Number(value[0].start_date)
																					}
																				} else if (value[0].session_type == '2') {
																					// var date = new Date(Number(value[0].start_date) * 1000)
																					// var months = (value.length - 1)
																					// var d = date.getDate();
																					// date.setMonth(date.getMonth() + +months);
																					// if (date.getDate() != d) {
																					// 	date.setDate(0);
																					// }
																					// var end_date = date.getTime() / 1000;
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																						// weeks_to_ignore = weeks_to_ignore - 1
																						if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var months = ((value.length - 1) - weeks_to_ignore)
																					var d = date.getDate();
																					date.setMonth(date.getMonth() + +months);
																					if (date.getDate() != d) {
																						date.setDate(0);
																					}
																					var end_date = date.getTime() / 1000;
																				}
																				final_arr.push({
																					'session_id': value[0].session_id,
																					'end_date': end_date,
																					'type': value[0].session_type,
																					'start_date': value[0].start_date
																				})
																			}
																		}
																		let promise = Promise.resolve();
																		const posts = final_arr;
																		posts.forEach(post => {
																			promise = promise.then(() => {
																				var dataIn = post
																				// for (var p = 0; p < final_arr.length; p++) {
																				var slotObj = {
																					'session_end_date': dataIn.end_date
																				}
																				dbo.collection("TBL_SESSIONS").updateOne({
																					_id: ObjectId(dataIn.session_id)
																				}, {
																					$set: slotObj
																				}, function (err, rese) {
																					console.log('success')
																				})
																				// }
																			})
																		})

																		promise.then(() => {
																			setTimeout(function () {
																				response()
																			}, 150);

																		})

																		// console.log(final_arr)
																		function response() {
																			if (req.body.user_type == 0) {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'client_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENT_INFO',
																							localField: 'client_id',
																							foreignField: 'client_id',
																							as: 'client_info'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'user_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},
																					{
																						"$unwind": "$client_info"
																					},
																					{
																						"$match": {
																							"client_info.trainer_id": ObjectId(req.body.user_id)
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							if (data[0]['client'][0]['timezone'] == undefined) {
																								data[0]['client'][0]['timezone'] = ''
																							}
																							if (data[0]['client'][0]['timezone_str'] == undefined) {
																								data[0]['client'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"client_id": data[0]['client_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0].client_info.first_name,
																								"last_name": data[0].client_info.last_name,
																								"image": data[0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),


																							}
																							res.send({
																								"success": true,
																								"message": "Session created succesfully!",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			} else {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},

																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'trainer_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'trainer_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							// console.log(data[0]['clientdetails'])
																							// console.log(data)
																							if (data[0]['trainer'][0]['timezone'] == undefined) {
																								data[0]['trainer'][0]['timezone'] = ''
																							}
																							if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																								data[0]['trainer'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"client_id": data[0]['client_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0]['trainerdetails'][0]['first_name'],
																								"last_name": data[0]['trainerdetails'][0]['last_name'],
																								"image": data[0]['trainerdetails'][0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),
																							}
																							res.send({
																								"success": true,
																								"message": "Session created",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			}
																		}

																	})
																}
															})

														}
													});
												}
											} else {
												var session_end_date = Number(result_count[0].session_end_date)
												var session_date_time = Number(result_count[0].utc)
												// var end_date_time = new Date(session_date_time * 1000)
												var end_date_time = new Date(req.body.reschedule_utc * 1000)
												end_date_time.setDate(end_date_time.getMonth() - 1);

												var seconds = end_date_time.getTime() / 1000

												var start_date_time = new Date(req.body.reschedule_utc * 1000)
												start_date_time.setMonth(start_date_time.getMonth() + 1);
												var seconds_start = start_date_time.getTime() / 1000

												// var start_date = start_date_time.getDate()
												// var start_year = start_date_time.getFullYear()
												// var start_month = start_date_time.getMonth() + 1

												// if (start_date < 10) {
												// 	start_date = '0' + start_date
												// }
												// if (start_month < 10) {
												// 	start_month = '0' + start_month
												// }

												if (Number(seconds) < Number(session_date_time)) {
													var Date_month = new Date(end_date_time.getTime());
													var week_month = getWeekNumber(new Date(Date_month))
													// req.body.week_month = week_month[1]

													console.log('HEREEEEEEE22 TWO')

													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: req.body
													}, function (err, rese) {
														if (err) {
															throw err;
														} else {
															var slotObj = {
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																slot_id: ObjectId(req.body.slot_id),
																day: req.body.day.toString(),
																time: req.body.time.toString(),
																month: req.body.month.toString(),
																year: req.body.year.toString(),
																created_at: getCurrentTime(),
																updated: getCurrentTime()

															}

															dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
																session_id: ObjectId(session_id_b)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})

															dbo.collection("TBL_SESSIONS").find({
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																status: {
																	$in: [0, 1, 2]
																},
																utc: {
																	$gt: getCurrentTime().toString()
																}
															}).sort({
																utc: 1
															}).toArray(async function (err, result_count) {
																console.log(result_count)
																// console.log(resv1)
																var total_no_of_sessions = Number(resv1.no_of_sessions)
																var total_sessions = result_count
																var counter = -1
																var arr_sess = []

																var loopCount = total_sessions.length
																var onlyOne = false
																var ignore_no_repeat = false
																var j = 0

																var repeat_W_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '1'
																	return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																});
																var repeat_M_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '2'
																	return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																});
																for (var f = 0; f < loopCount; f++) {
																	if (ignore_no_repeat == false) {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})

																		if (loopCount == f + 1) {
																			console.log('1st Loop Fin')
																			ignore_no_repeat = true
																			f = -1
																			if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																				break;
																			}
																		}
																		continue;
																	}
																	console.log(arr_sess)
																	if (arr_sess.length >= total_no_of_sessions) {
																		console.log('Loop completed')
																		break;
																	}

																	if (total_sessions[f].repeat == '0') {
																		// console.log('continue repeat')
																		// continue;
																		// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																	} else if (total_sessions[f].repeat == '1') { //weekly

																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	} else if (total_sessions[f].repeat == '2') { //Monthly
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat
																		})
																	}
																	// counter = arr_sess.length
																	if (loopCount == f + 1) {
																		f = -1
																		console.log('Loop Repeating Now')
																		continue;
																	}

																}

																var result = arr_sess.reduce(function (r, a) {
																	if (a.session_type != '0') {
																		r[a.session_id] = r[a.session_id] || [];
																		r[a.session_id].push(a);

																	}
																	return r;
																}, {});

																var final_arr = []
																for (key in result) {
																	if (result.hasOwnProperty(key)) {
																		var value = result[key];
																		console.log(value.length)
																		console.log(value[0].start_date)


																		if (value[0].session_type == '1') {
																			// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var week = (value.length - 1)
																			date.setDate(date.getDate() + week * 7);
																			var end_date = date.getTime() / 1000;
																		} else if (value[0].session_type == '2') {
																			var date = new Date(Number(value[0].start_date) * 1000)
																			var months = (value.length - 1)
																			var d = date.getDate();
																			date.setMonth(date.getMonth() + +months);
																			if (date.getDate() != d) {
																				date.setDate(0);
																			}
																			var end_date = date.getTime() / 1000;
																		}
																		final_arr.push({
																			'session_id': value[0].session_id,
																			'end_date': end_date,
																			'type': value[0].session_type,
																			'start_date': value[0].start_date
																		})
																	}
																}
																let promise = Promise.resolve();
																const posts = final_arr;
																posts.forEach(post => {
																	promise = promise.then(() => {
																		var dataIn = post
																		// for (var p = 0; p < final_arr.length; p++) {
																		var slotObj = {
																			'session_end_date': dataIn.end_date
																		}
																		dbo.collection("TBL_SESSIONS").updateOne({
																			_id: ObjectId(dataIn.session_id)
																		}, {
																			$set: slotObj
																		}, function (err, rese) {
																			console.log('success')
																		})
																		// }
																	})
																})

																promise.then(() => {
																	setTimeout(function () {
																		response()
																	}, 150);

																})

																// console.log(final_arr)
																function response() {
																	if (req.body.user_type == 0) {
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'client_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENT_INFO',
																					localField: 'client_id',
																					foreignField: 'client_id',
																					as: 'client_info'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'user_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},
																			{
																				"$unwind": "$client_info"
																			},
																			{
																				"$match": {
																					"client_info.trainer_id": ObjectId(req.body.user_id)
																				}
																			},
																			// {$group: {
																			//      _id: "$_id",
																			//      client_info: {$push: "$client_info"}
																			//  }},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"client_id": data[0]['client_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0].client_info.first_name,
																						"last_name": data[0].client_info.last_name,
																						"image": data[0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),


																					}
																					res.send({
																						"success": true,
																						"message": "Session updated succesfully!",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	} else {
																		// sendNotification(req.body.trainer_id,resv.insertedId)
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					"_id": ObjectId(session_id_b)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},

																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'trainer_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'trainer_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['timezone'] == undefined) {
																						data[0]['timezone'] = ''
																					}
																					if (data[0]['timezone_str'] == undefined) {
																						data[0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"client_id": data[0]['client_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0]['trainerdetails'][0]['first_name'],
																						"last_name": data[0]['trainerdetails'][0]['last_name'],
																						"image": data[0]['trainerdetails'][0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),
																					}
																					res.send({
																						"success": true,
																						"message": "Session updated",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	}
																}

															})
														}
													})


												} else if (Number(seconds_start) > Number(session_end_date)) {


													// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
													var Date_month = new Date(seconds_start * 1000);
													var week_month = getWeekNumber(new Date(Date_month))


													console.log('THEREEEEEE2222333333 Number(seconds_start) > Number(session_end_date 222222')
													// var end_date_time1 = new Date(result_count[0].utc * 1000)
													// end_date_time1.setMonth(end_date_time1.getMonth() - 1);
													// var seconds1 = end_date_time1.getTime() / 1000

													var utc1 = new Date(req.body.reschedule_utc * 1000)
													utc1.setMonth(utc1.getMonth() + 1);
													var new_utc = utc1.getTime() / 1000


													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: {
															'session_end_date': Number(seconds),
															'ignore': 1
														}
													}, function (err, rese) {
														if (err) {
															res.send({
																"success": false,
																"message": "Something went wrong!",
																"data": {}
															});
															return false;
														} else {
															// logic here
															sessionObj.repeat = '0'
															dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
																if (err) {
																	throw err;
																} else {
																	slotObj.session_id = ObjectId(resv.insertedId);
																	dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
																		console.log('success')
																	})
																	dbo.collection("TBL_SESSIONS").find({
																		trainer_id: ObjectId(req.body.user_id),
																		client_id: ObjectId(req.body.client_id),
																		status: {
																			$in: [0, 1, 2]
																		},
																		utc: {
																			$gt: getCurrentTime().toString()
																		},
																		// ignore: {
																		// 	$ne: 1
																		// }
																	}).sort({
																		utc: 1
																	}).toArray(async function (err, result_count) {
																		console.log(result_count)
																		// console.log(resv1)
																		var total_no_of_sessions = Number(resv1.no_of_sessions)
																		var total_sessions = result_count
																		var counter = -1
																		var arr_sess = []
																		var arr_sess_ignore = []
																		var loopCount = total_sessions.length
																		var onlyOne = false
																		var ignore_no_repeat = false
																		var j = 0

																		var repeat_W_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '1'
																			return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																		});
																		var repeat_M_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '2'
																			return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																		});
																		for (var f = 0; f < loopCount; f++) {
																			if (!total_sessions[f].ignore) {
																				var is_ignore = 0;
																			} else {
																				var is_ignore = total_sessions[f].ignore;
																			}
																			if (!total_sessions[f].session_end_date) {
																				var is_session_end_date = '';
																			} else {
																				var is_session_end_date = total_sessions[f].session_end_date;
																			}
																			if (is_session_end_date != '') {
																				var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																				var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																			} else {
																				var weeks_btw = ''
																				var months_btw = ''
																			}

																			if (ignore_no_repeat == false) {
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}


																				if (loopCount == f + 1) {
																					console.log('1st Loop Fin')
																					ignore_no_repeat = true
																					f = -1

																					if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																						break;
																					}
																				}
																				continue;
																			}
																			// console.log(arr_sess)
																			if (arr_sess.length >= total_no_of_sessions) {
																				console.log('Loop completed')
																				break;
																			}

																			if (total_sessions[f].repeat == '0') {

																			} else if (total_sessions[f].repeat == '1') { //weekly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			} else if (total_sessions[f].repeat == '2') { //Monthly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			}
																			// counter = arr_sess.length
																			if (loopCount == f + 1) {
																				// if (arr_sess.length < total_no_of_sessions ) {
																				f = -1

																				console.log('Loop Repeating Now')
																				continue;
																				// }
																			}

																		}

																		// NEW WEEK LOGIC
																		var result_final_ignore = [];
																		var total_sessions_in_ignore = 0
																		var total_sessions_in_ignore_month = 0

																		var seen = Object.create(null)
																		result_final_ignore = arr_sess_ignore.filter(o => {
																			var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																			if (!seen[key]) {
																				seen[key] = true;
																				return true;
																			}
																		});
																		for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																			if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																				result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																			}
																			if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																				result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																			}
																			total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																			result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																			total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																			result_final_ignore[loop_c].total = total_sessions_in_ignore
																		}

																		var result = arr_sess.reduce(function (r, a) {
																			if (a.session_type != '0') {
																				r[a.session_id] = r[a.session_id] || [];
																				r[a.session_id].push(a);

																			}
																			return r;
																		}, {});

																		var final_arr = []
																		for (key in result) {
																			if (result.hasOwnProperty(key)) {
																				var value = result[key];
																				console.log(value.length)
																				console.log(value[0].start_date)


																				if (value[0].session_type == '1') {
																					// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																						if (isNaN(weeks_to_ignore)) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var week = (value.length - 1)
																					// date.setDate(date.getDate() + week * 7);
																					date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																					var end_date = date.getTime() / 1000;
																					if (Number(end_date) < Number(value[0].start_date)) {
																						var end_date = Number(value[0].start_date)
																					}
																				} else if (value[0].session_type == '2') {
																					// var date = new Date(Number(value[0].start_date) * 1000)
																					// var months = (value.length - 1)
																					// var d = date.getDate();
																					// date.setMonth(date.getMonth() + +months);
																					// if (date.getDate() != d) {
																					// 	date.setDate(0);
																					// }
																					// var end_date = date.getTime() / 1000;
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																						// weeks_to_ignore = weeks_to_ignore - 1
																						if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var months = ((value.length - 1) - weeks_to_ignore)
																					var d = date.getDate();
																					date.setMonth(date.getMonth() + +months);
																					if (date.getDate() != d) {
																						date.setDate(0);
																					}
																					var end_date = date.getTime() / 1000;
																				}
																				final_arr.push({
																					'session_id': value[0].session_id,
																					'end_date': end_date,
																					'type': value[0].session_type,
																					'start_date': value[0].start_date
																				})
																			}
																		}
																		let promise = Promise.resolve();
																		const posts = final_arr;
																		posts.forEach(post => {
																			promise = promise.then(() => {
																				var dataIn = post

																				var slotObj = {
																					'session_end_date': dataIn.end_date
																				}
																				dbo.collection("TBL_SESSIONS").updateOne({
																					_id: ObjectId(dataIn.session_id)
																				}, {
																					$set: slotObj
																				}, function (err, rese) {
																					console.log('success')
																				})

																			})
																		})

																		promise.then(() => {
																			setTimeout(function () {
																				response()
																			}, 150);

																		})

																		// console.log(final_arr)
																		function response() {
																			if (req.body.user_type == 0) {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'client_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENT_INFO',
																							localField: 'client_id',
																							foreignField: 'client_id',
																							as: 'client_info'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'user_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},
																					{
																						"$unwind": "$client_info"
																					},
																					{
																						"$match": {
																							"client_info.trainer_id": ObjectId(req.body.user_id)
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							if (data[0]['client'][0]['timezone'] == undefined) {
																								data[0]['client'][0]['timezone'] = ''
																							}
																							if (data[0]['client'][0]['timezone_str'] == undefined) {
																								data[0]['client'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"client_id": data[0]['client_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0].client_info.first_name,
																								"last_name": data[0].client_info.last_name,
																								"image": data[0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),


																							}
																							res.send({
																								"success": true,
																								"message": "Session created succesfully!",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			} else {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},

																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'trainer_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'trainer_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							// console.log(data[0]['clientdetails'])
																							// console.log(data)
																							if (data[0]['trainer'][0]['timezone'] == undefined) {
																								data[0]['trainer'][0]['timezone'] = ''
																							}
																							if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																								data[0]['trainer'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"client_id": data[0]['client_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0]['trainerdetails'][0]['first_name'],
																								"last_name": data[0]['trainerdetails'][0]['last_name'],
																								"image": data[0]['trainerdetails'][0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),
																							}
																							res.send({
																								"success": true,
																								"message": "Session created",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			}
																		}

																	})
																}
															})

														}
													});
												} else {
													var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
													var week_month = getWeekNumber(new Date(Date_month))


													console.log('THEREEEEEE22')
													dbo.collection('TBL_SESSIONS').updateOne({
														_id: ObjectId(session_id_b)
													}, {
														$set: {
															'session_end_date': Number(seconds),
															'ignore': 1
														}
													}, function (err, rese) {
														if (err) {
															res.send({
																"success": false,
																"message": "Something went wrong!",
																"data": {}
															});
															return false;
														} else {
															// logic here

															dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
																if (err) {
																	throw err;
																} else {
																	slotObj.session_id = ObjectId(resv.insertedId);
																	dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
																		console.log('success')
																	})
																	dbo.collection("TBL_SESSIONS").find({
																		trainer_id: ObjectId(req.body.user_id),
																		client_id: ObjectId(req.body.client_id),
																		status: {
																			$in: [0, 1, 2]
																		},
																		utc: {
																			$gt: getCurrentTime().toString()
																		},
																		// ignore: {
																		// 	$ne: 1
																		// }
																	}).sort({
																		utc: 1
																	}).toArray(async function (err, result_count) {
																		console.log(result_count)
																		// console.log(resv1)
																		var total_no_of_sessions = Number(resv1.no_of_sessions)
																		var total_sessions = result_count
																		var counter = -1
																		var arr_sess = []
																		var arr_sess_ignore = []
																		var loopCount = total_sessions.length
																		var onlyOne = false
																		var ignore_no_repeat = false
																		var j = 0

																		var repeat_W_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '1'
																			return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																		});
																		var repeat_M_isPresent = total_sessions.some(function (el) {
																			// return el.repeat === '2'
																			return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																		});
																		for (var f = 0; f < loopCount; f++) {
																			if (!total_sessions[f].ignore) {
																				var is_ignore = 0;
																			} else {
																				var is_ignore = total_sessions[f].ignore;
																			}
																			if (!total_sessions[f].session_end_date) {
																				var is_session_end_date = '';
																			} else {
																				var is_session_end_date = total_sessions[f].session_end_date;
																			}
																			if (is_session_end_date != '') {
																				var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																				var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																			} else {
																				var weeks_btw = ''
																				var months_btw = ''
																			}

																			if (ignore_no_repeat == false) {
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}


																				if (loopCount == f + 1) {
																					console.log('1st Loop Fin')
																					ignore_no_repeat = true
																					f = -1
																					// if (loopCount == 1) {
																					// 	f--
																					// }
																					if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																						break;
																					}
																				}
																				continue;
																			}
																			// console.log(arr_sess)
																			if (arr_sess.length >= total_no_of_sessions) {
																				console.log('Loop completed')
																				break;
																			}

																			if (total_sessions[f].repeat == '0') {
																				// console.log('continue repeat')
																				// continue;
																				// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																			} else if (total_sessions[f].repeat == '1') { //weekly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			} else if (total_sessions[f].repeat == '2') { //Monthly
																				if (is_ignore == 1) {
																					arr_sess_ignore.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				} else {
																					arr_sess.push({
																						'session_id': total_sessions[f]._id,
																						"start_date": total_sessions[f].utc,
																						"session_type": total_sessions[f].repeat,
																						"is_session_end_date": is_session_end_date,
																						"weeks_btw": weeks_btw,
																						"months_btw": months_btw,
																					})
																				}

																			}
																			// counter = arr_sess.length
																			if (loopCount == f + 1) {
																				// if (arr_sess.length < total_no_of_sessions ) {
																				f = -1
																				// if (loopCount == 1) {
																				// 	f--
																				// }
																				console.log('Loop Repeating Now')
																				continue;
																				// }
																			}

																		}

																		// NEW WEEK LOGIC
																		var result_final_ignore = [];
																		var total_sessions_in_ignore = 0
																		var total_sessions_in_ignore_month = 0

																		var seen = Object.create(null)
																		result_final_ignore = arr_sess_ignore.filter(o => {
																			var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																			if (!seen[key]) {
																				seen[key] = true;
																				return true;
																			}
																		});
																		for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																			if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																				result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																			}
																			if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																				result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																			}
																			total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																			result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																			total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																			result_final_ignore[loop_c].total = total_sessions_in_ignore
																		}

																		var result = arr_sess.reduce(function (r, a) {
																			if (a.session_type != '0') {
																				r[a.session_id] = r[a.session_id] || [];
																				r[a.session_id].push(a);

																			}
																			return r;
																		}, {});

																		var final_arr = []
																		for (key in result) {
																			if (result.hasOwnProperty(key)) {
																				var value = result[key];
																				console.log(value.length)
																				console.log(value[0].start_date)


																				if (value[0].session_type == '1') {
																					// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																						if (isNaN(weeks_to_ignore)) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var week = (value.length - 1)
																					// date.setDate(date.getDate() + week * 7);
																					date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																					var end_date = date.getTime() / 1000;
																					if (Number(end_date) < Number(value[0].start_date)) {
																						var end_date = Number(value[0].start_date)
																					}
																				} else if (value[0].session_type == '2') {
																					// var date = new Date(Number(value[0].start_date) * 1000)
																					// var months = (value.length - 1)
																					// var d = date.getDate();
																					// date.setMonth(date.getMonth() + +months);
																					// if (date.getDate() != d) {
																					// 	date.setDate(0);
																					// }
																					// var end_date = date.getTime() / 1000;
																					if (!result_final_ignore || result_final_ignore.length == 0) {
																						weeks_to_ignore = 0
																					} else {
																						var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																						// weeks_to_ignore = weeks_to_ignore - 1
																						if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																							weeks_to_ignore = 0
																						}
																					}

																					var date = new Date(Number(value[0].start_date) * 1000)
																					var months = ((value.length - 1) - weeks_to_ignore)
																					var d = date.getDate();
																					date.setMonth(date.getMonth() + +months);
																					if (date.getDate() != d) {
																						date.setDate(0);
																					}
																					var end_date = date.getTime() / 1000;
																				}
																				final_arr.push({
																					'session_id': value[0].session_id,
																					'end_date': end_date,
																					'type': value[0].session_type,
																					'start_date': value[0].start_date
																				})
																			}
																		}
																		let promise = Promise.resolve();
																		const posts = final_arr;
																		posts.forEach(post => {
																			promise = promise.then(() => {
																				var dataIn = post
																				// for (var p = 0; p < final_arr.length; p++) {
																				var slotObj = {
																					'session_end_date': dataIn.end_date
																				}
																				dbo.collection("TBL_SESSIONS").updateOne({
																					_id: ObjectId(dataIn.session_id)
																				}, {
																					$set: slotObj
																				}, function (err, rese) {
																					console.log('success')
																				})
																				// }
																			})
																		})

																		promise.then(() => {
																			setTimeout(function () {
																				response()
																			}, 150);

																		})

																		// console.log(final_arr)
																		function response() {
																			if (req.body.user_type == 0) {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'client_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENT_INFO',
																							localField: 'client_id',
																							foreignField: 'client_id',
																							as: 'client_info'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'user_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},
																					{
																						"$unwind": "$client_info"
																					},
																					{
																						"$match": {
																							"client_info.trainer_id": ObjectId(req.body.user_id)
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							if (data[0]['client'][0]['timezone'] == undefined) {
																								data[0]['client'][0]['timezone'] = ''
																							}
																							if (data[0]['client'][0]['timezone_str'] == undefined) {
																								data[0]['client'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"client_id": data[0]['client_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0].client_info.first_name,
																								"last_name": data[0].client_info.last_name,
																								"image": data[0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),


																							}
																							res.send({
																								"success": true,
																								"message": "Session created succesfully!",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			} else {
																				dbo.collection('TBL_SESSIONS').aggregate([{
																						$match: {
																							_id: ObjectId(resv.insertedId)
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_CLIENTS',
																							localField: 'user_id',
																							foreignField: '_id',
																							as: 'client'
																						}
																					},

																					{
																						$lookup: {
																							from: 'TBL_TRAINERS',
																							localField: 'trainer_id',
																							foreignField: '_id',
																							as: 'trainer'
																						}
																					},
																					{
																						$lookup: {
																							from: 'TBL_TRAINER_DETAILS',
																							localField: 'trainer_id',
																							foreignField: 'user_id',
																							as: 'trainerdetails'
																						}
																					},

																				]).toArray(function (err, resr) {
																					if (err) {
																						throw err;
																					} else {
																						if (resr) {
																							var data = JSON.parse(JSON.stringify(resr));
																							// console.log(data[0]['clientdetails'])
																							// console.log(data)
																							if (data[0]['trainer'][0]['timezone'] == undefined) {
																								data[0]['trainer'][0]['timezone'] = ''
																							}
																							if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																								data[0]['trainer'][0]['timezone_str'] = ''
																							}
																							if (data[0]['gym_name'] == undefined) {
																								data[0]['gym_name'] = ''
																							}
																							if (data[0]['session_end_date'] == undefined) {
																								data[0]['session_end_date'] = ''
																							}
																							dat = {
																								"id": data[0]['_id'],
																								"client_id": data[0]['client_id'],
																								"trainer_id": data[0]['trainer_id'],
																								"user_type": data[0]['user_type'],
																								"utc": data[0]['utc'],
																								"time": data[0]['time'],
																								"repeat": data[0]['repeat'],
																								"location": data[0]['location'],
																								"duration": data[0]['duration'],
																								"gym_name": data[0]['gym_name'],
																								"first_name": data[0]['trainerdetails'][0]['first_name'],
																								"last_name": data[0]['trainerdetails'][0]['last_name'],
																								"image": data[0]['trainerdetails'][0]['image'],
																								"timezone": data[0]['timezone'],
																								"timezone_str": data[0]['timezone_str'],
																								"status": data[0]['status'],
																								"day": data[0]['day'],
																								"month": data[0]['month'],
																								"year": data[0]['year'],
																								"date_str": data[0]['date_str'],
																								"time_str": data[0]['time_str'],
																								"session_end_date": data[0]['session_end_date'].toString(),
																							}
																							res.send({
																								"success": true,
																								"message": "Session created",
																								"data": dat
																							});
																							return false;
																						} else {
																							res.send({
																								"success": false,
																								"message": "something went wrong",
																								"data": {}
																							});
																							return false;
																						}
																					}

																				});
																			}
																		}

																	})
																}
															})

														}
													});

												}

											}
										}
									})
								} else {
									dbo.collection('TBL_SESSIONS').updateOne({
										_id: ObjectId(session_id_b)
									}, {
										$set: req.body
									}, function (err, rese) {
										if (err) {
											res.send({
												"success": false,
												"message": "Something went wrong!"
											});
											return false;
										} else {
											var slotObj = {
												trainer_id: ObjectId(req.body.user_id),
												client_id: ObjectId(req.body.client_id),
												slot_id: ObjectId(req.body.slot_id),
												day: req.body.day.toString(),
												time: req.body.time.toString(),
												month: req.body.month.toString(),
												year: req.body.year.toString(),
												created_at: getCurrentTime(),
												updated: getCurrentTime()

											}

											dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
												session_id: ObjectId(session_id_b)
											}, {
												$set: slotObj
											}, function (err, rese) {
												console.log('success')
											})
											if (req.body.user_type == 0) {
												dbo.collection('TBL_SESSIONS').aggregate([{
														$match: {
															"_id": ObjectId(session_id_b)
														}
													},
													{
														$lookup: {
															from: 'TBL_CLIENTS',
															localField: 'client_id',
															foreignField: '_id',
															as: 'client'
														}
													},
													{
														$lookup: {
															from: 'TBL_CLIENT_INFO',
															localField: 'client_id',
															foreignField: 'client_id',
															as: 'client_info'
														}
													},
													{
														"$unwind": "$client_info"
													},
													{
														"$match": {
															"client_info.trainer_id": ObjectId(req.body.user_id)
														}
													},
												]).toArray(function (err, resr) {
													if (err) {
														throw err;
													} else {
														if (resr) {
															console.log(resr)
															console.log('resr')

															var data = JSON.parse(JSON.stringify(resr));
															// console.log(data[0]['clientdetails'])
															console.log(data)
															// return
															var dat = [];
															for (var i = 0; i < data.length; i++) {
																if (data[i]['timezone'] == undefined) {
																	data[i]['timezone'] = ''
																}
																if (data[i]['timezone_str'] == undefined) {
																	data[i]['timezone_str'] = ''
																}
																if (data[i]['gym_name'] == undefined) {
																	data[i]['gym_name'] = ''
																}
																if (data[i]['session_end_date'] == undefined) {
																	data[i]['session_end_date'] = ''
																}
																// gym_name: req.body.gym_name,
																dat.push({
																	"id": data[i]['_id'],
																	"trainer_id": data[i]['trainer_id'],
																	"client_id": data[i]['client_id'],
																	"user_type": data[i]['user_type'],
																	"gym_name": data[i]['gym_name'],
																	"utc": data[i]['utc'],
																	"time": data[i]['time'],
																	"repeat": data[i]['repeat'],
																	"location": data[i]['location'],
																	"duration": data[i]['duration'],
																	"first_name": data[i].client_info.first_name,
																	"last_name": data[i].client_info.last_name,
																	"image": data[i]['image'],
																	"timezone": data[i]['timezone'],
																	"timezone_str": data[i]['timezone_str'],
																	"status": data[i]['status'],
																	"date_str": data[i]['date_str'],
																	"time_str": data[i]['time_str'],
																	"day": data[i]['day'],
																	"month": data[i]['month'],
																	"year": data[i]['year'],
																	"session_end_date": data[i]['session_end_date'].toString()
																})
															}
															res.send({
																"success": true,
																"message": "Session Updated",
																"data": dat[0]
															});
															return false;
														} else {
															res.send({
																"success": false,
																"message": "something went wrong",
																"data": {}
															});
															return false;
														}
													}

												});
											} else {
												dbo.collection('TBL_SESSIONS').aggregate([{
														$match: {
															_id: ObjectId(session_id_b)
														}
													},
													{
														$lookup: {
															from: 'TBL_TRAINERS',
															localField: 'trainer_id',
															foreignField: '_id',
															as: 'trainer'
														}
													},
													{
														$lookup: {
															from: 'TBL_TRAINER_DETAILS',
															localField: 'trainer_id',
															foreignField: 'user_id',
															as: 'trainerdetails'
														}
													},

												]).toArray(function (err, resr) {
													if (err) {
														throw err;
													} else {
														if (resr) {
															var data = JSON.parse(JSON.stringify(resr));
															var dat = [];
															for (var i = 0; i < data.length; i++) {
																if (data[i]['timezone'] == undefined) {
																	data[i]['timezone'] = ''
																}
																if (data[i]['timezone_str'] == undefined) {
																	data[i]['timezone_str'] = ''
																}
																if (data[i]['gym_name'] == undefined) {
																	data[i]['gym_name'] = ''
																}
																if (data[i]['session_end_date'] == undefined) {
																	data[i]['session_end_date'] = ''
																}
																dat.push({
																	"id": data[i]['_id'],
																	"client_id": data[i]['client_id'],
																	"trainer_id": data[i]['trainer_id'],
																	"user_type": data[i]['user_type'],
																	"gym_name": data[i]['gym_name'],
																	"utc": data[i]['utc'],
																	"time": data[i]['time'],
																	"repeat": data[i]['repeat'],
																	"location": data[i]['location'],
																	"duration": data[i]['duration'],
																	"first_name": data[i]['trainerdetails'][0]['first_name'],
																	"last_name": data[i]['trainerdetails'][0]['last_name'],
																	"image": data[i]['trainerdetails'][0]['image'],
																	"timezone": data[i]['timezone'],
																	"timezone_str": data[i]['timezone_str'],
																	"status": data[i]['status'],
																	"date_str": data[i]['date_str'],
																	"time_str": data[i]['time_str'],
																	"day": data[i]['day'],
																	"month": data[i]['month'],
																	"year": data[i]['year'],
																	"session_end_date": data[i]['session_end_date'].toString()
																})
															}
															res.send({
																"success": true,
																"message": "Session updated",
																"data": dat[0]
															});
															return false;
														} else {
															res.send({
																"success": false,
																"message": "something went wrong",
																"data": {}
															});
															return false;
														}
													}

												});
											}
										}
									});
								}


							}
						});
					})

				} else if (resv1.payment == '1') {

					if (req.body.reschedule_utc && req.body.reschedule_utc != '' && req.body.reschedule_all && req.body.reschedule_all != '') {


						dbo.collection("TBL_SESSIONS").find({
							"_id": ObjectId(session_id_b)

						}).toArray(async function (err, result_count) {
							if (req.body.user_type == 0) {
								var sessionObj = {
									trainer_id: ObjectId(req.body.user_id),
									client_id: ObjectId(req.body.client_id),
									utc: req.body.utc.toString(),
									duration: req.body.duration,
									location: req.body.location,
									repeat: req.body.repeat,
									gym_name: req.body.gym_name,
									// time: req.body.time_str,
									user_type: req.body.user_type,
									status: 2,
									day: req.body.day,
									month: req.body.month,
									year: req.body.year,
									date_str: req.body.date_str,
									time_str: req.body.time_str,
									timezone_str: req.body.timezone_str,
									time: req.body.time,
									created_at: getCurrentTime(),
									updated: getCurrentTime()
								};
								var slotObj = {
									trainer_id: ObjectId(req.body.user_id),
									client_id: ObjectId(req.body.client_id),
									slot_id: ObjectId(req.body.slot_id),
									day: req.body.day.toString(),
									time: req.body.time.toString(),
									month: req.body.month.toString(),
									year: req.body.year.toString(),
									created_at: getCurrentTime(),
									updated: getCurrentTime(),
									status: '1',
								}
							} else {
								var sessionObj = {
									client_id: ObjectId(req.body.client_id),
									trainer_id: ObjectId(req.body.user_id),
									utc: req.body.utc.toString(),
									duration: req.body.duration,
									location: req.body.location,
									repeat: req.body.repeat,
									gym_name: req.body.gym_name,
									// time: req.body.time,
									user_type: req.body.user_type,
									status: 1,
									day: req.body.day,
									month: req.body.month,
									year: req.body.year,
									date_str: req.body.date_str,
									time_str: req.body.time_str,
									time: req.body.time,
									timezone_str: req.body.timezone_str,
									created_at: getCurrentTime(),
									updated: getCurrentTime()
								};
								var slotObj = {
									trainer_id: ObjectId(req.body.user_id),
									client_id: ObjectId(req.body.client_id),
									slot_id: ObjectId(req.body.slot_id),
									day: req.body.day.toString(),
									time: req.body.time.toString(),
									month: req.body.month.toString(),
									year: req.body.year.toString(),
									created_at: getCurrentTime(),
									updated: getCurrentTime(),
									status: '0',
								}
							}
							if (result_count[0].repeat == '1') {
								if (req.body.reschedule_all == 0) {

									var session_date_time = Number(result_count[0].utc)
									var end_date_time = new Date(req.body.reschedule_utc * 1000)
									end_date_time.setDate(end_date_time.getDate() - 7);

									var start_date_time = new Date(req.body.reschedule_utc * 1000)
									start_date_time.setDate(start_date_time.getDate() + 7);

									var seconds = end_date_time.getTime() / 1000

									var seconds_start = start_date_time.getTime() / 1000

									var start_date = start_date_time.getDate()
									var start_year = start_date_time.getFullYear()
									var start_month = start_date_time.getMonth() + 1

									if (start_date < 10) {
										start_date = '0' + start_date
									}
									if (start_month < 10) {
										start_month = '0' + start_month
									}


									if (Number(seconds) < Number(session_date_time)) {
										var Date_month = new Date(req.body.reschedule_utc * 1000);
										var week_month = getWeekNumber(new Date(Date_month))

										var start_date_time = new Date(req.body.reschedule_utc * 1000)
										start_date_time.setDate(start_date_time.getDate() + 7);
										var seconds_start = start_date_time.getTime() / 1000

										var utc = new Date(result_count[0].utc * 1000)
										utc.setDate(utc.getDate() + 7);
										sessionObj.utc = utc.getTime() / 1000
										console.log('THEREEEEEE THIS UNIQ')
										// console.log('--------BODYYY')
										// console.log(req.body)

										var start_date_time_reschedule = new Date(req.body.utc * 1000)
										// start_date_time_reschedule.setDate(start_date_time_reschedule.getDate());
										var seconds_start_reschedule = start_date_time_reschedule.getTime() / 1000

										console.log('--------start_date_time_reschedule')
										console.log(start_date_time_reschedule)
										var start_date = start_date_time_reschedule.getDate()
										var start_year = start_date_time_reschedule.getFullYear()
										var start_month = start_date_time_reschedule.getMonth() + 1

										if (start_date < 10) {
											start_date = '0' + start_date
										}
										if (start_month < 10) {
											start_month = '0' + start_month
										}
										// logic here
										if (req.body.user_type == 0) {
											  // user_id: '5fe9c04c869f4727171c2f4c',
											  // force: '0',
											  // reschedule_date: '05.22.2021',
											  // day: '21',
											  // duration: '60',
											  // month: '05',
											  // year: '2021',
											  // reschedule_utc: '1621681200',
											  // time_str: '04:00',
											  // reschedule_all: '0',
											  // repeat: '1',
											  // client_id: 601bdd270af98486ddcba1d1,
											  // date_str: '05.21.2021',
											  // timezone_str: 'PST',
											  // slot_id: '6087a2d0c094476a8f31477d',
											  // utc: '1621594800',
											  // location: '0',
											  // user_type: '0',
											  // time: '4',
											  // gym_name: '',
											  // week_month: 20
											var sessionObj1 = {
												trainer_id: ObjectId(result_count[0].trainer_id),
												client_id: ObjectId(result_count[0].client_id),
												utc: seconds_start_reschedule.toString(),
												duration: result_count[0].duration,
												location: result_count[0].location,
												repeat: '0',
												gym_name: result_count[0].gym_name,
												user_type: result_count[0].user_type,
												status: 2,
												day: start_date.toString(),
												month: start_month.toString(),
												year: start_year.toString(),
												date_str: start_month + '.' + start_date + '.' + start_year,
												time_str: result_count[0].time_str,
												timezone_str: result_count[0].timezone_str,
												time: result_count[0].time,
												created_at: getCurrentTime(),
												updated: getCurrentTime(),
												week_month: week_month[1],
												session_end_date: result_count[0].session_end_date
											};


										}
										else{
											var sessionObj1 = {
												trainer_id: ObjectId(result_count[0].trainer_id),
												client_id: ObjectId(result_count[0].client_id),
												utc: seconds_start_reschedule.toString(),
												duration: result_count[0].duration,
												location: result_count[0].location,
												repeat: '0',
												gym_name: result_count[0].gym_name,
												user_type: result_count[0].user_type,
												status: 0,
												day: start_date.toString(),
												month: start_month.toString(),
												year: start_year.toString(),
												date_str: start_month + '.' + start_date + '.' + start_year,
												time_str: result_count[0].time_str,
												timezone_str: result_count[0].timezone_str,
												time: result_count[0].time,
												created_at: getCurrentTime(),
												updated: getCurrentTime(),
												week_month: week_month[1],
												session_end_date: result_count[0].session_end_date
											};
										
										}
										dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {

										})

										 // console.log('--------BODYYY')
										 // console.log(sessionObj1)
										// sessionObj.session_end_date = result_count[0].session_end_date

										req.body.utc = utc.getTime() / 1000
										req.body.utc = req.body.utc.toString()

										var start_date_utc = utc.getDate()
										var start_year_utc = utc.getFullYear()
										var start_month_utc = utc.getMonth() + 1

										if (start_date_utc < 10) {
											start_date_utc = '0' + start_date_utc
										}
										if (start_month_utc < 10) {
											start_month_utc = '0' + start_month_utc
										}

										req.body.date_str = start_month_utc + '.' + start_date_utc + '.' + start_year_utc

										req.body.time_str = result_count[0].time_str

										req.body.time = result_count[0].time

										req.body.session_end_date = result_count[0].session_end_date
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: req.body
										}, function (err, rese) {
											if (err) {
												throw err;
											} else {
												var slotObj = {
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													slot_id: ObjectId(req.body.slot_id),
													day: req.body.day.toString(),
													time: req.body.time.toString(),
													month: req.body.month.toString(),
													year: req.body.year.toString(),
													created_at: getCurrentTime(),
													updated: getCurrentTime()

												}

												dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
													session_id: ObjectId(session_id_b)
												}, {
													$set: slotObj
												}, function (err, rese) {
													console.log('success')
												})

												dbo.collection("TBL_SESSIONS").find({
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													status: {
														$in: [0, 1, 2]
													},
													utc: {
														$gt: getCurrentTime().toString()
													}
												}).sort({
													utc: 1
												}).toArray(async function (err, result_count) {
													// console.log(result_count)
													// console.log(resv1)
													var total_no_of_sessions = Number(resv1.no_of_sessions)
													var total_sessions = result_count
													var counter = -1
													var arr_sess = []

													var loopCount = total_sessions.length
													var onlyOne = false
													var ignore_no_repeat = false
													var j = 0

													var repeat_W_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '1'
														return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
													});
													var repeat_M_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '2'
														return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
													});
													for (var f = 0; f < loopCount; f++) {
														if (ignore_no_repeat == false) {
															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})

															if (loopCount == f + 1) {
																console.log('1st Loop Fin')
																ignore_no_repeat = true
																f = -1
																if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																	break;
																}
															}
															continue;
														}
														// console.log(arr_sess)
														if (arr_sess.length >= total_no_of_sessions) {
															console.log('Loop completed')
															break;
														}

														if (total_sessions[f].repeat == '0') {
															// console.log('continue repeat')
															// continue;
															// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
														} else if (total_sessions[f].repeat == '1') { //weekly

															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})
														} else if (total_sessions[f].repeat == '2') { //Monthly
															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})
														}
														// counter = arr_sess.length
														if (loopCount == f + 1) {
															f = -1
															console.log('Loop Repeating Now')
															continue;
														}

													}

													var result = arr_sess.reduce(function (r, a) {
														if (a.session_type != '0') {
															r[a.session_id] = r[a.session_id] || [];
															r[a.session_id].push(a);

														}
														return r;
													}, {});

													var final_arr = []
													for (key in result) {
														if (result.hasOwnProperty(key)) {
															var value = result[key];
															// console.log(value.length)
															// console.log(value[0].start_date)


															if (value[0].session_type == '1') {
																// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																var date = new Date(Number(value[0].start_date) * 1000)
																var week = (value.length - 1)
																date.setDate(date.getDate() + week * 7);
																var end_date = date.getTime() / 1000;
															} else if (value[0].session_type == '2') {
																var date = new Date(Number(value[0].start_date) * 1000)
																var months = (value.length - 1)
																var d = date.getDate();
																date.setMonth(date.getMonth() + +months);
																if (date.getDate() != d) {
																	date.setDate(0);
																}
																var end_date = date.getTime() / 1000;
															}
															final_arr.push({
																'session_id': value[0].session_id,
																'end_date': end_date,
																'type': value[0].session_type,
																'start_date': value[0].start_date
															})
														}
													}
													let promise = Promise.resolve();
													const posts = final_arr;
													posts.forEach(post => {
														promise = promise.then(() => {
															var dataIn = post
															// for (var p = 0; p < final_arr.length; p++) {
															var slotObj = {
																'session_end_date': dataIn.end_date
															}
															dbo.collection("TBL_SESSIONS").updateOne({
																_id: ObjectId(dataIn.session_id)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})
															// }
														})
													})

													promise.then(() => {
														setTimeout(function () {
															response()
														}, 150);

													})

													// console.log(final_arr)
													function response() {
														session_id_b = sessionObj1._id
														if (req.body.user_type == 0) {
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'client_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENT_INFO',
																		localField: 'client_id',
																		foreignField: 'client_id',
																		as: 'client_info'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'user_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},
																{
																	"$unwind": "$client_info"
																},
																{
																	"$match": {
																		"client_info.trainer_id": ObjectId(req.body.user_id)
																	}
																},
																// {$group: {
																//      _id: "$_id",
																//      client_info: {$push: "$client_info"}
																//  }},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"client_id": data[0]['client_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0].client_info.first_name,
																			"last_name": data[0].client_info.last_name,
																			"image": data[0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),


																		}
																		res.send({
																			"success": true,
																			"message": "Session updated succesfully!",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														} else {
															// sendNotification(req.body.trainer_id,resv.insertedId)
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},
																// {
																// 	$lookup: {
																// 		from: 'TBL_CLIENT_DETAILS',
																// 		localField: 'user_id',
																// 		foreignField: 'user_id',
																// 		as: 'clientdetails'
																// 	}
																// },
																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'trainer_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'trainer_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"client_id": data[0]['client_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0]['trainerdetails'][0]['first_name'],
																			"last_name": data[0]['trainerdetails'][0]['last_name'],
																			"image": data[0]['trainerdetails'][0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),
																		}
																		res.send({
																			"success": true,
																			"message": "Session updated",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														}
													}

												})
											}
										})

										// }
										// });


									} else {

										var Date_month = new Date(req.body.reschedule_utc * 1000);
										var week_month = getWeekNumber(new Date(Date_month))

										var start_date_time = new Date(req.body.reschedule_utc * 1000)
										start_date_time.setDate(start_date_time.getDate() + 7);
										var seconds_start = start_date_time.getTime() / 1000

										var utc = new Date(req.body.utc * 1000)
										// utc.setDate(utc.getDate() + 7);
										sessionObj.utc = utc.getTime() / 1000
										sessionObj.utc = sessionObj.utc.toString()
										sessionObj.repeat = '0'
										console.log('THEREEEEEE ONLY ONE TWO')
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds),
												'ignore': 1
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												console.log('logic here 11--------------------------------------------')
												// logic here
												var sessionObj1 = {
													trainer_id: ObjectId(result_count[0].trainer_id),
													client_id: ObjectId(result_count[0].client_id),
													utc: seconds_start.toString(),
													duration: result_count[0].duration,
													location: result_count[0].location,
													repeat: result_count[0].repeat,
													gym_name: result_count[0].gym_name,
													user_type: result_count[0].user_type,
													status: 2,
													day: start_date.toString(),
													month: start_month.toString(),
													year: start_year.toString(),
													date_str: start_month + '.' + start_date + '.' + start_year,
													time_str: result_count[0].time_str,
													timezone_str: result_count[0].timezone_str,
													time: result_count[0].time,
													created_at: getCurrentTime(),
													updated: getCurrentTime(),
													week_month: week_month[1],
													session_end_date: result_count[0].session_end_date
												};
												dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {
													sessionObj.session_end_date = result_count[0].session_end_date
													dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
														if (err) {
															throw err;
														} else {
															slotObj.session_id = ObjectId(resv.insertedId);
															dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
																console.log('success')
															})
															dbo.collection("TBL_SESSIONS").find({
																trainer_id: ObjectId(req.body.user_id),
																client_id: ObjectId(req.body.client_id),
																status: {
																	$in: [0, 1, 2]
																},
																utc: {
																	$gt: getCurrentTime().toString()
																},
																// ignore: {
																// 	$ne: 1
																// }
															}).sort({
																utc: 1
															}).toArray(async function (err, result_count) {
																console.log(result_count)
																// console.log(resv1)
																var total_no_of_sessions = Number(resv1.no_of_sessions)
																var total_sessions = result_count
																var counter = -1
																var arr_sess = []
																var arr_sess_ignore = []
																var loopCount = total_sessions.length
																var onlyOne = false
																var ignore_no_repeat = false
																var j = 0

																var repeat_W_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '1'
																	return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
																});
																var repeat_M_isPresent = total_sessions.some(function (el) {
																	// return el.repeat === '2'
																	return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
																});
																for (var f = 0; f < loopCount; f++) {
																	if (!total_sessions[f].ignore) {
																		var is_ignore = 0;
																	} else {
																		var is_ignore = total_sessions[f].ignore;
																	}
																	if (!total_sessions[f].session_end_date) {
																		var is_session_end_date = '';
																	} else {
																		var is_session_end_date = total_sessions[f].session_end_date;
																	}
																	if (is_session_end_date != '') {
																		var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																		var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																	} else {
																		var weeks_btw = ''
																		var months_btw = ''
																	}

																	if (ignore_no_repeat == false) {
																		if (is_ignore == 1) {
																			arr_sess_ignore.push({
																				'session_id': total_sessions[f]._id,
																				"start_date": total_sessions[f].utc,
																				"session_type": total_sessions[f].repeat,
																				"is_session_end_date": is_session_end_date,
																				"weeks_btw": weeks_btw,
																				"months_btw": months_btw,
																			})
																		} else {
																			arr_sess.push({
																				'session_id': total_sessions[f]._id,
																				"start_date": total_sessions[f].utc,
																				"session_type": total_sessions[f].repeat,
																				"is_session_end_date": is_session_end_date,
																				"weeks_btw": weeks_btw,
																				"months_btw": months_btw,
																			})
																		}


																		if (loopCount == f + 1) {
																			console.log('1st Loop Fin')
																			ignore_no_repeat = true
																			f = -1
																			// if (loopCount == 1) {
																			// 	f--
																			// }
																			if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																				break;
																			}
																		}
																		continue;
																	}
																	// console.log(arr_sess)
																	if (arr_sess.length >= total_no_of_sessions) {
																		console.log('Loop completed')
																		break;
																	}

																	if (total_sessions[f].repeat == '0') {
																		// console.log('continue repeat')
																		// continue;
																		// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																	} else if (total_sessions[f].repeat == '1') { //weekly
																		if (is_ignore == 1) {
																			arr_sess_ignore.push({
																				'session_id': total_sessions[f]._id,
																				"start_date": total_sessions[f].utc,
																				"session_type": total_sessions[f].repeat,
																				"is_session_end_date": is_session_end_date,
																				"weeks_btw": weeks_btw,
																				"months_btw": months_btw,
																			})
																		} else {
																			arr_sess.push({
																				'session_id': total_sessions[f]._id,
																				"start_date": total_sessions[f].utc,
																				"session_type": total_sessions[f].repeat,
																				"is_session_end_date": is_session_end_date,
																				"weeks_btw": weeks_btw,
																				"months_btw": months_btw,
																			})
																		}

																	} else if (total_sessions[f].repeat == '2') { //Monthly
																		if (is_ignore == 1) {
																			arr_sess_ignore.push({
																				'session_id': total_sessions[f]._id,
																				"start_date": total_sessions[f].utc,
																				"session_type": total_sessions[f].repeat,
																				"is_session_end_date": is_session_end_date,
																				"weeks_btw": weeks_btw,
																				"months_btw": months_btw,
																			})
																		} else {
																			arr_sess.push({
																				'session_id': total_sessions[f]._id,
																				"start_date": total_sessions[f].utc,
																				"session_type": total_sessions[f].repeat,
																				"is_session_end_date": is_session_end_date,
																				"weeks_btw": weeks_btw,
																				"months_btw": months_btw,
																			})
																		}

																	}
																	// counter = arr_sess.length
																	if (loopCount == f + 1) {
																		// if (arr_sess.length < total_no_of_sessions ) {
																		f = -1
																		// if (loopCount == 1) {
																		// 	f--
																		// }
																		console.log('Loop Repeating Now')
																		continue;
																		// }
																	}

																}

																// NEW WEEK LOGIC
																var result_final_ignore = [];
																var total_sessions_in_ignore = 0
																var total_sessions_in_ignore_month = 0

																var seen = Object.create(null)
																result_final_ignore = arr_sess_ignore.filter(o => {
																	var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																	if (!seen[key]) {
																		seen[key] = true;
																		return true;
																	}
																});
																for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																	if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																		result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																	}
																	if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																		result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																	}
																	total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																	result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																	total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																	result_final_ignore[loop_c].total = total_sessions_in_ignore
																}

																var result = arr_sess.reduce(function (r, a) {
																	if (a.session_type != '0') {
																		r[a.session_id] = r[a.session_id] || [];
																		r[a.session_id].push(a);

																	}
																	return r;
																}, {});

																var final_arr = []
																for (key in result) {
																	if (result.hasOwnProperty(key)) {
																		var value = result[key];
																		console.log(value.length)
																		console.log(value[0].start_date)


																		if (value[0].session_type == '1') {
																			// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																			if (!result_final_ignore || result_final_ignore.length == 0) {
																				weeks_to_ignore = 0
																			} else {
																				var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																				if (isNaN(weeks_to_ignore)) {
																					weeks_to_ignore = 0
																				}
																			}

																			var date = new Date(Number(value[0].start_date) * 1000)
																			var week = (value.length - 1)
																			// date.setDate(date.getDate() + week * 7);
																			date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																			var end_date = date.getTime() / 1000;
																			if (Number(end_date) < Number(value[0].start_date)) {
																				var end_date = Number(value[0].start_date)
																			}
																		} else if (value[0].session_type == '2') {
																			if (!result_final_ignore || result_final_ignore.length == 0) {
																				weeks_to_ignore = 0
																			} else {
																				var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																				// weeks_to_ignore = weeks_to_ignore - 1
																				if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																					weeks_to_ignore = 0
																				}
																			}

																			var date = new Date(Number(value[0].start_date) * 1000)
																			var months = ((value.length - 1) - weeks_to_ignore)
																			var d = date.getDate();
																			date.setMonth(date.getMonth() + +months);
																			if (date.getDate() != d) {
																				date.setDate(0);
																			}
																			var end_date = date.getTime() / 1000;
																			// var date = new Date(Number(value[0].start_date) * 1000)
																			// var months = (value.length - 1)
																			// var d = date.getDate();
																			// date.setMonth(date.getMonth() + +months);
																			// if (date.getDate() != d) {
																			// 	date.setDate(0);
																			// }
																			// var end_date = date.getTime() / 1000;
																		}
																		final_arr.push({
																			'session_id': value[0].session_id,
																			'end_date': end_date,
																			'type': value[0].session_type,
																			'start_date': value[0].start_date
																		})
																	}
																}
																let promise = Promise.resolve();
																const posts = final_arr;
																posts.forEach(post => {
																	promise = promise.then(() => {
																		var dataIn = post
																		// for (var p = 0; p < final_arr.length; p++) {
																		var slotObj = {
																			'session_end_date': dataIn.end_date
																		}
																		dbo.collection("TBL_SESSIONS").updateOne({
																			_id: ObjectId(dataIn.session_id)
																		}, {
																			$set: slotObj
																		}, function (err, rese) {
																			console.log('success')
																		})
																		// }
																	})
																})

																promise.then(() => {
																	setTimeout(function () {
																		response()
																	}, 150);

																})

																// console.log(final_arr)
																function response() {
																	if (req.body.user_type == 0) {
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					_id: ObjectId(resv.insertedId)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'client_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENT_INFO',
																					localField: 'client_id',
																					foreignField: 'client_id',
																					as: 'client_info'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'user_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},
																			{
																				"$unwind": "$client_info"
																			},
																			{
																				"$match": {
																					"client_info.trainer_id": ObjectId(req.body.user_id)
																				}
																			},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					if (data[0]['client'][0]['timezone'] == undefined) {
																						data[0]['client'][0]['timezone'] = ''
																					}
																					if (data[0]['client'][0]['timezone_str'] == undefined) {
																						data[0]['client'][0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"client_id": data[0]['client_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0].client_info.first_name,
																						"last_name": data[0].client_info.last_name,
																						"image": data[0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),


																					}
																					res.send({
																						"success": true,
																						"message": "Session created succesfully!",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	} else {
																		dbo.collection('TBL_SESSIONS').aggregate([{
																				$match: {
																					_id: ObjectId(resv.insertedId)
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_CLIENTS',
																					localField: 'user_id',
																					foreignField: '_id',
																					as: 'client'
																				}
																			},

																			{
																				$lookup: {
																					from: 'TBL_TRAINERS',
																					localField: 'trainer_id',
																					foreignField: '_id',
																					as: 'trainer'
																				}
																			},
																			{
																				$lookup: {
																					from: 'TBL_TRAINER_DETAILS',
																					localField: 'trainer_id',
																					foreignField: 'user_id',
																					as: 'trainerdetails'
																				}
																			},

																		]).toArray(function (err, resr) {
																			if (err) {
																				throw err;
																			} else {
																				if (resr) {
																					var data = JSON.parse(JSON.stringify(resr));
																					// console.log(data[0]['clientdetails'])
																					// console.log(data)
																					if (data[0]['trainer'][0]['timezone'] == undefined) {
																						data[0]['trainer'][0]['timezone'] = ''
																					}
																					if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																						data[0]['trainer'][0]['timezone_str'] = ''
																					}
																					if (data[0]['gym_name'] == undefined) {
																						data[0]['gym_name'] = ''
																					}
																					if (data[0]['session_end_date'] == undefined) {
																						data[0]['session_end_date'] = ''
																					}
																					dat = {
																						"id": data[0]['_id'],
																						"client_id": data[0]['client_id'],
																						"trainer_id": data[0]['trainer_id'],
																						"user_type": data[0]['user_type'],
																						"utc": data[0]['utc'],
																						"time": data[0]['time'],
																						"repeat": data[0]['repeat'],
																						"location": data[0]['location'],
																						"duration": data[0]['duration'],
																						"gym_name": data[0]['gym_name'],
																						"first_name": data[0]['trainerdetails'][0]['first_name'],
																						"last_name": data[0]['trainerdetails'][0]['last_name'],
																						"image": data[0]['trainerdetails'][0]['image'],
																						"timezone": data[0]['timezone'],
																						"timezone_str": data[0]['timezone_str'],
																						"status": data[0]['status'],
																						"day": data[0]['day'],
																						"month": data[0]['month'],
																						"year": data[0]['year'],
																						"date_str": data[0]['date_str'],
																						"time_str": data[0]['time_str'],
																						"session_end_date": data[0]['session_end_date'].toString(),
																					}
																					res.send({
																						"success": true,
																						"message": "Session created",
																						"data": dat
																					});
																					return false;
																				} else {
																					res.send({
																						"success": false,
																						"message": "something went wrong",
																						"data": {}
																					});
																					return false;
																				}
																			}

																		});
																	}
																}

															})
														}
													})
												})


											}
										});


									}
								} else {
									// console.log(sessionObj)
									// return
									var Date_month = new Date('' + req.body.year + '/' + req.body.month + '/' + req.body.day + '');
									var week_month = getWeekNumber(new Date(Date_month))
									sessionObj.week_month = week_month[1]

									var session_date_time = Number(result_count[0].utc)

									var end_date_time = new Date(req.body.reschedule_utc * 1000)
									end_date_time.setDate(end_date_time.getDate() - 7);

									var seconds = end_date_time.getTime() / 1000

									// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
									// var week_month = getWeekNumber(new Date(Date_month))
									console.log('end_date_time ' + end_date_time)
									console.log('session_date_time ' + session_date_time)

									if (Number(seconds) < Number(session_date_time)) {
										console.log('HEREEEEEEE TEST TWO')
										req.body.ignore = 0
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: req.body
										}, function (err, rese) {
											if (err) {
												throw err;
											} else {
												var slotObj = {
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													slot_id: ObjectId(req.body.slot_id),
													day: req.body.day.toString(),
													time: req.body.time.toString(),
													month: req.body.month.toString(),
													year: req.body.year.toString(),
													created_at: getCurrentTime(),
													updated: getCurrentTime()

												}

												dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
													session_id: ObjectId(session_id_b)
												}, {
													$set: slotObj
												}, function (err, rese) {
													console.log('success')
												})

												dbo.collection("TBL_SESSIONS").find({
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													status: {
														$in: [0, 1, 2]
													},
													utc: {
														$gt: getCurrentTime().toString()
													},
													// ignore: {
													// 	$ne: 1
													// }
												}).sort({
													utc: 1
												}).toArray(async function (err, result_count) {
													// console.log(result_count)
													// console.log(resv1)
													var total_no_of_sessions = Number(resv1.no_of_sessions)
													var total_sessions = result_count
													var counter = -1
													var arr_sess = []
													var arr_sess_ignore = []

													var loopCount = total_sessions.length
													var onlyOne = false
													var ignore_no_repeat = false
													var j = 0

													var repeat_W_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '1'
														return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
													});
													var repeat_M_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '2'
														return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
													});
													for (var f = 0; f < loopCount; f++) {
														if (!total_sessions[f].ignore) {
															var is_ignore = 0;
														} else {
															var is_ignore = total_sessions[f].ignore;
														}
														if (!total_sessions[f].session_end_date) {
															var is_session_end_date = '';
														} else {
															var is_session_end_date = total_sessions[f].session_end_date;
														}
														if (is_session_end_date != '') {
															var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
															var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
														} else {
															var weeks_btw = ''
															var months_btw = ''
														}

														if (ignore_no_repeat == false) {
															if (is_ignore == 1) {
																arr_sess_ignore.push({
																	'session_id': total_sessions[f]._id,
																	"start_date": total_sessions[f].utc,
																	"session_type": total_sessions[f].repeat,
																	"is_session_end_date": is_session_end_date,
																	"weeks_btw": weeks_btw,
																	"months_btw": months_btw,
																})
															} else {
																arr_sess.push({
																	'session_id': total_sessions[f]._id,
																	"start_date": total_sessions[f].utc,
																	"session_type": total_sessions[f].repeat,
																	"is_session_end_date": is_session_end_date,
																	"weeks_btw": weeks_btw,
																	"months_btw": months_btw,
																})
															}


															if (loopCount == f + 1) {
																console.log('1st Loop Fin')
																ignore_no_repeat = true
																f = -1
																if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																	break;
																}
															}
															continue;
														}
														// console.log(arr_sess)
														if (arr_sess.length >= total_no_of_sessions) {
															console.log('Loop completed')
															break;
														}

														if (total_sessions[f].repeat == '0') {
															// console.log('continue repeat')
															// continue;
															// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
														} else if (total_sessions[f].repeat == '1') { //weekly
															if (is_ignore == 1) {
																arr_sess_ignore.push({
																	'session_id': total_sessions[f]._id,
																	"start_date": total_sessions[f].utc,
																	"session_type": total_sessions[f].repeat,
																	"is_session_end_date": is_session_end_date,
																	"weeks_btw": weeks_btw,
																	"months_btw": months_btw,
																})
															} else {
																arr_sess.push({
																	'session_id': total_sessions[f]._id,
																	"start_date": total_sessions[f].utc,
																	"session_type": total_sessions[f].repeat,
																	"is_session_end_date": is_session_end_date,
																	"weeks_btw": weeks_btw,
																	"months_btw": months_btw,
																})
															}

														} else if (total_sessions[f].repeat == '2') { //Monthly
															if (is_ignore == 1) {
																arr_sess_ignore.push({
																	'session_id': total_sessions[f]._id,
																	"start_date": total_sessions[f].utc,
																	"session_type": total_sessions[f].repeat,
																	"is_session_end_date": is_session_end_date,
																	"weeks_btw": weeks_btw,
																	"months_btw": months_btw,
																})
															} else {
																arr_sess.push({
																	'session_id': total_sessions[f]._id,
																	"start_date": total_sessions[f].utc,
																	"session_type": total_sessions[f].repeat,
																	"is_session_end_date": is_session_end_date,
																	"weeks_btw": weeks_btw,
																	"months_btw": months_btw,
																})
															}

														}
														// counter = arr_sess.length
														if (loopCount == f + 1) {
															f = -1
															console.log('Loop Repeating Now')
															continue;
														}

													}

													// NEW WEEK LOGIC
													var result_final_ignore = [];
													var total_sessions_in_ignore = 0
													var total_sessions_in_ignore_month = 0

													var seen = Object.create(null)
													result_final_ignore = arr_sess_ignore.filter(o => {
														var key = ['_id', 'start_date'].map(k => o[k]).join('|');
														if (!seen[key]) {
															seen[key] = true;
															return true;
														}
													});
													for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
														if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
															result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
														}
														if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
															result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
														}
														total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
														result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
														total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
														result_final_ignore[loop_c].total = total_sessions_in_ignore
													}

													console.log('HEYYYYY____________result_final_ignore********______________')
														console.log(result_final_ignore)
													console.log('HEYYYYY**************************')
													var result = arr_sess.reduce(function (r, a) {
														if (a.session_type != '0') {
															r[a.session_id] = r[a.session_id] || [];
															r[a.session_id].push(a);

														}
														return r;
													}, {});
													console.log('result***********************______________')
														console.log(result)
													console.log('HEYYYYY**************************')
													var final_arr = []
													for (key in result) {
														if (result.hasOwnProperty(key)) {
															var value = result[key];
															// console.log(value.length)
															// console.log(value[0].start_date)


															if (value[0].session_type == '1') {
																// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																if (!result_final_ignore || result_final_ignore.length == 0) {
																	weeks_to_ignore = 0
																} else {
																	var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																	if (isNaN(weeks_to_ignore)) {
																		weeks_to_ignore = 0
																	}
																}


																var date = new Date(Number(value[0].start_date) * 1000)
																var week = (value.length - 1)
																date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																var end_date = date.getTime() / 1000;
																console.log('end_date***********************______________')
																	console.log('end_date '+end_date)
																	console.log('value[0].start_date '+value[0].start_date)
																	console.log('weeks_to_ignore '+weeks_to_ignore)
																	console.log('week '+week)
																console.log('end_date**************************')
																if (Number(end_date) < Number(value[0].start_date)) {
																			var end_date = Number(value[0].start_date)
																		}
																// var end_date_set = new Date(Number(end_date) * 1000)
																// end_date_set.setDate(Number(end_date_set.getDate()) - 7)
																// end_date = end_date_set.getTime() / 1000;

															} else if (value[0].session_type == '2') {
																// var date = new Date(Number(value[0].start_date) * 1000)
																// var months = (value.length - 1)
																// var d = date.getDate();
																// date.setMonth(date.getMonth() + +months);
																// if (date.getDate() != d) {
																// 	date.setDate(0);
																// }
																// var end_date = date.getTime() / 1000;
																if (!result_final_ignore || result_final_ignore.length == 0) {
																	weeks_to_ignore = 0
																} else {
																	var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																	// weeks_to_ignore = weeks_to_ignore - 1
																	if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																		weeks_to_ignore = 0
																	}
																}

																var date = new Date(Number(value[0].start_date) * 1000)
																var months = ((value.length - 1) - weeks_to_ignore)
																var d = date.getDate();
																date.setMonth(date.getMonth() + +months);
																if (date.getDate() != d) {
																	date.setDate(0);
																}
																var end_date = date.getTime() / 1000;
															}
															final_arr.push({
																'session_id': value[0].session_id,
																'end_date': end_date,
																'type': value[0].session_type,
																'start_date': value[0].start_date
															})
														}
													}
													let promise = Promise.resolve();
													const posts = final_arr;
													posts.forEach(post => {
														promise = promise.then(() => {
															var dataIn = post
															// for (var p = 0; p < final_arr.length; p++) {
															// var end_date_set = new Date(Number(dataIn.end_date) * 1000)
															// end_date_set.setDate(Number(end_date_set.getDate()) - 7)
															// end_date_set = end_date_set.getTime() / 1000;

															var slotObj = {
																'session_end_date': dataIn.end_date
															}
															dbo.collection("TBL_SESSIONS").updateOne({
																_id: ObjectId(dataIn.session_id)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})
															// }
														})
													})

													promise.then(() => {
														setTimeout(function () {
															response()
														}, 150);

													})

													// console.log(final_arr)
													function response() {
														if (req.body.user_type == 0) {
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'client_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENT_INFO',
																		localField: 'client_id',
																		foreignField: 'client_id',
																		as: 'client_info'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'user_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},
																{
																	"$unwind": "$client_info"
																},
																{
																	"$match": {
																		"client_info.trainer_id": ObjectId(req.body.user_id)
																	}
																},
																// {$group: {
																//      _id: "$_id",
																//      client_info: {$push: "$client_info"}
																//  }},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"client_id": data[0]['client_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0].client_info.first_name,
																			"last_name": data[0].client_info.last_name,
																			"image": data[0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),


																		}
																		res.send({
																			"success": true,
																			"message": "Session updated succesfully!",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														} else {
															// sendNotification(req.body.trainer_id,resv.insertedId)
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},
																// {
																// 	$lookup: {
																// 		from: 'TBL_CLIENT_DETAILS',
																// 		localField: 'user_id',
																// 		foreignField: 'user_id',
																// 		as: 'clientdetails'
																// 	}
																// },
																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'trainer_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'trainer_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"client_id": data[0]['client_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0]['trainerdetails'][0]['first_name'],
																			"last_name": data[0]['trainerdetails'][0]['last_name'],
																			"image": data[0]['trainerdetails'][0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),
																		}
																		res.send({
																			"success": true,
																			"message": "Session updated",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														}
													}

												})
											}
										})
									} else {
										console.log('THEREEEEEE TEST 2')
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds),
												'ignore': 1
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												// logic here

												dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
													if (err) {
														throw err;
													} else {
														slotObj.session_id = ObjectId(resv.insertedId);
														dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
															console.log('success')
														})
														dbo.collection("TBL_SESSIONS").find({
															trainer_id: ObjectId(req.body.user_id),
															client_id: ObjectId(req.body.client_id),
															status: {
																$in: [0, 1, 2]
															},
															utc: {
																$gt: getCurrentTime().toString()
															},
															// ignore: {
															// 	$ne: 1
															// }
														}).sort({
															utc: 1
														}).toArray(async function (err, result_count) {
															console.log(result_count)
															// console.log(resv1)
															var total_no_of_sessions = Number(resv1.no_of_sessions)
															var total_sessions = result_count
															var counter = -1
															var arr_sess = []
															var arr_sess_ignore = []
															var loopCount = total_sessions.length
															var onlyOne = false
															var ignore_no_repeat = false
															var j = 0

															var repeat_W_isPresent = total_sessions.some(function (el) {
																// return el.repeat === '1'
																return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
															});
															var repeat_M_isPresent = total_sessions.some(function (el) {
																// return el.repeat === '2'
																return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
															});
															for (var f = 0; f < loopCount; f++) {
																if (!total_sessions[f].ignore) {
																	var is_ignore = 0;
																} else {
																	var is_ignore = total_sessions[f].ignore;
																}
																if (!total_sessions[f].session_end_date) {
																	var is_session_end_date = '';
																} else {
																	var is_session_end_date = total_sessions[f].session_end_date;
																}
																if (is_session_end_date != '') {
																	var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																	var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																} else {
																	var weeks_btw = ''
																	var months_btw = ''
																}

																if (ignore_no_repeat == false) {
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"ignore": is_ignore,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"ignore": is_ignore,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}


																	if (loopCount == f + 1) {
																		console.log('1st Loop Fin')
																		ignore_no_repeat = true
																		f = -1
																		// if (loopCount == 1) {
																		// 	f--
																		// }
																		if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																			break;
																		}
																	}
																	continue;
																}
																// console.log(arr_sess)
																if (arr_sess.length >= total_no_of_sessions) {
																	console.log('Loop completed')
																	break;
																}

																if (total_sessions[f].repeat == '0') {
																	// console.log('continue repeat')
																	// continue;
																	// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																} else if (total_sessions[f].repeat == '1') { //weekly
																	if (is_ignore == 1) {

																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"ignore": is_ignore,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"ignore": is_ignore,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}
																} else if (total_sessions[f].repeat == '2') { //Monthly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"ignore": is_ignore,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"ignore": is_ignore,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																}
																// counter = arr_sess.length
																if (loopCount == f + 1) {
																	// if (arr_sess.length < total_no_of_sessions ) {
																	f = -1
																	// if (loopCount == 1) {
																	// 	f--
																	// }
																	console.log('Loop Repeating Now')
																	continue;
																	// }
																}

															}

															// NEW WEEK LOGIC
															// console.log(arr_sess_ignore);
															// console.log('**************************arr_sess_ohmnoreeee');
															var result_final_ignore = [];
															var total_sessions_in_ignore = 0
															var total_sessions_in_ignore_month = 0

															var seen = Object.create(null)
															result_final_ignore = arr_sess_ignore.filter(o => {
																var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																if (!seen[key]) {
																	seen[key] = true;
																	return true;
																}
															});
															for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																	result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																}
																if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																	result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																}
																total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																result_final_ignore[loop_c].total = total_sessions_in_ignore
															}
															console.log(result_final_ignore)
															console.log('**************************result_final_ignore')
															// console.log(arr_sess);
															// console.log('**************************arr_sess');
															var result = arr_sess.reduce(function (r, a) {
																if (a.session_type != '0') {
																	r[a.session_id] = r[a.session_id] || [];
																	r[a.session_id].push(a);

																}
																return r;
															}, {});

															var final_arr = []
															// console.log(result)
															// console.log('result-------------------------------')
															for (key in result) {
																if (result.hasOwnProperty(key)) {
																	var value = result[key];
																	// console.log('value.length '+ value.length)
																	// console.log('value[0].start_date '+ value[0].start_date)
																	// console.log(value)
																	// console.log('-------------------value')

																	if (value[0].session_type == '1') {
																		// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																			if (isNaN(weeks_to_ignore)) {
																				weeks_to_ignore = 0
																			}
																		}
																		var date = new Date(Number(value[0].start_date) * 1000)
																		var week = (value.length - 1)
																		date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																		var end_date = date.getTime() / 1000;
																		if (Number(end_date) < Number(value[0].start_date)) {
																			var end_date = Number(value[0].start_date)
																		}
																		// console.log('end_date------------- '+ end_date)

																		// var end_date_set = new Date(Number(end_date) * 1000)
																		// end_date_set.setDate(Number(end_date_set.getDate()) - 7)
																		// end_date = end_date_set.getTime() / 1000;
																	} else if (value[0].session_type == '2') {
																		// var date = new Date(Number(value[0].start_date) * 1000)
																		// var months = (value.length - 1)
																		// var d = date.getDate();
																		// date.setMonth(date.getMonth() + +months);
																		// if (date.getDate() != d) {
																		// 	date.setDate(0);
																		// }
																		// var end_date = date.getTime() / 1000;
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																			// weeks_to_ignore = weeks_to_ignore - 1
																			if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var months = ((value.length - 1) - weeks_to_ignore)
																		var d = date.getDate();
																		date.setMonth(date.getMonth() + +months);
																		if (date.getDate() != d) {
																			date.setDate(0);
																		}
																		var end_date = date.getTime() / 1000;

																	}
																	final_arr.push({
																		'session_id': value[0].session_id,
																		'end_date': end_date,
																		'type': value[0].session_type,
																		'start_date': value[0].start_date
																	})
																}
															}
															let promise = Promise.resolve();
															const posts = final_arr;
															posts.forEach(post => {
																promise = promise.then(() => {
																	var dataIn = post
																	// for (var p = 0; p < final_arr.length; p++) {
																	// console.log('session_end_date------------------ ' + dataIn.end_date)
																	var slotObj = {
																		'session_end_date': dataIn.end_date
																	}
																	dbo.collection("TBL_SESSIONS").updateOne({
																		_id: ObjectId(dataIn.session_id)
																	}, {
																		$set: slotObj
																	}, function (err, rese) {
																		console.log('success')
																	})
																	// }
																})
															})

															promise.then(() => {
																setTimeout(function () {
																	response()
																}, 150);

															})

															// console.log(final_arr)
															function response() {
																if (req.body.user_type == 0) {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'client_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENT_INFO',
																				localField: 'client_id',
																				foreignField: 'client_id',
																				as: 'client_info'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'user_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},
																		{
																			"$unwind": "$client_info"
																		},
																		{
																			"$match": {
																				"client_info.trainer_id": ObjectId(req.body.user_id)
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				if (data[0]['client'][0]['timezone'] == undefined) {
																					data[0]['client'][0]['timezone'] = ''
																				}
																				if (data[0]['client'][0]['timezone_str'] == undefined) {
																					data[0]['client'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"client_id": data[0]['client_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0].client_info.first_name,
																					"last_name": data[0].client_info.last_name,
																					"image": data[0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),


																				}
																				res.send({
																					"success": true,
																					"message": "Session created succesfully!",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																} else {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},

																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'trainer_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'trainer_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				// console.log(data[0]['clientdetails'])
																				// console.log(data)
																				if (data[0]['trainer'][0]['timezone'] == undefined) {
																					data[0]['trainer'][0]['timezone'] = ''
																				}
																				if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																					data[0]['trainer'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"client_id": data[0]['client_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0]['trainerdetails'][0]['first_name'],
																					"last_name": data[0]['trainerdetails'][0]['last_name'],
																					"image": data[0]['trainerdetails'][0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),
																				}
																				res.send({
																					"success": true,
																					"message": "Session created",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																}
															}

														})
													}
												})

											}
										});
									}

								}
							} else if (result_count[0].repeat == '2') {
								console.log('I am here')
								if (req.body.reschedule_all == 0) {
									console.log('I am now here')
									var session_end_date = Number(result_count[0].session_end_date)
									var session_date_time = Number(result_count[0].utc)
									var end_date_time = new Date(req.body.reschedule_utc * 1000)
									end_date_time.setMonth(end_date_time.getMonth() - 1);

									var start_date_time = new Date(req.body.reschedule_utc * 1000)
									start_date_time.setMonth(start_date_time.getMonth() + 1);


									var seconds = end_date_time.getTime() / 1000

									var seconds_start = start_date_time.getTime() / 1000

									var start_date = start_date_time.getDate()
									var start_year = start_date_time.getFullYear()
									var start_month = start_date_time.getMonth() + 1

									if (start_date < 10) {
										start_date = '0' + start_date
									}
									if (start_month < 10) {
										start_month = '0' + start_month
									}

									if (Number(seconds) < Number(session_date_time)) {


										var utc1 = new Date(result_count[0].utc * 1000)
										utc1.setMonth(utc1.getMonth() + 1);
										var new_utc = utc1.getTime() / 1000

										var start_date = utc1.getDate()
										var start_year = utc1.getFullYear()
										var start_month = utc1.getMonth() + 1

										if (start_date < 10) {
											start_date = '0' + start_date
										}
										if (start_month < 10) {
											start_month = '0' + start_month
										}

										var Date_month = new Date(utc1.getTime());
										var week_month = getWeekNumber(new Date(Date_month))
										// console.log('new_utc '+new_utc)
										// console.log('new Date(result_count[0].utc * 1000) '+start_month)
										// req.body.week_month = week_month[1]
										var sessionObj1 = {
											trainer_id: ObjectId(result_count[0].trainer_id),
											client_id: ObjectId(result_count[0].client_id),
											utc: new_utc.toString(),
											duration: result_count[0].duration,
											location: result_count[0].location,
											repeat: '2',
											gym_name: result_count[0].gym_name,
											user_type: result_count[0].user_type,
											status: 2,
											day: start_date.toString(),
											month: start_month.toString(),
											year: start_year.toString(),
											date_str: start_month + '.' + start_date + '.' + start_year,
											time_str: result_count[0].time_str,
											timezone_str: result_count[0].timezone_str,
											time: result_count[0].time,
											created_at: getCurrentTime(),
											updated: getCurrentTime(),
											week_month: week_month[1],
											session_end_date: result_count[0].session_end_date
										};
										// console.log(sessionObj1)
										// return
										dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {

										})
										console.log('HEREEEEEEE2222333333')

										req.body.repeat = '0'
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: req.body
										}, function (err, rese) {
											if (err) {
												throw err;
											} else {
												var slotObj = {
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													slot_id: ObjectId(req.body.slot_id),
													day: req.body.day.toString(),
													time: req.body.time.toString(),
													month: req.body.month.toString(),
													year: req.body.year.toString(),
													created_at: getCurrentTime(),
													updated: getCurrentTime()

												}

												dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
													session_id: ObjectId(session_id_b)
												}, {
													$set: slotObj
												}, function (err, rese) {
													console.log('success')
												})

												dbo.collection("TBL_SESSIONS").find({
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													status: {
														$in: [0, 1, 2]
													},
													utc: {
														$gt: getCurrentTime().toString()
													}
												}).sort({
													utc: 1
												}).toArray(async function (err, result_count) {
													console.log(result_count)
													// console.log(resv1)
													var total_no_of_sessions = Number(resv1.no_of_sessions)
													var total_sessions = result_count
													var counter = -1
													var arr_sess = []

													var loopCount = total_sessions.length
													var onlyOne = false
													var ignore_no_repeat = false
													var j = 0

													var repeat_W_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '1'
														return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
													});
													var repeat_M_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '2'
														return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
													});
													for (var f = 0; f < loopCount; f++) {
														if (ignore_no_repeat == false) {
															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})

															if (loopCount == f + 1) {
																console.log('1st Loop Fin')
																ignore_no_repeat = true
																f = -1
																if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																	break;
																}
															}
															continue;
														}
														// console.log(arr_sess)
														if (arr_sess.length >= total_no_of_sessions) {
															console.log('Loop completed')
															break;
														}

														if (total_sessions[f].repeat == '0') {
															// console.log('continue repeat')
															// continue;
															// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
														} else if (total_sessions[f].repeat == '1') { //weekly

															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})
														} else if (total_sessions[f].repeat == '2') { //Monthly
															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})
														}
														// counter = arr_sess.length
														if (loopCount == f + 1) {
															f = -1
															console.log('Loop Repeating Now')
															continue;
														}

													}

													var result = arr_sess.reduce(function (r, a) {
														if (a.session_type != '0') {
															r[a.session_id] = r[a.session_id] || [];
															r[a.session_id].push(a);

														}
														return r;
													}, {});

													var final_arr = []
													for (key in result) {
														if (result.hasOwnProperty(key)) {
															var value = result[key];
															// console.log(value.length)
															// console.log(value[0].start_date)


															if (value[0].session_type == '1') {
																// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																var date = new Date(Number(value[0].start_date) * 1000)
																var week = (value.length - 1)
																date.setDate(date.getDate() + week * 7);
																var end_date = date.getTime() / 1000;
															} else if (value[0].session_type == '2') {
																var date = new Date(Number(value[0].start_date) * 1000)
																var months = (value.length - 1)
																var d = date.getDate();
																date.setMonth(date.getMonth() + +months);
																if (date.getDate() != d) {
																	date.setDate(0);
																}
																var end_date = date.getTime() / 1000;
															}
															final_arr.push({
																'session_id': value[0].session_id,
																'end_date': end_date,
																'type': value[0].session_type,
																'start_date': value[0].start_date
															})
														}
													}
													let promise = Promise.resolve();
													const posts = final_arr;
													posts.forEach(post => {
														promise = promise.then(() => {
															var dataIn = post
															// for (var p = 0; p < final_arr.length; p++) {
															var slotObj = {
																'session_end_date': dataIn.end_date
															}
															dbo.collection("TBL_SESSIONS").updateOne({
																_id: ObjectId(dataIn.session_id)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})
															// }
														})
													})

													promise.then(() => {
														setTimeout(function () {
															response()
														}, 150);

													})

													// console.log(final_arr)
													function response() {
														if (req.body.user_type == 0) {
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'client_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENT_INFO',
																		localField: 'client_id',
																		foreignField: 'client_id',
																		as: 'client_info'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'user_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},
																{
																	"$unwind": "$client_info"
																},
																{
																	"$match": {
																		"client_info.trainer_id": ObjectId(req.body.user_id)
																	}
																},
																// {$group: {
																//      _id: "$_id",
																//      client_info: {$push: "$client_info"}
																//  }},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"client_id": data[0]['client_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0].client_info.first_name,
																			"last_name": data[0].client_info.last_name,
																			"image": data[0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),


																		}
																		res.send({
																			"success": true,
																			"message": "Session updated succesfully!",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														} else {
															// sendNotification(req.body.trainer_id,resv.insertedId)
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},

																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'trainer_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'trainer_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"client_id": data[0]['client_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0]['trainerdetails'][0]['first_name'],
																			"last_name": data[0]['trainerdetails'][0]['last_name'],
																			"image": data[0]['trainerdetails'][0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),
																		}
																		res.send({
																			"success": true,
																			"message": "Session updated",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														}
													}

												})
											}
										})

									} else if (Number(seconds_start) > Number(session_end_date)) {


										// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
										var Date_month = new Date(seconds_start * 1000);
										var week_month = getWeekNumber(new Date(Date_month))


										console.log('THEREEEEEE2222333333 Number(seconds_start) > Number(session_end_date 444444')
										// var end_date_time1 = new Date(result_count[0].utc * 1000)
										// end_date_time1.setMonth(end_date_time1.getMonth() - 1);
										// var seconds1 = end_date_time1.getTime() / 1000

										var utc1 = new Date(req.body.reschedule_utc * 1000)
										utc1.setMonth(utc1.getMonth() + 1);
										var new_utc = utc1.getTime() / 1000


										// var sessionObj1 = {
										// 	trainer_id: ObjectId(result_count[0].trainer_id),
										// 	client_id: ObjectId(result_count[0].client_id),
										// 	utc: new_utc.toString(),
										// 	duration: result_count[0].duration,
										// 	location: result_count[0].location,
										// 	repeat: '2',
										// 	gym_name: result_count[0].gym_name,
										// 	user_type: result_count[0].user_type,
										// 	status: 2,
										// 	day: start_date.toString(),
										// 	month: start_month.toString(),
										// 	year: start_year.toString(),
										// 	date_str: start_month + '.' + start_date + '.' + start_year,
										// 	time_str: result_count[0].time_str,
										// 	timezone_str: result_count[0].timezone_str,
										// 	time: result_count[0].time,
										// 	created_at: getCurrentTime(),
										// 	updated: getCurrentTime(),
										// 	week_month: week_month[1],
										// 	session_end_date: result_count[0].session_end_date,
										// 	ignore:1
										// };
										// dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {

										// })

										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds),
												'ignore': 1
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												// logic here
												sessionObj.repeat = '0'
												dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
													if (err) {
														throw err;
													} else {
														slotObj.session_id = ObjectId(resv.insertedId);
														dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
															console.log('success')
														})
														dbo.collection("TBL_SESSIONS").find({
															trainer_id: ObjectId(req.body.user_id),
															client_id: ObjectId(req.body.client_id),
															status: {
																$in: [0, 1, 2]
															},
															utc: {
																$gt: getCurrentTime().toString()
															},
															// ignore: {
															// 	$ne: 1
															// }
														}).sort({
															utc: 1
														}).toArray(async function (err, result_count) {
															console.log(result_count)
															// console.log(resv1)
															var total_no_of_sessions = Number(resv1.no_of_sessions)
															var total_sessions = result_count
															var counter = -1
															var arr_sess = []
															var arr_sess_ignore = []

															var loopCount = total_sessions.length
															var onlyOne = false
															var ignore_no_repeat = false
															var j = 0

															var repeat_W_isPresent = total_sessions.some(function (el) {
																// return el.repeat === '1'
																return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
															});
															var repeat_M_isPresent = total_sessions.some(function (el) {
																// return el.repeat === '2'
																return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
															});
															for (var f = 0; f < loopCount; f++) {
																if (!total_sessions[f].ignore) {
																	var is_ignore = 0;
																} else {
																	var is_ignore = total_sessions[f].ignore;
																}
																if (!total_sessions[f].session_end_date) {
																	var is_session_end_date = '';
																} else {
																	var is_session_end_date = total_sessions[f].session_end_date;
																}
																if (is_session_end_date != '') {
																	var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																	var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																} else {
																	var weeks_btw = ''
																	var months_btw = ''
																}

																if (ignore_no_repeat == false) {
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}


																	if (loopCount == f + 1) {
																		console.log('1st Loop Fin')
																		ignore_no_repeat = true
																		f = -1
																		// if (loopCount == 1) {
																		// 	f--
																		// }
																		if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																			break;
																		}
																	}
																	continue;
																}
																// console.log(arr_sess)
																if (arr_sess.length >= total_no_of_sessions) {
																	console.log('Loop completed')
																	break;
																}

																if (total_sessions[f].repeat == '0') {
																	// console.log('continue repeat')
																	// continue;
																	// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																} else if (total_sessions[f].repeat == '1') { //weekly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																} else if (total_sessions[f].repeat == '2') { //Monthly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}
																}
																// counter = arr_sess.length
																if (loopCount == f + 1) {
																	// if (arr_sess.length < total_no_of_sessions ) {
																	f = -1
																	// if (loopCount == 1) {
																	// 	f--
																	// }
																	console.log('Loop Repeating Now')
																	continue;
																	// }
																}

															}

															// NEW WEEK LOGIC
															var result_final_ignore = [];
															var total_sessions_in_ignore = 0
															var total_sessions_in_ignore_month = 0

															var seen = Object.create(null)
															result_final_ignore = arr_sess_ignore.filter(o => {
																var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																if (!seen[key]) {
																	seen[key] = true;
																	return true;
																}
															});
															for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																	result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																}
																if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																	result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																}
																total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																result_final_ignore[loop_c].total = total_sessions_in_ignore
															}

															var result = arr_sess.reduce(function (r, a) {
																if (a.session_type != '0') {
																	r[a.session_id] = r[a.session_id] || [];
																	r[a.session_id].push(a);

																}
																return r;
															}, {});

															var final_arr = []
															for (key in result) {
																if (result.hasOwnProperty(key)) {
																	var value = result[key];
																	console.log(value.length)
																	console.log(value[0].start_date)


																	if (value[0].session_type == '1') {
																		// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																			if (isNaN(weeks_to_ignore)) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var week = (value.length - 1)
																		// date.setDate(date.getDate() + week * 7);
																		date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																		var end_date = date.getTime() / 1000;
																		if (Number(end_date) < Number(value[0].start_date)) {
																			var end_date = Number(value[0].start_date)
																		}
																	} else if (value[0].session_type == '2') {
																		// var date = new Date(Number(value[0].start_date) * 1000)
																		// var months = (value.length - 1)
																		// var d = date.getDate();
																		// date.setMonth(date.getMonth() + +months);
																		// if (date.getDate() != d) {
																		// 	date.setDate(0);
																		// }
																		// var end_date = date.getTime() / 1000;
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																			// weeks_to_ignore = weeks_to_ignore - 1
																			if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var months = ((value.length - 1) - weeks_to_ignore)
																		var d = date.getDate();
																		date.setMonth(date.getMonth() + +months);
																		if (date.getDate() != d) {
																			date.setDate(0);
																		}
																		var end_date = date.getTime() / 1000;
																	}
																	final_arr.push({
																		'session_id': value[0].session_id,
																		'end_date': end_date,
																		'type': value[0].session_type,
																		'start_date': value[0].start_date
																	})
																}
															}
															let promise = Promise.resolve();
															const posts = final_arr;
															posts.forEach(post => {
																promise = promise.then(() => {
																	var dataIn = post
																	// for (var p = 0; p < final_arr.length; p++) {
																	var slotObj = {
																		'session_end_date': dataIn.end_date
																	}
																	dbo.collection("TBL_SESSIONS").updateOne({
																		_id: ObjectId(dataIn.session_id)
																	}, {
																		$set: slotObj
																	}, function (err, rese) {
																		console.log('success')
																	})
																	// }
																})
															})

															promise.then(() => {
																setTimeout(function () {
																	response()
																}, 150);

															})

															// console.log(final_arr)
															function response() {
																if (req.body.user_type == 0) {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'client_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENT_INFO',
																				localField: 'client_id',
																				foreignField: 'client_id',
																				as: 'client_info'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'user_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},
																		{
																			"$unwind": "$client_info"
																		},
																		{
																			"$match": {
																				"client_info.trainer_id": ObjectId(req.body.user_id)
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				if (data[0]['client'][0]['timezone'] == undefined) {
																					data[0]['client'][0]['timezone'] = ''
																				}
																				if (data[0]['client'][0]['timezone_str'] == undefined) {
																					data[0]['client'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"client_id": data[0]['client_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0].client_info.first_name,
																					"last_name": data[0].client_info.last_name,
																					"image": data[0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),


																				}
																				res.send({
																					"success": true,
																					"message": "Session created succesfully!",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																} else {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},

																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'trainer_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'trainer_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				// console.log(data[0]['clientdetails'])
																				// console.log(data)
																				if (data[0]['trainer'][0]['timezone'] == undefined) {
																					data[0]['trainer'][0]['timezone'] = ''
																				}
																				if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																					data[0]['trainer'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"client_id": data[0]['client_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0]['trainerdetails'][0]['first_name'],
																					"last_name": data[0]['trainerdetails'][0]['last_name'],
																					"image": data[0]['trainerdetails'][0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),
																				}
																				res.send({
																					"success": true,
																					"message": "Session created",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																}
															}

														})
													}
												})

											}
										});
									} else {

										// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
										var Date_month = new Date(seconds_start * 1000);
										var week_month = getWeekNumber(new Date(Date_month))


										console.log('THEREEEEEE2222333333 TWOO')
										// var end_date_time1 = new Date(result_count[0].utc * 1000)
										// end_date_time1.setMonth(end_date_time1.getMonth() - 1);
										// var seconds1 = end_date_time1.getTime() / 1000

										var utc1 = new Date(req.body.reschedule_utc * 1000)
										utc1.setMonth(utc1.getMonth() + 1);
										var new_utc = utc1.getTime() / 1000


										var sessionObj1 = {
											trainer_id: ObjectId(result_count[0].trainer_id),
											client_id: ObjectId(result_count[0].client_id),
											utc: new_utc.toString(),
											duration: result_count[0].duration,
											location: result_count[0].location,
											repeat: '2',
											gym_name: result_count[0].gym_name,
											user_type: result_count[0].user_type,
											status: 2,
											day: start_date.toString(),
											month: start_month.toString(),
											year: start_year.toString(),
											date_str: start_month + '.' + start_date + '.' + start_year,
											time_str: result_count[0].time_str,
											timezone_str: result_count[0].timezone_str,
											time: result_count[0].time,
											created_at: getCurrentTime(),
											updated: getCurrentTime(),
											week_month: week_month[1],
											session_end_date: result_count[0].session_end_date,
											ignore: 1
										};
										dbo.collection("TBL_SESSIONS").insertOne(sessionObj1, function (err, resv) {

										})

										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds),
												'ignore': 1
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												// logic here
												sessionObj.repeat = '0'
												dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
													if (err) {
														throw err;
													} else {
														slotObj.session_id = ObjectId(resv.insertedId);
														dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
															console.log('success')
														})
														dbo.collection("TBL_SESSIONS").find({
															trainer_id: ObjectId(req.body.user_id),
															client_id: ObjectId(req.body.client_id),
															status: {
																$in: [0, 1, 2]
															},
															utc: {
																$gt: getCurrentTime().toString()
															},
															// ignore: {
															// 	$ne: 1
															// }
														}).sort({
															utc: 1
														}).toArray(async function (err, result_count) {
															console.log(result_count)
															// console.log(resv1)
															var total_no_of_sessions = Number(resv1.no_of_sessions)
															var total_sessions = result_count
															var counter = -1
															var arr_sess = []
															var arr_sess_ignore = []

															var loopCount = total_sessions.length
															var onlyOne = false
															var ignore_no_repeat = false
															var j = 0

															var repeat_W_isPresent = total_sessions.some(function (el) {
																// return el.repeat === '1'
																return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
															});
															var repeat_M_isPresent = total_sessions.some(function (el) {
																// return el.repeat === '2'
																return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
															});
															for (var f = 0; f < loopCount; f++) {
																if (!total_sessions[f].ignore) {
																	var is_ignore = 0;
																} else {
																	var is_ignore = total_sessions[f].ignore;
																}
																if (!total_sessions[f].session_end_date) {
																	var is_session_end_date = '';
																} else {
																	var is_session_end_date = total_sessions[f].session_end_date;
																}
																if (is_session_end_date != '') {
																	var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																	var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																} else {
																	var weeks_btw = ''
																	var months_btw = ''
																}

																if (ignore_no_repeat == false) {
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}


																	if (loopCount == f + 1) {
																		console.log('1st Loop Fin')
																		ignore_no_repeat = true
																		f = -1
																		// if (loopCount == 1) {
																		// 	f--
																		// }
																		if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																			break;
																		}
																	}
																	continue;
																}
																// console.log(arr_sess)
																if (arr_sess.length >= total_no_of_sessions) {
																	console.log('Loop completed')
																	break;
																}

																if (total_sessions[f].repeat == '0') {
																	// console.log('continue repeat')
																	// continue;
																	// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																} else if (total_sessions[f].repeat == '1') { //weekly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																} else if (total_sessions[f].repeat == '2') { //Monthly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																}
																// counter = arr_sess.length
																if (loopCount == f + 1) {
																	// if (arr_sess.length < total_no_of_sessions ) {
																	f = -1
																	// if (loopCount == 1) {
																	// 	f--
																	// }
																	console.log('Loop Repeating Now')
																	continue;
																	// }
																}

															}

															// NEW WEEK LOGIC
															var result_final_ignore = [];
															var total_sessions_in_ignore = 0
															var total_sessions_in_ignore_month = 0

															var seen = Object.create(null)
															result_final_ignore = arr_sess_ignore.filter(o => {
																var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																if (!seen[key]) {
																	seen[key] = true;
																	return true;
																}
															});
															for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																	result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																}
																if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																	result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																}
																total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																result_final_ignore[loop_c].total = total_sessions_in_ignore
															}

															var result = arr_sess.reduce(function (r, a) {
																if (a.session_type != '0') {
																	r[a.session_id] = r[a.session_id] || [];
																	r[a.session_id].push(a);

																}
																return r;
															}, {});

															var final_arr = []
															for (key in result) {
																if (result.hasOwnProperty(key)) {
																	var value = result[key];
																	console.log(value.length)
																	console.log(value[0].start_date)


																	if (value[0].session_type == '1') {
																		// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																			if (isNaN(weeks_to_ignore)) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var week = (value.length - 1)
																		// date.setDate(date.getDate() + week * 7);
																		date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																		var end_date = date.getTime() / 1000;
																		if (Number(end_date) < Number(value[0].start_date)) {
																			var end_date = Number(value[0].start_date)
																		}
																	} else if (value[0].session_type == '2') {
																		// var date = new Date(Number(value[0].start_date) * 1000)
																		// var months = (value.length - 1)
																		// var d = date.getDate();
																		// date.setMonth(date.getMonth() + +months);
																		// if (date.getDate() != d) {
																		// 	date.setDate(0);
																		// }
																		// var end_date = date.getTime() / 1000;
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																			// weeks_to_ignore = weeks_to_ignore - 1
																			if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var months = ((value.length - 1) - weeks_to_ignore)
																		var d = date.getDate();
																		date.setMonth(date.getMonth() + +months);
																		if (date.getDate() != d) {
																			date.setDate(0);
																		}
																		var end_date = date.getTime() / 1000;
																	}
																	final_arr.push({
																		'session_id': value[0].session_id,
																		'end_date': end_date,
																		'type': value[0].session_type,
																		'start_date': value[0].start_date
																	})
																}
															}
															let promise = Promise.resolve();
															const posts = final_arr;
															posts.forEach(post => {
																promise = promise.then(() => {
																	var dataIn = post
																	// for (var p = 0; p < final_arr.length; p++) {
																	var slotObj = {
																		'session_end_date': dataIn.end_date
																	}
																	dbo.collection("TBL_SESSIONS").updateOne({
																		_id: ObjectId(dataIn.session_id)
																	}, {
																		$set: slotObj
																	}, function (err, rese) {
																		console.log('success')
																	})
																	// }
																})
															})

															promise.then(() => {
																setTimeout(function () {
																	response()
																}, 150);

															})

															// console.log(final_arr)
															function response() {
																if (req.body.user_type == 0) {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'client_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENT_INFO',
																				localField: 'client_id',
																				foreignField: 'client_id',
																				as: 'client_info'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'user_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},
																		{
																			"$unwind": "$client_info"
																		},
																		{
																			"$match": {
																				"client_info.trainer_id": ObjectId(req.body.user_id)
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				if (data[0]['client'][0]['timezone'] == undefined) {
																					data[0]['client'][0]['timezone'] = ''
																				}
																				if (data[0]['client'][0]['timezone_str'] == undefined) {
																					data[0]['client'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"client_id": data[0]['client_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0].client_info.first_name,
																					"last_name": data[0].client_info.last_name,
																					"image": data[0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),


																				}
																				res.send({
																					"success": true,
																					"message": "Session created succesfully!",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																} else {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},

																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'trainer_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'trainer_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				// console.log(data[0]['clientdetails'])
																				// console.log(data)
																				if (data[0]['trainer'][0]['timezone'] == undefined) {
																					data[0]['trainer'][0]['timezone'] = ''
																				}
																				if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																					data[0]['trainer'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"client_id": data[0]['client_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0]['trainerdetails'][0]['first_name'],
																					"last_name": data[0]['trainerdetails'][0]['last_name'],
																					"image": data[0]['trainerdetails'][0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),
																				}
																				res.send({
																					"success": true,
																					"message": "Session created",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																}
															}

														})
													}
												})

											}
										});
									}
								} else {
									console.log('I am now now here')
									var session_end_date = Number(result_count[0].session_end_date)
									var session_date_time = Number(result_count[0].utc)
									// var end_date_time = new Date(session_date_time * 1000)
									var end_date_time = new Date(req.body.reschedule_utc * 1000)
									end_date_time.setMonth(end_date_time.getMonth() - 1);

									var seconds = end_date_time.getTime() / 1000

									var start_date_time = new Date(req.body.reschedule_utc * 1000)
									start_date_time.setMonth(start_date_time.getMonth() + 1);
									var seconds_start = start_date_time.getTime() / 1000

									// var start_date = start_date_time.getDate()
									// var start_year = start_date_time.getFullYear()
									// var start_month = start_date_time.getMonth() + 1

									// if (start_date < 10) {
									// 	start_date = '0' + start_date
									// }
									// if (start_month < 10) {
									// 	start_month = '0' + start_month
									// }

									if (Number(seconds) < Number(session_date_time)) {
										var Date_month = new Date(end_date_time.getTime());
										var week_month = getWeekNumber(new Date(Date_month))
										// req.body.week_month = week_month[1]

										console.log('HEREEEEEEE22 ONE')

										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: req.body
										}, function (err, rese) {
											if (err) {
												throw err;
											} else {
												var slotObj = {
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													slot_id: ObjectId(req.body.slot_id),
													day: req.body.day.toString(),
													time: req.body.time.toString(),
													month: req.body.month.toString(),
													year: req.body.year.toString(),
													created_at: getCurrentTime(),
													updated: getCurrentTime()

												}

												dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
													session_id: ObjectId(session_id_b)
												}, {
													$set: slotObj
												}, function (err, rese) {
													console.log('success')
												})

												dbo.collection("TBL_SESSIONS").find({
													trainer_id: ObjectId(req.body.user_id),
													client_id: ObjectId(req.body.client_id),
													status: {
														$in: [0, 1, 2]
													},
													utc: {
														$gt: getCurrentTime().toString()
													}
												}).sort({
													utc: 1
												}).toArray(async function (err, result_count) {
													console.log(result_count)
													// console.log(resv1)
													var total_no_of_sessions = Number(resv1.no_of_sessions)
													var total_sessions = result_count
													var counter = -1
													var arr_sess = []

													var loopCount = total_sessions.length
													var onlyOne = false
													var ignore_no_repeat = false
													var j = 0

													var repeat_W_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '1'
														return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
													});
													var repeat_M_isPresent = total_sessions.some(function (el) {
														// return el.repeat === '2'
														return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
													});
													for (var f = 0; f < loopCount; f++) {
														if (ignore_no_repeat == false) {
															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})

															if (loopCount == f + 1) {
																console.log('1st Loop Fin')
																ignore_no_repeat = true
																f = -1
																if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																	break;
																}
															}
															continue;
														}
														console.log(arr_sess)
														if (arr_sess.length >= total_no_of_sessions) {
															console.log('Loop completed')
															break;
														}

														if (total_sessions[f].repeat == '0') {
															// console.log('continue repeat')
															// continue;
															// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
														} else if (total_sessions[f].repeat == '1') { //weekly

															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})
														} else if (total_sessions[f].repeat == '2') { //Monthly
															arr_sess.push({
																'session_id': total_sessions[f]._id,
																"start_date": total_sessions[f].utc,
																"session_type": total_sessions[f].repeat
															})
														}
														// counter = arr_sess.length
														if (loopCount == f + 1) {
															f = -1
															console.log('Loop Repeating Now')
															continue;
														}

													}

													var result = arr_sess.reduce(function (r, a) {
														if (a.session_type != '0') {
															r[a.session_id] = r[a.session_id] || [];
															r[a.session_id].push(a);

														}
														return r;
													}, {});

													var final_arr = []
													for (key in result) {
														if (result.hasOwnProperty(key)) {
															var value = result[key];
															console.log(value.length)
															console.log(value[0].start_date)


															if (value[0].session_type == '1') {
																// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																var date = new Date(Number(value[0].start_date) * 1000)
																var week = (value.length - 1)
																date.setDate(date.getDate() + week * 7);
																var end_date = date.getTime() / 1000;
															} else if (value[0].session_type == '2') {
																var date = new Date(Number(value[0].start_date) * 1000)
																var months = (value.length - 1)
																var d = date.getDate();
																date.setMonth(date.getMonth() + +months);
																if (date.getDate() != d) {
																	date.setDate(0);
																}
																var end_date = date.getTime() / 1000;
															}
															final_arr.push({
																'session_id': value[0].session_id,
																'end_date': end_date,
																'type': value[0].session_type,
																'start_date': value[0].start_date
															})
														}
													}
													let promise = Promise.resolve();
													const posts = final_arr;
													posts.forEach(post => {
														promise = promise.then(() => {
															var dataIn = post
															// for (var p = 0; p < final_arr.length; p++) {
															var slotObj = {
																'session_end_date': dataIn.end_date
															}
															dbo.collection("TBL_SESSIONS").updateOne({
																_id: ObjectId(dataIn.session_id)
															}, {
																$set: slotObj
															}, function (err, rese) {
																console.log('success')
															})
															// }
														})
													})

													promise.then(() => {
														setTimeout(function () {
															response()
														}, 150);

													})

													// console.log(final_arr)
													function response() {
														if (req.body.user_type == 0) {
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'client_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENT_INFO',
																		localField: 'client_id',
																		foreignField: 'client_id',
																		as: 'client_info'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'user_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},
																{
																	"$unwind": "$client_info"
																},
																{
																	"$match": {
																		"client_info.trainer_id": ObjectId(req.body.user_id)
																	}
																},
																// {$group: {
																//      _id: "$_id",
																//      client_info: {$push: "$client_info"}
																//  }},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"client_id": data[0]['client_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0].client_info.first_name,
																			"last_name": data[0].client_info.last_name,
																			"image": data[0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),


																		}
																		res.send({
																			"success": true,
																			"message": "Session updated succesfully!",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														} else {
															// sendNotification(req.body.trainer_id,resv.insertedId)
															dbo.collection('TBL_SESSIONS').aggregate([{
																	$match: {
																		"_id": ObjectId(session_id_b)
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_CLIENTS',
																		localField: 'user_id',
																		foreignField: '_id',
																		as: 'client'
																	}
																},

																{
																	$lookup: {
																		from: 'TBL_TRAINERS',
																		localField: 'trainer_id',
																		foreignField: '_id',
																		as: 'trainer'
																	}
																},
																{
																	$lookup: {
																		from: 'TBL_TRAINER_DETAILS',
																		localField: 'trainer_id',
																		foreignField: 'user_id',
																		as: 'trainerdetails'
																	}
																},

															]).toArray(function (err, resr) {
																if (err) {
																	throw err;
																} else {
																	if (resr) {
																		var data = JSON.parse(JSON.stringify(resr));
																		// console.log(data[0]['clientdetails'])
																		// console.log(data)
																		if (data[0]['timezone'] == undefined) {
																			data[0]['timezone'] = ''
																		}
																		if (data[0]['timezone_str'] == undefined) {
																			data[0]['timezone_str'] = ''
																		}
																		if (data[0]['gym_name'] == undefined) {
																			data[0]['gym_name'] = ''
																		}
																		if (data[0]['session_end_date'] == undefined) {
																			data[0]['session_end_date'] = ''
																		}
																		dat = {
																			"id": data[0]['_id'],
																			"client_id": data[0]['client_id'],
																			"trainer_id": data[0]['trainer_id'],
																			"user_type": data[0]['user_type'],
																			"utc": data[0]['utc'],
																			"time": data[0]['time'],
																			"repeat": data[0]['repeat'],
																			"location": data[0]['location'],
																			"duration": data[0]['duration'],
																			"gym_name": data[0]['gym_name'],
																			"first_name": data[0]['trainerdetails'][0]['first_name'],
																			"last_name": data[0]['trainerdetails'][0]['last_name'],
																			"image": data[0]['trainerdetails'][0]['image'],
																			"timezone": data[0]['timezone'],
																			"timezone_str": data[0]['timezone_str'],
																			"status": data[0]['status'],
																			"day": data[0]['day'],
																			"month": data[0]['month'],
																			"year": data[0]['year'],
																			"date_str": data[0]['date_str'],
																			"time_str": data[0]['time_str'],
																			"session_end_date": data[0]['session_end_date'].toString(),
																		}
																		res.send({
																			"success": true,
																			"message": "Session updated",
																			"data": dat
																		});
																		return false;
																	} else {
																		res.send({
																			"success": false,
																			"message": "something went wrong",
																			"data": {}
																		});
																		return false;
																	}
																}

															});
														}
													}

												})
											}
										})


									} else if (Number(seconds_start) > Number(session_end_date)) {


										// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
										var Date_month = new Date(seconds_start * 1000);
										var week_month = getWeekNumber(new Date(Date_month))


										console.log('THEREEEEEE2222333333 Number(seconds_start) > Number(session_end_date 4444333222')
										// var end_date_time1 = new Date(result_count[0].utc * 1000)
										// end_date_time1.setMonth(end_date_time1.getMonth() - 1);
										// var seconds1 = end_date_time1.getTime() / 1000

										var utc1 = new Date(req.body.reschedule_utc * 1000)
										utc1.setMonth(utc1.getMonth() + 1);
										var new_utc = utc1.getTime() / 1000


										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds),
												'ignore': 1
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												// logic here
												// sessionObj.repeat = '0'
												// why ?
												dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
													if (err) {
														throw err;
													} else {
														slotObj.session_id = ObjectId(resv.insertedId);
														dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
															console.log('success')
														})
														dbo.collection("TBL_SESSIONS").find({
															trainer_id: ObjectId(req.body.user_id),
															client_id: ObjectId(req.body.client_id),
															status: {
																$in: [0, 1, 2]
															},
															utc: {
																$gt: getCurrentTime().toString()
															},
															// ignore: {
															// 	$ne: 1
															// }
														}).sort({
															utc: 1
														}).toArray(async function (err, result_count) {
															console.log(result_count)
															// console.log(resv1)
															var total_no_of_sessions = Number(resv1.no_of_sessions)
															var total_sessions = result_count
															var counter = -1
															var arr_sess = []
															var arr_sess_ignore = []

															var loopCount = total_sessions.length
															var onlyOne = false
															var ignore_no_repeat = false
															var j = 0

															var repeat_W_isPresent = total_sessions.some(function (el) {
																return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
															});
															var repeat_M_isPresent = total_sessions.some(function (el) {
																return el.repeat === '2'&& (el.ignore == 0 || !el.ignore)
															});
															// var repeat_W_isPresent = total_sessions.some(function (el) {
															// 	return el.repeat === '1' 
															// });
															// var repeat_M_isPresent = total_sessions.some(function (el) {
															// 	return el.repeat === '2'
															// });
															for (var f = 0; f < loopCount; f++) {
																if (!total_sessions[f].ignore) {
																	var is_ignore = 0;
																} else {
																	var is_ignore = total_sessions[f].ignore;
																}
																if (!total_sessions[f].session_end_date) {
																	var is_session_end_date = '';
																} else {
																	var is_session_end_date = total_sessions[f].session_end_date;
																}
																if (is_session_end_date != '') {
																	var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																	var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																} else {
																	var weeks_btw = ''
																	var months_btw = ''
																}


																if (ignore_no_repeat == false) {
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}


																	if (loopCount == f + 1) {
																		console.log('1st Loop Fin')
																		ignore_no_repeat = true
																		f = -1
																		
																		if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																			break;
																		}
																	}
																	continue;
																}
																// console.log(arr_sess)
																console.log('arr_sess.length---+++ '+arr_sess.length)
																console.log('total_no_of_sessions.length---+++ '+total_no_of_sessions)
																console.log(total_sessions[f])
																console.log('--------++++++++--------')
																if (arr_sess.length >= total_no_of_sessions) {
																	console.log('Loop completed')
																	break;
																}

																if (total_sessions[f].repeat == '0') {
																	// console.log('continue repeat')
																	// continue;
																	// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																} else if (total_sessions[f].repeat == '1') { //weekly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																} else if (total_sessions[f].repeat == '2') { //Monthly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																}
																// counter = arr_sess.length
																if (loopCount == f + 1) {
																	// if (arr_sess.length < total_no_of_sessions ) {
																	f = -1
																	// if (loopCount == 1) {
																	// 	f--
																	// }
																	console.log('Loop Repeating Now')
																	continue;
																	// }
																}

															}

															var result_final_ignore = [];
															var total_sessions_in_ignore = 0
															var total_sessions_in_ignore_month = 0

															var seen = Object.create(null)
															result_final_ignore = arr_sess_ignore.filter(o => {
																var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																if (!seen[key]) {
																	seen[key] = true;
																	return true;
																}
															});
															for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																	result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																}
																if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																	result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																}
																total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																result_final_ignore[loop_c].total = total_sessions_in_ignore
															}

															var result = arr_sess.reduce(function (r, a) {
																if (a.session_type != '0') {
																	r[a.session_id] = r[a.session_id] || [];
																	r[a.session_id].push(a);

																}
																return r;
															}, {});

															var final_arr = []
															for (key in result) {
																if (result.hasOwnProperty(key)) {
																	var value = result[key];
																	// console.log(value.length)
																	// console.log(value[0].start_date)


																	if (value[0].session_type == '1') {
																		// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																			if (isNaN(weeks_to_ignore)) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var week = (value.length - 1)
																		// date.setDate(date.getDate() + week * 7);
																		date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																		var end_date = date.getTime() / 1000;
																		if (Number(end_date) < Number(value[0].start_date)) {
																			var end_date = Number(value[0].start_date)
																		}
																	} else if (value[0].session_type == '2') {
																		// var date = new Date(Number(value[0].start_date) * 1000)
																		// var months = (value.length - 1)
																		// var d = date.getDate();
																		// date.setMonth(date.getMonth() + +months);
																		// if (date.getDate() != d) {
																		// 	date.setDate(0);
																		// }
																		// var end_date = date.getTime() / 1000;
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																			// weeks_to_ignore = weeks_to_ignore - 1
																			if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var months = ((value.length - 1) - weeks_to_ignore)
																		var d = date.getDate();
																		date.setMonth(date.getMonth() + +months);
																		if (date.getDate() != d) {
																			date.setDate(0);
																		}
																		var end_date = date.getTime() / 1000;
																	}
																	final_arr.push({
																		'session_id': value[0].session_id,
																		'end_date': end_date,
																		'type': value[0].session_type,
																		'start_date': value[0].start_date
																	})
																}
															}
															let promise = Promise.resolve();
															const posts = final_arr;
															posts.forEach(post => {
																promise = promise.then(() => {
																	var dataIn = post
																	// for (var p = 0; p < final_arr.length; p++) {
																	var slotObj = {
																		'session_end_date': dataIn.end_date
																	}
																	dbo.collection("TBL_SESSIONS").updateOne({
																		_id: ObjectId(dataIn.session_id)
																	}, {
																		$set: slotObj
																	}, function (err, rese) {
																		console.log('success')
																	})
																	// }
																})
															})

															promise.then(() => {
																setTimeout(function () {
																	response()
																}, 150);

															})

															// console.log(final_arr)
															function response() {
																if (req.body.user_type == 0) {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'client_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENT_INFO',
																				localField: 'client_id',
																				foreignField: 'client_id',
																				as: 'client_info'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'user_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},
																		{
																			"$unwind": "$client_info"
																		},
																		{
																			"$match": {
																				"client_info.trainer_id": ObjectId(req.body.user_id)
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				if (data[0]['client'][0]['timezone'] == undefined) {
																					data[0]['client'][0]['timezone'] = ''
																				}
																				if (data[0]['client'][0]['timezone_str'] == undefined) {
																					data[0]['client'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"client_id": data[0]['client_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0].client_info.first_name,
																					"last_name": data[0].client_info.last_name,
																					"image": data[0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),


																				}
																				res.send({
																					"success": true,
																					"message": "Session created succesfully!",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																} else {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},

																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'trainer_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'trainer_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				// console.log(data[0]['clientdetails'])
																				// console.log(data)
																				if (data[0]['trainer'][0]['timezone'] == undefined) {
																					data[0]['trainer'][0]['timezone'] = ''
																				}
																				if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																					data[0]['trainer'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"client_id": data[0]['client_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0]['trainerdetails'][0]['first_name'],
																					"last_name": data[0]['trainerdetails'][0]['last_name'],
																					"image": data[0]['trainerdetails'][0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),
																				}
																				res.send({
																					"success": true,
																					"message": "Session created",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																}
															}

														})
													}
												})

											}
										});
									} else {
										var Date_month = new Date(Number(seconds_start) * 1000);
										// var Date_month = new Date('' + end_year + '/' + end_month + '/' + end_date + '');
										var week_month = getWeekNumber(new Date(Date_month))


										console.log('THEREEEEEE22')
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds),
												'ignore': 1
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												// logic here

												dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
													if (err) {
														throw err;
													} else {
														slotObj.session_id = ObjectId(resv.insertedId);
														dbo.collection("TBL_TRAINER_BOOKED_SLOTS").insertOne(slotObj, function (err, resSlot) {
															console.log('success')
														})
														dbo.collection("TBL_SESSIONS").find({
															trainer_id: ObjectId(req.body.user_id),
															client_id: ObjectId(req.body.client_id),
															status: {
																$in: [0, 1, 2]
															},
															utc: {
																$gt: getCurrentTime().toString()
															},
															// ignore: {
															// 	$ne: 1
															// }
														}).sort({
															utc: 1
														}).toArray(async function (err, result_count) {
															console.log(result_count)
															// console.log(resv1)
															var total_no_of_sessions = Number(resv1.no_of_sessions)
															var total_sessions = result_count
															var counter = -1
															var arr_sess = []
															var arr_sess_ignore = []
															var loopCount = total_sessions.length
															var onlyOne = false
															var ignore_no_repeat = false
															var j = 0

															// var repeat_W_isPresent = total_sessions.some(function (el) {
															// 	return el.repeat === '1'
															// });
															var repeat_W_isPresent = total_sessions.some(function (el) {
																return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
															});
															var repeat_M_isPresent = total_sessions.some(function (el) {
																// return el.repeat === '2'
																return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
															});
															for (var f = 0; f < loopCount; f++) {
																if (!total_sessions[f].ignore) {
																	var is_ignore = 0;
																} else {
																	var is_ignore = total_sessions[f].ignore;
																}
																if (!total_sessions[f].session_end_date) {
																	var is_session_end_date = '';
																} else {
																	var is_session_end_date = total_sessions[f].session_end_date;
																}
																if (is_session_end_date != '') {
																	var weeks_btw = weeksBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																	var months_btw = monthBetween(new Date(total_sessions[f].utc * 1000), new Date(is_session_end_date * 1000))
																} else {
																	var weeks_btw = ''
																	var months_btw = ''
																}


																if (ignore_no_repeat == false) {
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}


																	if (loopCount == f + 1) {
																		console.log('1st Loop Fin')
																		ignore_no_repeat = true
																		f = -1
																		// if (loopCount == 1) {
																		// 	f--
																		// }
																		if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
																			break;
																		}
																	}
																	continue;
																}
																// console.log(arr_sess)
																if (arr_sess.length >= total_no_of_sessions) {
																	console.log('Loop completed')
																	break;
																}

																if (total_sessions[f].repeat == '0') {
																	// console.log('continue repeat')
																	// continue;
																	// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
																} else if (total_sessions[f].repeat == '1') { //weekly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																} else if (total_sessions[f].repeat == '2') { //Monthly
																	if (is_ignore == 1) {
																		arr_sess_ignore.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	} else {
																		arr_sess.push({
																			'session_id': total_sessions[f]._id,
																			"start_date": total_sessions[f].utc,
																			"session_type": total_sessions[f].repeat,
																			"is_session_end_date": is_session_end_date,
																			"weeks_btw": weeks_btw,
																			"months_btw": months_btw,
																		})
																	}

																}
																// counter = arr_sess.length
																if (loopCount == f + 1) {
																	// if (arr_sess.length < total_no_of_sessions ) {
																	f = -1
																	// if (loopCount == 1) {
																	// 	f--
																	// }
																	console.log('Loop Repeating Now')
																	continue;
																	// }
																}

															}

															// NEW WEEK LOGIC
															var result_final_ignore = [];
															var total_sessions_in_ignore = 0
															var total_sessions_in_ignore_month = 0

															var seen = Object.create(null)
															result_final_ignore = arr_sess_ignore.filter(o => {
																var key = ['_id', 'start_date'].map(k => o[k]).join('|');
																if (!seen[key]) {
																	seen[key] = true;
																	return true;
																}
															});
															for (var loop_c = 0; loop_c < result_final_ignore.length; loop_c++) {
																if (result_final_ignore[loop_c].weeks_btw || result_final_ignore[loop_c].weeks_btw == 0) {
																	result_final_ignore[loop_c].weeks_btw = Number(result_final_ignore[loop_c].weeks_btw) + 1
																}
																if (result_final_ignore[loop_c].months_btw || result_final_ignore[loop_c].months_btw == 0) {
																	result_final_ignore[loop_c].months_btw = Number(result_final_ignore[loop_c].months_btw) + 1
																}
																total_sessions_in_ignore_month += Number(result_final_ignore[loop_c].months_btw)
																result_final_ignore[loop_c].total_month = total_sessions_in_ignore_month
																total_sessions_in_ignore += Number(result_final_ignore[loop_c].weeks_btw)
																result_final_ignore[loop_c].total = total_sessions_in_ignore
															}

															console.log(result_final_ignore)
															console.log('result_final_ignore-------- ')
															var result = arr_sess.reduce(function (r, a) {
																if (a.session_type != '0') {
																	r[a.session_id] = r[a.session_id] || [];
																	r[a.session_id].push(a);

																}
																return r;
															}, {});

															var final_arr = []
															for (key in result) {
																if (result.hasOwnProperty(key)) {
																	var value = result[key];
																	// console.log(value.length)
																	// console.log(value[0].start_date)


																	if (value[0].session_type == '1') {
																		// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total)
																			if (isNaN(weeks_to_ignore)) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var week = (value.length - 1)
																		date.setDate(date.getDate() + (week - weeks_to_ignore) * 7);
																		// date.setDate(date.getDate() + week * 7);
																		var end_date = date.getTime() / 1000;
																		if (Number(end_date) < Number(value[0].start_date)) {
																			var end_date = Number(value[0].start_date)
																		}
																	} else if (value[0].session_type == '2') {
																		if (!result_final_ignore || result_final_ignore.length == 0) {
																			weeks_to_ignore = 0
																		} else {
																			var weeks_to_ignore = Number(result_final_ignore[result_final_ignore.length - 1].total_month)
																			// weeks_to_ignore = weeks_to_ignore - 1
																			if (isNaN(weeks_to_ignore) || weeks_to_ignore < 0) {
																				weeks_to_ignore = 0
																			}
																		}

																		var date = new Date(Number(value[0].start_date) * 1000)
																		var months = ((value.length - 1) - weeks_to_ignore)
																		var d = date.getDate();
																		date.setMonth(date.getMonth() + +months);
																		if (date.getDate() != d) {
																			date.setDate(0);
																		}
																		var end_date = date.getTime() / 1000;
																	}
																	final_arr.push({
																		'session_id': value[0].session_id,
																		'end_date': end_date,
																		'type': value[0].session_type,
																		'start_date': value[0].start_date
																	})
																}
															}
															let promise = Promise.resolve();
															const posts = final_arr;
															posts.forEach(post => {
																promise = promise.then(() => {
																	var dataIn = post
																	// for (var p = 0; p < final_arr.length; p++) {
																	var slotObj = {
																		'session_end_date': dataIn.end_date
																	}
																	dbo.collection("TBL_SESSIONS").updateOne({
																		_id: ObjectId(dataIn.session_id)
																	}, {
																		$set: slotObj
																	}, function (err, rese) {
																		console.log('success')
																	})
																	// }
																})
															})

															promise.then(() => {
																setTimeout(function () {
																	response()
																}, 150);

															})

															// console.log(final_arr)
															function response() {
																if (req.body.user_type == 0) {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'client_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENT_INFO',
																				localField: 'client_id',
																				foreignField: 'client_id',
																				as: 'client_info'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'user_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},
																		{
																			"$unwind": "$client_info"
																		},
																		{
																			"$match": {
																				"client_info.trainer_id": ObjectId(req.body.user_id)
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				if (data[0]['client'][0]['timezone'] == undefined) {
																					data[0]['client'][0]['timezone'] = ''
																				}
																				if (data[0]['client'][0]['timezone_str'] == undefined) {
																					data[0]['client'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"client_id": data[0]['client_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0].client_info.first_name,
																					"last_name": data[0].client_info.last_name,
																					"image": data[0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),


																				}
																				res.send({
																					"success": true,
																					"message": "Session created succesfully!",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																} else {
																	dbo.collection('TBL_SESSIONS').aggregate([{
																			$match: {
																				_id: ObjectId(resv.insertedId)
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_CLIENTS',
																				localField: 'user_id',
																				foreignField: '_id',
																				as: 'client'
																			}
																		},

																		{
																			$lookup: {
																				from: 'TBL_TRAINERS',
																				localField: 'trainer_id',
																				foreignField: '_id',
																				as: 'trainer'
																			}
																		},
																		{
																			$lookup: {
																				from: 'TBL_TRAINER_DETAILS',
																				localField: 'trainer_id',
																				foreignField: 'user_id',
																				as: 'trainerdetails'
																			}
																		},

																	]).toArray(function (err, resr) {
																		if (err) {
																			throw err;
																		} else {
																			if (resr) {
																				var data = JSON.parse(JSON.stringify(resr));
																				// console.log(data[0]['clientdetails'])
																				// console.log(data)
																				if (data[0]['trainer'][0]['timezone'] == undefined) {
																					data[0]['trainer'][0]['timezone'] = ''
																				}
																				if (data[0]['trainer'][0]['timezone_str'] == undefined) {
																					data[0]['trainer'][0]['timezone_str'] = ''
																				}
																				if (data[0]['gym_name'] == undefined) {
																					data[0]['gym_name'] = ''
																				}
																				if (data[0]['session_end_date'] == undefined) {
																					data[0]['session_end_date'] = ''
																				}
																				dat = {
																					"id": data[0]['_id'],
																					"client_id": data[0]['client_id'],
																					"trainer_id": data[0]['trainer_id'],
																					"user_type": data[0]['user_type'],
																					"utc": data[0]['utc'],
																					"time": data[0]['time'],
																					"repeat": data[0]['repeat'],
																					"location": data[0]['location'],
																					"duration": data[0]['duration'],
																					"gym_name": data[0]['gym_name'],
																					"first_name": data[0]['trainerdetails'][0]['first_name'],
																					"last_name": data[0]['trainerdetails'][0]['last_name'],
																					"image": data[0]['trainerdetails'][0]['image'],
																					"timezone": data[0]['timezone'],
																					"timezone_str": data[0]['timezone_str'],
																					"status": data[0]['status'],
																					"day": data[0]['day'],
																					"month": data[0]['month'],
																					"year": data[0]['year'],
																					"date_str": data[0]['date_str'],
																					"time_str": data[0]['time_str'],
																					"session_end_date": data[0]['session_end_date'].toString(),
																				}
																				res.send({
																					"success": true,
																					"message": "Session created",
																					"data": dat
																				});
																				return false;
																			} else {
																				res.send({
																					"success": false,
																					"message": "something went wrong",
																					"data": {}
																				});
																				return false;
																			}
																		}

																	});
																}
															}

														})
													}
												})

											}
										});

									}

								}
							}
						})

					} else {
						console.log('I am now now now here ******************')
						// console.log(req.body)
						dbo.collection('TBL_SESSIONS').updateOne({
							_id: ObjectId(session_id_b)
						}, {
							$set: req.body
						}, function (err, rese) {
							if (err) {
								throw err;
							} else {
								var slotObj = {
									trainer_id: ObjectId(req.body.user_id),
									client_id: ObjectId(req.body.client_id),
									slot_id: ObjectId(req.body.slot_id),
									day: req.body.day.toString(),
									time: req.body.time.toString(),
									month: req.body.month.toString(),
									year: req.body.year.toString(),
									created_at: getCurrentTime(),
									updated: getCurrentTime()

								}

								dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
									session_id: ObjectId(session_id_b)
								}, {
									$set: slotObj
								}, function (err, rese) {
									console.log('success')
								})

								dbo.collection("TBL_SESSIONS").find({
									trainer_id: ObjectId(req.body.user_id),
									client_id: ObjectId(req.body.client_id),
									status: {
										$in: [0, 1, 2]
									},
									utc: {
										$gt: getCurrentTime().toString()
									}
								}).sort({
									utc: 1
								}).toArray(async function (err, result_count) {
									// console.log(result_count)
									// console.log(resv1)
									// var total_no_of_sessions = Number(resv1.no_of_sessions)
									// var total_sessions = result_count
									// var counter = -1
									// var arr_sess = []

									// var loopCount = total_sessions.length
									// var onlyOne = false
									// var ignore_no_repeat = false
									// var j = 0

									// var repeat_W_isPresent = total_sessions.some(function (el) {
									// 	// return el.repeat === '1'
									// 	return el.repeat === '1' && (el.ignore == 0 || !el.ignore)
									// });
									// var repeat_M_isPresent = total_sessions.some(function (el) {
									// 	// return el.repeat === '2'
									// 	return el.repeat === '2' && (el.ignore == 0 || !el.ignore)
									// });
									// for (var f = 0; f < loopCount; f++) {
									// 	if (ignore_no_repeat == false) {
									// 		arr_sess.push({
									// 			'session_id': total_sessions[f]._id,
									// 			"start_date": total_sessions[f].utc,
									// 			"session_type": total_sessions[f].repeat
									// 		})

									// 		if (loopCount == f + 1) {
									// 			console.log('1st Loop Fin')
									// 			ignore_no_repeat = true
									// 			f = -1
									// 			if (repeat_W_isPresent == false && repeat_M_isPresent == false) {
									// 				break;
									// 			}
									// 		}
									// 		continue;
									// 	}
									// 	// console.log(arr_sess)
									// 	if (arr_sess.length >= total_no_of_sessions) {
									// 		console.log('Loop completed')
									// 		break;
									// 	}

									// 	if (total_sessions[f].repeat == '0') {
									// 		// console.log('continue repeat')
									// 		// continue;
									// 		// arr_sess.push({'session_id':total_sessions[f]._id, "start_date":total_sessions[f].utc, "session_type":total_sessions[f].repeat})
									// 	} else if (total_sessions[f].repeat == '1') { //weekly

									// 		arr_sess.push({
									// 			'session_id': total_sessions[f]._id,
									// 			"start_date": total_sessions[f].utc,
									// 			"session_type": total_sessions[f].repeat
									// 		})
									// 	} else if (total_sessions[f].repeat == '2') { //Monthly
									// 		arr_sess.push({
									// 			'session_id': total_sessions[f]._id,
									// 			"start_date": total_sessions[f].utc,
									// 			"session_type": total_sessions[f].repeat
									// 		})
									// 	}
									// 	// counter = arr_sess.length
									// 	if (loopCount == f + 1) {
									// 		f = -1
									// 		console.log('Loop Repeating Now')
									// 		continue;
									// 	}

									// }

									// var result = arr_sess.reduce(function (r, a) {
									// 	if (a.session_type != '0') {
									// 		r[a.session_id] = r[a.session_id] || [];
									// 		r[a.session_id].push(a);

									// 	}
									// 	return r;
									// }, {});

									// var final_arr = []
									// for (key in result) {
									// 	if (result.hasOwnProperty(key)) {
									// 		var value = result[key];
									// 		console.log(value.length)
									// 		console.log(value[0].start_date)


									// 		if (value[0].session_type == '1') {
									// 			// var end_date = ((Number(value[0].start_date) * 1000 ) + (7*(value.length-1)) * 24 * 60 * 60 * 1000) / 1000
									// 			var date = new Date(Number(value[0].start_date) * 1000)
									// 			var week = (value.length - 1)
									// 			date.setDate(date.getDate() + week * 7);
									// 			var end_date = date.getTime() / 1000;
									// 		} else if (value[0].session_type == '2') {
									// 			var date = new Date(Number(value[0].start_date) * 1000)
									// 			var months = (value.length - 1)
									// 			var d = date.getDate();
									// 			date.setMonth(date.getMonth() + +months);
									// 			if (date.getDate() != d) {
									// 				date.setDate(0);
									// 			}
									// 			var end_date = date.getTime() / 1000;
									// 		}
									// 		final_arr.push({
									// 			'session_id': value[0].session_id,
									// 			'end_date': end_date,
									// 			'type': value[0].session_type,
									// 			'start_date': value[0].start_date
									// 		})
									// 	}
									// }
									// let promise = Promise.resolve();
									// const posts = final_arr;
									// posts.forEach(post => {
									// 	promise = promise.then(() => {
									// 		var dataIn = post
									// 		// for (var p = 0; p < final_arr.length; p++) {
									// 		var slotObj = {
									// 			'session_end_date': dataIn.end_date
									// 		}
									// 		dbo.collection("TBL_SESSIONS").updateOne({
									// 			_id: ObjectId(dataIn.session_id)
									// 		}, {
									// 			$set: slotObj
									// 		}, function (err, rese) {
									// 			console.log('success')
									// 		})
									// 		// }
									// 	})
									// })

									// promise.then(() => {
									// 	setTimeout(function () {
									// 		response()
									// 	}, 150);

									// })
									setTimeout(function () {
										response()
									}, 150);
									// console.log(final_arr)
									function response() {
										if (req.body.user_type == 0) {
											dbo.collection('TBL_SESSIONS').aggregate([{
													$match: {
														"_id": ObjectId(session_id_b)
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENTS',
														localField: 'client_id',
														foreignField: '_id',
														as: 'client'
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENT_INFO',
														localField: 'client_id',
														foreignField: 'client_id',
														as: 'client_info'
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINERS',
														localField: 'user_id',
														foreignField: '_id',
														as: 'trainer'
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINER_DETAILS',
														localField: 'user_id',
														foreignField: 'user_id',
														as: 'trainerdetails'
													}
												},
												{
													"$unwind": "$client_info"
												},
												{
													"$match": {
														"client_info.trainer_id": ObjectId(req.body.user_id)
													}
												},
												// {$group: {
												//      _id: "$_id",
												//      client_info: {$push: "$client_info"}
												//  }},

											]).toArray(function (err, resr) {
												if (err) {
													throw err;
												} else {
													if (resr) {
														var data = JSON.parse(JSON.stringify(resr));
														// console.log(data[0]['clientdetails'])
														// console.log(data)
														if (data[0]['timezone'] == undefined) {
															data[0]['timezone'] = ''
														}
														if (data[0]['timezone_str'] == undefined) {
															data[0]['timezone_str'] = ''
														}
														if (data[0]['gym_name'] == undefined) {
															data[0]['gym_name'] = ''
														}
														if (data[0]['session_end_date'] == undefined) {
															data[0]['session_end_date'] = ''
														}
														dat = {
															"id": data[0]['_id'],
															"trainer_id": data[0]['trainer_id'],
															"client_id": data[0]['client_id'],
															"user_type": data[0]['user_type'],
															"utc": data[0]['utc'],
															"time": data[0]['time'],
															"repeat": data[0]['repeat'],
															"location": data[0]['location'],
															"duration": data[0]['duration'],
															"gym_name": data[0]['gym_name'],
															"first_name": data[0].client_info.first_name,
															"last_name": data[0].client_info.last_name,
															"image": data[0]['image'],
															"timezone": data[0]['timezone'],
															"timezone_str": data[0]['timezone_str'],
															"status": data[0]['status'],
															"day": data[0]['day'],
															"month": data[0]['month'],
															"year": data[0]['year'],
															"date_str": data[0]['date_str'],
															"time_str": data[0]['time_str'],
															"session_end_date": data[0]['session_end_date'].toString(),


														}
														res.send({
															"success": true,
															"message": "Session updated succesfully!",
															"data": dat
														});
														return false;
													} else {
														res.send({
															"success": false,
															"message": "something went wrong",
															"data": {}
														});
														return false;
													}
												}

											});
										} else {
											// sendNotification(req.body.trainer_id,resv.insertedId)
											dbo.collection('TBL_SESSIONS').aggregate([{
													$match: {
														"_id": ObjectId(session_id_b)
													}
												},
												{
													$lookup: {
														from: 'TBL_CLIENTS',
														localField: 'user_id',
														foreignField: '_id',
														as: 'client'
													}
												},
												// {
												// 	$lookup: {
												// 		from: 'TBL_CLIENT_DETAILS',
												// 		localField: 'user_id',
												// 		foreignField: 'user_id',
												// 		as: 'clientdetails'
												// 	}
												// },
												{
													$lookup: {
														from: 'TBL_TRAINERS',
														localField: 'trainer_id',
														foreignField: '_id',
														as: 'trainer'
													}
												},
												{
													$lookup: {
														from: 'TBL_TRAINER_DETAILS',
														localField: 'trainer_id',
														foreignField: 'user_id',
														as: 'trainerdetails'
													}
												},

											]).toArray(function (err, resr) {
												if (err) {
													throw err;
												} else {
													if (resr) {
														var data = JSON.parse(JSON.stringify(resr));
														// console.log(data[0]['clientdetails'])
														// console.log(data)
														if (data[0]['timezone'] == undefined) {
															data[0]['timezone'] = ''
														}
														if (data[0]['timezone_str'] == undefined) {
															data[0]['timezone_str'] = ''
														}
														if (data[0]['gym_name'] == undefined) {
															data[0]['gym_name'] = ''
														}
														if (data[0]['session_end_date'] == undefined) {
															data[0]['session_end_date'] = ''
														}
														dat = {
															"id": data[0]['_id'],
															"client_id": data[0]['client_id'],
															"trainer_id": data[0]['trainer_id'],
															"user_type": data[0]['user_type'],
															"utc": data[0]['utc'],
															"time": data[0]['time'],
															"repeat": data[0]['repeat'],
															"location": data[0]['location'],
															"duration": data[0]['duration'],
															"gym_name": data[0]['gym_name'],
															"first_name": data[0]['trainerdetails'][0]['first_name'],
															"last_name": data[0]['trainerdetails'][0]['last_name'],
															"image": data[0]['trainerdetails'][0]['image'],
															"timezone": data[0]['timezone'],
															"timezone_str": data[0]['timezone_str'],
															"status": data[0]['status'],
															"day": data[0]['day'],
															"month": data[0]['month'],
															"year": data[0]['year'],
															"date_str": data[0]['date_str'],
															"time_str": data[0]['time_str'],
															"session_end_date": data[0]['session_end_date'].toString(),
														}
														res.send({
															"success": true,
															"message": "Session updated",
															"data": dat
														});
														return false;
													} else {
														res.send({
															"success": false,
															"message": "something went wrong",
															"data": {}
														});
														return false;
													}
												}

											});
										}
									}

								})
							}
						})
					}


				} else {
					dbo.collection('TBL_SESSIONS').updateOne({
						_id: ObjectId(session_id_b)
					}, {
						$set: req.body
					}, function (err, rese) {
						if (err) {
							res.send({
								"success": false,
								"message": "Something went wrong!"
							});
							return false;
						} else {
							var slotObj = {
								trainer_id: ObjectId(req.body.user_id),
								client_id: ObjectId(req.body.client_id),
								slot_id: ObjectId(req.body.slot_id),
								day: req.body.day.toString(),
								time: req.body.time.toString(),
								month: req.body.month.toString(),
								year: req.body.year.toString(),
								created_at: getCurrentTime(),
								updated: getCurrentTime()

							}

							dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
								session_id: ObjectId(session_id_b)
							}, {
								$set: slotObj
							}, function (err, rese) {
								console.log('success')
							})
							if (req.body.user_type == 0) {
								dbo.collection('TBL_SESSIONS').aggregate([{
										$match: {
											"_id": ObjectId(session_id_b)
										}
									},
									{
										$lookup: {
											from: 'TBL_CLIENTS',
											localField: 'client_id',
											foreignField: '_id',
											as: 'client'
										}
									},
									{
										$lookup: {
											from: 'TBL_CLIENT_INFO',
											localField: 'client_id',
											foreignField: 'client_id',
											as: 'client_info'
										}
									},
									{
										"$unwind": "$client_info"
									},
									{
										"$match": {
											"client_info.trainer_id": ObjectId(req.body.user_id)
										}
									},
								]).toArray(function (err, resr) {
									if (err) {
										throw err;
									} else {
										if (resr) {
											console.log(resr)

											var data = JSON.parse(JSON.stringify(resr));
											// console.log(data[0]['clientdetails'])
											console.log(data)
											// return
											var dat = [];
											for (var i = 0; i < data.length; i++) {
												if (data[i]['timezone'] == undefined) {
													data[i]['timezone'] = ''
												}
												if (data[i]['timezone_str'] == undefined) {
													data[i]['timezone_str'] = ''
												}
												if (data[i]['gym_name'] == undefined) {
													data[i]['gym_name'] = ''
												}
												if (data[i]['session_end_date'] == undefined) {
													data[i]['session_end_date'] = ''
												}
												// gym_name: req.body.gym_name,
												dat.push({
													"id": data[i]['_id'],
													"trainer_id": data[i]['trainer_id'],
													"client_id": data[i]['client_id'],
													"user_type": data[i]['user_type'],
													"gym_name": data[i]['gym_name'],
													"utc": data[i]['utc'],
													"time": data[i]['time'],
													"repeat": data[i]['repeat'],
													"location": data[i]['location'],
													"duration": data[i]['duration'],
													"first_name": data[i].client_info.first_name,
													"last_name": data[i].client_info.last_name,
													"image": data[i]['image'],
													"timezone": data[i]['timezone'],
													"timezone_str": data[i]['timezone_str'],
													"status": data[i]['status'],
													"date_str": data[i]['date_str'],
													"time_str": data[i]['time_str'],
													"day": data[i]['day'],
													"month": data[i]['month'],
													"year": data[i]['year'],
													"session_end_date": data[i]['session_end_date'].toString()
												})
											}
											res.send({
												"success": true,
												"message": "Session Updated",
												"data": dat[0]
											});
											return false;
										} else {
											res.send({
												"success": false,
												"message": "something went wrong",
												"data": {}
											});
											return false;
										}
									}

								});
							} else {
								dbo.collection('TBL_SESSIONS').aggregate([{
										$match: {
											_id: ObjectId(session_id_b)
										}
									},
									{
										$lookup: {
											from: 'TBL_TRAINERS',
											localField: 'trainer_id',
											foreignField: '_id',
											as: 'trainer'
										}
									},
									{
										$lookup: {
											from: 'TBL_TRAINER_DETAILS',
											localField: 'trainer_id',
											foreignField: 'user_id',
											as: 'trainerdetails'
										}
									},

								]).toArray(function (err, resr) {
									if (err) {
										throw err;
									} else {
										if (resr) {
											var data = JSON.parse(JSON.stringify(resr));
											var dat = [];
											for (var i = 0; i < data.length; i++) {
												if (data[i]['timezone'] == undefined) {
													data[i]['timezone'] = ''
												}
												if (data[i]['timezone_str'] == undefined) {
													data[i]['timezone_str'] = ''
												}
												if (data[i]['gym_name'] == undefined) {
													data[i]['gym_name'] = ''
												}
												if (data[i]['session_end_date'] == undefined) {
													data[i]['session_end_date'] = ''
												}
												dat.push({
													"id": data[i]['_id'],
													"client_id": data[i]['client_id'],
													"trainer_id": data[i]['trainer_id'],
													"user_type": data[i]['user_type'],
													"gym_name": data[i]['gym_name'],
													"utc": data[i]['utc'],
													"time": data[i]['time'],
													"repeat": data[i]['repeat'],
													"location": data[i]['location'],
													"duration": data[i]['duration'],
													"first_name": data[i]['trainerdetails'][0]['first_name'],
													"last_name": data[i]['trainerdetails'][0]['last_name'],
													"image": data[i]['trainerdetails'][0]['image'],
													"timezone": data[i]['timezone'],
													"timezone_str": data[i]['timezone_str'],
													"status": data[i]['status'],
													"date_str": data[i]['date_str'],
													"time_str": data[i]['time_str'],
													"day": data[i]['day'],
													"month": data[i]['month'],
													"year": data[i]['year'],
													"session_end_date": data[i]['session_end_date'].toString()
												})
											}
											res.send({
												"success": true,
												"message": "Session updated",
												"data": dat[0]
											});
											return false;
										} else {
											res.send({
												"success": false,
												"message": "something went wrong",
												"data": {}
											});
											return false;
										}
									}

								});
							}
						}
					});
				}
				// console.log(resv1.no_of_sessions_week)
				// return false

			} else if (resv1.isBlocked != undefined && resv1.isBlocked == '1') {
				if (req.body.user_type == 0) {
					res.send({
						"success": false,
						"message": "This client is blocked.",
						"data": {}
					});
					return false;
				} else {
					res.send({
						"success": false,
						"message": "You have been blocked by the Trainer",
						"data": {}
					});
					return false;
				}

			}


		}
	})
	// dbo.collection('TBL_SESSIONS').updateOne({
	// 	_id: ObjectId(session_id_b)
	// }, {
	// 	$set: req.body
	// }, function (err, rese) {
	// 	if (err) {
	// 		res.send({
	// 			"success": false,
	// 			"message": "Something went wrong!"
	// 		});
	// 		return false;
	// 	} else {
	// 		var slotObj = {
	// 			trainer_id: ObjectId(req.body.user_id),
	// 			client_id: ObjectId(req.body.client_id),
	// 			slot_id: ObjectId(req.body.slot_id),
	// 			day: req.body.day.toString(),
	// 			time: req.body.time.toString(),
	// 			month: req.body.month.toString(),
	// 			year: req.body.year.toString(),
	// 			created_at: getCurrentTime(),
	// 			updated: getCurrentTime()

	// 		}

	// 		dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
	// 			session_id: ObjectId(session_id_b)
	// 		}, {
	// 			$set: slotObj
	// 		}, function (err, rese) {
	// 			console.log('success')
	// 		})
	// 		if (req.body.user_type == 0) {
	// 			dbo.collection('TBL_SESSIONS').aggregate([{
	// 					$match: {
	// 						"_id": ObjectId(session_id_b)
	// 					}
	// 				},
	// 				{
	// 					$lookup: {
	// 						from: 'TBL_CLIENTS',
	// 						localField: 'client_id',
	// 						foreignField: '_id',
	// 						as: 'client'
	// 					}
	// 				},
	// 				// {
	// 				// 	$lookup: {
	// 				// 		from: 'TBL_CLIENT_DETAILS',
	// 				// 		localField: 'client_id',
	// 				// 		foreignField: 'user_id',
	// 				// 		as: 'clientdetails'
	// 				// 	}
	// 				// },
	// 			]).toArray(function (err, resr) {
	// 				if (err) {
	// 					throw err;
	// 				} else {
	// 					if (resr) {
	// 						console.log(resr)

	// 						var data = JSON.parse(JSON.stringify(resr));
	// 						// console.log(data[0]['clientdetails'])
	// 						console.log(data)
	// 						// return
	// 						var dat = [];
	// 						for (var i = 0; i < data.length; i++) {
	// 							if (!data[i]['client'] || data[i]['client'][0]['timezone'] == undefined) {
	// 								data[i]['client'][0]['timezone'] = ''
	// 							}
	// 							if (!data[i]['client'] || data[i]['client'][0]['timezone_str'] == undefined) {
	// 								data[i]['client'][0]['timezone_str'] = ''
	// 							}
	// 							if (data[i]['gym_name'] == undefined) {
	// 								data[i]['gym_name'] = ''
	// 							}
	// 							// gym_name: req.body.gym_name,
	// 							dat.push({
	// 								"id": data[i]['_id'],
	// 								"user_id": data[i]['user_id'],
	// 								"client_id": data[i]['client_id'],
	// 								"user_type": data[i]['user_type'],
	// 								"gym_name": data[i]['gym_name'],
	// 								"utc": data[i]['utc'],
	// 								"time": data[i]['time'],
	// 								"repeat": data[i]['repeat'],
	// 								"location": data[i]['location'],
	// 								"duration": data[i]['duration'],
	// 								"first_name": data[i]['first_name'],
	// 								"last_name": data[i]['last_name'],
	// 								"image": data[i]['image'],
	// 								"timezone": data[i]['client'][0]['timezone'],
	// 								"timezone_str": data[i]['client'][0]['timezone_str'],
	// 								"status": data[i]['status'],
	// 								"date_str": data[i]['date_str'],
	// 								"time_str": data[i]['time_str'],
	// 								"day": data[i]['day'],
	// 								"month": data[i]['month'],
	// 								"year": data[i]['year']
	// 							})
	// 						}
	// 						res.send({
	// 							"success": true,
	// 							"message": "Session Updated",
	// 							"data": dat[0]
	// 						});
	// 						return false;
	// 					} else {
	// 						res.send({
	// 							"success": false,
	// 							"message": "something went wrong",
	// 							"data": {}
	// 						});
	// 						return false;
	// 					}
	// 				}

	// 			});
	// 		} else {
	// 			dbo.collection('TBL_SESSIONS').aggregate([{
	// 					$match: {
	// 						_id: ObjectId(session_id_b)
	// 					}
	// 				},
	// 				{
	// 					$lookup: {
	// 						from: 'TBL_TRAINERS',
	// 						localField: 'trainer_id',
	// 						foreignField: '_id',
	// 						as: 'trainer'
	// 					}
	// 				},
	// 				{
	// 					$lookup: {
	// 						from: 'TBL_TRAINER_DETAILS',
	// 						localField: 'trainer_id',
	// 						foreignField: 'user_id',
	// 						as: 'trainerdetails'
	// 					}
	// 				},

	// 			]).toArray(function (err, resr) {
	// 				if (err) {
	// 					throw err;
	// 				} else {
	// 					if (resr) {
	// 						var data = JSON.parse(JSON.stringify(resr));
	// 						var dat = [];
	// 						for (var i = 0; i < data.length; i++) {
	// 							if (data[i]['trainer'][0]['timezone'] == undefined) {
	// 								data[i]['trainer'][0]['timezone'] = ''
	// 							}
	// 							if (data[i]['trainer'][0]['timezone_str'] == undefined) {
	// 								data[i]['trainer'][0]['timezone_str'] = ''
	// 							}
	// 							if (data[i]['gym_name'] == undefined) {
	// 								data[i]['gym_name'] = ''
	// 							}
	// 							dat.push({
	// 								"id": data[i]['_id'],
	// 								"user_id": data[i]['user_id'],
	// 								"trainer_id": data[i]['trainer_id'],
	// 								"user_type": data[i]['user_type'],
	// 								"gym_name": data[i]['gym_name'],
	// 								"utc": data[i]['utc'],
	// 								"time": data[i]['time'],
	// 								"repeat": data[i]['repeat'],
	// 								"location": data[i]['location'],
	// 								"duration": data[i]['duration'],
	// 								"first_name": data[i]['trainerdetails'][0]['first_name'],
	// 								"last_name": data[i]['trainerdetails'][0]['last_name'],
	// 								"image": data[i]['trainerdetails'][0]['image'],
	// 								"timezone": data[i]['trainer'][0]['timezone'],
	// 								"timezone_str": data[i]['trainer'][0]['timezone_str'],
	// 								"status": data[i]['status'],
	// 								"date_str": data[i]['date_str'],
	// 								"time_str": data[i]['time_str'],
	// 								"day": data[i]['day'],
	// 								"month": data[i]['month'],
	// 								"year": data[i]['year']
	// 							})
	// 						}
	// 						res.send({
	// 							"success": true,
	// 							"message": "Session updated",
	// 							"data": dat[0]
	// 						});
	// 						return false;
	// 					} else {
	// 						res.send({
	// 							"success": false,
	// 							"message": "something went wrong",
	// 							"data": {}
	// 						});
	// 						return false;
	// 					}
	// 				}

	// 			});
	// 		}
	// 	}
	// });
}

exports.cancel_session = async function (req, res) {
	const {
		user_id,
		session_id,
	} = req.body;
	let errors = [];
	if (!user_id || !session_id) {
		res.send({
			"success": false,
			"message": "Please enter all fields",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	var session_id_b = req.body.session_id
	dbo.collection('TBL_SESSIONS').updateOne({
		_id: ObjectId(session_id_b)
	}, {
		$set: {
			'status': 3
		}
	}, function (err, rese) {
		if (err) {
			res.send({
				"success": false,
				"message": "Something went wrong!",
				"data": {}
			});
			return false;
		} else {
			res.send({
				"success": true,
				"message": "We have successfully cancelled the requested session.",
				"data": {}
			});
		}
	});
}
exports.session_update_status = async function (req, res) {
	const {
		trainer_id,
		client_id,
		session_id,
		status,
	} = req.body;
	let errors = [];
	if (!trainer_id || !session_id) {
		res.send({
			"success": false,
			"message": "Please enter all fields",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	var session_id_b = req.body.session_id
	if (Number(status) == 1) {
		dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
			session_id: ObjectId(session_id_b)
		}, {
			$set: {
				'status': status.toString()
			}
		}, function (err, rese) {
			console.log('success')
		})
	}
	// if (Number(status) == 3 || Number(status) == 4 || Number(status) == 5) {
	// 	dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
	// 		session_id: ObjectId(session_id_b)
	// 	}, {
	// 		$set: {
	// 			'status': '0'
	// 		}
	// 	}, function (err, rese) {
	// 		console.log('success')
	// 	})
	// }
	// 0 - Pending
	// 1 - Accepted
	// 2 - Auto Accepted
	// 3 - Cancelled By Trainer 
	// 4 - Rejected
	// 5 - Cancelled By Client
	console.log('------------req.body')
	console.log(req.body)
	if ((Number(status) == 3 || Number(status) == 4 || Number(status) == 5) && req.body.cancel_all && req.body.cancel_date) {
		dbo.collection('TBL_SESSIONS').aggregate([{
			$match: {
				"_id": ObjectId(session_id_b)
			}
		}, ]).toArray(function (err, resr) {
			if (err) {
				throw err;
			} else {
				if (resr) {
					if (resr[0].repeat == '1') {
						if (req.body.cancel_all == 0) {
							console.log('DELETE ONE')

							var cancel_date = req.body.cancel_date.split(".");
							var end_date = Number(cancel_date[1]) - 7
							var end_month = Number(cancel_date[0])
							var end_year = Number(cancel_date[2])

							var start_date = Number(cancel_date[1]) + 7
							var start_month = Number(cancel_date[0])
							var start_year = Number(cancel_date[2])

							var session_date_time = Number(resr[0].utc)
							var end_date_time = new Date(req.body.cancel_date_utc * 1000)
							end_date_time.setDate(end_date_time.getDate() - 7);


							var start_date_time = new Date(req.body.cancel_date_utc * 1000)
							start_date_time.setDate(start_date_time.getDate() + 7);

							var seconds = end_date_time.getTime() / 1000

							var seconds_start = start_date_time.getTime() / 1000

							var start_date = start_date_time.getDate()
							var start_year = start_date_time.getFullYear()
							var start_month = start_date_time.getMonth() + 1

							var session_end_date = Number(resr[0].session_end_date)

							var start_date_time1 = new Date(req.body.cancel_date_utc * 1000)
							start_date_time1.setDate(start_date_time1.getDate() + 7);
							var seconds_start1 = start_date_time1.getTime() / 1000

							var set_end_date_new = new Date(Number(resr[0].session_end_date) * 1000)
							set_end_date_new.setDate(set_end_date_new.getDate() - 7);
							var seconds_set_end_date_new = set_end_date_new.getTime() / 1000

							if (start_date < 10) {
								start_date = '0' + start_date
							}
							if (start_month < 10) {
								start_month = '0' + start_month
							}
							// console.log('seconds_start1 '+ seconds_start1)
							// console.log('session_end_date '+ session_end_date)
							if (Number(seconds) < Number(session_date_time)) {
								console.log('IF 1')


								var Date_month = new Date(req.body.cancel_date_utc * 1000);
								var week_month = getWeekNumber(new Date(Date_month))
								// req.body.week_month = week_month[1]

								dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
									session_id: ObjectId(session_id_b)
								}, {
									$set: {
										'status': status.toString()
									}
								}, function (err, rese) {
									console.log('success')
								})

								if (Number(session_date_time) > Number(seconds_set_end_date_new)) {
									dbo.collection('TBL_SESSIONS').updateOne({
										_id: ObjectId(session_id_b)
									}, {
										$set: {
											'status': Number(status)

										}
									}, function (err, rese) {
										if (err) {
											res.send({
												"success": false,
												"message": "Something went wrong!",
												"data": {}
											});
											return false;
										} else {
											res.send({
												"success": true,
												"message": "We have successfully cancelled the requested session.",
												"data": {}
											});
										}
									});
								} else {
									dbo.collection('TBL_SESSIONS').updateOne({
										_id: ObjectId(session_id_b)
									}, {
										$set: {
											'utc': seconds_start.toString(),
											day: start_date.toString(),
											month: start_month.toString(),
											year: start_year.toString(),
											date_str: start_month + '.' + start_date + '.' + start_year,
											'week_month': week_month[1],
										}
									}, function (err, rese) {
										if (err) {
											res.send({
												"success": false,
												"message": "Something went wrong!",
												"data": {}
											});
											return false;
										} else {
											res.send({
												"success": true,
												"message": "We have successfully cancelled the requested session.",
												"data": {}
											});
										}
									});
								}


							} else if (Number(seconds_start1) > Number(session_end_date)) {
								console.log('IF ELSE 1')
								dbo.collection('TBL_SESSIONS').updateOne({
									_id: ObjectId(session_id_b)
								}, {
									$set: {
										'session_end_date': Number(seconds_set_end_date_new)
									}
								}, function (err, rese) {
									if (err) {
										res.send({
											"success": false,
											"message": "Something went wrong!",
											"data": {}
										});
										return false;
									} else {
										res.send({
											"success": true,
											"message": "We have successfully cancelled the requested session.",
											"data": {}
										});
									}
								});
							} else {
								console.log('ELSE 1')
								var Date_month = new Date(req.body.cancel_date_utc * 1000);
								var week_month = getWeekNumber(new Date(Date_month))
								var sessionObj = {
									trainer_id: ObjectId(resr[0].trainer_id),
									client_id: ObjectId(resr[0].client_id),
									utc: seconds_start.toString(),
									duration: resr[0].duration,
									location: resr[0].location,
									repeat: resr[0].repeat,
									gym_name: resr[0].gym_name,
									user_type: resr[0].user_type,
									status: 2,
									day: start_date.toString(),
									month: start_month.toString(),
									year: start_year.toString(),
									date_str: start_month + '.' + start_date + '.' + start_year,
									time_str: resr[0].time_str,
									timezone_str: resr[0].timezone_str,
									time: resr[0].time,
									created_at: getCurrentTime(),
									updated: getCurrentTime(),
									week_month: week_month[1],
									session_end_date: resr[0].session_end_date
								};
								dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
									if (err) {
										throw err;
									} else {
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds)
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												res.send({
													"success": true,
													"message": "We have successfully cancelled the requested session.",
													"data": {}
												});
											}
										});
									}
								})

							}
						} else {
							console.log('DELETE ALL')
							var cancel_date = req.body.cancel_date.split(".");
							var end_date = Number(cancel_date[1]) - 7
							var end_month = Number(cancel_date[0])
							var end_year = Number(cancel_date[2])

							var session_date_time = Number(resr[0].utc)
							// var end_date_time = new Date(session_date_time * 1000)
							var end_date_time = new Date(req.body.cancel_date_utc * 1000)
							end_date_time.setDate(end_date_time.getDate() - 7);
							// end_date_time.setDate(end_date)
							// end_date_time.setMonth(end_month)
							// end_date_time.setYear(end_year)
							var seconds = end_date_time.getTime() / 1000


							var session_end_date = Number(resr[0].session_end_date)

							var start_date_time = new Date(req.body.cancel_date_utc * 1000)
							start_date_time.setDate(start_date_time.getDate() - 7);
							var seconds_start = start_date_time.getTime() / 1000


							if (Number(seconds) < Number(session_date_time)) {
								dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
									session_id: ObjectId(session_id_b)
								}, {
									$set: {
										'status': status.toString()
									}
								}, function (err, rese) {
									console.log('success')
								})

								dbo.collection('TBL_SESSIONS').updateOne({
									_id: ObjectId(session_id_b)
								}, {
									$set: {
										'status': Number(status)
									}
								}, function (err, rese) {
									if (err) {
										res.send({
											"success": false,
											"message": "Something went wrong!",
											"data": {}
										});
										return false;
									} else {
										res.send({
											"success": true,
											"message": "We have successfully cancelled the requested session.",
											"data": {}
										});
									}
								});
							}
							// else if (Number(seconds_start) > Number(session_end_date)){
							// 	dbo.collection('TBL_SESSIONS').updateOne({
							// 		_id: ObjectId(session_id_b)
							// 	}, {
							// 		$set: {
							// 			'session_end_date': Number(seconds)
							// 		}
							// 	}, function (err, rese) {
							// 		if (err) {
							// 			res.send({
							// 				"success": false,
							// 				"message": "Something went wrong!",
							// 				"data": {}
							// 			});
							// 			return false;
							// 		} else {
							// 			res.send({
							// 				"success": true,
							// 				"message": "We have successfully cancelled the requested session.",
							// 				"data": {}
							// 			});
							// 		}
							// 	});
							// }
							else {
								dbo.collection('TBL_SESSIONS').updateOne({
									_id: ObjectId(session_id_b)
								}, {
									$set: {
										'session_end_date': Number(seconds)
									}
								}, function (err, rese) {
									if (err) {
										res.send({
											"success": false,
											"message": "Something went wrong!",
											"data": {}
										});
										return false;
									} else {
										res.send({
											"success": true,
											"message": "We have successfully cancelled the requested session.",
											"data": {}
										});
									}
								});
							}

						}
					} else if (resr[0].repeat == '2') {
						if (req.body.cancel_all == 0) {
							console.log('req.body.cancel_all == 0')
							var cancel_date = req.body.cancel_date.split(".");
							var end_date = Number(cancel_date[1]) - 7
							var end_month = Number(cancel_date[0])
							var end_year = Number(cancel_date[2])

							var start_date = Number(cancel_date[1]) + 7
							var start_month = Number(cancel_date[0])
							var start_year = Number(cancel_date[2])

							var session_date_time = Number(resr[0].utc)
							var end_date_time = new Date(req.body.cancel_date_utc * 1000)
							end_date_time.setMonth(end_date_time.getMonth() - 1);
							// end_date_time.setDate(end_date)
							// end_date_time.setMonth(end_month)
							// end_date_time.setYear(end_year)

							var start_date_time = new Date(req.body.cancel_date_utc * 1000)
							start_date_time.setMonth(start_date_time.getMonth() + 1);
							// start_date_time.setDate(start_date)
							// start_date_time.setMonth(start_month)
							// start_date_time.setYear(start_year)

							var seconds = end_date_time.getTime() / 1000

							var seconds_start = start_date_time.getTime() / 1000

							var start_date = start_date_time.getDate()
							var start_year = start_date_time.getFullYear()
							var start_month = start_date_time.getMonth() + 1

							var session_end_date = Number(resr[0].session_end_date)

							var start_date_time1 = new Date(req.body.cancel_date_utc * 1000)
							start_date_time1.setMonth(start_date_time1.getMonth() + 1);
							var seconds_start1 = start_date_time1.getTime() / 1000

							var set_end_date_new = new Date(Number(resr[0].session_end_date) * 1000)
							set_end_date_new.setMonth(set_end_date_new.getMonth() - 1);
							var seconds_set_end_date_new = set_end_date_new.getTime() / 1000

							if (start_date < 10) {
								start_date = '0' + start_date
							}
							if (start_month < 10) {
								start_month = '0' + start_month
							}

							if (Number(seconds) < Number(session_date_time)) {
								console.log('IF 2')
								var Date_month = new Date(req.body.cancel_date_utc * 1000);
								var week_month = getWeekNumber(new Date(Date_month))
								// req.body.week_month = week_month[1]

								dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
									session_id: ObjectId(session_id_b)
								}, {
									$set: {
										'status': status.toString()
									}
								}, function (err, rese) {
									console.log('success')
								})

								if (Number(session_date_time) > Number(seconds_set_end_date_new)) {
									dbo.collection('TBL_SESSIONS').updateOne({
										_id: ObjectId(session_id_b)
									}, {
										$set: {
											'status': Number(status)

										}
									}, function (err, rese) {
										if (err) {
											res.send({
												"success": false,
												"message": "Something went wrong!",
												"data": {}
											});
											return false;
										} else {
											res.send({
												"success": true,
												"message": "We have successfully cancelled the requested session.",
												"data": {}
											});
										}
									});
								} else {
									dbo.collection('TBL_SESSIONS').updateOne({
										_id: ObjectId(session_id_b)
									}, {
										$set: {
											'utc': seconds_start.toString(),
											'week_month': week_month[1],
											'day': start_date.toString(),
											'month': start_month.toString(),
											'year': start_year.toString(),
											'date_str': start_month + '.' + start_date + '.' + start_year,
										}
									}, function (err, rese) {
										if (err) {
											res.send({
												"success": false,
												"message": "Something went wrong!",
												"data": {}
											});
											return false;
										} else {
											res.send({
												"success": true,
												"message": "We have successfully cancelled the requested session.",
												"data": {}
											});
										}
									});
								}


							} else if (Number(seconds_start1) > Number(session_end_date)) {
								console.log('IF ELSE 2')
								dbo.collection('TBL_SESSIONS').updateOne({
									_id: ObjectId(session_id_b)
								}, {
									$set: {
										'session_end_date': Number(seconds_set_end_date_new)
									}
								}, function (err, rese) {
									if (err) {
										res.send({
											"success": false,
											"message": "Something went wrong!",
											"data": {}
										});
										return false;
									} else {
										res.send({
											"success": true,
											"message": "We have successfully cancelled the requested session.",
											"data": {}
										});
									}
								});
							} else {
								console.log('ELSE 2')
								var Date_month = new Date(req.body.cancel_date_utc * 1000);
								var week_month = getWeekNumber(new Date(Date_month))
								var sessionObj = {
									trainer_id: ObjectId(resr[0].trainer_id),
									client_id: ObjectId(resr[0].client_id),
									utc: seconds_start.toString(),
									duration: resr[0].duration,
									location: resr[0].location,
									repeat: resr[0].repeat,
									gym_name: resr[0].gym_name,
									user_type: resr[0].user_type,
									status: 2,
									day: start_date.toString(),
									month: start_month.toString(),
									year: start_year.toString(),
									date_str: start_month + '.' + start_date + '.' + start_year,
									time_str: resr[0].time_str,
									timezone_str: resr[0].timezone_str,
									time: resr[0].time,
									created_at: getCurrentTime(),
									updated: getCurrentTime(),
									week_month: week_month[1],
									session_end_date: resr[0].session_end_date
								};
								dbo.collection("TBL_SESSIONS").insertOne(sessionObj, function (err, resv) {
									if (err) {
										throw err;
									} else {
										dbo.collection('TBL_SESSIONS').updateOne({
											_id: ObjectId(session_id_b)
										}, {
											$set: {
												'session_end_date': Number(seconds)
											}
										}, function (err, rese) {
											if (err) {
												res.send({
													"success": false,
													"message": "Something went wrong!",
													"data": {}
												});
												return false;
											} else {
												res.send({
													"success": true,
													"message": "We have successfully cancelled the requested session.",
													"data": {}
												});
											}
										});
									}
								})

							}
						} else {
							console.log('req.body.cancel_all == 1')
							var cancel_date = req.body.cancel_date.split(".");
							var end_date = Number(cancel_date[1]) - 7
							var end_month = Number(cancel_date[0])
							var end_year = Number(cancel_date[2])

							var session_date_time = Number(resr[0].utc)
							// var end_date_time = new Date(session_date_time * 1000)
							var end_date_time = new Date(req.body.cancel_date_utc * 1000)
							end_date_time.setMonth(end_date_time.getMonth() - 1);
							// end_date_time.setDate(end_date)
							// end_date_time.setMonth(end_month)
							// end_date_time.setYear(end_year)
							var session_end_date = Number(resr[0].session_end_date)

							var start_date_time1 = new Date(req.body.cancel_date_utc * 1000)
							start_date_time1.setMonth(start_date_time1.getMonth() + 1);
							var seconds_start1 = start_date_time1.getTime() / 1000

							var seconds = end_date_time.getTime() / 1000

							if (Number(seconds) < Number(session_date_time)) {
								dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
									session_id: ObjectId(session_id_b)
								}, {
									$set: {
										'status': status.toString()
									}
								}, function (err, rese) {
									console.log('success')
								})

								dbo.collection('TBL_SESSIONS').updateOne({
									_id: ObjectId(session_id_b)
								}, {
									$set: {
										'status': Number(status)
									}
								}, function (err, rese) {
									if (err) {
										res.send({
											"success": false,
											"message": "Something went wrong!",
											"data": {}
										});
										return false;
									} else {
										res.send({
											"success": true,
											"message": "We have successfully cancelled the requested session.",
											"data": {}
										});
									}
								});
							}
							//  else if (Number(seconds_start1) > Number(session_end_date)){

							// }
							else {
								dbo.collection('TBL_SESSIONS').updateOne({
									_id: ObjectId(session_id_b)
								}, {
									$set: {
										'session_end_date': Number(seconds)
									}
								}, function (err, rese) {
									if (err) {
										res.send({
											"success": false,
											"message": "Something went wrong!",
											"data": {}
										});
										return false;
									} else {
										res.send({
											"success": true,
											"message": "We have successfully cancelled the requested session.",
											"data": {}
										});
									}
								});
							}

						}
					}
				}
			}
		})


	} else {
		if (Number(status) == 3 || Number(status) == 4 || Number(status) == 5) {
			dbo.collection("TBL_TRAINER_BOOKED_SLOTS").updateOne({
				session_id: ObjectId(session_id_b)
			}, {
				$set: {
					'status': '0'
				}
			}, function (err, rese) {
				console.log('success')
			})
		}
		dbo.collection('TBL_SESSIONS').updateOne({
			_id: ObjectId(session_id_b)
		}, {
			$set: {
				'status': Number(status)
			}
		}, function (err, rese) {
			if (err) {
				res.send({
					"success": false,
					"message": "Something went wrong!",
					"data": {}
				});
				return false;
			} else {
				if (req.body.status == 1) {
					res.send({
						"success": true,
						"message": "You have accepted the session.",
						"data": {}
					});
				} else if (req.body.status == 4) {
					res.send({
						"success": true,
						"message": "We have successfully rejected the requested session.",
						"data": {}
					});
				} else {
					res.send({
						"success": true,
						"message": "We have successfully cancelled the requested session.",
						"data": {}
					});
				}

			}
		});
	}

}
async function sendNotification(user_id, session_id) {
	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_PUSH_TOKENS').find({
			trainer_id: ObjectId(user_id)
		})
		.toArray(function (err, tokens) {
			var dTokens = []
			for (let e = 0; e < tokens.length; e++) {
				dTokens[e] = tokens[e].token;
			}
			var payload = {
				notification: {
					title: "Session Scheduled",
					body: "A new session has been Scheduled!"
				},
				data: {
					session_id: session_id,
					user_id: user_id,
					// gym_id: gym_id,
				}
			};
			var registrationToken = dTokens;
			if (tokens.length != 0) {
				admin.messaging().sendToDevice(registrationToken, payload, options)
					.then(function (response) {
						console.log("Successfully sent message:", response);
					})
					.catch(function (error) {
						console.log("Error sending message:", error);
					});
			} else {
				console.log("no token");
			}
		});
}

function getCurrentTime() {
	var d = new Date();
	var n = d.toUTCString();
	var date = new Date(n);
	var seconds = date.getTime() / 1000; //1440516958
	return seconds;
}

function addDays(date, days) {
	var result = new Date(date);
	result.setDate(result.getDate() + days);
	return result;
}

function getWeekNumber(d) {
	// Copy date so don't modify original
	d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
	// Set to nearest Thursday: current date + 4 - current day number
	// Make Sunday's day number 7
	d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
	// Get first day of year
	var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
	// Calculate full weeks to nearest Thursday
	var weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
	// Return array of year and week number
	return [d.getUTCFullYear(), weekNo];
}

function weeksBetween(d1, d2) {
	return Math.round((d2 - d1) / (7 * 24 * 60 * 60 * 1000));
}

function countDubli(array) {
	uniqueCount = array
	var count = {};
	uniqueCount.forEach(function (i) {
		count[i] = (count[i] || 0) + 1;
	});
	return count;

}

function monthBetween(d1, d2) {
	var months;
	months = (d2.getFullYear() - d1.getFullYear()) * 12;
	months -= d1.getMonth();
	months += d2.getMonth();
	return months <= 0 ? 0 : months;
}

function dateDiffInDays(a, b) {
	const _MS_PER_DAY = 1000 * 60 * 60 * 24;
	// Discard the time and time-zone information.
	const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
	const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

	return Math.floor((utc2 - utc1) / _MS_PER_DAY);
}