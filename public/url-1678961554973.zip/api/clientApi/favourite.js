var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
const { ObjectId } = require('mongodb');
//const {email, first_name, last_name, password, social_id, image,type } = req.body;




mongo.set('useFindAndModify', false);

//var mongodbutil = require( './mongodbutil' );
var index = require('./index')


exports.addFavorites = async function (req, res) {
    const { client_id, trainer_id, favorite } = req.body;
    if (!client_id) {
        res.send({ "success": false, "message": "client_id empty", "data": {} });
        return false;
    }
    else if (!trainer_id) {
        res.send({ "success": false, "message": "trainer_id empty", "data": {} });
        return false;
    }
    else if (!favorite) {
        res.send({ "success": false, "message": "favorites cannot be  empty", "data": {} });
        return false;
    }

    let dbo = await mongodbutil.Get();
    data = { "client_id": ObjectId(client_id), "trainer_id": ObjectId(trainer_id), "favorite": favorite, 'created_at': getCurrentTime(), 'updated_at': getCurrentTime() }

    dbo.collection("TBL_FAVORITES").find({
        trainer_id: ObjectId(trainer_id),
        client_id: ObjectId(client_id),

    }).toArray(function (err, favorite_data) {
        if (err) {
            throw err;
        }
        else {
            //if already entry exist then update favorites value
            if (favorite_data.length > 0) {
                dbo.collection('TBL_FAVORITES').updateOne({ _id: ObjectId(favorite_data[0]._id) },
                    { $set: { favorite: favorite } }, function (err, rese) {
                        if (err) {
                            res.send({ "success": false, "message": "Something went wrong!", "data": {}, "err": err.message });
                        }
                        else {
                            res.send({ "success": true, "message": favorite == 1 ? "trainer marked favorites." : 'trainer unmarked from favorites' });

                            return false;
                        }
                    });

            }
            else {
                dbo.collection("TBL_FAVORITES").insertOne(data, function (err1, resr) {
                    if (err1) {
                        res.send({ "success": false, "message": "Something went wrong!", "data": {}, "err": err1.message });
                    }
                    else {
                        if (resr) {

                            res.send({ "success": true, "message": favorite == 1 ? "trainer marked favorites." : 'trainer unmarked from favorites' });
                            return false;
                        }
                        else {
                            res.send({ "success": false, "message": "something went wrong", "data": [] });
                            return false;
                        }
                    }
                });

            }

        }


    })



    //});
}

exports.getFavorites = async (req, res) => {
    const { client_id } = req.body;
    if (!client_id) {
        res.send({ "success": false, "message": "client_id cannot be empty", "data": {} });
        return false;
    }
    let dbo = await mongodbutil.Get();
    dbo.collection('TBL_FAVORITES').aggregate([
        {
            $match: {
                client_id: ObjectId(req.body.client_id),
                favorite: "1"

            }

        },
        {

            $lookup:
            {
                from: 'TBL_TRAINERS',
                localField: 'trainer_id',
                foreignField: '_id',
                as: 'trainer'
            }
        },
        {
            "$unwind": {
                "path": "$trainer",
                "preserveNullAndEmptyArrays": true
            }
        },
        {

            $lookup:
            {
                from: 'TBL_TRAINER_DETAILS',
                localField: 'trainer_id',
                foreignField: 'user_id',
                as: 'trainer_details'
            }
        },

        {
            "$unwind": {
                "path": "$trainer_details",
                "preserveNullAndEmptyArrays": true
            }
        },
        {
            $project: {
                //"favorites": { $cond: { if: "$favorites", then: true, else: false } },
                "favorite":  { $cond: [{ $eq: ['$favorite', '1'] }, true, false] },
                "trainer_id": 1,
                "first_name": "$trainer_details.first_name",
                "last_name": "$trainer_details.last_name",
                "image": "$trainer_details.image",
                "bio": "$trainer_details.bio",
                "ratings": { $cond: { if: "$trainer.ratings", then: "$trainer.ratings", else: 0 } },
                "avg_rating": { $cond: { if: "$trainer.avg_ratings", then: "$trainer.avg_ratings", else: 0 } },
                "formatted_address": { $cond: { if: "$trainer.formatted_address", then: "$trainer.formatted_address", else:'' } },
                "price": { $cond: { if: "$trainer.price", then: "$trainer.price", else: 0 } },
                "longitude":{ $cond: { if: "$trainer.longitude", then: "$trainer.longitude", else: 0 } },
                "latitude":{ $cond: { if: "$trainer.latitude", then: "$trainer.latitude", else: 0 } },
                //"longitude":{ $toString:{ $cond: { if: "$trainer.longitude", then: "$trainer.longitude", else: 0 } }},
                //"latitude":{ $toString:{ $cond: { if: "$trainer.latitude", then: "$trainer.latitude", else: 0 } }},



            }
        }

    ]).toArray(function (err, resr) {
        if (err) {
            throw err;
        }
        else {
            console.log(resr)
            return res.send({ "success": true, "message": "success", "data": resr })
        }
    })
}



function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}
