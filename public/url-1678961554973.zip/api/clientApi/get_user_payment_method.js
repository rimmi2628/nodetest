var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')
const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.get_user_payment_method = async function (req, res) {
  if (!req.body.user_id) {
    res.send({
      "success": false,
      "message": "user_id empty",
      "data": []
    });
    return false;
  }
  let dbo = await mongodbutil.Get();
  dbo.collection('TBL_CARDS').aggregate([{
    $match: {
      trainer_id: ObjectId(req.body.user_id)
    }
  }]).toArray(function (err, resr) {
    if (err) {
      throw err;
    } else {
      if (resr) {
        for (var i = 0; i < resr.length; i++) {
          resr[i].user_id = resr[i].trainer_id;
          resr[i].type = resr[i].payment_type;
          resr[i].id = resr[i]._id;
          if (!resr[i].primary) {
            resr[i].primary = 0
          }
          else{
            resr[i].primary = parseInt(resr[i].primary)
          }
          delete resr[i].payment_method;
          delete resr[i].trainer_id;
          delete resr[i].paypal_authorization;
          delete resr[i].paypal_email;
          delete resr[i].updated_at;
          delete resr[i].created_at;
          if (resr[i].payment_type == "0") {
            delete resr[i].account_number
            delete resr[i].routing_number
            delete resr[i].account_type
          }
          else{
            delete resr[i].customer_id
            delete resr[i].cvv
            delete resr[i].mm
            delete resr[i].number
            delete resr[i].number
            delete resr[i].yy
            delete resr[i].zip

          }
          delete resr[i].payment_type
          delete resr[i]._id
        }
        res.send({
          "success": true,
          "message": "success",
          "data": resr
        });
        return false;
      } else {
        res.send({
          "success": false,
          "message": "something went wrong",
          "data": []
        });
        return false;
      }
    }
  });
}