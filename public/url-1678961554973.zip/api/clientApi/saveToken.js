var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());
// console.log(sourceFile)

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);

var mongodbutil = require( './mongodbutil' );

 exports.save_token = async function(req, res) {
    const {trainer_id,token,platform} = req.body;
    if(!trainer_id ){
      res.send({"success":false,"message":"trainer_id empty","data":{}});
      return false;
    }
    else if(!token){
      res.send({"success":false,"message":"token empty","data":{}});
      return false;
    }
    else if (!platform) {
        res.send({"success":false,"message":"platform cannot be empty empty","data":{}});
      return false;
    }
        let dbo =  await mongodbutil.Get();
        // data = {"trainer_id":ObjectId(trainer_id),"token":token,"platform":platform,'created_at':getCurrentTime(),'updated_at':getCurrentTime()}
        var toki = dbo.collection("TBL_PUSH_TOKENS").replaceOne(
            { "token" : token },
            { "token" : token, "trainer_id" : ObjectId(trainer_id), "platform" : platform ,'created_at':getCurrentTime(),'updated_at':getCurrentTime()},
            { upsert: true }, function(err,resr){
            if (err){
                throw err;
            }
            else{
                 if(resr){
                    res.send({"success":true,"message":"We have successfully registered your device for push notifications","data":[]});
                    return false;
                }
                else{
                    res.send({"success":false,"message":"something went wrong","data":[]});
                    return false;
                }
              }
        }); 
        // console.log(toki)
        //  dbo.collection("TBL_PUSH_TOKENS").insertOne(data, function(err,resr){
        //     if (err){
        //         throw err;
        //     }
        //     else{
        //         if(resr){

        //             res.send({"success":true,"message":"We have successfully registered your device for push notifications","data":[]});
        //             return false;
        //         }
        //         else{
        //             res.send({"success":false,"message":"something went wrong","data":[]});
        //             return false;
        //         }
        //     }
        // }); 
    //});
  }

 exports.un_register_push = async function (req, res) {
    let dbo =  await mongodbutil.Get();
    const {trainer_id,token,platform} = req.body;
    if(!trainer_id ){
      res.send({"success":false,"message":"trainer_id empty","data":{}});
      return false;
    }
    else if(!token){
      res.send({"success":false,"message":"token empty","data":{}});
      return false;
    }
    else if (!platform) {
        res.send({"success":false,"message":"platform cannot be empty empty","data":{}});
      return false;
    }
    var myquery = { "trainer_id":ObjectId(trainer_id),"token":token,"platform":platform,};
    dbo.collection("TBL_PUSH_TOKENS").deleteMany(myquery, function (err, resr) {
         if (err){
            throw err;
        }
        else{
            if(resr){
                res.send({"success":true,"message":"We have successfully De-registered your device for push notifications","data":[]});
                return false;
            }
            else{
                res.send({"success":false,"message":"something went wrong","data":[]});
                return false;
            }
        }
    });
}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

