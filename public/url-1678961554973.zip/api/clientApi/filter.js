var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


// const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.filter = async function(req, res) {
    var minPrice = 0;
    var maxPrice = 250; 
    var minRadius = 0; 
    var maxRadius = 100;

    var minSession = 20;
    var maxSession = 100;
    let dbo =  await mongodbutil.Get();
    dbo.collection("TBL_SERVICES").find().toArray(function(err, resr) {
        var data_t = [];
        for (var i = 0; i < resr.length; i++) {
            data_t.push(resr[i])
        }
        var data={
          "price":{"min":minPrice,"max":maxPrice},
          "radius":{"min":minRadius,"max":maxRadius},
          "session_length":{"min":minSession,"max":maxSession},
          // "equipments":resr,
          "trainings":data_t
          
        }
        res.send({"success":true,"message":"Success","data":data});
        return false;
    })
    // MongoClient.connect(url, function(err, db) {
    //   if (err) throw err;
    
    
}