var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var sourceFile = require('./register.js');
var db = mongo.connect("mongodb://localhost:27017/gymtraining", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}, function (err, response) {
    if (err) {
        console.log(err);
    } else { //console.log('Connected to ' + db, ' + ', response); 
    }
});
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.payment_method = async function (req, res) {
    const {
        payment_type
    } = req.body;
    // if(!user_id ||!ending ||!expiry ||!type ||!customer_id ||!email ||!authorization ||!routing_number ||!account_number ||!payment_method ||!zip ){
    //     res.send({"success":false,"message":"all fields required","data":{}});
    //     return false;
    // }
    if (!payment_type) {
        res.send({
            "success": false,
            "message": "Payment type empty",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    if (req.body.payment_type == 0) {
        if (!req.body.yy) {
            res.send({
                "success": false,
                "message": "expiry yy empty",
                "data": {}
            });
            return false;
        } else if (!req.body.mm) {
            res.send({
                "success": false,
                "message": "expiry mm  missing",
                "data": {}
            });
            return false;
        }
        else if (!req.body.card_holder_name) {
            res.send({
                "success": false,
                "message": "card_holder_name missing",
                "data": {}
            });
            return false;
        }
        // else if(!req.body.type){
        //     res.send({"success":false,"message":"card type missing","data":{}});
        //     return false;
        // }
        else if (!req.body.number) {
            res.send({
                "success": false,
                "message": "number missing",
                "data": {}
            });
            return false;
        } else if (!req.body.user_id) {
            res.send({
                "success": false,
                "message": "user_id missing",
                "data": {}
            });
            return false;
        }
        //  else if(!req.body.primary){
        //     res.send({"success":false,"message":"user_id missing","data":{}});
        //     return false;
        // }
        else if (!req.body.customer_id) {
            res.send({
                "success": false,
                "message": "customer_id missing",
                "data": {}
            });
            return false;
        } else if (!req.body.cvv) {
            res.send({
                "success": false,
                "message": "cvv missing",
                "data": {}
            });
            return false;
        }


    } else if (req.body.payment_type == 1) {
        if (!req.body.user_id) {
            res.send({
                "success": false,
                "message": "user_id missing",
                "data": {}
            });
            return false;
        } else if (!req.body.account_number) {
            res.send({
                "success": false,
                "message": "account_number missing",
                "data": {}
            });
            return false;
        } else if (!req.body.routing_number) {
            res.send({
                "success": false,
                "message": "routing_number missing",
                "data": {}
            });
            return false;
        }
        else if (!req.body.name_on_account) {
            res.send({
                "success": false,
                "message": "name_on_account missing",
                "data": {}
            });
            return false;
        }
        else if (!req.body.bank_name) {
            res.send({
                "success": false,
                "message": "bank_name missing",
                "data": {}
            });
            return false;
        }
        
         

    } else if (req.body.payment_type == 2) {
        if (!req.body.user_id) {
            res.send({
                "success": false,
                "message": "user_id missing",
                "data": {}
            });
            return false;
        } else if (!req.body.paypal_email) {
            res.send({
                "success": false,
                "message": "empty paypal_email",
                "data": {}
            });
            return false;
        } else if (!req.body.paypal_authorization) {
            res.send({
                "success": false,
                "message": "empty paypal_authorization",
                "data": {}
            });
            return false;
        }

    }


    // - user_id
    // - number( last 4)
    // - mm
    // - yy
    // - cvv
    // - customer_id (stripe)
    // - zip
    // - primary
    // - routing
    // - account_number
    // - paypal_email
    // - paypal_authorization
    // - payment_type


    data = {
        "trainer_id": ObjectId(req.body.user_id),
        "number": req.body.number,
        "mm": req.body.mm,
        "yy": req.body.yy,
        "payment_type": req.body.payment_type,
        "customer_id": req.body.customer_id,
        "zip": req.body.zip,
        "cvv": req.body.cvv,
        "account_type": req.body.account_type,
        "paypal_email": req.body.paypal_email,
        "paypal_authorization": req.body.paypal_authorization,
        "routing_number": req.body.routing_number,
        "account_number": req.body.account_number,
        "name_on_account": req.body.name_on_account,
        "bank_name": req.body.bank_name,
        "card_holder_name": req.body.card_holder_name,
        'created_at': getCurrentTime(),
        'updated_at': getCurrentTime()
        


    }

    //console.log("Asdas")
    if (req.body.payment_type == 0) {
        // console.log("Assfdsds")
        dbo.collection('TBL_CARDS').updateOne({
            trainer_id: ObjectId(req.body.user_id),
            payment_type: req.body.payment_type
        }, {
            $set: data
        }, {
            upsert: true
        }, function (err, rese) {
            if (err) {
                res.send({
                    "success": true,
                    "message": "Unable to save data.",
                    "data": {}
                });
                return false;
            } else {
                if (req.body.primary == '1') {
                    //console.log("Asdasfdsds")
                    dbo.collection('TBL_CARDS').updateMany({
                        trainer_id: ObjectId(req.body.user_id)
                    }, {
                        $set: {
                            "primary": '0'
                        }
                    }, function (err, rese) {
                        if (err) {
                            res.send({
                                "success": true,
                                "message": "Unable to save data.",
                                "data": {}
                            });
                            return false;
                        } else {
                            dbo.collection('TBL_CARDS').updateOne({
                                trainer_id: ObjectId(req.body.user_id),
                                payment_type: req.body.payment_type
                            }, {
                                $set: {
                                    "primary": '1'
                                }
                            }, {
                                upsert: true
                            }, function (err, rese) {
                                if (err) {
                                    res.send({
                                        "success": true,
                                        "message": "Unable to save data.",
                                        "data": {}
                                    });
                                    return false;
                                } else {
                                    console.log("Asdasfdsdssadfsd")
                                    res.send({
                                        "success": true,
                                        "message": "Card details has been saved",
                                        "data": []
                                    });
                                    return false;
                                }
                            })

                        }
                    })
                } else {
                    res.send({
                        "success": true,
                        "message": "Card details has been saved",
                        "data": []
                    });
                    return false;
                }
            }
        })

    } else if (req.body.payment_type == 1) {
        dbo.collection('TBL_CARDS').updateOne({
            trainer_id: ObjectId(req.body.user_id),
            payment_type: req.body.payment_type
        }, {
            $set: data
        }, {
            upsert: true
        }, function (err, rese) {
            if (err) {
                res.send({
                    "success": false,
                    "message": "Unable to save data.",
                    "data": {}
                });
                return false;
            } else {
                if (req.body.primary == '1') {
                    dbo.collection('TBL_CARDS').updateMany({
                        trainer_id: ObjectId(req.body.user_id)
                    }, {
                        $set: {
                            "primary": '0'
                        }
                    }, function (err, rese) {
                        if (err) {
                            res.send({
                                "success": true,
                                "message": "Unable to save data.",
                                "data": {}
                            });
                            return false;
                        } else {
                            dbo.collection('TBL_CARDS').updateOne({
                                trainer_id: ObjectId(req.body.user_id),
                                payment_type: req.body.payment_type
                            }, {
                                $set: {
                                    "primary": '1'
                                }
                            }, {
                                upsert: true
                            }, function (err, rese) {
                                if (err) {
                                    res.send({
                                        "success": true,
                                        "message": "Unable to save data.",
                                        "data": {}
                                    });
                                    return false;
                                } else {
                                    res.send({
                                        "success": true,
                                        "message": "Bank details has been saved",
                                        "data": []
                                    });
                                    return false;
                                }
                            })

                        }
                    })
                } else {
                    res.send({
                        "success": true,
                        "message": "Bank details has been saved",
                        "data": []
                    });
                    return false;
                }
            }

        })
    } else {
        dbo.collection('TBL_CARDS').updateOne({
            trainer_id: ObjectId(req.body.user_id),
            payment_type: req.body.payment_type
        }, {
            $set: data
        }, {
            upsert: true
        }, function (err, rese) {
            if (err) {
                res.send({
                    "success": false,
                    "message": "Unable to save data.",
                    "data": {}
                });
                return false;
            } else {
                if (req.body.primary == '1') {
                    dbo.collection('TBL_CARDS').updateMany({
                        trainer_id: ObjectId(req.body.user_id)
                    }, {
                        $set: {
                            "primary": '0'
                        }
                    }, function (err, rese) {
                        if (err) {
                            res.send({
                                "success": true,
                                "message": "Unable to save data.",
                                "data": {}
                            });
                            return false;
                        } else {
                            dbo.collection('TBL_CARDS').updateOne({
                                trainer_id: ObjectId(req.body.user_id),
                                payment_type: req.body.payment_type
                            }, {
                                $set: {
                                    "primary": '1'
                                }
                            }, {
                                upsert: true
                            }, function (err, rese) {
                                if (err) {
                                    res.send({
                                        "success": true,
                                        "message": "Unable to save data.",
                                        "data": {}
                                    });
                                    return false;
                                } else {
                                    console.log("Asdasfdsdssadfsd")
                                    res.send({
                                        "success": true,
                                        "message": "Paypal details has been saved",
                                        "data": []
                                    });
                                    return false;
                                }
                            })

                        }
                    })
                } else {
                    res.send({
                        "success": true,
                        "message": "Paypal details has been saved",
                        "data": []
                    });
                    return false;
                }
            }
        })
    }

}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}