var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')
const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});

var sourceFile = require('./register.js');
var db = mongo.connect("mongodb://localhost:27017/gymtraining", {
  useNewUrlParser: true,
  useUnifiedTopology: true
}, function (err, response) {
  if (err) {
    console.log(err);
  } else { //console.log('Connected to ' + db, ' + ', response); 
  }
});
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.login = async function (req, res) {

  // app.post('/api/login', (req, res) => {
  // console.log(req.body);return;
  const {
    email,
    password,
    social_id,
    type,
    user_type
  } = req.body;
  let errors = [];
  if (type == 0) {
    if (!password || !email || !user_type) {
      res.send({
        "success": false,
        "message": "Please enter all fields",
        "data": {}
      });
      return false;
    }
  } else {
    if (!social_id || !user_type) {
      res.send({
        "success": false,
        "message": "Please enter all fields",
        "data": {}
      });
      return false;
    }
  }
  if (user_type == 0) {
    if (type == 0) {
      sourceFile.TBL_TRAINERS.findOne({
        email: email
      }).then(async user => {
        if (user) {
          bcrypt.compare(req.body.password, user.password, function (err, resaa) {
            if (err) {
              res.send({
                "success": false,
                "message": "Email address or password is wrong.",
                "data": {}
              });
              return false;
            }
            if (resaa) {
              sourceFile.TBL_TRAINERS.findOne({
                email: email
              }).then(async user => {
                if (user) {
                  let dbo = await mongodbutil.Get();
                  dbo.collection('TBL_TRAINERS').aggregate([{
                      $match: {
                        _id: ObjectId(user._id)
                      }
                    },
                    {
                      $lookup: {
                        from: 'TBL_TRAINER_DETAILS',
                        localField: '_id',
                        foreignField: 'user_id',
                        as: 'userdetails'
                      }
                    },
                    {
                      $lookup: {
                        from: 'TBL_SERVICES',
                        localField: 'services.id',
                        foreignField: '_id',
                        as: 'services'
                      }
                    },


                  ]).toArray(function (err, resr) {
                    if (err) {
                      throw err;
                    } else {
                      if (resr) {

                        var data = JSON.parse(JSON.stringify(resr));
                        if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
                          var gov_id_verified = true;
                        } else {
                          var gov_id_verified = false;
                        }
                        if (data[0]['isBlocked'] == '1') {
                          res.send({
                            "success": false,
                            "message": "Unfortunately, you have been blocked by Hourful team. Please reach support for more information at info@hourful.io",
                            "data": {}
                          });
                          return false;
                        }
                        data = {
                          "user_id": data[0]['_id'],
                          "first_name": data[0]['userdetails'][0]['first_name'],
                          "last_name": data[0]['userdetails'][0]['last_name'],
                          "phone_number": data[0]['userdetails'][0]['phone_number'],
                          "phone_verified": data[0]['userdetails'][0]['phone_verified'],
                          "email_verified": data[0]['userdetails'][0]['email_verified'],
                          "goverment_id": data[0]['userdetails'][0]['goverment_id'],
                          "gov_id_verified": gov_id_verified,
                          "selfie": data[0]['userdetails'][0]['selfie'],
                          "image": data[0]['userdetails'][0]['image'],
                          "status": data[0]['status'],
                          "email": data[0]['email'],
                          "social": data[0]['social_id'],
                          "services": data[0]['services'],
                          "bio": data[0]['userdetails'][0]['bio'],
                          "timezone": data[0]['timezone'],
                          "timezone_str": data[0]['timezone_str'],
                          "user_type": data[0]['user_type'].toString(),

                        }
                        res.send({
                          "success": true,
                          "message": "Login successfull",
                          "data": data
                        });
                        return false;
                      } else {
                        res.send({
                          "success": false,
                          "message": "something went wrong",
                          "data": {}
                        });
                        return false;
                      }
                    }

                  });
                } else {
                  res.send({
                    "success": false,
                    "message": "Something went wrong",
                    "data": {}
                  });
                  return false;
                }
              })
            } else {
              res.send({
                "success": false,
                "message": "Email address or password is wrong.",
                "data": {}
              });
              return false;
            }
          });
        } else {
          res.send({
            "success": false,
            "message": "Email not exists",
            "data": {}
          });
          return false;
        }
      });
    } else {
      sourceFile.TBL_TRAINERS.findOne({
        social_id: social_id
      }).then(async user => {
        if (user) {
          let dbo = await mongodbutil.Get();
          dbo.collection('TBL_TRAINERS').aggregate([{
              $match: {
                _id: ObjectId(user._id)
              }
            },
            {
              $lookup: {
                from: 'TBL_TRAINER_DETAILS',
                localField: '_id',
                foreignField: 'user_id',
                as: 'userdetails'
              }
            },
            {
              $lookup: {
                from: 'TBL_SERVICES',
                localField: 'services.id',
                foreignField: '_id',
                as: 'services'
              }
            },

          ]).toArray(function (err, resr) {
            if (err) {
              throw err;
            } else {
              if (resr) {
                var data = JSON.parse(JSON.stringify(resr));
                if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
                  var gov_id_verified = true;
                } else {
                  var gov_id_verified = false;
                }
                if (data[0]['isBlocked'] == '1') {
                  res.send({
                    "success": false,
                    "message": "Unfortunately, you have been blocked by Hourful team. Please reach support for more information at info@hourful.io",
                    "data": {}
                  });
                  return false;
                }
                dat = {
                  "user_id": data[0]['_id'],
                  "email": data[0]['email'],
                  "bio": data[0]['userdetails'][0]['bio'],
                  "first_name": data[0]['userdetails'][0]['first_name'],
                  "last_name": data[0]['userdetails'][0]['last_name'],
                  "phone_number": data[0]['userdetails'][0]['phone'],
                  "phone_verified": data[0]['userdetails'][0]['phone_verified'],
                  "email_verified": data[0]['userdetails'][0]['email_verified'],
                  "goverment_id": data[0]['userdetails'][0]['goverment_id'],
                  "gov_id_verified": gov_id_verified,
                  "selfie": data[0]['userdetails'][0]['selfie'],
                  "image": data[0]['userdetails'][0]['image'],
                  "status": data[0]['status'],
                  "social_image": data[0]['userdetails'][0]['social_image'],
                  "services": data[0]['services'],
                  "type": data[0]['type'],
                  "timezone": data[0]['timezone'],
                  "timezone_str": data[0]['timezone_str'],
                  "user_type": data[0]['user_type'].toString(),
                }

                if (data[0]['email'] != undefined || data[0]['userdetails'][0]['email_verified'] != null) {
                  dat.email_verified = 1
                } else {
                  dat.email_verified = 0
                }
                res.send({
                  "success": true,
                  "message": "Login successfull",
                  "data": dat
                });
                return false;
              } else {
                res.send({
                  "success": false,
                  "message": "something went wrong",
                  "data": {}
                });
                return false;
              }
            }

          });
        } else {
          if (req.files != undefined || req.files != null) {
            var sampleFile = req.files.social_image;
            var location = path.join(__dirname, '../../uploads/images');
            sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.social_image.mimetype.split('/')[1], function (err) {
              if (err) {} else {
                req.body['social_image'] = sampleFile.md5 + "." + req.files.social_image.mimetype.split('/')[1];
              }
            })
          } else {
            req.body['social_image'] = ""
          }
          const newUser = new sourceFile.TBL_TRAINERS(req.body);
          newUser
            .save()
            .then(async user => {
              let dbo = await mongodbutil.Get();
              var myobj = {
                user_id: newUser._id,
                first_name: req.body.first_name,
                last_name: req.body.last_name,
                social_image: req.body['social_image'],
                created_at: getCurrentTime(),
                updated: getCurrentTime()
              };
              dbo.collection("TBL_TRAINER_DETAILS").insertOne(myobj, function (err, resv) {
                if (err) {
                  throw err;
                } else {
                  if (req.body.email != undefined || req.body.email != null) {
                    req.body.email_verified = 1;
                  }
                  req.body.user_id = newUser._id;
                  delete req.body.social_id;

                  res.send({
                    "success": true,
                    "message": "login successfull",
                    "data": req.body
                  });
                  return false;

                }
              });
            })
        }
      });
    }
  }
  else{
    if (type == 0) {
      sourceFile.TBL_CLIENTS.findOne({
        email: email
      }).then(async user => {
        if (user) {
          bcrypt.compare(req.body.password, user.password, function (err, resaa) {
            if (err) {
              res.send({
                "success": false,
                "message": "Email address or password is wrong.",
                "data": {}
              });
              return false;
            }
            if (resaa) {
              sourceFile.TBL_CLIENTS.findOne({
                email: email
              }).then(async user => {
                if (user) {
                  let dbo = await mongodbutil.Get();
                  dbo.collection('TBL_CLIENTS').aggregate([{
                      $match: {
                        _id: ObjectId(user._id)
                      }
                    }
                  ]).toArray(function (err, resr) {
                    if (err) {
                      throw err;
                    } else {
                      if (resr) {

                        var data = JSON.parse(JSON.stringify(resr));
                        if (data[0]['goverment_id'] != undefined) {
                          var gov_id_verified = true;
                        } else {
                          var gov_id_verified = false;
                        }
                        if (data[0]['isBlocked'] == '1') {
                          res.send({
                            "success": false,
                            "message": "Unfortunately, you have been blocked by Hourful team. Please reach support for more information at info@hourful.io",
                            "data": {}
                          });
                          return false;
                        } 
                        if (!data[0]['current_trainer']) {
                          data[0]['current_trainer'] = ''
                        }
                        data = {
                          "user_id": data[0]['_id'],
                          "first_name": data[0]['first_name'],
                          "last_name": data[0]['last_name'],
                          "phone_number": data[0]['phone'],
                          "email": data[0]['email'],
                          "user_type": data[0]['user_type'].toString(),
                          "trainer_id": data[0]['current_trainer'],
                          // "phone_verified": data[0]['phone_verified'],
                          // "email_verified": data[0]['email_verified'],
                          "goverment_id": data[0]['goverment_id'],
                          // "gov_id_verified": gov_id_verified,
                          "selfie": data[0]['selfie'],
                          "image": data[0]['image'],
                          "status": data[0]['status'],
                          "email": data[0]['email'],
                          "social_id": data[0]['social_id'],
                          // "services": data[0]['services'],
                          "bio": data[0]['bio'],
                          "timezone": data[0]['timezone'],
                          "timezone_str": data[0]['timezone_str'],
                          "type": data[0]['type']
                        }
                        res.send({
                          "success": true,
                          "message": "Login successfull",
                          "data": data
                        });
                        return false;
                      } else {
                        res.send({
                          "success": false,
                          "message": "something went wrong",
                          "data": {}
                        });
                        return false;
                      }
                    }

                  });
                } else {
                  res.send({
                    "success": false,
                    "message": "Something went wrong",
                    "data": {}
                  });
                  return false;
                }
              })
            } else {
              res.send({
                "success": false,
                "message": "Email address or password is wrong.",
                "data": {}
              });
              return false;
            }
          });
        } else {
          res.send({
            "success": false,
            "message": "Email not exists",
            "data": {}
          });
          return false;
        }
      });
    } else {
      sourceFile.TBL_CLIENTS.findOne({
        social_id: social_id
      }).then(async user => {
        if (user) {
          let dbo = await mongodbutil.Get();
          dbo.collection('TBL_CLIENTS').aggregate([{
              $match: {
                _id: ObjectId(user._id)
              }
            },

          ]).toArray(function (err, resr) {
            if (err) {
              throw err;
            } else {
              if (resr) {
                var data = JSON.parse(JSON.stringify(resr));
                if (data[0]['goverment_id'] != undefined) {
                  var gov_id_verified = true;
                } else {
                  var gov_id_verified = false;
                }
                if (data[0]['isBlocked'] == '1') {
                  res.send({
                    "success": false,
                    "message": "Unfortunately, you have been blocked by Hourful team. Please reach support for more information at info@hourful.io",
                    "data": {}
                  });
                  return false;
                }
                if (!data[0]['current_trainer']) {
                  data[0]['current_trainer'] = ''
                }
                dat = {
                   "user_id": data[0]['_id'],
                    "first_name": data[0]['first_name'],
                    "last_name": data[0]['last_name'],
                    "phone_number": data[0]['phone_number'],
                    "email": data[0]['email'],
                    "user_type": data[0]['user_type'].toString(),
                    "trainer_id": data[0]['current_trainer'],
                    // "phone_verified": data[0]['phone_verified'],
                    // "email_verified": data[0]['email_verified'],
                    "goverment_id": data[0]['goverment_id'],
                    // "gov_id_verified": gov_id_verified,
                    "selfie": data[0]['selfie'],
                    "image": data[0]['image'],
                    "social_image": data[0]['social_image'],
                    "status": data[0]['status'],
                    "email": data[0]['email'],
                    "social_id": data[0]['social_id'],
                    // "services": data[0]['services'],
                    "bio": data[0]['bio'],
                    "timezone": data[0]['timezone'],
                    "timezone_str": data[0]['timezone_str'],
                    "type": data[0]['type']
                }

                // if (data[0]['email'] != undefined || data[0]['email_verified'] != null) {
                //   dat.email_verified = 1
                // } else {
                //   dat.email_verified = 0
                // }
                res.send({
                  "success": true,
                  "message": "Login successfull",
                  "data": dat
                });
                return false;
              } else {
                res.send({
                  "success": false,
                  "message": "something went wrong",
                  "data": {}
                });
                return false;
              }
            }

          });
        } else {
          if (req.files != undefined || req.files != null) {
            var sampleFile = req.files.social_image;
            var location = path.join(__dirname, '../../uploads/images');
            sampleFile.mv(location + "/" + sampleFile.md5 + "." + req.files.social_image.mimetype.split('/')[1], function (err) {
              if (err) {} else {
                req.body['image'] = sampleFile.md5 + "." + req.files.social_image.mimetype.split('/')[1];
              }
            })
          } else {
            req.body['image'] = ""
          }
          const newUser = new sourceFile.TBL_CLIENTS(req.body);
          newUser
            .save()
            .then(async user => {
              let dbo = await mongodbutil.Get();
              var myobj = {
                user_id: newUser._id,
                first_name: req.body.first_name,
                last_name: req.body.last_name,
                image: req.body['social_image'],
                created_at: getCurrentTime(),
                updated: getCurrentTime()
              };
              // dbo.collection("TBL_CLIENT_DETAILS").insertOne(myobj, function (err, resv) {
              //   if (err) {
              //     throw err;
              //   } else {
              //     if (req.body.email != undefined || req.body.email != null) {
              //       req.body.email_verified = 1;
              //     }
              //     req.body.user_id = newUser._id;
              //     delete req.body.social_id;

                  res.send({
                    "success": true,
                    "message": "Login successfull",
                    "data": req.body
                  });
                  return false;

              //   }
              // });
            })
        }
      });
    }
  }


};

function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}