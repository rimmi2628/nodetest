var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
const { ObjectId } = require('mongodb');

exports.trainer_feedback = async function (req, res) {
    let dbo = await mongodbutil.Get();
    let { session_id, client_id, trainer_id, ratings, comments } = req.body
    console.log(req.body)
    if (!session_id || !client_id || !trainer_id || !ratings) {
        res.send({ "success": false, "message": "Please enter all fields", "data": {} });
        return false;
    }
    let insertData = {
        session_id: ObjectId(session_id),
        client_id: ObjectId(client_id),
        trainer_id: ObjectId(trainer_id),
        ratings: parseFloat(ratings),
        comments: comments ? comments : '',
        created_at:getCurrentTime(),
        updated_at:getCurrentTime()

    }

    // dbo.collection('TBL_TRAINERS').find({ _id: ObjectId(trainer_id) })


    dbo.collection('TBL_TRAINERS').find({
        _id: ObjectId(trainer_id)
    }).toArray(function (errRating, trainerRating) { 
        if(errRating){
            throw errRating
        }
        else{
            ratings=parseFloat(ratings)
            let new_avg_rating,new_ratings
            let trainerDetails=trainerRating[0]
            let avrage_rating=parseFloat(trainerDetails.avg_ratings)
            let countRating=parseFloat(trainerDetails.ratings)
            console.log(avrage_rating,countRating,ratings,countRating)
            if(avrage_rating && countRating){
                new_avg_rating=(avrage_rating*countRating+ratings)/(countRating+1)
                new_ratings=countRating+1


            }
            else{
                new_avg_rating=ratings
                new_ratings=1


            }
            let updateDetails={
                avg_ratings:new_avg_rating,
                ratings:new_ratings
            }

            dbo.collection('TBL_TRAINERS').updateOne({_id: ObjectId(trainer_id)}, {$set:updateDetails}, function (updateErr, resv) {
                if (updateErr) {
                    throw err;
                } else {
                  //  console.log(resv)
                }
            })
        }

    })
    dbo.collection("TBL_CLIENT_TRAINER_RATINGS").insertOne(insertData, function (err, resr) {
        if (err) {

            return res.send({ "success": false, "message": "Something Went Wrong", error: err.message });

        }
        else {
            return res.send({ "success": true, "message": "Your Rating Submitted Sucessfully" });


        }
    })

}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

