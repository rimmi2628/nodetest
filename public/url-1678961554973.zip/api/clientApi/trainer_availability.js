var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = require('mongodb').ObjectID
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
var mongodbutil = require('./mongodbutil');
var sourceFile = require('../register.js');

exports.set_availability = async function (req, res) {
	if (!req.body.user_id || !req.body.availability) {
		res.send({
			"success": false,
			"message": "user_id or availability empty",
			"data": []
		});
		return false;
	}
	console.log(JSON.parse(req.body.availability))
	let dbo = await mongodbutil.Get();
	var data = ''
	var data = JSON.parse(req.body.availability)
	var sun = data[6]
	var mon = data[0]
	var tue = data[1]
	var wed = data[2]
	var thur = data[3]
	var fri = data[4]
	var sat = data[5]
	if (sun) {
		var fSlotsS = []
		for (var i = 0; i < sun.slots.length; i++) {
		var newSlots = []
		var j = 0
			sun.slots[i].trainer_id = ObjectId(req.body.user_id)
			sun.slots[i].day = "6"
			sun.slots[i].type = '1'
			sun.slots[i].date = ''
			sun.slots[i].start_time = sun.slots[i].from_hrs
			sun.slots[i].end_time = sun.slots[i].to_hrs
			// sun.slots[i].day = ''
			sun.slots[i].month = ''
			sun.slots[i].repeat = '1'
			sun.slots[i].year = ''
			if (!sun.copy_to) {
				sun.slots[i].copy_to = "";
			}
			else{
				sun.slots[i].copy_to = sun.copy_to.join();
			}
			fSlotsS[i] = []
			for (var d = parseInt(sun.slots[i].from_hrs); d < parseInt(sun.slots[i].to_hrs); d = parseInt(d)+1) {
				// console.log(d)
				newSlots.push(d.toString())
				fSlotsS[i].push(d.toString())
			}
			
			
		}
		console.log(newSlots)
		// return false
		var myquery = { trainer_id: ObjectId(req.body.user_id), day:"6"};
		dbo.collection("TBL_TRAINER_AVAILABILITY").deleteMany(myquery, function (err, obj) {
		   if (err) throw err;
		   console.log('deleted availability')
		   // console.log(obj)
		});		
		if (sun.slots.length != 0) {
			dbo.collection("TBL_TRAINER_AVAILABILITY").insertMany(sun.slots, function (err, resv) {
				if (err) {
					throw err;
				} else {
					var dd = []
					for (var i = 0; i < resv.insertedIds.length; i++) {
						for (var l = 0; l < fSlotsS[i].length; l++) {
							dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),day:'6',time : fSlotsS[i][l],price : '0',slots : '1',availableSlots : '1',instantBooking : '0',date : ''})
						}
						
					}
					dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
						if (err) {
							throw err;
						} 
					});
					console.log(resv)
				}
			});
		}
		
	}
	if (mon) {
		var fSlotsM = []
		for (var i = 0; i < mon.slots.length; i++) {
		var newSlots = []
		var j = 0
			mon.slots[i].trainer_id = ObjectId(req.body.user_id)
			mon.slots[i].day = "0"
			mon.slots[i].type = '1'
			mon.slots[i].date = ''
			mon.slots[i].start_time = mon.slots[i].from_hrs
			mon.slots[i].end_time = mon.slots[i].to_hrs
			// mon.slots[i].day = ''
			mon.slots[i].month = ''
			mon.slots[i].repeat = '1'
			mon.slots[i].year = ''
			if (!mon.copy_to) {
				mon.slots[i].copy_to = "";
			}
			else{
				mon.slots[i].copy_to = mon.copy_to.join();
			}
			fSlotsM[i] = []
			for (var d = parseInt(mon.slots[i].from_hrs); d < parseInt(mon.slots[i].to_hrs); d = parseInt(d)+1) {
				// console.log(d)
				newSlots.push(d.toString())
				fSlotsM[i].push(d.toString())
			}

			// mon.slots[i].copy_to = mon.copy_to.join();
		}
		var myquery = { trainer_id: ObjectId(req.body.user_id), day:"0"};
		dbo.collection("TBL_TRAINER_AVAILABILITY").deleteMany(myquery, function (err, obj) {
		   if (err) throw err;
		   console.log('deleted availability')
		});		
		if (mon.slots.length != 0) {
			dbo.collection("TBL_TRAINER_AVAILABILITY").insertMany(mon.slots, function (err, resv) {
				if (err) {
					throw err;
				} else {
					var dd = []
					for (var i = 0; i < resv.insertedIds.length; i++) {
						console.log(fSlotsM[i].length)
						for (var l = 0; l < fSlotsM[i].length; l++) {
							dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),day:'0',time : fSlotsM[i][l],price : '0',slots : '1',availableSlots : '1',instantBooking : '0',date : ''})
						}
						
					}
					dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
						if (err) {
							throw err;
						} 
					});
					console.log(resv)
				}
			});
		}
	}
	if (tue) {
		var fSlotsTu = []
		for (var i = 0; i < tue.slots.length; i++) {
		var newSlots = []
		var j = 0
			tue.slots[i].trainer_id = ObjectId(req.body.user_id)
			tue.slots[i].day = "1"
			tue.slots[i].type = '1'
			tue.slots[i].date = ''
			tue.slots[i].start_time = tue.slots[i].from_hrs
			tue.slots[i].end_time = tue.slots[i].to_hrs
			// tue.slots[i].day = ''
			tue.slots[i].month = ''
			tue.slots[i].repeat = '1'
			tue.slots[i].year = ''
			// tue.slots[i].copy_to = tue.copy_to.join();
			if (!tue.copy_to) {
				tue.slots[i].copy_to = "";
			}
			else{
				tue.slots[i].copy_to = tue.copy_to.join();
			}
			fSlotsTu[i] = []
			for (var d = parseInt(tue.slots[i].from_hrs); d < parseInt(tue.slots[i].to_hrs); d = parseInt(d)+1) {
				console.log(d)
				newSlots.push(d.toString())
				fSlotsTu[i].push(d.toString())
			}

		}
		var myquery = { trainer_id: ObjectId(req.body.user_id), day:"1"};
		dbo.collection("TBL_TRAINER_AVAILABILITY").deleteMany(myquery, function (err, obj) {
		   if (err) throw err;
		   console.log('deleted availability')
		});		
		if (tue.slots.length != 0) {
			dbo.collection("TBL_TRAINER_AVAILABILITY").insertMany(tue.slots, function (err, resv) {
				if (err) {
					throw err;
				} else {
					var dd = []
					// for (var i = 0; i < resv.insertedIds.length; i++) {
					// 	dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),time : '',price : '',slots : '2',availableSlots : '2',instantBooking : '',date : ''})
					// }
					for (var i = 0; i < resv.insertedIds.length; i++) {
						for (var l = 0; l < fSlotsTu[i].length; l++) {
							dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),day:'1',time : fSlotsTu[i][l],price : '0',slots : '1',availableSlots : '1',instantBooking : '0',date : ''})
						}
						
					}
					dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
						if (err) {
							throw err;
						} 
					});
					console.log(resv)
				}
			});
		}
	}
	if (wed) {
		var fSlotsWe = []
		for (var i = 0; i < wed.slots.length; i++) {
		var newSlots = []
		var j = 0

			wed.slots[i].trainer_id = ObjectId(req.body.user_id)
			wed.slots[i].day = "2"
			wed.slots[i].type = '1'
			wed.slots[i].date = ''
			wed.slots[i].start_time = wed.slots[i].from_hrs
			wed.slots[i].end_time = wed.slots[i].to_hrs
			// wed.slots[i].day = ''
			wed.slots[i].month = ''
			wed.slots[i].repeat = '1'
			wed.slots[i].year = ''
			// wed.slots[i].copy_to = wed.copy_to.join();
			if (!wed.copy_to) {
				wed.slots[i].copy_to = "";
			}
			else{
				wed.slots[i].copy_to = wed.copy_to.join();
			}
			fSlotsWe[i] = []
			for (var d = parseInt(wed.slots[i].from_hrs); d < parseInt(wed.slots[i].to_hrs); d = parseInt(d)+1) {
				console.log(d)
				newSlots.push(d.toString())
				fSlotsWe[i].push(d.toString())
			}

		}
		var myquery = { trainer_id: ObjectId(req.body.user_id), day:"2"};
		dbo.collection("TBL_TRAINER_AVAILABILITY").deleteMany(myquery, function (err, obj) {
		   if (err) throw err;
		   console.log('deleted availability')
		});	
		if (wed.slots.length != 0) {	
			dbo.collection("TBL_TRAINER_AVAILABILITY").insertMany(wed.slots, function (err, resv) {
				if (err) {
					throw err;
				} else {
					var dd = []
					// for (var i = 0; i < resv.insertedIds.length; i++) {
					// 	dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),time : '',price : '',slots : '2',availableSlots : '2',instantBooking : '',date : ''})
					// }
					for (var i = 0; i < resv.insertedIds.length; i++) {
						for (var l = 0; l < fSlotsWe[i].length; l++) {
							dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),day:'2',time :fSlotsWe[i][l],price : '0',slots : '1',availableSlots : '1',instantBooking : '0',date : ''})
						}
						
					}
					dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
						if (err) {
							throw err;
						} 
					});
					console.log(resv)
				}
			});
		}
	}
	if (thur) {
		
		var fSlotsTh = []
		for (var i = 0; i < thur.slots.length; i++) {
			var newSlots = []
			var j = 0
			thur.slots[i].trainer_id = ObjectId(req.body.user_id)
			thur.slots[i].day = "3"
			thur.slots[i].type = '1'
			thur.slots[i].date = ''
			thur.slots[i].start_time = thur.slots[i].from_hrs
			thur.slots[i].end_time = thur.slots[i].to_hrs
			// thur.slots[i].day = ''
			thur.slots[i].month = ''
			thur.slots[i].repeat = '1'
			thur.slots[i].year = ''
			// thur.slots[i].copy_to = thur.copy_to.join();
			if (!thur.copy_to) {
				thur.slots[i].copy_to = "";
			}
			else{
				thur.slots[i].copy_to = thur.copy_to.join();
			}
			console.log('d')
			fSlotsTh[i] = []
			for (var d = parseInt(thur.slots[i].from_hrs); d < parseInt(thur.slots[i].to_hrs); d = parseInt(d)+1) {

				console.log(d)
				newSlots.push(d.toString())
				fSlotsTh[i].push(d.toString())
			}
	
		}
		// console.log(fSlotsTh)
		// console.log(fSlotsTh[0].length)
		// console.log(newSlots)
		// console.log('newSlots')
		// return false
		var myquery = { trainer_id: ObjectId(req.body.user_id), day:"3"};
		dbo.collection("TBL_TRAINER_AVAILABILITY").deleteMany(myquery, function (err, obj) {
		   if (err) throw err;
		   console.log('deleted availability')
		});		
		if (thur.slots.length != 0) {
			dbo.collection("TBL_TRAINER_AVAILABILITY").insertMany(thur.slots, function (err, resv) {
				if (err) {
					throw err;
				} else {
					var dd = []
					// for (var i = 0; i < resv.insertedIds.length; i++) {
					// 	dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),time : '',price : '',slots : '2',availableSlots : '2',instantBooking : '',date : ''})
					// }
					for (var i = 0; i < resv.insertedIds.length; i++) {
						for (var l = 0; l < fSlotsTh[i].length; l++) {
							console.log(fSlotsTh)
							dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),day:'3',time : fSlotsTh[i][l],price : '0',slots : '1',availableSlots : '1',instantBooking : '0',date : ''})
						}
						
					}
					dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
						if (err) {
							throw err;
						} 
					});
					console.log(resv)
				}
			});
		}
	}
	if (fri) {
		var fSlotsFr = []
		
		for (var i = 0; i < fri.slots.length; i++) {
			var newSlots = []
			var j = 0
			fri.slots[i].trainer_id = ObjectId(req.body.user_id)
			fri.slots[i].day = "4"
			fri.slots[i].type = '1'
			fri.slots[i].date = ''
			fri.slots[i].start_time = fri.slots[i].from_hrs
			fri.slots[i].end_time = fri.slots[i].from_hrs
			// fri.slots[i].day = ''
			fri.slots[i].month = ''
			fri.slots[i].repeat = '1'
			fri.slots[i].year = ''
			// fri.slots[i].copy_to = fri.copy_to.join();
			if (!fri.copy_to) {
				fri.slots[i].copy_to = "";
			}
			else{
				fri.slots[i].copy_to = fri.copy_to.join();
			}
			fSlotsFr[i] = []
			for (var d = parseInt(fri.slots[i].from_hrs); d < parseInt(fri.slots[i].to_hrs); d = parseInt(d)+1) {
				console.log(d)
				newSlots.push(d.toString())
				fSlotsFr[i].push(d.toString())

			}

		}
		var myquery = { trainer_id: ObjectId(req.body.user_id), day:"4"};
		dbo.collection("TBL_TRAINER_AVAILABILITY").deleteMany(myquery, function (err, obj) {
		   if (err) throw err;
		   console.log('deleted availability')
		});		
		if (fri.slots.length != 0) {
			dbo.collection("TBL_TRAINER_AVAILABILITY").insertMany(fri.slots, function (err, resv) {
				if (err) {
					throw err;
				} else {
					var dd = []
					// for (var i = 0; i < resv.insertedIds.length; i++) {
					// 	dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),time : '',price : '',slots : '2',availableSlots : '2',instantBooking : '',date : ''})
					// }
					for (var i = 0; i < resv.insertedIds.length; i++) {
						for (var l = 0; l < fSlotsFr[i].length; l++) {
							dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),day:'4',time : fSlotsFr[i][l],price : '0',slots : '1',availableSlots : '1',instantBooking : '0',date : ''})
						}
						
					}
					dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
						if (err) {
							throw err;
						} 
					});
					console.log(resv)
				}
			});
		}
	}
	if (sat) {
		var fSlotsSa = []
		
		for (var i = 0; i < sat.slots.length; i++) {
			var newSlots = []
			var j = 0
			sat.slots[i].trainer_id = ObjectId(req.body.user_id)
			sat.slots[i].day = "5"
			sat.slots[i].type = '1'
			sat.slots[i].date = ''
			sat.slots[i].start_time = sat.slots[i].from_hrs
			sat.slots[i].end_time = sat.slots[i].to_hrs
			// sat.slots[i].day = ''
			sat.slots[i].month = ''
			sat.slots[i].repeat = '1'
			sat.slots[i].year = ''
			// sat.slots[i].copy_to = sat.copy_to.join();
			if (!sat.copy_to) {
				sat.slots[i].copy_to = "";
			}
			else{
				sat.slots[i].copy_to = sat.copy_to.join();
			}
			fSlotsSa[i] = []
			for (var d = parseInt(sat.slots[i].from_hrs); d < parseInt(sat.slots[i].to_hrs); d = parseInt(d)+1) {
				console.log(d)
				newSlots.push(d.toString())
				fSlotsSa[i].push(d.toString())
			}
			
		}
		var myquery = { trainer_id: ObjectId(req.body.user_id), day:"5"};
		dbo.collection("TBL_TRAINER_AVAILABILITY").deleteMany(myquery, function (err, obj) {
		   if (err) throw err;
		   console.log('deleted availability')
		});		
		if (sat.slots.length != 0) {
			dbo.collection("TBL_TRAINER_AVAILABILITY").insertMany(sat.slots, function (err, resv) {
				if (err) {
					throw err;
				} else {
					var dd = []
					// for (var i = 0; i < resv.insertedIds.length; i++) {
					// 	dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),time : '',price : '',slots : '2',availableSlots : '2',instantBooking : '',date : ''})
					// }
					for (var i = 0; i < resv.insertedIds.length; i++) {
						for (var l = 0; l < fSlotsSa[i].length; l++) {
							dd.push({trainer_availability_id : ObjectId(resv.insertedIds[i]),day:'5',time : fSlotsSa[i][l],price : '0',slots : '1',availableSlots : '1',instantBooking : '0',date : ''})
						}
						
					}
					dbo.collection("TBL_TRAINER_AVAILABILITY_SLOTS").insertMany(dd, function (err, resv) {
						if (err) {
							throw err;
						} 
					});
					console.log(resv)
				}
			});
		}
	}
	dbo.collection('TBL_TRAINER_AVAILABILITY').aggregate([{
    $match: {
      trainer_id: ObjectId(req.body.user_id)
    }
	  }]).toArray(function (err, resr) {
	    if (err) {
	      throw err;
	    } else {
	    	data = []
	    	datac = []
	    	data1 = []
	    	data1c = []
	    	data2 = []
	    	data2c = []
	    	data3 = []
	    	data3c = []
	    	data4 = []
	    	data4c = []
	    	data5 = []
	    	data5c = []
	    	data6 = []
	    	data6c = []

	    	for (var i = 0; i < resr.length; i++) {
	    		if(resr[i].day == 0){
	    			// data.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			datac.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 1){
	    			// data1.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data1.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data1c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 2){
	    			// data2.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data2.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data2c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 3){
	    			// data3.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data3.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data3c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 4){
	    			// data4.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data4.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data4c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 5){
	    			// data5.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data5.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data5c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 6){

	    			// data6.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data6.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data6c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    	} 
	    	var finalArr = [];
	    	var finalArr1 = {};
	    	if (!datac[0]) {
	    		datac.push({copy_to:[]})
	    	}
	    	if (!data1c[0]) {
	    		data1c.push({copy_to:[]})
	    	}
	    	if (!data2c[0]) {
	    		data2c.push({copy_to:[]})
	    	}
	    	if (!data3c[0]) {
	    		data3c.push({copy_to:[]})
	    	}
	    	if (!data4c[0]) {
	    		data4c.push({copy_to:[]})
	    	}
	    	if (!data5c[0]) {
	    		data5c.push({copy_to:[]})
	    	}
	    	if (!data6c[0]) {
	    		data6c.push({copy_to:[]})
	    	}
	    	finalArr.push({slots:data,copy_to:datac[0].copy_to})
	    	finalArr.push({slots:data1,copy_to:data1c[0].copy_to})
	    	finalArr.push({slots:data2,copy_to:data2c[0].copy_to})
	    	finalArr.push({slots:data3,copy_to:data3c[0].copy_to})
	    	finalArr.push({slots:data4,copy_to:data4c[0].copy_to})
	    	finalArr.push({slots:data5,copy_to:data5c[0].copy_to})
	    	finalArr.push({slots:data6,copy_to:data6c[0].copy_to})
	    	// console.log(finalArr);
	    	// return false
	    	finalArr1[0] = finalArr[0]
	    	finalArr1[1] = finalArr[1]
	    	finalArr1[2] = finalArr[2]
	    	finalArr1[3] = finalArr[3]
	    	finalArr1[4] = finalArr[4]
	    	finalArr1[5] = finalArr[5]
	    	finalArr1[6] = finalArr[6]
	    	// console.log(finalArr);
	    	res.send({
	          "success": true,
	          "message": "success",
	          "data": finalArr1
	        });
	        return false;
	    }
	});
	// res.send({ "status": true, "message": 'success',"data": data });

}

exports.trainer_availability = async function (req, res) {
	if (!req.body.user_id || !req.body.trainer_id) {
		res.send({
			"success": false,
			"message": "user_id or trainer_id empty",
			"data": []
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_TRAINER_AVAILABILITY').aggregate([{
    $match: {
      trainer_id: ObjectId(req.body.trainer_id)
    }
	  }]).toArray(function (err, resr) {
	    if (err) {
	      throw err;
	    } else {
	    	data = []
	    	datac = []
	    	data1 = []
	    	data1c = []
	    	data2 = []
	    	data2c = []
	    	data3 = []
	    	data3c = []
	    	data4 = []
	    	data4c = []
	    	data5 = []
	    	data5c = []
	    	data6 = []
	    	data6c = []

	    	for (var i = 0; i < resr.length; i++) {
	    		if(resr[i].day == 0){
	    			// data.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			datac.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 1){
	    			// data1.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data1.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data1c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 2){
	    			// data2.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data2.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data2c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 3){
	    			// data3.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data3.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data3c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 4){
	    			// data4.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data4.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data4c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 5){
	    			// data5.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data5.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data5c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    		if(resr[i].day == 6){

	    			// data6.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id,type:resr[i].type,date:resr[i].date,start_time:resr[i].start_time,end_time:resr[i].end_time,month:resr[i].month,year:resr[i].year})
	    			data6.push({_id:resr[i]._id,day:resr[i].day,from_hrs:resr[i].from_hrs,to_hrs:resr[i].to_hrs,trainer_id:resr[i].trainer_id})
	    			data6c.push({copy_to:resr[i].copy_to.split(",")})
	    		}
	    	} 
	    	var finalArr = [];
	    	var finalArr1 = {};
	    	if (!datac[0]) {
	    		datac.push({copy_to:[]})
	    	}
	    	if (!data1c[0]) {
	    		data1c.push({copy_to:[]})
	    	}
	    	if (!data2c[0]) {
	    		data2c.push({copy_to:[]})
	    	}
	    	if (!data3c[0]) {
	    		data3c.push({copy_to:[]})
	    	}
	    	if (!data4c[0]) {
	    		data4c.push({copy_to:[]})
	    	}
	    	if (!data5c[0]) {
	    		data5c.push({copy_to:[]})
	    	}
	    	if (!data6c[0]) {
	    		data6c.push({copy_to:[]})
	    	}
	    	console.log(checkArray(datac[0].copy_to));
	    	console.log(datac[0].copy_to);
	    	if (checkArray(datac[0].copy_to) == 'false') {
	    		 datac[0].copy_to = []
	    		// datac.push({copy_to:[]})
	    	}
	    	if (checkArray(data1c[0].copy_to) == 'false') {
	    		 data1c[0].copy_to = []
	    		// data1c.push({copy_to:[]})
	    	}
	    	if (checkArray(data2c[0].copy_to) == 'false') {
	    		 data2c[0].copy_to = []
	    		// data2c.push({copy_to:[]})
	    	}
	    	if (checkArray(data3c[0].copy_to) == 'false') {
	    		 data3c[0].copy_to = []
	    		// data3c.push({copy_to:[]})
	    	}
	    	if (checkArray(data4c[0].copy_to) == 'false') {
	    		 data4c[0].copy_to = []
	    		// data4c.push({copy_to:[]})
	    	}
	    	if (checkArray(data5c[0].copy_to) == 'false') {
	    		 data5c[0].copy_to = []
	    		// data5c.push({copy_to:[]})
	    	}
	    	if (checkArray(data6c[0].copy_to) == 'false') {
	    		data6c[0].copy_to = []
	    		// data6c.push({copy_to:[]})
	    	}
	    	finalArr.push({slots:data,copy_to:datac[0].copy_to})
	    	finalArr.push({slots:data1,copy_to:data1c[0].copy_to})
	    	finalArr.push({slots:data2,copy_to:data2c[0].copy_to})
	    	finalArr.push({slots:data3,copy_to:data3c[0].copy_to})
	    	finalArr.push({slots:data4,copy_to:data4c[0].copy_to})
	    	finalArr.push({slots:data5,copy_to:data5c[0].copy_to})
	    	finalArr.push({slots:data6,copy_to:data6c[0].copy_to})
	    	// console.log(finalArr);
	    	// return false
	    	finalArr1[0] = finalArr[0]
	    	finalArr1[1] = finalArr[1]
	    	finalArr1[2] = finalArr[2]
	    	finalArr1[3] = finalArr[3]
	    	finalArr1[4] = finalArr[4]
	    	finalArr1[5] = finalArr[5]
	    	finalArr1[6] = finalArr[6]
	    	// console.log(finalArr);
	    	res.send({
	          "success": true,
	          "message": "success",
	          "data": finalArr1
	        });
	        return false;
	    }
	});
}

function checkArray(my_arr){
   for(var i=0;i<my_arr.length;i++){
       if(my_arr[i] === "")   
          return 'false';
   }
   return 'true';
}

function getCurrentTime() {
	var d = new Date();
	var n = d.toUTCString();
	var date = new Date(n);
	var seconds = date.getTime() / 1000; //1440516958
	return seconds;
}