var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);

var mongodbutil = require('./mongodbutil');

exports.punch_card = async function (req, res) {
    if ( !req.body.client_id) {
        res.send({
            "success": false,
            "message": " client_id required",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    if (!req.body.trainer_id ) {
            dbo.collection('TBL_TRAINER_PUNCH_CARDS').aggregate([
            {
                $match: {
                    status: {$ne:'0'},
                    
                }
            },
        

        ]).toArray(function (err, resr) {
            if (err) {
                throw err;
            } else {
                if (resr) {

                    dbo.collection('TBL_CLIENT_PUNCH_CARDS').aggregate([
                        {
                            $match: {
                                client_id: ObjectId(req.body.client_id)
                            },
                        },
                        {
                            $sort: {
                                created_at: -1
                            }
                        },
                        {

                            $lookup: {
                                from: 'TBL_TRAINERS',
                                localField: 'trainer_id',
                                foreignField: 'trainer_main_id',
                                as: 'trainerdetails'
                            }
                        },
                    ]).toArray(function (err, resr_user) {
                        var res_data = []
                        var res_data_client = []
                        var data_user = JSON.parse(JSON.stringify(resr_user));

                        for (var k = 0; k < data_user.length; k++) {
                        if (!data_user[k]['trainerdetails']) {
                            var name = ''
                        }
                        else{
                            var name = data_user[k]['trainerdetails'][0].name
                        }
                            res_data_client.push({
                                "id": data_user[k]['_id'].toString(),
                                "sessions": data_user[k]['total_sessions'].toString(),
                                "pending": data_user[k]['sessions_available'].toString(),
                                "price": data_user[k]['price'].toString(),
                                "purchased_date": data_user[k]['created_at'].toString(),
                                "trainer_name": name
                            })
                        }

                        var data = JSON.parse(JSON.stringify(resr));
                    
                        for (var j = 0; j < data.length; j++) {
                        
                            res_data.push({
                                "id": data[j]['_id'].toString(),
                                "sessions": data[j]['sessions'].toString(),
                                "price": data[j]['price'].toString(),
                            })
                        }
                        var data_send = {}
                        data_send.purchase_new = res_data
                        data_send.purchased = res_data_client
                        // data_send.push({'purchase_new':res_data},{'purchased':res_data_client})
                        // data_send.push()
                        res.send({
                            "success": true,
                            "message": "success",
                            "data": data_send
                        });
                        return false;

                    })
                    
                } else {
                    res.send({
                        "success": false,
                        "message": "something went wrong",
                        "data": {}
                    });
                    return false;
                }
            }

        });
    }
    else{
        dbo.collection('TBL_TRAINER_PUNCH_CARDS').aggregate([
            {
                $match: {
                    status: {$ne:'0'},

                    trainer_id: ObjectId(req.body.trainer_id)
                }
            },
        

        ]).toArray(function (err, resr) {
            if (err) {
                throw err;
            } else {
                if (resr) {

                    dbo.collection('TBL_CLIENT_PUNCH_CARDS').aggregate([
                        {
                            $match: {
                                client_id: ObjectId(req.body.client_id),
                                sessions_available: {$gte:1},
                                trainer_id: ObjectId(req.body.trainer_id)
                            }
                        },
                        {

                            $lookup: {
                                from: 'TBL_TRAINERS',
                                localField: 'trainer_id',
                                foreignField: 'trainer_main_id',
                                as: 'trainerdetails'
                            }
                        },
                    ]).toArray(function (err, resr_user) {
                        var res_data = []
                        var res_data_client = []
                        var data_user = JSON.parse(JSON.stringify(resr_user));

                        for (var k = 0; k < data_user.length; k++) {
                            if (!data_user[k]['trainerdetails']) {
                                var name = ''
                            }
                            else{
                                var name = data_user[k]['trainerdetails'][0].name
                            }
                            res_data_client.push({
                                "id": data_user[k]['_id'].toString(),
                                "sessions": data_user[k]['total_sessions'].toString(),
                                "pending": data_user[k]['sessions_available'].toString(),
                                "price": data_user[k]['price'].toString(),
                                "purchased_date": data_user[k]['created_at'].toString(),
                                "trainer_name": name
                            })
                        }

                        var data = JSON.parse(JSON.stringify(resr));
                    
                        for (var j = 0; j < data.length; j++) {
                        
                            res_data.push({
                                "id": data[j]['_id'].toString(),
                                "sessions": data[j]['sessions'].toString(),
                                "price": data[j]['price'].toString(),
                            })
                        }
                        var data_send = {}
                        data_send.purchase_new = res_data
                        data_send.purchased = res_data_client
                        // data_send.push({'purchase_new':res_data},{'purchased':res_data_client})
                        // data_send.push()
                        res.send({
                            "success": true,
                            "message": "success",
                            "data": data_send
                        });
                        return false;

                    })
                    
                } else {
                    res.send({
                        "success": false,
                        "message": "something went wrong",
                        "data": {}
                    });
                    return false;
                }
            }

        });
    }
}

exports.buy_punch_card = async function (req, res) {
    if (!req.body.trainer_id || !req.body.client_id || !req.body.punch_card_id) {
        res.send({
            "success": false,
            "message": "trainer id and client_id and punch_card_id required",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    // "total_sessions": "5",
    // "sessions_available": "4",
    // "trainer_id": "60cb81d4ca27f966ffef20e4",
    // "client_id": "60c8a5c034abfb24902c0aeb",
    // "punch_id": "60d2dc74dd69a25905bf2397",
    // "price": "20",
    // "created_at": 1624535636
    var data = {
        'punch_id':ObjectId(req.body.punch_card_id),trainer_id:ObjectId(req.body.trainer_id),client_id:ObjectId(req.body.client_id),sessions_available:parseInt(req.body.sessions),total_sessions:parseInt(req.body.sessions),price:req.body.price,created_at:getCurrentTime(),updated_at:getCurrentTime(),transaction_id:req.body.transaction_id
    }
     dbo.collection("TBL_CLIENT_PUNCH_CARDS").insertOne(data, function(err,resr){
        if (err){
            throw err;
        }
        else{
            if(resr){
                res.send({"success":true,"message":"Punch Card Added!","data":[]});
                return false;
            }
            else{
                res.send({"success":false,"message":"something went wrong","data":[]});
                return false;
            }
        }
    }); 
}


exports.punch_card_details = async function (req, res) {
    if (!req.body.punch_card_id || !req.body.client_id) {
        res.send({
            "success": false,
            "message": "punch_card_id and client_idrequired",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();

    

    // dbo.collection('TBL_CLIENT_PUNCH_CARDS').aggregate([
    //     {
    //         $match: {
    //             punch_id: ObjectId(req.body.punch_card_id),
    //             client_id:ObjectId(req.body.client_id),
    //         }
    //     },
        


    // ]).toArray(function (err, resr_user) {
        dbo.collection('TBL_BOOKINGS').aggregate([
        {
            $match: {
                punch_card_id: ObjectId(req.body.punch_card_id),
                user_id:ObjectId(req.body.client_id),
            }
        },
        {
            $lookup: {
                from: 'TBL_CLIENTS_DETAILS',
                localField: 'user_id',
                foreignField: 'user_id',
                as: 'userdetails'
            }
        },
        {

            $lookup: {
                from: 'TBL_TRAINERS',
                localField: 'trainer_id',
                foreignField: 'trainer_main_id',
                as: 'trainerdetails'
            }
        },
        {

            $lookup: {
                from: 'TBL_FEEDBACK_TO_USER',
                localField: '_id',
                foreignField: 'booking_id',
                as: 'reviews'
            }
        },
    {
            $unwind: {
                path: "$reviews",
                preserveNullAndEmptyArrays: true
            }
        },

    ]).toArray(function (err, resr_user_fin) {
            var res_data = []
            var res_data_client = []
            var data_user = JSON.parse(JSON.stringify(resr_user_fin));

           // console.log(data_user[0].bookingdetails)
           // console.log(data_user)
           // return false
           // var bookings = data_user[0].bookingdetails
           var gymdeta = []

           for (var i = 0; i < data_user.length; i++) {
                if (resr_user_fin[i]['status'] == undefined) {
                    resr_user_fin[i]['status'] = 0;
                }
                if (resr_user_fin[i]['trainerdetails'].length) {
                    // if (! resr_user_fin[i]['userdetails'][0].last_name) {
                    //      resr_user_fin[i]['userdetails'][0].last_name = ''
                    // }
                    if (!resr_user_fin[i]['trainerdetails'][0]) {
                        var name = ''
                    }
                    else{
                        var name = resr_user_fin[i]['trainerdetails'][0].name
                    }
                     // var name = resr_user_fin[i]['userdetails'][0].first_name + ' ' + resr_user_fin[i]['userdetails'][0].last_name
                     // var name = resr_user_fin[i]['userdetails'][0].first_name + ' ' + resr_user_fin[i]['userdetails'][0].last_name
                    if (!resr_user_fin[i]["day"] || !resr_user_fin[i]["month"] || !resr_user_fin[i]["year"]) {
                        resr_user_fin[i]["day"] = '';
                        resr_user_fin[i]["month"] = '';
                        resr_user_fin[i]["year"] = '';
                    }
                    
                    if (!resr_user_fin[i]["rating"]) {
                        resr_user_fin[i]["rating"] = '0';
                    }
                    if (!resr_user_fin[i]["reviews"]) {
                        resr_user_fin[i]["reviews"] = '';
                    }
                    else{
                        resr_user_fin[i]['rating'] = resr_user_fin[i]['reviews'].rating;
                        resr_user_fin[i]["reviews"] = resr_user_fin[i]['reviews'].rating;

                    }
                   
                       gymdeta.push({
                        "_id": String(resr_user_fin[i]["_id"]),
                        "client_id": String(resr_user_fin[i]["user_id"]),
                        "review": String(resr_user_fin[i]['reviews']),
                        "rating": String(resr_user_fin[i]['rating']),
                        "status": String(resr_user_fin[i]['status']),
                        "payment_type": String(resr_user_fin[i]['payment_method']),
                        "price": String(resr_user_fin[i]['price']),
                        "trainer_id": String(resr_user_fin[i]["trainer_id"]),
                        "name": String(name),
                        "image": String(resr_user_fin[i]['userdetails'][0].image),
                        "schedule_time": String(resr_user_fin[i].schedule_time),
                        "time": {
                            "from": String(resr_user_fin[i]["time"]),
                            "date": String(resr_user_fin[i]["date"]),
                            "day": String(resr_user_fin[i]["day"]),
                            "month": String(resr_user_fin[i]["month"]),
                            "year": String(resr_user_fin[i]["year"]),
                            "utc": String(resr_user_fin[i]["schedule_time"]),
                            "slot_id": String(resr_user_fin[i]["slot_id"]),
                            "gym_name": String(resr_user_fin[i]['gym'][0].name),


                        }
                    })
                }
           }
           // return false
            
            
            res.send({
                "success": true,
                "message": "success",
                "data": gymdeta
            });
            return false;
    })
        

    // })
    

}


function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}