var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')
const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');



exports.change_password = async function (req, res) {
    console.log('change--->', req.body)

    if (!(req.body.user_id && req.body.old_password && req.body.new_password && req.body.user_type)) {
        res.send({
            "success": false,
            "message": "Please send all fields",
            "data": []
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
   dbo.collection('TBL_CLIENTS').aggregate([{
        $match: {
            _id: ObjectId(req.body.user_id)
        }
    }]).toArray(function (err, resr) {
        if (err) {
            throw err;
        } else {
            if (resr) {
                user = resr[0];
                console.log("############->", resr)
                console.log("<-############")
                if (!user) {
                    res.send({
                        "success": false,
                        "message": "User not found",
                        "data": []
                    });
                    return false;
                }
                if (user.type == 0 || user.type == 1) {
                    bcrypt.compare(req.body.old_password, user.password, function (err, response) {
                        if (err) {
                            res.send({
                                "success": false,
                                message: 'Got error while comparing passwords.'
                            });
                            return false;
                        }
                        if (response) {
                            bcrypt.genSalt(10, (err, salt) => {
                                bcrypt.hash(req.body.new_password, salt, (err, hash) => {
                                    if (err) throw err;
                                    dbo.collection('TBL_CLIENTS').updateOne({
                                        _id: ObjectId(user._id)
                                    }, {
                                        $set: {
                                            password: hash,

                                        }
                                    }, function (err, rese) {
                                        console.log("----------->")
                                        console.log(rese)
                                        console.log("<----------------")
                                        if (err) {
                                            res.send({
                                                "success": false,
                                                "message": "Something went wrong!"
                                            });
                                            return false;
                                        } else {
                                            res.send({
                                                "success": true,
                                                message: 'We have successfully changed your password.'
                                            });
                                            return false;
                                        }
                                    });
                                });
                            });
                        } else {
                            res.send({
                                "success": false,
                                message: 'Old Password do not match'
                            });
                            return false;
                        }
                    });
                } else {
                    res.send({
                        "success": false,
                        "message": "Not an Email account"
                    });
                    return false;
                }
            } else {
                res.send({
                    "success": false,
                    "message": "something went wrong",
                    "data": []
                });
                return false;
            }
        }
    });

}

