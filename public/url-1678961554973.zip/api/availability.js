
var mongo = require("mongoose");  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  

 
 mongo.set('useFindAndModify', false);

var mongodbutil = require( './mongodbutil' );


 exports.availability =async function(req, res) {
    const {date} = req.body;
    console.log(req.body)
    if (!date )  {
          res.send({"success":"0","message":"Please enter all fields","data":{}});
          return false;
    }
    // MongoClient.connect(url, function(err, db) {
        let dbo =  await mongodbutil.Get();

      // if (err) throw err;
        // var dbo = db.db("gymtraining");
        
        var day = new Date(date);
        day = day.getDay();
       //var day=parseInt(date.split('-')[2])
       //var month=parseInt(date.split('-')[1])
       //var year=parseInt(date.split('-')[0])
        console.log('day--', typeof day,day,'date--',date)
        // Select TBL_GYM_AVAILABILITY for which  (day = <day> && repeat = 1 && gym_id = <gym_id> ) OR (date = <date> && gym_id =<gym_id> )
  

        dbo.collection("TBL_GYM_AVAILABILITY").find( { $or: [ { day:day,repeat:1 }, {"date":date} ] } ).toArray(async function(err, result) {

      // dbo.collection("TBL_GYM_AVAILABILITY").find({"date":date}).toArray(async function(err, result) {
            if (err){
                res.send({"success":false,"message":"something went wrong","data":[]});
                return false;
            }
            else{
               console.log("result",result)
               var datearray =[];

               ///return res.json(result)
               
               //return;
                  var day_availability
                  var date_availability
                  if(result.length > 0){
                    // var jj = 0;
                    for(var i =result.length - 1 ;i>=0;i--){
                      // console.log("index",i)
                      // console.log("result",result[i])
                      if(result[i].date == date) {
                           // console.log("exact date matched")
                            dbo.collection("TBL_AVAILABILITY_SLOTS").find( { "gym_availability_id":ObjectId(result[i]._id),availableSlots : { $gt :0}    } ).sort( { date : -1 } ).toArray(async function(err, result) {
                              // console.log("result",i)
                                res.send({"success":true,"message":"success","data":result});
                                //return;
                                //jj = 1;
                           })
                            return;
                      } else if(result[i].repeat == 1){ 
                     //  datearray.push(getWeeke(result[i],month,year));

                        console.log("repeat case")
                         dbo.collection("TBL_AVAILABILITY_SLOTS").find( { "gym_availability_id":ObjectId(result[i]._id),availableSlots : { $gt :0}  } ).sort( { date : -1 } ).toArray(async function(err, result) {
                               res.send({"success":true,"message":"success","data":result});
                              
                           })
                        return;
                      }
                    }
                  //  console.log(datearray)
                    //res.end()

                  }
                  else{
                     res.send({"success":true,"message":"success","data":[]});
                  }
                  

                
                
            } 
            // dbo.close();
          });
          
    // })
}

function getWeeke(result,month,year) {
  // console.log(result);
  var tuesdays= [];
 if(result.repeat == 1)  {
   // console.log("here")
   var d =  new Date(year, month - 1, 1);
   month = d.getMonth(1);
   // tuesdays= [];
   // console.log("month",month)
   // Get the first Monday in the month
   while (d.getDay() !== result.day) {
       d.setDate(d.getDate() + 1);
   }

   // Get all the other Tuesdays in the month
   while (d.getMonth() === month) {
       tuesdays.push(new Date(d.getTime()).getDate());
       d.setDate(d.getDate() + 7);
   }
   // console.log(tuesdays)
    // return tuesdays;
 }
 else{
   console.log("SDfs",result.year)
   console.log("SDfsss",result.month)
     if (result.year==year && result.month == month) {
         // days = day = 13
          var day = new Date(result.date) 
          tuesdays.push(day.getDate());
     }

 }

  return tuesdays;

}


// db.collection.aggregate([
//   {
//     $project: {
//       date: {
//         $dateFromString: {
//           dateString: "$date",
//           // timezone: "America/New_York"
          
//         }
//       }
//     }
//   },
//   {
//     "$match": {
//       "date": {
//         "$gte": new Date("2020-04-27")
//       }
//     }
//   }
// ])
