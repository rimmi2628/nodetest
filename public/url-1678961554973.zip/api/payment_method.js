var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());



var sourceFile = require('./register.js');
// console.log(sourceFile)
var db = mongo.connect("mongodb://localhost:27017/gymtraining", { useNewUrlParser: true, useUnifiedTopology: true }, function (err, response) {
    if (err) { console.log(err); }
    else { //console.log('Connected to ' + db, ' + ', response); 
    }
});
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.payment_method = async function (req, res) {
    console.log("--------------payment-method------------->")
    console.log(req.body)
    console.log("<---------------------------")
    const { payment_type } = req.body;
    // if(!user_id ||!ending ||!expiry ||!type ||!customer_id ||!email ||!authorization ||!routing_number ||!account_number ||!payment_method ||!zip ){
    //     res.send({"success":false,"message":"all fields required","data":{}});
    //     return false;
    // }
    if (!payment_type) {
        res.send({ "success": false, "message": "Payment type empty", "data": {} });
        return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    //     if (err) throw err;
    let dbo = await mongodbutil.Get();
    // console.log(req.body)
    // else {}
    if (req.body.payment_type == 0) {
        if (!req.body.yy) {
            res.send({ "success": false, "message": "expiry yy empty", "data": {} });
            return false;
        }
        else if (!req.body.mm) {
            res.send({ "success": false, "message": "expiry mm  missing", "data": {} });
            return false;
        }
        // else if(!req.body.type){
        //     res.send({"success":false,"message":"card type missing","data":{}});
        //     return false;
        // }
        else if (!req.body.number) {
            res.send({ "success": false, "message": "number missing", "data": {} });
            return false;
        }
        else if (!req.body.user_id) {
            res.send({ "success": false, "message": "user_id missing", "data": {} });
            return false;
        }
        //  else if(!req.body.primary){
        //     res.send({"success":false,"message":"user_id missing","data":{}});
        //     return false;
        // }
        else if (!req.body.customer_id) {
            res.send({ "success": false, "message": "customer_id missing", "data": {} });
            return false;
        }
        else if (!req.body.cvv) {
            res.send({ "success": false, "message": "cvv missing", "data": {} });
            return false;
        }


    }
    else if (req.body.payment_type == 1) {
        if (!req.body.user_id) {
            res.send({ "success": false, "message": "user_id missing", "data": {} });
            return false;
        }
        else if (!req.body.account_number) {
            res.send({ "success": false, "message": "account_number missing", "data": {} });
            return false;
        }
        else if (!req.body.routing_number) {
            res.send({ "success": false, "message": "routing_number missing", "data": {} });
            return false;
        }

    }
    else if (req.body.payment_type == 2) {
        if (!req.body.user_id) {
            res.send({ "success": false, "message": "user_id missing", "data": {} });
            return false;
        }
        else if (!req.body.paypal_email) {
            res.send({ "success": false, "message": "empty paypal_email", "data": {} });
            return false;
        }
        else if (!req.body.paypal_authorization) {
            res.send({ "success": false, "message": "empty paypal_authorization", "data": {} });
            return false;
        }

    }


    // - user_id
    // - number( last 4)
    // - mm
    // - yy
    // - cvv
    // - customer_id (stripe)
    // - zip
    // - primary
    // - routing
    // - account_number
    // - paypal_email
    // - paypal_authorization
    // - payment_type




    data = {
        "trainer_id": ObjectId(req.body.user_id), card_holder_name: req.body.card_holder_name,
        "number": req.body.number, "mm": req.body.mm, "yy": req.body.yy,
        "payment_type": req.body.payment_type, "customer_id": req.body.customer_id,
        "zip": req.body.zip, "cvv": req.body.cvv, "account_type": req.body.account_type,
        "paypal_email": req.body.paypal_email, "paypal_authorization": req.body.paypal_authorization,
        "routing_number": req.body.routing_number, "account_number": req.body.account_number,
        "bank_name": req.body.bank_name, "name_on_account": req.body.name_on_account,
        'created_at': getCurrentTime(), 'updated_at': getCurrentTime()
    }

    //console.log("Asdas")
    if (req.body.payment_type == 0) {
        // console.log("Assfdsds")
        dbo.collection('TBL_CARDS').updateOne({ trainer_id: ObjectId(req.body.user_id), payment_type: req.body.payment_type }, { $set: data }, { upsert: true }, function (err, rese) {
            if (err) {
                res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                return false;
            }
            else {
                if (req.body.primary == '1') {
                    //console.log("Asdasfdsds")
                    dbo.collection('TBL_CARDS').updateMany({ trainer_id: ObjectId(req.body.user_id) }, { $set: { "primary": '0' } }, function (err, rese) {
                        if (err) {
                            res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                            return false;
                        }
                        else {
                            dbo.collection('TBL_CARDS').updateOne({ trainer_id: ObjectId(req.body.user_id), payment_type: req.body.payment_type }, { $set: { "primary": '1' } }, { upsert: true }, function (err, rese) {
                                if (err) {
                                    res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                                    return false;
                                }
                                else {
                                    console.log("Asdasfdsdssadfsd")
                                    res.send({ "success": true, "message": "Card details has been saved", "data": [] });
                                    return false;
                                }
                            })

                        }
                    })
                }
                else {
                    updatePrimaryStatus(dbo,res,req.body.user_id,payment_type)
                    //res.send({ "success": true, "message": "Card details has been saved", "data": [] });
                   // return false;
                }
                //  	 res.send({"success":true,"message":"success","data":[]});
                // return false;
            }
        })

    }
    else if (req.body.payment_type == 1) {
        dbo.collection('TBL_CARDS').updateOne({ trainer_id: ObjectId(req.body.user_id), payment_type: req.body.payment_type }, { $set: data }, { upsert: true }, function (err, rese) {
            if (err) {
                res.send({ "success": false, "message": "Unable to save data.", "data": {} });
                return false;
            }
            else {
                if (req.body.primary == '1') {
                    //console.log("Asdasfdsds")
                    dbo.collection('TBL_CARDS').updateMany({ trainer_id: ObjectId(req.body.user_id) }, { $set: { "primary": '0' } }, function (err, rese) {
                        if (err) {
                            res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                            return false;
                        }
                        else {
                            dbo.collection('TBL_CARDS').updateOne({ trainer_id: ObjectId(req.body.user_id), payment_type: req.body.payment_type }, { $set: { "primary": '1' } }, { upsert: true }, function (err, rese) {
                                if (err) {
                                    res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                                    return false;
                                }
                                else {
                                    // console.log("Asdasfdsdssadfsd")
                                    res.send({ "success": true, "message": "Bank details has been saved", "data": [] });
                                    return false;
                                }
                            })

                        }
                    })
                }
               
                else {
                    updatePrimaryStatus(dbo,res,req.body.user_id,payment_type)
                   // res.send({ "success": true, "message": "Bank details has been saved", "data": [] });
                   // return false;
                }
            }

        })
    }

    else {
        dbo.collection('TBL_CARDS').updateOne({ trainer_id: ObjectId(req.body.user_id), payment_type: req.body.payment_type }, { $set: data }, { upsert: true }, function (err, rese) {
            if (err) {
                res.send({ "success": false, "message": "Unable to save data.", "data": {} });
                return false;
            }
            else {
                if (req.body.primary == '1') {
                    //console.log("Asdasfdsds")
                    dbo.collection('TBL_CARDS').updateMany({ trainer_id: ObjectId(req.body.user_id) }, { $set: { "primary": '0' } }, function (err, rese) {
                        if (err) {
                            res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                            return false;
                        }
                        else {
                            dbo.collection('TBL_CARDS').updateOne({ trainer_id: ObjectId(req.body.user_id), payment_type: req.body.payment_type }, { $set: { "primary": '1' } }, { upsert: true }, function (err, rese) {
                                if (err) {
                                    res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                                    return false;
                                }
                                else {
                                    console.log("Asdasfdsdssadfsd")
                                    res.send({ "success": true, "message": "Paypal details has been saved", "data": [] });
                                    return false;
                                }
                            })

                        }
                    })
                }

                else {
                    res.send({ "success": true, "message": "Paypal details has been saved", "data": [] });
                    return false;
                }
            }
        })
        // dbo.collection("TBL_CARDS").insertOne(data, function(err,resr){
        //      if (err){
        //          throw err;
        //      }
        //      else{
        //          if(resr){
        //              res.send({"success":true,"message":"Information saved."});
        //              return false;
        //          }
        //          else{
        //              res.send({"success":false,"message":"something went wrong","data":[]});
        //              return false;
        //          }
        //      }
        //  });  
    }

    // });  
}
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}

function updatePrimaryStatus(dbo,res,user_id,payment_type){
    dbo.collection('TBL_CARDS').updateMany({ trainer_id: ObjectId(user_id) }, { $set: { "primary": '1' } }, function (err, rese) {
        if (err) {
            res.send({ "success": true, "message": "Unable to save data.", "data": {} });
            return false;
        }
        else {
            dbo.collection('TBL_CARDS').updateOne({ trainer_id: ObjectId(user_id), payment_type: payment_type }, { $set: { "primary": '0' } }, { upsert: true }, function (err, rese) {
                if (err) {
                    res.send({ "success": true, "message": "Unable to save data.", "data": {} });
                    return false;
                }
                else {
                    // console.log("Asdasfdsdssadfsd")
                    res.send({ "success": true, "message": payment_type==0?"Card details has been saved":"Bank details has been saved", "data": [] });
                    return false;
                }
            })

        }
    })

}