var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");

const Utill = require('../helper/Constant')
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());





var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.gym_details = async function (req, res) {
  const { gym_id, user_id, date } = req.body;
  if (!gym_id || !user_id || !date) {
    res.send({ "success": false, "message": "Please enter all fields", "data": {} });
    return false;
  }
  // MongoClient.connect(url, function(err, db) {
  let dbo = await mongodbutil.Get();
  // var dbo = db.db("gymtraining");
  // var query = { _id: user_id };
  // dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
  dbo.collection('TBL_GYMS').aggregate([
    { $match: { _id: ObjectId(gym_id) } },
    {
      $lookup:
      {
        from: 'TBL_EQUIPMENTS',
        localField: 'equipments_id',
        foreignField: '_id',
        as: 'equipments_ids'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_GYM_IMAGES',
        localField: 'images_ids.id',
        foreignField: '_id',
        as: 'images_ids'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_FAVORITES',
        localField: '_id',
        foreignField: 'gym_id',
        as: 'favorites'
      }
    },
    {
      "$addFields": {
        "favorites": {
          "$arrayElemAt": [
            {
              "$filter": {
                "input": "$favorites",
                "as": "comp",
                "cond": {
                  "$eq": ["$$comp.trainer_id", ObjectId(user_id)]
                }
              }
            }, 0
          ]
        }
      }
    }
  ]).toArray(function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      if (resr) {
       // return res.json(resr)

        var data = JSON.parse(JSON.stringify(resr));
        if (data[0].favorites != undefined) {
          data[0].favorite = true;
        }
        else {
          data[0].favorite = false;
        }
        var images = [];
        if (String(resr[0]['storefront']).includes('http')) {
          var attach = "";
        }
        else {
          var attach = Utill.IMAGE_BASE_URL;
        }
        images.push({
          "_id": "5ec38a821a9ca845e0831a8c",
          "image": attach + "" + resr[0]['storefront']
        })
        images.push({
          "_id": "5ec38a821a9ca845e0831a8c",
          "image": attach + "" + resr[0]['reception']
        })
        images.push({
          "_id": "5ec38a821a9ca845e0831a8c",
          "image": attach + "" + resr[0]['gym_interior']
        })
        if (data[0].images_ids.length > 0) {
          for (var i = 0; i < data[0].images_ids.length; i++) {




            if (String(data[0].images_ids[i].image).includes('http')) {

              data[0].images_ids[i].image = data[0].images_ids[i].image
              if (resr[i].images_ids[j]['image'] == undefined || resr[i].images_ids[j]['image'] == null || resr[i].images_ids[j]['image'] == "") {
                resr[i].images_ids[j]['image'] = data[0].images_ids[j]['name']
              }

              // console.log(resr[i].images_ids[j]['image'])

            }
            else {
              data[0].images_ids[i].image = Utill.IMAGE_BASE_URL + resr[0].images_ids[i]['image']
              // console.log(resr[i].images_ids[j]['image'])
              if (data[0].images_ids[i].image == Utill.IMAGE_BASE_URL + "undefined") {
                data[0].images_ids[i].image = data[0].images_ids[i].name
              }
            }





            // data[0].images_ids[i].image = "https://hourful.io/"+data[0].images_ids[i].image
            images.push(data[0].images_ids[i])
          }
        }
        data[0].images_ids = images;

        if (data[0].logo != undefined) {
          if (String(data[0].logo).includes('http')) {
            data[0].logo = data[0].logo
          }
          else {
            data[0].logo = Utill.IMAGE_BASE_URL + data[0].logo
          }

        }

        if (data[0].space_owner == "") {
          data[0].claim = 0;
        }
        else {
          data[0].claim = 1;
        }






        // console.log(data)
        dbo.collection("TBL_GYM_AVAILABILITY").find({ "date": date, "gym_id": ObjectId(gym_id) }).toArray(function (err, result) {
          if (err) {
            res.send({ "success": false, "message": "something went wrong", "data": [] });
            return false;
          }
          else {
            //  console.log(result[0])
            if (result.length > 0) {
              dbo.collection("TBL_AVAILABILITY_SLOTS").find({ "gym_availability_id": ObjectId(result[0]['_id']) }).toArray(function (err, ress) {
                if (err) {
                  res.send({ "success": false, "message": "something went wrong", "data": [] });
                  return false;
                }
                else {

                  /* var gymdetails=
                  {
                    "_id":data[0]._id, 
                    "name":data[0].name,
                    "logo":data[0].logo,
                    "price":data[0].price,
                    "avg_rating":data[0].avg_rating,
                    "num_of_ratings":data[0].ratings,
                    "images":data[0].images_ids,
                    "address":data[0].formatted_address,
                  	
                    "bio":data[0].bio,
                    "equipments":data[0].equipments_ids,
                    "availability":ress,
                    "favorite":data[0].favorite,
                    "time_zone":"US/Eastern",
                  } */
                  delete data[0].equipments_id;
                  var gymdetails = data[0];
                  res.send({ "success": true, "message": "success", "data": gymdetails });
                  return false;
                }

              });
              // console.log("adsd");
            } else {
              var day = new Date(date);
              day = day.getDay();
              // console.log(day)
              dbo.collection('TBL_GYM_AVAILABILITY').aggregate([
                { $match: { day: String(day), repeat: "1", gym_id: ObjectId(gym_id) } },
                { $sort: { date: -1 } },
                { $limit: 1 },
                {
                  $lookup:
                  {
                    from: 'TBL_AVAILABILITY_SLOTS',
                    localField: '_id',
                    foreignField: 'gym_availability_id',
                    as: 'gym'
                  }
                },


              ]).toArray(function (err, resr) {
                if (err) {
                  throw err;
                }
                else {
                  if (resr) {
                    // console.log("asd",resr.length)
                    if (resr.length > 0) {

                      /* var gymdetails=
                        {
                          "_id":data[0]._id, 
                          "name":data[0].name,
                          "logo":data[0].link,
                          "price":data[0].price,
                          "avg_rating":data[0].avg_rating,
                          "num_of_ratings":data[0].ratings,
                          "images":data[0].images_ids,
                          "address":data[0].formatted_address,
                          
                          "description":data[0].bio,
                          "equipments":data[0].equipments_ids,
                          "availability":resr[0]['gym'],
                          "favorite":data[0].favorite,
                           "time_zone":"US/Eastern",
      } */
                      delete data[0].equipments_id;
                      var gymdetails = data[0];
                      gymdetails['time_zone'] = gymdetails['timezone'];
                      res.send({ "success": true, "message": "success", "data": gymdetails });
                      return false;
                    }
                    else {
                      /* var gymdetails=
                        {
                        "_id":data[0]._id, 
                        "name":data[0].name,
                        "logo":data[0].link,
                        "price":data[0].price,
                        "avg_rating":data[0].avg_rating,
                        "num_of_ratings":data[0].ratings,
                        "images":data[0].images_ids,
                        "address":data[0].formatted_address,
                      	
                        "description":data[0].bio,
                        "equipments":data[0].equipments_ids,
                        "availability":[],
                        "favorite":data[0].favorite,
                          "time_zone":"US/Eastern",
                      } */
                      delete data[0].equipments_id;
                      var gymdetails = data[0];
                      gymdetails['time_zone'] = gymdetails['timezone'];
                      res.send({ "success": true, "message": "success", "data": gymdetails });
                      return false;
                    }

                  }
                  else {
                    //console.log(data);return;
                    /* var gymdetails=
                    {
                      "_id":data[0]._id, 
                      "name":data[0].name,
                      "logo":data[0].link,
                      "price":data[0].price,
                      "avg_rating":data[0].avg_rating,
                      "num_of_ratings":data[0].ratings,
                      "images":data[0].images_ids,
                      "address":data[0].formatted_address,
                    	
                      "description":data[0].bio,
                      "equipments":data[0].equipments_ids,
                      "availability":[],
                      "favorite":data[0].favorite,
                        "time_zone":"US/Eastern",
                    } */

                    delete data[0].equipments_id;
                    var gymdetails = data[0];
                    gymdetails['time_zone'] = gymdetails['timezone'];
                    res.send({ "success": true, "message": "success", "data": gymdetails });
                    return false;
                  }
                }

              });
              //console.log(day);

            }


          }
          // dbo.close();
        });
      }
      else {
        res.send({ "success": false, "message": "something went wrong", "data": {} });
        return false;
      }
    }

  });
  // });
}

