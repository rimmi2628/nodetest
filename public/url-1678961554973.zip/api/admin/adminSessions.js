var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

const {
	admin
} = require('../firebaseConfig.js');
var options = {
	priority: "high",
	timeToLive: 60 * 60 * 24
};
var app = express()
app.use(bodyParser.urlencoded({
	extended: true
}));
app.use(bodyParser.json());
var mongodbutil = require('./mongodbutil');

exports.allSessions = async function (req, res) {
	if (Object.keys(req.body).length === 0) {
		cPage = 1
	} else {
		cPage = req.body.pageNo
	}
	var pageNo = parseInt(cPage)
	var size = 8
	var query = {}
	if (pageNo < 0 || pageNo === 0) {
		response = {
			"error": true,
			"message": "invalid page number, should start with 1"
		};
		return res.json(response)
	}
	query.skip = size * (pageNo - 1)
	query.limit = size
	let dbo = await mongodbutil.Get();
	var id = req.body.id
	dbo.collection("TBL_SESSIONS").count({}, function (err, totalCount) {
		if (err) {
			response = {
				"error": true,
				"message": "Error fetching data"
			}
			return false;
		}

		var totalPages = Math.ceil(totalCount / size)
		dbo.collection('TBL_SESSIONS').aggregate([{
				$sort: {
					"_id": -1
				}
			},
			{
				$skip: query.skip
			},
			{
				$limit: query.limit
			},
			{
				$lookup: {
					from: 'TBL_TRAINERS',
					localField: 'trainer_id',
					foreignField: '_id',
					as: 'trainer'
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINER_DETAILS',
					localField: 'trainer_id',
					foreignField: 'user_id',
					as: 'trainerDetails'
				}
			},
			{
				$lookup: {
					from: 'TBL_CLIENTS',
					localField: 'client_id',
					foreignField: '_id',
					as: 'client'
				}
			},
			
			{
				"$unwind": "$trainerDetails"
			},
		]).sort({
			created_at: -1
		}).toArray(function (err, data) {
			if (err) {
				throw err;
			} else {
				console.log(data)
				if (Object.keys(data).length === 0) {
					res.send({
						"status": '0',
						"message": 'err',
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				} else {
					res.send({
						"status": '1',
						"message": 'Success',
						"data": data,
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				}
			}
		});
	});
}

exports.search = async function (req, res) {
	if (req.body.pageNo === undefined || req.body.pageNo < 0 || req.body.pageNo === 0) {
		cPage = 1
	} else {
		cPage = req.body.pageNo
	}
	var pageNo = parseInt(cPage)
	var size = 8
	var query = {}
	query.skip = size * (pageNo - 1)
	query.limit = size

	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_SESSIONS').aggregate([{
			$sort: {
				"_id": -1
			}
		},
		{
			$lookup: {
				from: 'TBL_TRAINERS',
				localField: 'trainer_id',
				foreignField: '_id',
				as: 'trainer'
			}
		},
		{
			$lookup: {
				from: 'TBL_TRAINER_DETAILS',
				localField: 'trainer_id',
				foreignField: 'user_id',
				as: 'trainerDetails'
			}
		},
		{
			$lookup: {
				from: 'TBL_CLIENTS',
				localField: 'client_id',
				foreignField: '_id',
				as: 'client'
			}
		},
		{
			"$unwind": "$trainerDetails"
		},
		{
			"$unwind": "$trainerDetails.first_name"
		},
		{
			"$unwind": "$client"
		},
		{
			"$unwind": "$client.first_name"
		},
		{
			"$match": {
				$or: [{
						"trainerDetails.first_name": {
							$regex: req.body.email,
							$options: 'i'
						}
					},
					{
						"client.first_name": {
							$regex: req.body.email,
							$options: 'i'
						}
					},
				]
			}
		},
		{
			$group: {
				_id: "$author",
				posts: {
					$sum: 1
				},
			}
		},
		{
			$project: {
				total: '$posts'
			}
		},

	]).toArray(function (err, data1) {
		dbo.collection('TBL_SESSIONS').aggregate([{
				$sort: {
					"_id": -1
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINERS',
					localField: 'trainer_id',
					foreignField: '_id',
					as: 'trainer'
				}
			},
			{
				$lookup: {
					from: 'TBL_TRAINER_DETAILS',
					localField: 'trainer_id',
					foreignField: 'user_id',
					as: 'trainerDetails'
				}
			},
			{
				$lookup: {
					from: 'TBL_CLIENTS',
					localField: 'client_id',
					foreignField: '_id',
					as: 'client'
				}
			},
			{
				"$unwind": "$trainerDetails"
			},
			{
				"$unwind": "$trainerDetails.first_name"
			},
			{
				"$unwind": "$client"
			},
			{
				"$unwind": "$client.first_name"
			},
			{
				"$match": {
					$or: [{
							"trainerDetails.first_name": {
								$regex: req.body.email,
								$options: 'i'
							}
						},
						{
							"client.first_name": {
								$regex: req.body.email,
								$options: 'i'
							}
						},
					]
				}
			},
			{
				$skip: query.skip
			},
			{
				$limit: query.limit
			},

		]).toArray(function (err, data) {
			if (err) {
				throw err;
			} else {
				console.log(data)
				if (data.length === 0) {
					var totalCount = 0
				} else {
					var totalCount = data1[0].total
				}
				var totalPages = Math.ceil(totalCount / size)
				if (totalCount === 0) {
					res.send({
						"status": '0',
						"message": 'err',
						"data": [],
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				} else {
					res.send({
						"status": '1',
						"message": 'Success',
						"data": data,
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				}
			}
		});
	});

}