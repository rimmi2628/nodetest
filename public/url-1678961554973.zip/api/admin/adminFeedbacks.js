var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
var fs = require("fs");
var mongodbutil = require( './mongodbutil' );
exports.feedbacks = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    let dbo =  await mongodbutil.Get();
        var id = req.body.id
        if (req.body.type == '1') {
            dbo.collection("TBL_FEEDBACK").count({}, function (err, totalCount) {
                if (err) {
                    response = {
                        "error": true,
                        "message": "Error fetching data"
                    }
                    return false;
                }

                var totalPages = Math.ceil(totalCount / size)
                dbo.collection('TBL_FEEDBACK').aggregate([
                    {
                        $skip: query.skip
                    },
                    {
                        $limit: query.limit
                    },
                    {
                        $lookup: {
                            from: 'TBL_TRAINERS',
                            localField: 'user_id',
                            foreignField: '_id',
                            as: 'user'
                        }
                    },
                    {
                        $lookup: {
                            from: 'TBL_TRAINER_DETAILS',
                            localField: 'user_id',
                            foreignField: 'user_id',
                            as: 'userDetails'
                        }
                    },
                    {
                        $lookup: {
                            from: 'TBL_BOOKINS',
                            localField: 'booking_id',
                            foreignField: '_id',
                            as: 'bookings'
                        }
                    },
                    {
                        $lookup: {
                            from: 'TBL_BADGES',
                            localField: 'badges.id',
                            foreignField: '_id',
                            as: 'badges'
                        }
                    },
                    {
                        $lookup: {
                            from: 'TBL_GYMS',
                            localField: 'gym_id',
                            foreignField: '_id',
                            as: 'gym'
                        }
                    },
                ]).toArray(function (err, data) {
                    if (err) {
                        throw err;
                    } else {
                        if (Object.keys(data).length === 0) {
                            res.send({
                                "status": '0',
                                "message": 'err',
                                "data": [],
                                "currentPage": cPage,
                                "pages": totalPages,
                                "totalItems": totalCount,
                                "perPage": size
                            });
                        } else {
                            res.send({
                                "status": '1',
                                "message": 'Success',
                                "data": data,
                                "currentPage": cPage,
                                "pages": totalPages,
                                "totalItems": totalCount,
                                "perPage": size
                            });
                        }
                    }
                });
            }); 
        }
        else if(req.body.type == '0'){
             dbo.collection("TBL_FEEDBACK_TO_TRAINER").count({}, function (err, totalCount) {
                if (err) {
                    response = {
                        "error": true,
                        "message": "Error fetching data"
                    }
                    return false;
                }

                var totalPages = Math.ceil(totalCount / size)
                dbo.collection('TBL_FEEDBACK_TO_TRAINER').aggregate([
                    {
                        $skip: query.skip
                    },
                    {
                        $limit: query.limit
                    },
                    {
                        $lookup: {
                            from: 'TBL_TRAINERS',
                            localField: 'user_id',
                            foreignField: '_id',
                            as: 'user'
                        }
                    },
                    {
                        $lookup: {
                            from: 'TBL_TRAINER_DETAILS',
                            localField: 'user_id',
                            foreignField: 'user_id',
                            as: 'userDetails'
                        }
                    },
                    {
                        $lookup: {
                            from: 'TBL_BOOKINS',
                            localField: 'booking_id',
                            foreignField: '_id',
                            as: 'bookings'
                        }
                    },
                    {
                        $lookup: {
                            from: 'TBL_GYMS',
                            localField: 'gym_id',
                            foreignField: '_id',
                            as: 'gym'
                        }
                    },
                ]).toArray(function (err, data) {
                    if (err) {
                        throw err;
                    } else {
                        if (Object.keys(data).length === 0) {
                            res.send({
                                "status": '0',
                                "message": 'err',
                                "data": [],
                                "currentPage": cPage,
                                "pages": totalPages,
                                "totalItems": totalCount,
                                "perPage": size
                            });
                        } else {
                            res.send({
                                "status": '1',
                                "message": 'Success',
                                "data": data,
                                "currentPage": cPage,
                                "pages": totalPages,
                                "totalItems": totalCount,
                                "perPage": size
                            });
                        }
                    }
                });
            }); 
        }
        
    // });
}

exports.delete = async function (req, res) {
    let dbo =  await mongodbutil.Get();
        var myquery = { _id: ObjectId(req.body.id) };
        // console.log(myquery)
        // return
        // var dbo = db.db("gymtraining");
        if(req.body.type == 0){
            dbo.collection("TBL_FEEDBACK_TO_TRAINER").deleteOne(myquery, function (err, obj) {
                if (err) throw err;
                res.send({ "status": '1', "message": 'Success' });
                // db.close();
            });  
        }
        else if(req.body.type == 1){
            dbo.collection("TBL_FEEDBACK").deleteOne(myquery, function (err, obj) {
                if (err) throw err;
                res.send({ "status": '1', "message": 'Success' });
                // db.close();
            });  
        }
        
    // });
}

exports.filterFeedback = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
   let dbo =  await mongodbutil.Get();
        var id = req.body.id
        dbo.collection("TBL_REPORT").count({'type':0}, function (err, totalCount) {
            if (err) {
                response = {
                    "error": true,
                    "message": "Error fetching data"
                }
                return false;
            }

            var totalPages = Math.ceil(totalCount / size)
            dbo.collection('TBL_REPORT').aggregate([
                {
                    $match:{
                        type:"0"
                    }
                },
                {
                    $skip: query.skip
                },
                {
                    $limit: query.limit
                },
                {
                    $lookup: {
                        from: 'TBL_TRAINERS',
                        localField: 'user_id',
                        foreignField: '_id',
                        as: 'user'
                    }
                },
                {
                    $lookup: {
                        from: 'TBL_TRAINER_DETAILS',
                        localField: 'user_id',
                        foreignField: 'user_id',
                        as: 'userDetails'
                    }
                },
                // },
                // {
                //     $lookup: {
                //         from: 'TBL_BADGES',
                //         localField: 'badges.id',
                //         foreignField: '_id',
                //         as: 'badges'
                //     }
                // },
                {
                    $lookup: {
                        from: 'TBL_GYMS',
                        localField: 'gym_id',
                        foreignField: '_id',
                        as: 'gym'
                    }
                },
            ]).toArray(function (err, data) {
                if (err) {
                    throw err;
                } else {
                    if (Object.keys(data).length === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                }
            });
        });
    // });

}

exports.search = async function (req, res) {
    if (req.body.pageNo === undefined || req.body.pageNo < 0 || req.body.pageNo === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    // if (pageNo < 0 || pageNo === 0) {
    //     response = {
    //         "error": true,
    //         "message": "invalid page number, should start with 1"
    //     };
    //     return res.json(response)
    // }
    query.skip = size * (pageNo - 1)
    query.limit = size
    
   let dbo =  await mongodbutil.Get();
   if (req.body.type == 1) {
       dbo.collection('TBL_FEEDBACK').aggregate([
            // 
             {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetails'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetailss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gymss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_BOOKINS',
                    localField: 'booking_id',
                    foreignField: '_id',
                    as: 'bookings'
                }
            },
            {
                $lookup: {
                    from: 'TBL_BADGES',
                    localField: 'badges.id',
                    foreignField: '_id',
                    as: 'badges'
                }
            },
            {"$unwind":"$user"},
            {"$unwind":"$user.email"}, 
            {"$unwind":"$gymss"},
            {"$unwind":"$gymss.name"},
            {"$unwind":"$gymss.formatted_address"},
            {"$unwind":"$userDetailss"},
            {"$unwind":"$userDetailss.first_name"},
            
            {"$match":  {$or:[{
                   "user.email": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"gymss.name": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"userDetailss.first_name": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                } ]
            }},
            { $group : {
                _id : "$author",
                posts : { $sum : 1 },
                articles: {$push: '$$ROOT'},
            }},
            { $project: {total: '$posts', articles: {$slice: ['$articles', query.skip, query.limit]}}},
            // {
            //     $skip: query.skip
            // },
            // {
            //     $limit: query.limit
            // },
            // {"$match": {
                   
            //     }
            // },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                console.log(data)
                if ( data.length === 0) {
                   var totalCount = 0
                }
                else{
                    var totalCount = data[0].total
                }
                var totalPages = Math.ceil( totalCount/ size)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0].articles,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                // res.send({ "status": '1', "message": 'Success', "data": data });
            }
        });
   }
   else{
       dbo.collection('TBL_FEEDBACK_TO_TRAINER').aggregate([
            // 
             {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetails'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetailss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gymss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_BOOKINS',
                    localField: 'booking_id',
                    foreignField: '_id',
                    as: 'bookings'
                }
            },
            
            {"$unwind":"$user"},
            {"$unwind":"$user.email"}, 
            {"$unwind":"$gymss"},
            {"$unwind":"$gymss.name"},
            {"$unwind":"$gymss.formatted_address"},
            {"$unwind":"$userDetailss"},
            {"$unwind":"$userDetailss.first_name"},
            
            {"$match":  {$or:[{
                   "user.email": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"gymss.name": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"userDetailss.first_name": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                } ]
            }},
            { $group : {
                _id : "$author",
                posts : { $sum : 1 },
                articles: {$push: '$$ROOT'},
            }},
            { $project: {total: '$posts', articles: {$slice: ['$articles', query.skip, query.limit]}}},
            // {
            //     $skip: query.skip
            // },
            // {
            //     $limit: query.limit
            // },
            // {"$match": {
                   
            //     }
            // },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                console.log(data)
                if ( data.length === 0) {
                   var totalCount = 0
                }
                else{
                    var totalCount = data[0].total
                }
                var totalPages = Math.ceil( totalCount/ size)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0].articles,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                // res.send({ "status": '1', "message": 'Success', "data": data });
            }
        });
   }
        
    // });
}