var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
const bcrypt = require('bcrypt')
var fs = require("fs");
var nodemailer = require('nodemailer');
var db = mongo.connect("mongodb://localhost:27017/gymtraining", { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false }, function (err, response) {
    if (err) { console.log(err); }
    //    else{ console.log('Connected to ' + db, ' + ', response); }  
});
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
let reqPath = path.join(__dirname, '../../../');
var reqLink ='uploads/images/';
var mongodbutil = require( './mongodbutil' );
exports.allGyms = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    }
    else {
        cPage = req.body.pageNo
    }
    // console.log(cPage)
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = { "error": true, "message": "invalid page number, should start with 1" };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size

        let dbo =  await mongodbutil.Get();
        dbo.collection("TBL_GYMS").count({}, function (err, totalCount) {
        // dbo.collection("TBL_GYMS").countDocuments({}, function (err, totalCount) {
            
            if (err) {
                response = { "error": true, "message": "Error fetching data" }
            }
            else {
                dbo.collection("TBL_GYMS").find({}, query).toArray(function (err, data) {
                    if (err) throw err;
                    var totalPages = Math.ceil(totalCount / size)
                    if (Object.keys(data).length === 0) {
                        status = 3
                    }
                    else {
                        status = 1
                    }
                    res.send({ "status": status, "message": 'Success', "data": data, "currentPage": cPage, "pages": totalPages, "totalItems": totalCount, "perPage": size });
                    // console.log(data)
                    // db.close();
                });
            }
        });
    // });
}

exports.blockGym = async function (req, res) {
        let dbo =  await mongodbutil.Get();
        var myquery = { _id: ObjectId(req.body.id) };
        if (req.body.status == 1) {
            var newvalues = { $set: { isBlocked: "0" } };
            var blocked = 0
        } else {
            var newvalues = { $set: { isBlocked: "1" } };
            var blocked = 1

        }
        // var dbo = db.db("gymtraining");
        dbo.collection("TBL_GYMS").updateOne(myquery, newvalues, function (err, data) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'Gym Blocked', 'blocked': blocked });
            // db.close();
        });
    // });
}

exports.search = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    }
    else {
        cPage = req.body.pageNo
    }
    // console.log(cPage)
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = { "error": true, "message": "invalid page number, should start with 1" };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_GYMS').aggregate([
            // {
            //     $match: {
            //         name: {
            //             $regex: req.body.name,
            //             $options: 'i'
            //         }
            //     }
            // }
            // ,
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: '_id',
                    foreignField: '_id',
                    as: 'gymss'
                }
            },
            {"$unwind":"$gymss"},
            {"$unwind":"$gymss.name"},
            {"$unwind":"$gymss.formatted_address"},
            {"$match":  {$or:[
                {"gymss.name": {
                        $regex: req.body.name,
                        $options: 'i'
                    }
                },
                {"gymss.formatted_address": {
                        $regex: req.body.name,
                        $options: 'i'
                    }
                }]
            }},
            { $group : {
                _id : "$author",
                posts : { $sum : 1 },
                articles: {$push: '$$ROOT'},
            }},
            { $project: {total: '$posts', articles: {$slice: ['$articles', query.skip, query.limit]}}},
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                console.log(data)
                if ( data.length === 0) {
                   var totalCount = 0
                }
                else{
                    var totalCount = data[0].total
                }
                var totalPages = Math.ceil( totalCount/ size)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0].articles,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                // res.send({ "status": '1', "message": 'Success', "data": data });
            }
        });
    // });
}

exports.gymDetails =async function (req, res) {
    let dbo =  await mongodbutil.Get();
        var id = req.body.id
        dbo.collection('TBL_GYMS').aggregate([
            { $match: { _id: ObjectId(id) } },
            {
                $lookup:
                {
                    from: 'TBL_EQUIPMENTS',
                    localField: 'equipments_id',
                    foreignField: '_id',
                    as: 'equipments'
                }
            },
            {
                $lookup:
                {
                    from: 'TBL_GYM_IMAGES',
                    localField: 'images_ids.id',
                    foreignField: '_id',
                    as: 'images_ids'
                }
            },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                if (Object.keys(data).length === 0) {
                    res.send({ "status": '0', "message": 'err' });
                }
                else {
                    res.send({ "status": '1', "message": 'Success', "data": data });
                }
            }
        });
    // });
}

exports.updateGym =async function (req, res) {
    let dbo =  await mongodbutil.Get();
        var data = {}
        var img = []
        // console.log(req)
        // return
        var myquery = { _id: ObjectId(req.body.id) };
        console.log(req.files)
        if (req.files != undefined || req.files != null) {
            var seconds = Math.round(new Date().getTime() / 1000)
            if (req.files.imageSrcFront) {
                req.files.imageSrcFront.mv(reqPath + "/uploads/images/" + req.files.imageSrcFront.md5 + "_" + seconds + "." + req.files.imageSrcFront.mimetype.split('/')[1], function (err, img1) { })
                data.reception = reqLink+req.files.imageSrcFront.md5 + "_" + seconds + "." + req.files.imageSrcFront.mimetype.split('/')[1]
                delete req.files.imageSrcFront;
            }
            // return
            if (req.files.imageSrcReception) {
                req.files.imageSrcReception.mv(reqPath + "/uploads/images/" + req.files.imageSrcReception.md5 + "_" + seconds + "." + req.files.imageSrcReception.mimetype.split('/')[1], function (err, img2) {})
                data.storefront = reqLink+req.files.imageSrcReception.md5 + "_" + seconds + "." + req.files.imageSrcReception.mimetype.split('/')[1]
                delete req.files.imageSrcReception;
            }
            if (req.files.imageSrcLogo) {
                req.files.imageSrcLogo.mv(reqPath + "/uploads/images/" + req.files.imageSrcLogo.md5 + "_" + seconds + "." + req.files.imageSrcLogo.mimetype.split('/')[1], function (err, img2) {})
                data.logo = reqLink+req.files.imageSrcLogo.md5 + "_" + seconds + "." + req.files.imageSrcLogo.mimetype.split('/')[1]
                delete req.files.imageSrcLogo;
            }
            
            console.log(data)
            // return
            
            
            for (let j = 0; j < Object.keys(req.files).length; j++) {
                var keys = Object.keys(req.files)
                var sampleFile = req.files[keys[j]]
                
                sampleFile.mv(reqPath + "/uploads/images/" + sampleFile.md5 + "_" + seconds + "." + req.files[keys[j]].mimetype.split('/')[1], function (err, data) {
                    if (err) {
                        // stat++
                        return false;
                    }
                    else {}
                })
            }
        }
        else {
            // var img = 1
            // console.log(img)
        }
        var equipments_idsParsed = JSON.parse(req.body.equipments_ids);
        var equipments_ids = []
        for (var i = 0; i < equipments_idsParsed.length; i++) {
            equipments_ids.push(ObjectId(equipments_idsParsed[i]));
        }
        data.equipments_id = equipments_ids
        // data.bio = req.body.bio
        data.name = req.body.name
        data.price = parseFloat(req.body.price)
        data.street_number = req.body.street_number
        data.locality = req.body.locality
        data.country = req.body.country
        data.postal_code = req.body.postal_code
        data.phone = req.body.phone
        data.bio = req.body.bio
        //let dbo =  await mongodbutil.Get();
        images_ids = []
        deleted = []
        var isDeleted = false;
        var deleted_imgParsed = JSON.parse(req.body.deleted_img)
        for (var i = 0; i < Object.keys(deleted_imgParsed).length; i++) {
            deleted.push(ObjectId(deleted_imgParsed[i]['_id']));
            isDeleted = true
        }
        if (req.files != undefined || req.files != null) {
            for (let j = 0; j < Object.keys(req.files).length; j++) {
                var sampleFile = req.files[keys[j]]
                img.push({ 'image': reqLink+sampleFile.md5 + "_" + seconds + "." + req.files[keys[j]].mimetype.split('/')[1] });
            }
            dbo.collection("TBL_GYM_IMAGES").insertMany(img, function (err, docsInserted) {
                if (docsInserted) { 
                    for (var i = 0; i < Object.keys(docsInserted.insertedIds).length; i++) {
                        images_ids.push({ id: ObjectId(docsInserted.insertedIds[i]) });
                    }
                }
                
                var oldImg_idsParsed = JSON.parse(req.body.old);
                for (var i = 0; i < Object.keys(oldImg_idsParsed).length; i++) {
                    images_ids.push({ id: ObjectId(oldImg_idsParsed[i]['_id']) });
                }

                data.images_ids = images_ids
                var newvalues = { $set: data };
                // console.log(oldImg_idsParsed)
                // return
                if (isDeleted) {
                    dbo.collection("TBL_GYM_IMAGES").deleteMany({ _id: { $in: deleted } }, function (err, obj) {
                        if (err) throw err;
                        // console.log(obj.result.n + " document(s) deleted");
                    });
                }
                dbo.collection("TBL_GYMS").updateOne(myquery, newvalues, function (err, data) {
                    if (err) throw err;
                    res.send({ "status": '1', "message": 'Gym Details Updated' });
                    // console.log(img)
                    // db.close();
                });
            });
        }
        else {
            var oldImg_idsParsed = JSON.parse(req.body.old);
            for (var i = 0; i < Object.keys(oldImg_idsParsed).length; i++) {
                images_ids.push({ id: ObjectId(oldImg_idsParsed[i]['_id']) });
            }
            data.images_ids = images_ids
            var newvalues = { $set: data };
            if (isDeleted) {
                dbo.collection("TBL_GYM_IMAGES").deleteMany({ _id: { $in: deleted } }, function (err, obj) {
                    if (err) throw err;
                    // console.log(obj.result.n + " document(s) deleted");
                });
            }
            dbo.collection("TBL_GYMS").updateOne(myquery, newvalues, function (err, data) {
                if (err) throw err;
                res.send({ "status": '1', "message": 'Gym Details Updated' });
                // console.log(img)
            });
        }
        // console.log(newvalues);
        // return

    // });
}

exports.gymsList = async function (req, res) {
    let dbo =  await mongodbutil.Get();
        // var dbo = db.db("gymtraining");
        dbo.collection('TBL_GYMS').aggregate([
            // {
            //     $lookup:
            //     {
            //         from: 'TBL_EQUIPMENTS',
            //         localField: 'equipments_id',
            //         foreignField: '_id',
            //         as: 'equipments'
            //     }
            // },
            // {
            //     $lookup:
            //     {
            //         from: 'TBL_GYM_AVAILABILITY',
            //         localField: '_id',
            //         foreignField: 'gym_id',
            //         as: 'availability'
            //     }
            // },
            // {
            //     $lookup:
            //     {
            //         from: 'TBL_AVAILABILITY_SLOTS',
            //         localField: 'availability._id',
            //         foreignField: 'gym_availability_id',
            //         as: 'slots'
            //     }
            // },
            // {
            //     $lookup:
            //     {
            //         from: 'TBL_GYM_IMAGES',
            //         localField: 'images_ids.id',
            //         foreignField: '_id',
            //         as: 'images_ids'
            //     }
            // },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                if (Object.keys(data).length === 0) {
                    res.send({ "status": '0', "message": 'err' });
                }
                else {
                    res.send({ "status": '1', "message": 'Success', "data": data });
                }
            }
        });

    // });
}
exports.gymsList1 = async function (req, res) {
    let dbo =  await mongodbutil.Get();
        // var dbo = db.db("gymtraining");
        dbo.collection('TBL_GYMS').find({}).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                if (Object.keys(data).length === 0) {
                    res.send({ "status": '0', "message": 'err' });
                }
                else {
                    res.send({ "status": '1', "message": 'Success', "data": data });
                }
            }
        });

    // });
}
exports.delete = async function (req, res) {
    let dbo =  await mongodbutil.Get();
        var myquery = { _id: ObjectId(req.body.id) };
        dbo.collection("TBL_GYMS").deleteOne(myquery, function (err, obj) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'Success' });
            // db.close();
        });
    // });
}