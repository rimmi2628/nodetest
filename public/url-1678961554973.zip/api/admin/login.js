var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
var ObjectId = require('mongodb').ObjectID; 
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
const bcrypt = require('bcrypt')
     
var app = express()  
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json()); 
var mongodbutil = require( './mongodbutil' );
exports.login = async function(req, res){
    const {email, password } = req.body;
    let errors = [];
        if(!password || !email){
            res.send({"status":'0',"message":"Please enter all fields","data":{}});
            return false;
        }
        // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
        // if (err) throw err;
        var myquery = { email ,isAdmin:'1'};
        let dbo =  await mongodbutil.Get();
        dbo.collection("TBL_TRAINERS").findOne(myquery, function(err, data) {
            if (err) throw err;
            if (data) {
                 bcrypt.compare(req.body.password, data.password, function(err, resaa) {
                   if (err){
                     res.send({"status":'0',"message":"Email address or password is wrong.","data":{}});
                     return false;
                   }
                   if (resaa){
                    dbo.collection('TBL_TRAINERS').aggregate([
                    { $match : { _id : ObjectId(data._id) } } ,
                    { 
                        $lookup:
                            {
                                from: 'TBL_TRAINER_DETAILS',
                                localField: '_id',
                                foreignField: 'user_id',
                                as: 'userdetails'
                            }
                        },  
                    ]).toArray(function(err, resr) {
                            if (err){
                                throw err;
                            }
                            else{
                                if(resr){
                                    res.send({"status":'1',"message":"Login successfull","data":data});
                                    return false;
                                }
                                else{
                                    res.send({"status":'0',"message":"something went wrong","data":{}});
                                    return false;
                                }
                            }
                        });
                    }
                    else{
                        res.send({"status":'0',"message":"Email address or password is wrong.","data":{}});
                        return false;
                    }
                });
            }
            else{
                res.send({ "status":'0',"message": 'Email not found'}); 
                return false;
            }
            // res.send({ "status":'1',"message": 'Logged In','data':data});  
            // db.close();
        });
    // });
        
}