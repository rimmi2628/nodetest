var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

var app = express()
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var mongodbutil = require( './mongodbutil' );
exports.allRequests = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
        let dbo =  await mongodbutil.Get();
        var id = req.body.id
        dbo.collection("TBL_PAYMENT_REQUEST").count({}, function (err, totalCount) {
            if (err) {
                response = {
                    "error": true,
                    "message": "Error fetching data"
                }
                return false;
            }

            var totalPages = Math.ceil(totalCount / size)
            dbo.collection('TBL_PAYMENT_REQUEST').aggregate([
            {
                $sort: {"created_at": -1} 
            },    
            {
                $skip: query.skip
            },
            {
                $limit: query.limit
            },
            {
                $lookup: {
                    from: 'TBL_SPACE_OWNER',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            
            ]).toArray(function (err, data) {
                if (err) {
                    throw err;
                } else {
                    if (Object.keys(data).length === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                }
            });
        });
    // });
} 

exports.earningStatus =async function (req, res) { 
    let dbo =  await mongodbutil.Get();
        var myquery = { _id: ObjectId(req.body.earning_id) };
        if (req.body.status == 1) {
            var newvalues = { $set: { 'status': "1" ,'payment_ref_id':req.body.paymentId,"amount_transferred":req.body.amount }};
            if(req.body.notes){
                var myobj = { 'earning_id': ObjectId(req.body.earning_id), 'notes': req.body.notes,created_at:getCurrentTime(),updated_at:getCurrentTime()};
                dbo.collection("TBL_EARNING_NOTES").insertOne(myobj, function(err, data) {
                    if (err) throw err;
                        // res.send({ "status": '1', "message": 'success', 'data': data });
                        // db.close();
                });
            }
            
            var status = 1
        } else {
            var newvalues = { $set: { 'status': "2" } };
            var status = 2

        }
        if (status == 2) {
            dbo.collection('TBL_PAYMENT_REQUEST').aggregate([
                        {
                            $match: {
                                _id: ObjectId(req.body.earning_id)
                            }

                        }
                        
                        ]).toArray(function (err, data) {
                            if (err) {
                                throw err;
                            } else {
                                console.log(data[0].user_id)
                                var ii = ObjectId(data[0].user_id)
                  
                                var NotiObj = { trainer_id: '',gym_id: '',user_id:ii,text:"Your earning request of $"+data[0].amount+" has been rejected.",status:0,action:1,type:8,created_at:getCurrentTime(),price:''+parseInt(data[0].amount)+'',updated:getCurrentTime(),date:formatDateTime(getCurrentTime(),3),time:formatDateTime(getCurrentTime(),2)};
                                dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(NotiObj, function(err,resr){
                                  if (err){
                                      throw err;
                                  }
                                  console.log(NotiObj)
                                });
                            }
                        });
        }
        
        // console.log(req.body)
       // let dbo =  await mongodbutil.Get();
        dbo.collection("TBL_PAYMENT_REQUEST").updateOne(myquery, newvalues, function (err, data) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'success', 'statuss': status });
            // db.close();
        });
        

    // });
}

exports.earningDetails =async  function (req, res) {
    var earning_id = ObjectId(req.body.id)
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_PAYMENT_REQUEST').aggregate([
            {
                $match: {
                    _id: earning_id
                }

            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            {
                $lookup: {
                    from: 'TBL_EARNING_NOTES',
                    localField: '_id',
                    foreignField: 'earning_id',
                    as: 'notes'
                }
            },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (Object.keys(data).length === 0) {
                    res.send({
                        "status": '0',
                        "message": 'err',
                    });
                } else {
                    res.send({
                        "status": '1',
                        "message": 'Success',
                        "data": data,
                    });
                }
            }
        });
    // });
}
exports.earningnote =async function (req, res) { 
    let dbo =  await mongodbutil.Get();
        // var myquery = { _id: ObjectId(req.body.earning_id) };
        // var newvalues = { $set: {'notes':req.body.notes }};
        // var status = 1 
        // dbo.collection("TBL_NOTES").updateOne(myquery, newvalues, function (err, data) {
        //     if (err) throw err;
        //     res.send({ "status": '1', "message": 'success', 'statuss': status });
        //     // db.close();
        // });
        if (req.body.view == undefined) {
            var myobj = { 'earning_id': ObjectId(req.body.earning_id), 'notes': req.body.notes,created_at:getCurrentTime(),updated_at:getCurrentTime()};
            dbo.collection("TBL_EARNING_NOTES").insertOne(myobj, function(err, data) {
                if (err) throw err;
                    res.send({ "status": '1', "message": 'success', 'data': data });
                    // db.close();
            });
        }
        else{
            dbo.collection('TBL_EARNING_NOTES').aggregate([
            {
            $match: {
                    earning_id: ObjectId(req.body.earning_id)
                    }
            },
            ]).sort({created_at: -1}).toArray(function (err, data) {
                if (err) {
                    throw err;
                } else {
                    if (Object.keys(data).length === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data,
                            
                        });
                    }
                }
            });
        }
        
        
}

exports.allRequestsTrainer = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    let dbo = await mongodbutil.Get();
    var id = req.body.id
    dbo.collection("TBL_PAYMENT_REQUEST").count({trainer: 1}, function (err, totalCount) {
        if (err) {
            response = {
                "error": true,
                "message": "Error fetching data"
            }
            return false;
        }

        var totalPages = Math.ceil(totalCount / size)
        dbo.collection('TBL_PAYMENT_REQUEST').aggregate([
            {
            $match: {
                    trainer: 1
                }
            },
            {
                $sort: {
                    "created_at": -1
                }
            },
            {
                $skip: query.skip
            },
            {
                $limit: query.limit
            },
            {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'trainer'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'trainer_details'
                }
            },

        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (Object.keys(data).length === 0) {
                    res.send({
                        "status": '0',
                        "message": 'err',
                        "currentPage": cPage,
                        "pages": totalPages,
                        "totalItems": totalCount,
                        "perPage": size
                    });
                } else {
                    res.send({
                        "status": '1',
                        "message": 'Success',
                        "data": data,
                        "currentPage": cPage,
                        "pages": totalPages,
                        "totalItems": totalCount,
                        "perPage": size
                    });
                }
            }
        });
    });
    // });
}
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }
function formatDateTime(datetime,type){
        const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
        const d = new Date(datetime*1000);
        var month =  monthNames[d.getMonth()];
        var date = d.getDate();
        var year = d.getFullYear();

        var hours = d.getHours();
        var minutes = d.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0'+minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
      // February 10, 2020 at 10:15 AM
        if(type==2){
          return d;
          // return month+" "+date+","+year+" at "+strTime
        }
        else if(type == 3){
          return d;
        }
        else{
          return month+" "+date+","+year+" at "+strTime
        }
      }