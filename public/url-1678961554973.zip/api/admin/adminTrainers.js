var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
var fs = require("fs");
let reqPath = path.join(__dirname, '../../../');
var reqLink ='uploads/images/';
var mongodbutil = require( './mongodbutil' );
exports.allTrainers = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size

        let dbo =  await mongodbutil.Get();
        dbo.collection("TBL_TRAINERS").count({isAdmin:     { $not: { $eq: '1' }}}, function (err, totalCount) {
            if (err) {
                response = {
                    "error": true,
                    "message": "Error fetching data"
                }
            } else {
            dbo.collection("TBL_TRAINERS").aggregate([
                { $match: 
                    { 
                        isAdmin:     { $not: { $eq: '1' }}, 
                    }
                },
                {
                    $skip: query.skip
                },
                {
                    $limit: query.limit
                },
                {
                    $lookup: {
                        from: 'TBL_TRAINER_DETAILS',
                        localField: '_id',
                        foreignField: 'user_id',
                        as: 'userdetails'
                    }
                },
                {
                    $lookup: {
                        from: 'TBL_SERVICES',
                        localField: 'services.id',
                        foreignField: '_id',
                        as: 'services'
                    }
                },
            ]).toArray(function (err, data) {
                    if (err) throw err;
                    var totalPages = Math.ceil(totalCount / size)
                    if (Object.keys(data).length === 0) {
                        status = 3
                    } else {
                        status = 1
                    }
                    res.send({
                        "status": status,
                        "message": 'Success',
                        "data": data,
                        "currentPage": cPage,
                        "pages": totalPages,
                        "totalItems": totalCount,
                        "perPage": size
                    });
                    // console.log(data)
                    // db.close();
                });
            }
        });
    // });
}

exports.trainerDetails = async function (req, res) {
    var user_id = req.body.id
   let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_TRAINERS').aggregate([{
            $match: {
                _id: ObjectId(user_id)
            }
        },
        {
            $lookup: {
                from: 'TBL_TRAINER_DETAILS',
                localField: '_id',
                foreignField: 'user_id',
                as: 'userdetails'
            }
        },
        {
            $lookup: {
                from: 'TBL_SERVICES',
                localField: 'services.id',
                foreignField: '_id',
                as: 'services'
            }
        },

        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (data) {
                    // console.log(data)
                    res.send({
                        "status": '1',
                        "message": "Login successfull",
                        "data": data
                    });
                    return false;
                } else {
                    res.send({
                        "status": '0',
                        "message": "something went wrong",
                        "data": {}
                    });
                    return false;
                }
            }
        });
    // });
}

// exports.search = async function (req, res) {
//     let dbo =  await mongodbutil.Get();
//         dbo.collection('TBL_TRAINERS').aggregate([
//             {
//                 $match: {
//                     email: {
//                         $regex: req.body.email,
//                         $options: 'i'
//                     }
//                 }
//             },
//             {
//                 $lookup: {
//                     from: 'TBL_TRAINER_DETAILS',
//                     localField: '_id',
//                     foreignField: 'user_id',
//                     as: 'userdetails'
//                 }
//             },
//         ]).toArray(function (err, data) {
//             if (err) {
//                 throw err;
//             }
//             else {
//                 res.send({ "status": '1', "message": 'Success', "data": data });
//             }
//         });
//     // });
// }
exports.search = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    }
    else {
        cPage = req.body.pageNo
    }
    // console.log(cPage)
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = { "error": true, "message": "invalid page number, should start with 1" };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_TRAINERS').aggregate([
            // {
            //     $match: {
            //         email: {
            //             $regex: req.body.email,
            //             $options: 'i'
            //         }
            //     }
            // }
            // ,
            {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: '_id',
                    foreignField: '_id',
                    as: 'trainerss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: '_id',
                    foreignField: 'user_id',
                    as: 'userdetailss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: '_id',
                    foreignField: 'user_id',
                    as: 'userdetails'
                }
            },
            {"$unwind":"$trainerss"},
            {"$unwind":"$userdetailss"},
            {"$unwind":"$userdetailss.first_name"},
            {"$unwind":"$trainerss.email"},
            {"$match":  {$or:[
                {"userdetailss.first_name": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"trainerss.email": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                }]
            }},
            { $group : {
                _id : "$author",
                posts : { $sum : 1 },
                articles: {$push: '$$ROOT'},
            }},
            { $project: {total: '$posts', articles: {$slice: ['$articles', query.skip, query.limit]}}},
        ]).toArray(function (err, data) {
            // console.log(data)
            // return
            if (err) {
                throw err;
            }
            else {
                console.log(data)
                if ( data.length === 0) {
                   var totalCount = 0
                }
                else{
                    var totalCount = data[0].total
                }
                var totalPages = Math.ceil( totalCount/ size)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0].articles,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                // res.send({ "status": '1', "message": 'Success', "data": data });
            }
        });
    // });
}
exports.block = async function (req, res) {
    // MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, function (err, db) {
    //     if (err) throw err;
        var myquery = { _id: ObjectId(req.body.id) };
        if (req.body.status == 1) {
            var newvalues = { $set: { isBlocked: "0" } };
            var blocked = 0
        } else {
            var newvalues = { $set: { isBlocked: "1" } };
            var blocked = 1

        }
        let dbo =  await mongodbutil.Get();
        dbo.collection("TBL_TRAINERS").updateOne(myquery, newvalues, function (err, data) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'Gym Blocked', 'blocked': blocked });
            // db.close();
        });
    // });
}

exports.updateTrainer = async function (req, res) {
    // MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, function (err, db) {
    //     if (err) throw err;
        let dbo =  await mongodbutil.Get();
        var services = []
        console.log(req.body)
        var servicesParsed = JSON.parse(req.body.services);
        var detailQuery = { user_id: ObjectId(req.body.id) };
        var myquery = { _id: ObjectId(req.body.id) };
        var stat = 0
        if (req.files != undefined || req.files != null) {
            var sampleFile = req.files.image;
            var seconds = Math.round(new Date().getTime() / 1000)
            sampleFile.mv(reqPath + "/uploads/images/" + sampleFile.md5 + "_" + seconds + "." + req.files.image.mimetype.split('/')[1], function (err, data) {
                if (err) {
                    stat++
                    return false;
                }
                else {
                    // fs.unlink(reqPath + "/uploads/images/" + req.body.old_img, (err) => {
                    //     // if (err) throw err;
                    //     // console.log('successfully deleted /tmp/hello');
                    // });
                    // img = sampleFile.md5 + "_" + seconds + "." + req.files.image.mimetype.split('/')[1];
                }
            })
        }
        else {
            var img = 1
        }
        for (var i = 0; i < servicesParsed.length; i++) {
            services.push({ id: ObjectId(servicesParsed[i]) });
        }
        if (img == 1) {
            var data = { first_name: req.body.first_name, last_name: req.body.last_name ,bio:req.body.bio}
        }
        else {
            var data = { first_name: req.body.first_name, last_name: req.body.last_name,bio:req.body.bio, image: sampleFile.md5 + "_" + seconds + "." + req.files.image.mimetype.split('/')[1] }
        }
        var newvalues = { $set: data };
        var servicevalues = { $set: { services: services ,bio:req.body.bio} };
        dbo.collection("TBL_TRAINERS").updateOne(myquery, servicevalues, function (err, data) {
            if (err) {
                stat++
                throw err;
            }
            // res.send({ "status":'1',"message": 'Success'});  
        });
        // return
        dbo.collection("TBL_TRAINER_DETAILS").updateOne(detailQuery, newvalues, function (err, data) {
            if (err || stat > 0) {
                res.send({ "status": '0', "message": 'Error', 'stat': stat });
                // throw err; 
            }
            else if (stat == 0) {
                if (img == 1) {
                    res.send({ "status": '1', "message": 'Trainer Details Updated'});
                }
                else{
                    res.send({ "status": '1', "message": 'Trainer Details Updated',"img":sampleFile.md5 + "_" + seconds + "." + req.files.image.mimetype.split('/')[1]  });
                }
                
                // db.close();
            }

        });
    // });
}
exports.trainerList = async function (req, res) {
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_TRAINERS').aggregate([
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: '_id',
                    foreignField: 'user_id',
                    as: 'userdetails'
                }
            },
            {
                $lookup: {
                    from: 'TBL_SERVICES',
                    localField: 'services.id',
                    foreignField: '_id',
                    as: 'services'
                }
            },
            {
                $lookup: {
                    from: 'TBL_CARDS',
                    localField: '_id',
                    foreignField: 'trainer_id',
                    as: 'cards'
                }
            },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (data) {
                    // console.log(data)
                    res.send({
                        "status": '1',
                        "message": "Success",
                        "data": data
                    });
                    return false;
                } else {
                    res.send({
                        "status": '0',
                        "message": "something went wrong",
                        "data": {}
                    });
                    return false;
                }
            }
        });

    // });
}
exports.delete = async function (req, res) {
    let dbo =  await mongodbutil.Get();
        var myquery = { _id: ObjectId(req.body.id) };
        var myquery2 = { user_id: ObjectId(req.body.id) };
        dbo.collection("TBL_TRAINERS").deleteOne(myquery, function (err, obj) {
            if (err) throw err;
            // res.send({ "status": '1', "message": 'Success' });
            // db.close();
        });
        dbo.collection("TBL_TRAINER_DETAILS").deleteOne(myquery2, function (err, obj) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'Success' });
            // db.close();
        });
    // });
}