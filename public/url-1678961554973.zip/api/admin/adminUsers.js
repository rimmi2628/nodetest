var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

const {
	admin
} = require('../firebaseConfig.js');
var options = {
	priority: "high",
	timeToLive: 60 * 60 * 24
};
var app = express()
app.use(bodyParser.urlencoded({
	extended: true
}));
app.use(bodyParser.json());
var mongodbutil = require('./mongodbutil');

exports.allUsers = async function (req, res) {
	if (Object.keys(req.body).length === 0) {
		cPage = 1
	} else {
		cPage = req.body.pageNo
	}
	var pageNo = parseInt(cPage)
	var size = 8
	var query = {}
	if (pageNo < 0 || pageNo === 0) {
		response = {
			"error": true,
			"message": "invalid page number, should start with 1"
		};
		return res.json(response)
	}
	query.skip = size * (pageNo - 1)
	query.limit = size
	let dbo = await mongodbutil.Get();
	var id = req.body.id
	dbo.collection("TBL_CLIENTS").count({"isSignup":1}, function (err, totalCount) {
		if (err) {
			response = {
				"error": true,
				"message": "Error fetching data"
			}
			return false;
		}

		var totalPages = Math.ceil(totalCount / size)
		dbo.collection('TBL_CLIENTS').aggregate([
			{
				$match: {
					isSignup: 1
				}
			},
            {
				$sort: {
					"_id": -1
				}
			},
			{
				$skip: query.skip
			},
			{
				$limit: query.limit
			},
		]).toArray(function (err, data) {
			if (err) {
				throw err;
			} else {
				if (Object.keys(data).length === 0) {
					res.send({
						"status": '0',
						"message": 'err',
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				} else {
					res.send({
						"status": '1',
						"message": 'Success',
						"data": data,
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				}
			}
		});
	});
}

exports.search = async function (req, res) {
	if (req.body.pageNo === undefined || req.body.pageNo < 0 || req.body.pageNo === 0) {
		cPage = 1
	} else {
		cPage = req.body.pageNo
	}
	var pageNo = parseInt(cPage)
	var size = 8
	var query = {}
	query.skip = size * (pageNo - 1)
	query.limit = size

	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_CLIENTS').aggregate([
	{
				$match: {
					isSignup: 1
				}
			},{

			$sort: {
				"_id": -1
			}
		},
		{
			"$match": {
				$or: [
					{
						"first_name": {
							$regex: req.body.email,
							$options: 'i'
						}
                    },
                    {
						"email": {
							$regex: req.body.email,
							$options: 'i'
						}
					},
				]
			}
		},
		{
			$group: {
				_id: "$author",
				posts: {
					$sum: 1
				},
			}
		},
		{
			$project: {
				total: '$posts'
			}
		},

	]).toArray(function (err, data1) {
		dbo.collection('TBL_CLIENTS').aggregate([
		{
				$match: {
					isSignup: 1
				}
			},{
				$sort: {
					"_id": -1
				}
			},
			{
				$lookup: {
					from: 'TBL_CLIENT_DETAILS',
					localField: '_id',
					foreignField: 'user_id',
					as: 'clientDetails'
				}
			},
			{
				"$match": {
					$or: [
						{
							"first_name": {
								$regex: req.body.email,
								$options: 'i'
							}
						},
                        {
                            "email": {
                                $regex: req.body.email,
                                $options: 'i'
                            }
                        },
					]
				}
			},
			{
				$skip: query.skip
			},
			{
				$limit: query.limit
			},

		]).toArray(function (err, data) {
			if (err) {
				throw err;
			} else {
				console.log(data)
				if (data.length === 0) {
					var totalCount = 0
				} else {
					var totalCount = data1[0].total
				}
				var totalPages = Math.ceil(totalCount / size)
				if (totalCount === 0) {
					res.send({
						"status": '0',
						"message": 'err',
						"data": [],
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				} else {
					res.send({
						"status": '1',
						"message": 'Success',
						"data": data,
						"currentPage": cPage,
						"pages": totalPages,
						"totalItems": totalCount,
						"perPage": size
					});
				}
			}
		});
	});

}

exports.block = async function (req, res) {
	var myquery = { _id: ObjectId(req.body.id) };
	if (req.body.status == 1) {
		var newvalues = { $set: { isBlocked: "0" } };
		var blocked = 0
	} else {
		var newvalues = { $set: { isBlocked: "1" } };
		var blocked = 1
	}
	let dbo =  await mongodbutil.Get();
	dbo.collection("TBL_CLIENTS").updateOne(myquery, newvalues, function (err, data) {
		if (err) throw err;
		res.send({ "status": '1', "message": 'user Blocked', 'blocked': blocked });
	});
}