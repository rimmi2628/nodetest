var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
const Utill = require('../../helper/Constant')



// var stripe = require('stripe')('sk_test_1tqRe2GJZqKbCChbIZvB4GKs');

var stripe = require('stripe')(Utill.STRIPE_KEY);

const { admin } = require('../firebaseConfig.js');
var options = {
  priority: "high",
  timeToLive: 60 * 60 *24
};
var app = express()
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var mongodbutil = require( './mongodbutil' );
exports.allBookings = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    // MongoClient.connect(url, {
    //     useNewUrlParser: true,
    //     useUnifiedTopology: true
    // }, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db("gymtraining");
    let dbo =  await mongodbutil.Get();
        var id = req.body.id
        dbo.collection("TBL_BOOKINS").count({}, function (err, totalCount) {
            if (err) {
                response = {
                    "error": true,
                    "message": "Error fetching data"
                }
                return false;
            }

            var totalPages = Math.ceil(totalCount / size)
            dbo.collection('TBL_BOOKINS').aggregate([
            {
                $sort: {"_id": -1} 
            },
            {
                $skip: query.skip
            },
            {
                $limit: query.limit
            },
            {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetails'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            ]).sort({created_at: -1}).toArray(function (err, data) {
                if (err) {
                    throw err;
                } else {
                    if (Object.keys(data).length === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                }
            });
        });
    // });
}

exports.bookingDetails = async function (req, res) {
    var booking_id = ObjectId(req.body.id)
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_BOOKINS').aggregate([
            {
                $match: {
                    _id: booking_id
                }

            },
            {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetails'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (Object.keys(data).length === 0) {
                    res.send({
                        "status": '0',
                        "message": 'err',
                    });
                } else {
                    res.send({
                        "status": '1',
                        "message": 'Success',
                        "data": data,
                    });
                }
            }
        });
    // });
}

// exports.search = async function (req, res) {
//    let dbo =  await mongodbutil.Get();
//         dbo.collection('TBL_TRAINERS').aggregate([
//             {
//                 $match: {
//                     email: {
//                         $regex: req.body.email,
//                         $options: 'i'
//                     }
//                 }
//             },
//             {
//                 $lookup: {
//                     from: 'TBL_TRAINER_DETAILS',
//                     localField: '_id',
//                     foreignField: 'user_id',
//                     as: 'userDetails'
//                 }
//             },
//             {
//                 $lookup: {
//                     from: 'TBL_BOOKINS',
//                     localField: '_id',
//                     foreignField: 'user_id',
//                     as: 'bookings'
//                 }
//             },
//             // {
//             //     $lookup: {
//             //         from: 'TBL_GYMS',
//             //         localField: 'gym_id',
//             //         foreignField: '_id',
//             //         as: 'gym'
//             //     }
//             // },

//         ]).toArray(function (err, data) {
//             if (err) {
//                 throw err;
//             }
//             else {
//                 for (let k = 0; k < data.length; k++) {
//                     if (Object.keys(data[k].bookings) == 0) {
//                         delete data[k]
//                     }
//                 }
//                 dataa = data.filter(item => item);
//                 res.send({ "status": '1', "message": 'Success', "data": dataa });
//             }
//         });
//     // });
// }
exports.search = async function (req, res) {
    if (req.body.pageNo === undefined || req.body.pageNo < 0 || req.body.pageNo === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    // if (pageNo < 0 || pageNo === 0) {
    //     response = {
    //         "error": true,
    //         "message": "invalid page number, should start with 1"
    //     };
    //     return res.json(response)
    // }
    query.skip = size * (pageNo - 1)
    query.limit = size
    
   let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_BOOKINS').aggregate([
            // 
             {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetails'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetailss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gymss'
                }
            },
            {"$unwind":"$user"},
            {"$unwind":"$user.email"}, 
            {"$unwind":"$gymss"},
            {"$unwind":"$gymss.name"},
            {"$unwind":"$gymss.formatted_address"},
            {"$unwind":"$userDetailss"},
            {"$unwind":"$userDetailss.first_name"},
            
            {"$match":  {$or:[{
                   "user.email": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"gymss.name": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"gymss.formatted_address": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                },
                {"userDetailss.first_name": {
                        $regex: req.body.email,
                        $options: 'i'
                    }
                } ]
            }},
            { $group : {
                _id : "$author",
                posts : { $sum : 1 },
                articles: {$push: '$$ROOT'},
            }},
            { $project: {total: '$posts', articles: {$slice: ['$articles', query.skip, query.limit]}}},
            // {
            //     $skip: query.skip
            // },
            // {
            //     $limit: query.limit
            // },
            // {"$match": {
                   
            //     }
            // },
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                console.log(data)
                if ( data.length === 0) {
                   var totalCount = 0
                }
                else{
                    var totalCount = data[0].total
                }
                var totalPages = Math.ceil( totalCount/ size)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0].articles,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                // res.send({ "status": '1', "message": 'Success', "data": data });
            }
        });
    // });
}
exports.changeStatus = async function (req, res) {
   // let dbo =  await mongodbutil.Get();
        var myquery = { _id: ObjectId(req.body.id) };
        if (req.body.status == 1) {
            var newvalues = { $set: { status: 1 } };
            var status = 1
            var statusss = "0"
        } else {
            var newvalues = { $set: { status: 3 } };
            var status = 3
            var statusss = "3"
  
        }
       
       let dbo =  await mongodbutil.Get();
       const gyymdetails = dbo.collection('TBL_BOOKINS').find({ _id: ObjectId(req.body.id) })
			.toArray(function (err, data) {
				if (err) {
					throw err;
				} else {
					dbo.collection('TBL_GYMS').find({ _id: data[0].gym_id })
					.toArray(function (err, dataG) {
						if (err) {
							throw err;
						} else {
                            var ddn = getDate(data[0].schedule_time);
                            var dddt = strtime(data[0].schedule_time);
							var NotiObj = { trainer_id:data[0].user_id,date:data[0].date,time:data[0].time,gym_id:data[0].gym_id,gym_name:dataG[0].name,logo:dataG[0].logo,text:"",type:statusss,status:'1',date_time:data[0].schedule_time,created_at:getCurrentTime(),updated:getCurrentTime()};
							dbo.collection("TBL_NOTIFICATIONS").insertOne(NotiObj, function(err,resr){
							if (err){
								throw err;
							}
							});

							dbo.collection('TBL_TRAINER_DETAILS').find({ user_id: data[0].user_id })
							.toArray(function (err, data1) {
								if (err) {
									throw err;
								} else { 
									var actionInstant = 1
									var text =""
									if(status == '3'){
										text ='You have Rejected '+data1[0].first_name+" "+data1[0].last_name+' on  '+formatDateTime(getCurrentTime())+''
										var title = 'Booking Rejected'
										var nbody = 'Booking has been Rejected'
                                        if (data[0].payment_method == '0' && data[0].status == 0 ) {
                                           // stripe.refunds.create({
                                           //    charge:  data[0].transaction_id,
                                           //  });
                                           stripe.refunds.create({
                                                  charge:  data[0].transaction_id,
                                                },
                                                function(err, refund) {
                                                  // asynchronously called
                                                  if(err){
                                                      console.log(err)
                                                     // res.send({ "status":"0","message": 'Error Please try again later','error': err.raw.message});  
                                                     
                                                     return false;
                                                  }
                                                  else{
                                                    // console.log(refund)
                                                    var newvalues1 = { $set: { status: 3,refund_id:refund.id } };
                                                    dbo.collection("TBL_BOOKINS").updateOne(myquery, newvalues1, function (err, data) {
                                                        // console.log(data);
                                                    });
                                                    // console.log(newvalues1);
                                                  }
                                              }
                                            );
                                            
                                        }
                                        
                                        
                                        // return false ;
									}
									else if(status == '1'){
										text ='You have accepted '+data1[0].first_name+" "+data1[0].last_name+' on  '+formatDateTime(getCurrentTime())+''
										var title = 'Booking Accepted'
										var nbody = 'Booking has been Accepted'
                                        dbo.collection("TBL_AVAILABILITY_SLOTS").updateOne({_id:ObjectId(data[0].slot_id)},{$inc: {availableSlots: -1}} ,  function(err, resultsss) {
                                         
                                         })

									}
									dbo.collection('TBL_PUSH_TOKENS').find({ trainer_id: data[0].user_id })
										.toArray(function (err, tokens) {
											var dTokens= []
											for (let e = 0; e < tokens.length; e++) {
											dTokens[e] = tokens[e].token;
											}
											var payload = {
											notification: {
												title: title,
												body: nbody
											},
											data: {
												booking_id: req.body.id,
												// user_id: data[0].user_id,
												// gym_id: data[0].gym_id,
											}
											};
											var registrationToken = dTokens;
											if(tokens.length != 0){
												admin.messaging().sendToDevice(registrationToken, payload, options)
												.then(function(response) {
												console.log("Successfully sent message:", response);
												})
												.catch(function(error) {
												console.log("Error sending message:", error);
												});
											}
										});
									// console.log(data1)
									// return
									// if(status == '1'){
									// 	var gymNotiObj = { trainer_id: data[0].user_id,trainer_name:data1[0].first_name+" "+data1[0].last_name,gym_id: data[0].gym_id,gym_name:dataG[0].name,price:''+dataG[0].price+'',user_id:ObjectId(user_id),text:text,action:actionInstant,status:0,date_time:data[0].schedule_time,created_at:getCurrentTime(),updated:getCurrentTime(),type:2};
									// // console.log(gymNotiObj)
									// // return
									// dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(gymNotiObj, function(err,resr){
									// 	if (err){
									// 		throw err;
									// 	}
									// });
									// }
									
								}
							});
						}
					});
					
				} 
			});	
        dbo.collection("TBL_BOOKINS").updateOne(myquery, newvalues, function (err, data) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'success', 'status': status });
            // db.close();
        });
    // });
}

exports.addBooking = async function(req,res){
    // console.log(req.body)
    // return
    // if (duration === '') {
    //     req.body.duration = ""
    // }
    // console.log(req.body)
    if (req.body.pType == 0) {
        stripe.charges.create(
        {
            amount: parseFloat(req.body.price)*100,
            currency: 'usd',
            customer:req.body.cus_id,
            // source: 'tok_visa',
            description: 'Charge for Booking',
        },
            function(err, charge) {
                if (err) {
                   res.send({ "status": '0', "message": 'Error '+err.code+'','error':err});
                }
                else if (charge.status == "succeeded") {
                    // console.log(charge)
                    if (req.body.instantbook == true) {
                        var rData = {"user_id":req.body.trainerNames ,"gym_id":req.body.gymName ,"payment_method": '0',"transaction_id": charge.id,"slot_id":req.body.slot_id ,"date":req.body.date ,"time": req.body.time,"schedule_time":req.body.datetime ,"instantBooking":true ,"amount": req.body.price} 
                    }
                    else{
                        var rData = {"user_id":req.body.trainerNames ,"gym_id":req.body.gymName ,"payment_method": '0',"transaction_id": charge.id,"slot_id":req.body.slot_id ,"date":req.body.date ,"time": req.body.time,"schedule_time":req.body.datetime ,"instantBooking":false ,"amount": req.body.price} 
                    }
                    

                    res.send({ "status": '1', "message": 'success', 'data': rData });
                }
                // asynchronously called
            }
        );
    }
    else{
        res.send({ "status": '0', "message": 'err no Payment method selected', 'data': [] });
    }
    
    return
    var client = ''
    if (req.body.clientName !== '') {
        client = req.body.clientName
    }
    else {
        client = ''
    }
       let dbo =  await mongodbutil.Get();

        var myobj = { 'user_id': ObjectId(req.body.trainerNames), 'gym_id': ObjectId(req.body.gymName), 'slot_id': ObjectId(req.body.slot_id),'client_name': client ,'schedule_time': ''+req.body.datetime+'','status':"2","date":req.body.date,"time":req.body.time,"price":req.body.price,created_at:getCurrentTime(),updated_at:getCurrentTime()};
        dbo.collection("TBL_BOOKINS").insertOne(myobj, function(err, data) {
            if (err) throw err;
                res.send({ "status": '1', "message": 'success', 'data': data });
                // db.close();
            });
        // });
}

exports.findAvailability = async function (req, res) {
    var gym_id = ObjectId(req.body.id)
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_GYM_AVAILABILITY').aggregate([
            {
                $match: {
                    // $and: [ 
                        // {
                            gym_id: gym_id
                        // },
                        // {date: {
                        //     $gte: getDate(getCurrentTime())
                        // }}
                    // ]
                }

            },
            {
                $lookup: {
                    from: 'TBL_AVAILABILITY_SLOTS',
                    localField: '_id',
                    foreignField: 'gym_availability_id',
                    as: 'slots'
                }
            },
           
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (Object.keys(data).length === 0) {
                    res.send({
                        "status": '0',
                        "data": data,
                        "message": 'err',
                        "date":getDate(getCurrentTime())
                    });
                } else {
                    res.send({
                        "status": '1',
                        "message": 'Success',
                        "data": data,
                    });
                }
            }
        });
    // });
}
exports.availabileSlots = async function (req, res) {
    var slot_id = ObjectId(req.body.id)
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_AVAILABILITY_SLOTS').aggregate([
            {
                $match: {
                        gym_availability_id: slot_id,
                }

            }
           
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (Object.keys(data).length === 0) {
                    res.send({
                        "status": '0',
                        "data": data,
                        "message": 'err',
                        "date":getDate(getCurrentTime())
                    });
                } else {
                    res.send({
                        "status": '1',
                        "message": 'Success',
                        "data": data,
                    });
                }
            }
        });
    // });
}
exports.trainerPayment = async function (req, res) {
    var id = ObjectId(req.body.id)
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_CARDS').aggregate([
            {
                $match: {
                        trainer_id: id,
                }

            }
           
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (Object.keys(data).length === 0) {
                    res.send({
                        "status": '0',
                        "data": data,
                        "message": 'err',
                        "date":getDate(getCurrentTime())
                    });
                } else {
                    res.send({
                        "status": '1',
                        "message": 'Success',
                        "data": data,
                    });
                }
            }
        });
    // });
}
exports.slotPrice = async function (req, res) {
    var slot_id = ObjectId(req.body.id)
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_AVAILABILITY_SLOTS').aggregate([
            {
                $match: {
                        _id: slot_id,
                }

            }
           
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            } else {
                if (Object.keys(data).length === 0) {
                    res.send({
                        "status": '0',
                        "data": data,
                        "message": 'err',
                        "date":getDate(getCurrentTime())
                    });
                } else {
                    res.send({
                        "status": '1',
                        "message": 'Success',
                        "data": data,
                    });
                }
            }
        });
    // });
}
exports.addCard = async function (req, res) {
  console.log(req.body)
  var cvc = req.body.newCvv
  var ccNo = req.body.newCC
  var exp_month = req.body.mm
  var exp_year = req.body.yy
  var user_id = req.body.tName
  var zipcode = req.body.newZip
  // return false;
  stripe.tokens.create(
    {
      card: {
        number: ccNo,
        exp_month: exp_month,
        exp_year: exp_year,
        cvc: cvc,
      },
    },
    function(err, token) {
      // asynchronously called
      if(err){
          console.log(err)
         res.send({ "status":"0","message": 'Error Please try again later','error': err.raw.message});  
         
         return false;
      }
      else{
        stripe.customers.create(
          {
            description: 'Customer for hourful App',
            source: token.id
          },
          function(err, customer) {
            if(err){
              res.send({ "status":"0","message": 'Error Please try again later' });  
              // console.log(err)
              return false;
            }
            else{
              stripe.charges.create(
                {
                    amount: parseFloat(req.body.price)*100,
                    currency: 'usd',
                    customer:customer.id,
                    // source: 'tok_visa',
                    description: 'Charge for Booking',
                },
                    function(err, charge) {
                        if (err) {
                            console.log(err)
                            res.send({ "status": '0', "message": 'Error Amount too small'});
                        }
                        else if (charge.status == "succeeded") {
                            // console.log(charge)
                            // if (req.body.saveCard != undefined && req.body.saveCard == 1 ) {
                        var rData = {"user_id":req.body.tName ,"gym_id":req.body.gName ,"payment_method": '0',"transaction_id": charge.id,"slot_id":req.body.slot_id ,"date":req.body.date ,"time": req.body.time,"schedule_time":req.body.datetime ,"instantBooking":true ,"amount": req.body.price,"cus_id":customer.id} 
                            // }
                            // else{
                            //     var rData = {"save":'0',"user_id":req.body.tName ,"gym_id":req.body.gName ,"payment_method": '0',"transaction_id": charge.id,"slot_id":req.body.slot_id ,"date":req.body.date ,"time": req.body.time,"schedule_time":req.body.datetime ,"instantBooking":true ,"amount": req.body.price} 
                            // }
                            

                            res.send({ "status": '1', "message": 'success', 'data': rData });
                        }
                        // asynchronously called
                    }
                );
            //   console.log(customer)
            }
          }
        );
        // console.log(token.id)
      }
    }
  );
}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}

function formatDateTime(datetime){
	const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
	const d = new Date(datetime*1000);
	var month =  monthNames[d.getMonth()];
	var date = d.getDate();
	var year = d.getFullYear();

	var hours = d.getHours();
	var minutes = d.getMinutes();
	var ampm = hours >= 12 ? 'pm' : 'am';
	hours = hours % 12;
	hours = hours ? hours : 12; // the hour '0' should be '12'
	minutes = minutes < 10 ? '0'+minutes : minutes;
	var strTime = hours + ':' + minutes + ' ' + ampm;

	// Dec 10, 2019 @10:30 AM
	return month+" "+date+", "+year+" at "+strTime;
}
function strtime(datetime){
    const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
    const d = new Date(datetime*1000);
    var month =  monthNames[d.getMonth()];
    var date = d.getDate();
    var year = d.getFullYear();

    var hours = d.getHours();
    var minutes = d.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    hour =  hours < 10 ? '0'+hours : hours;
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes ;

    // Dec 10, 2019 @10:30 AM
    return strTime;
}
function getDate(datetime){
	const monthNames = ["01", "02", "03", "04", "05", "06","07", "08", "09", "10", "11", "12"];
	const d = new Date(datetime*1000);
	// var month =  monthNames[d.getMonth()];
	var month = monthNames[d.getMonth()];
	var date = d.getDate();
	var year = d.getFullYear();

	var hours = d.getHours();
	var minutes = d.getMinutes();
	var ampm = hours >= 12 ? 'pm' : 'am';
	hours = hours % 12;
	hours = hours ? hours : 12; // the hour '0' should be '12'
	minutes = minutes < 10 ? '0'+minutes : minutes;
	var strTime = hours + ':' + minutes + ' ' + ampm;
    // 2020-04-27",
	return year+"-"+month+"-"+date ;
}