
var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

var braintree = require("braintree");


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());
app.use('/img', express.static(path.join(__dirname, '/api/uploads/images')))


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});



var gateway = braintree.connect({
  environment: braintree.Environment.Sandbox,
  merchantId: "8vth6dk6nd73mq4v",
  publicKey: "569v88wmkphh5k4d",
  privateKey: "c1e0991931c219069f06d36b67a28ee3"
});






// var db = mongo.connect("mongodb://localhost:8082/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
//    if(err){ console.log( err); }  
//    else{ //console.log('Connected to ' + db, ' + ', response); 
//     }  
// });  
// const ObjectId = mongo.Types.ObjectId;
// const Schema = mongo.Schema ;  
//    //const {email, first_name, last_name, password, social_id, image,type } = req.body;

// const TBL_TRAINER = new Schema({

//     social_id: String,
//     email: String,
//     password: String,
//     details_id:String,
//     type: String,
//     services:Array,
//     email_verification_id:String,
//     favourites:String,
//     status:String,
//     created_at:Number,
//     updated_at:Number,
//   });

//   const TBL_TRAINER_DETAIL = new Schema({
//     first_name: String,
//     last_name: String,
//     bio: String,
//     phone_number:String,
//     phone_verified: String,
//     email_verified:Array,
//     image:String,
//     goverment_id:String,
//     selfie:String,
//     created_at:Number,
//     updated_at:Number,
//   });


// const TBL_TRAINERS = mongo.model('TBL_TRAINERS', TBL_TRAINER, 'TBL_TRAINERS');
// const TBL_TRAINER_DETAILS = mongo.model('TBL_TRAINER_DETAILS', TBL_TRAINER_DETAIL, 'TBL_TRAINER_DETAILS');



 app.use(bodyParser.json());
 // app.use(bodyParser.urlencoded());
 app.use(bodyParser.urlencoded({extended: true}));

 mongo.set('useFindAndModify', false);
 var r = require('./api/');
 var gymApps = require('./api/houfulapp/')

// app.use(express.urlencoded({extended:false}))   
  
app.use(function (req, res, next) {        
    //  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');    
     res.setHeader('Access-Control-Allow-Origin','*');    

     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');    
     res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');      
     res.setHeader('Access-Control-Allow-Credentials', true);       
     next();  
 });  
  


 //paypal
 
 app.post('/api/usePaypal', r.usePaypal.paypal)
 app.post('/api/usePaypalCred', r.usePaypal.withcardPaypal)
 // app.post('/api/transactionPaypal', r.usePaypal.transactionPaypal)
 
 //api
 app.post('/api/register', r.register.register)
 app.post('/api/get_services', r.get_services.get_services)
 app.post('/api/services', r.services.services)
 app.post('/api/phone_verification', r.phone_verification.phone_verification)
 app.post('/api/request_email_verification', r.request_email_verification.request_email_verification)
 app.post('/api/upload_id', r.upload_id.upload_id)
 app.post('/api/login', r.login.login)
 app.post('/api/bio', r.bio.bio)
 app.post('/api/filter', r.filter.filter)
 app.post('/api/gyms', r.gyms.gyms)
 app.post('/api/gym_details', r.gym_details.gym_details)
 app.post('/api/schedule', r.schedule.schedule)
 app.post('/api/add_client', r.add_client.add_client)
 app.post('/api/appointments', r.appointments.appointments)
 app.post('/api/gyms_insert', r.appointments.appointments)
 app.post('/api/availability', r.availability.availability)
 app.post('/api/badges', r.badges.badges)
 app.post('/api/feedback', r.feedback.feedback)
 app.post('/api/mark_favorite', r.favorites.favorites)
 app.post('/api/get_favorites', r.get_favorites.get_favorites)
 app.post('/api/payment_method', r.payment_method.payment_method)
 app.post('/api/reviews', r.reviews.reviews)
 app.post('/api/add_notes', r.add_notes.add_notes)
 app.post('/api/report_gym', r.report_gym.report_gym)
 app.post('/api/cancel_booking', r.cancel_booking.cancel_booking)
 app.post('/api/reschedule', r.reschedule.reschedule)
 app.post('/api/gym_reviews', r.gym_reviews.gym_reviews)
 app.post("/api/change_password", r.change_password.change_password)
 app.post("/api/update_profile", r.update_profile.update_profile)
 app.post("/api/reset_password", r.reset_password.reset_password)
 app.post("/api/get_user_payment_method", r.get_user_payment_method.get_user_payment_method)
 app.post("/api/availabilities", r.availabilities.availabilities)
 app.post('/api/emailConfirm', r.emailConfirm.emailConfirm)
 app.post('/api/debitBank', r.debitBank.debitBank)
 app.post('/api/report_problem', r.report_problem.report_problem)
 app.post('/api/get_aminities', r.get_aminities.get_aminities)
 app.post('/api/profile', r.profile.profile)

 
//Gym
app.post("/api/getGyms", r.admingyms.allGyms)
app.post("/api/blockGym", r.admingyms.blockGym)
app.post("/api/searchGym", r.admingyms.search)
app.post("/api/gymDetails", r.admingyms.gymDetails)
app.post("/api/updateGym", r.admingyms.updateGym)
app.get("/api/gymsList", r.admingyms.gymsList)
app.post("/api/deleteGym", r.admingyms.delete)

app.post("/api/getGymsEarning", r.earningsAladmin.allGyms)
app.post("/api/searchEarning", r.earningsAladmin.search)

//Trainer
app.post("/api/getTrainers", r.admintrainers.allTrainers)
app.post("/api/trainerDetails", r.admintrainers.trainerDetails)
app.post("/api/searchTrainer", r.admintrainers.search)
app.post("/api/blockTrainer", r.admintrainers.block)
app.post("/api/updateTrainer", r.admintrainers.updateTrainer)
app.get("/api/trainerList", r.admintrainers.trainerList)
app.post("/api/deleteTrainer", r.admintrainers.delete)

//Bookings
app.post("/api/getBookings", r.adminbookings.allBookings)
app.post("/api/bookingDetails", r.adminbookings.bookingDetails)
app.post("/api/changeStatus", r.adminbookings.changeStatus)
app.post("/api/searchBooking", r.adminbookings.search)
app.post("/api/addBooking", r.adminbookings.addBooking)
app.post("/api/findAvailability", r.adminbookings.findAvailability)
app.post("/api/availabileSlots", r.adminbookings.availabileSlots)
app.post("/api/trainerPayment", r.adminbookings.trainerPayment)
app.post("/api/slotPrice", r.adminbookings.slotPrice)
app.post("/api/addCard", r.adminbookings.addCard)
//Feedbacks
app.post("/api/getFeedbacks", r.adminfeedback.feedbacks)
app.post("/api/deleteFeedback", r.adminfeedback.delete)
app.post("/api/filterFeedback", r.adminfeedback.filterFeedback)
app.post("/api/searchFeedback", r.adminfeedback.search)

//Equipments
app.get("/api/getEquipments", r.adminequipments.equipments)
app.post("/api/allEquipmentsp", r.adminequipments.allEquipments)
app.post("/api/addEquipmentsa", r.adminequipments.addEquipments)
app.post("/api/deleteEquipmentsa", r.adminequipments.delete)
app.post("/api/updateEquipmentsa", r.adminequipments.update)

//Services
app.get("/api/getServices", r.adminservices.services)
app.post("/api/addServicesa", r.adminservices.addServices)
app.post("/api/allServicesp", r.adminservices.allServices)
app.post("/api/deleteServicesa", r.adminservices.delete)
app.post("/api/updateServicesa", r.adminservices.update)


//login
app.post("/api/adminlogin", r.adminlogin.login)

//earnings
app.post("/api/allEarnings",r.adminearnings.allRequests)
app.post("/api/earningStatus",r.adminearnings.earningStatus)
app.post("/api/earningDetails",r.adminearnings.earningDetails)
app.post("/api/earningNote",r.adminearnings.earningnote)
app.post("/api/allEarningsGym",r.earningsAladmin.allEarnings)

//save Token
app.post('/api/register_push', r.save_token.save_token)
app.post('/api/un_register_push', r.save_token.un_register_push)
//leads
app.post('/api/getLeads', r.adminleads.allLeads)
app.post('/api/searchLead', r.adminleads.search)

//intrests_shown
app.post('/api/getIntrestsShown', r.getIntrestsShown.getIntrestsShown)
app.post('/api/intrestsSearch', r.getIntrestsShown.search)
//notifiactions

app.post('/api/notifications', r.notifications.notifications)




app.post('/api/registerowner',gymApps.register.registerowner)
app.post('/api/loginowner',gymApps.login.loginowner)
app.post('/api/addGym',gymApps.addGym.addGym)
app.post('/api/getGym',gymApps.getGym.getGym)
app.post('/api/emailConfirmOwner', gymApps.emailConfirmOwner.emailConfirmOwner)
app.post('/api/resendEmail',gymApps.emailConfirm.emailConfirm)
app.post('/api/getBooking',gymApps.getBookings.getBookings)
app.post('/api/getDayBooking',gymApps.getDayBooking.getDayBooking)
app.post('/api/changeBookingStatus',gymApps.changeBookingStatus.changeBookingStatus)
app.post('/api/checkevent',gymApps.checkevent.checkevent)
app.post('/api/addIntrests',gymApps.addIntrests.addIntrests)
app.post('/api/getGymsCalendar',gymApps.getGymsCalendar.getGymsCalendar)
app.post('/api/getChatData',gymApps.getChatData.getChatData)
app.post('/api/forgot_password',gymApps.forgot_password.forgot_password)
app.post('/api/webnotifications', gymApps.notifications.notifications)
app.post('/api/changeNotificatonStatus', gymApps.changeNotificatonStatus.changeNotificatonStatus)
app.post('/api/emailConfirmWeb', gymApps.emailConfirmWeb.emailConfirmWeb)
app.post('/api/transferAmountTobank', gymApps.transferAmountTobank.transferAmountTobank)
app.post('/api/getUserData', gymApps.getUserData.getUserData)
app.post('/api/updateUserData', gymApps.updateUserData.updateUserData)
app.post('/api/updateGymData', gymApps.updateGymData.updateGymData)
app.post('/api/getPaymentInfo', gymApps.getPaymentInfo.getPaymentInfo)
app.post('/api/cancelPayment', gymApps.cancelPayment.cancelPayment)
app.post('/api/getNotReveiewedBookings', gymApps.getNotReveiewedBookings.getNotReveiewedBookings)
app.post('/api/submitReview', gymApps.submitReview.submitReview)
app.post('/api/getGymAddress', gymApps.getGymAddress.getGymAddress)
app.post('/api/interest_shown', gymApps.interest_shown.interest_shown)
//hourful app front end


app.post('/api/getMonthSchedule',gymApps.getMonthSchedule.getMonthSchedule)
app.post('/api/getQuickSchedule',gymApps.getQuickSchedule.getQuickSchedule)
app.post('/api/saveDetailSetupForm',gymApps.saveDetailSetupForm.saveDetailSetupForm)
app.post('/api/saveQuickSetupForm',gymApps.saveQuickSetupForm.saveQuickSetupForm)




app.post('/api/gyms_insert', function(req, res) {
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("gymtraining");
    dbo.collection('TBL_GYMS').insert( {
      "name": "ravi Fitness",
      "logo": "",
      "bio": "we are best",
      "price": 50,
      "min_price": "1",
      "max_price": "3",
      "avg_rating": "4.2",
      "ratings": "67",
      "street_number": "230 West 39th Street",
      "administrative_area_level_1": "2nd Floor, New York, NY 10018, United States",
      "administrative_area_level_2": "2nd Floor, New York, NY 10018, United States",
      "locality": "2nd Floor, New York, NY 10018, United States",
      "country": "United States",
      "postal_code": "10018",
      "formatted_address": "230 West 39th Street | 2nd Floor, New York, NY 10018, United States",
      "latitude": "40.713050",
      "longitude": "-74.007230",
      "equipments_ids": [
          {
              "id": ObjectId("5e5e3632f03a4e713238c565")
          },
          {
              "id": ObjectId("5e5e3653f03a4e713238c566")
          },
          {
              "id": ObjectId("5e5e3664f03a4e713238c567")
          },
          {
              "id": ObjectId("5e5e366ff03a4e713238c568")
          }
      ],
      "images_ids": [
          {
              "id": ObjectId("5e60d4f6f03a4e713238c56c")
          },
          {
              "id": ObjectId("5e60d515f03a4e713238c56d")
          },
          {
              "id": ObjectId("5e60d52af03a4e713238c56e")
          },
          {
              "id": ObjectId("5e60d557f03a4e713238c56f")
          }
      ],
      "location": {
          "type": "Point",
          "coordinates": [
              41.71305,
              -75.00723
          ]
      }
  } );
   dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
  })
})







///not used
app.post('/api/createProfile', function(req, res) {
  //console.log()
   if(req.files != undefined){
     var sampleFile = req.files.avatar;
     sampleFile.mv(__dirname+"/uploads/images/"+sampleFile.md5+".png", function(err) {
       if (err){
         res.send({"err":"unable to get files"});
       }
       else{
         console.log(req.body)
         const { location, gymType } = req.body;
         let errors = [];
       
         if (!location || !gymType) {
           errors.push({ msg: 'Please enter all fields' });
         }
         if (errors.length > 0) {
          res.send(errors);
         }
         else{
           MongoClient.connect(url, function(err, db) {
             if (err) throw err;
             var dbo = db.db("gymtraining");
             var myobj = { location: req.body.location,gymType: req.body.gymType,image: sampleFile.md5+".png" };
             dbo.collection("profile").insertOne(myobj, function(err, res) {
               if (err) throw err;
               console.log("1 document inserted");
               db.close();
             });
           });
         }
       } 
     });
   }
   else{
     res.send({"err":"unable to get files"});
   }
  
   // const tempPath = req.file.path;
   
   // const targetfilename =  req.file.filename;
   // const targetPath = path.join(__dirname, "./uploads/images/"+targetfilename+""+path.extname(req.file.originalname).toLowerCase());
   
   //   fs.rename(tempPath, targetPath, err => {
   //     if (err) return handleError(err, res);
 
   //     res
   //       .status(200)
   //       .contentType("text/plain")
   //       .end(targetPath);
   //   });
 
});






 

  
app.listen(8088, function () {  
    
 //console.log('Example app listening on port 8080!')  
})  