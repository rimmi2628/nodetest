var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
const { admin } = require('../firebaseConfig.js');
var options = {
  priority: "high",
  timeToLive: 60 * 60 *24
};
var app = express()
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var mongodbutil = require( './mongodbutil' );

exports.allEarnings = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    // MongoClient.connect(url, {
    //     useNewUrlParser: true,
    //     useUnifiedTopology: true
    // }, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db("gymtraining");
    let dbo =  await mongodbutil.Get();
        var id = req.body.id
        dbo.collection("TBL_BOOKINS").count({ 'gym_id': ObjectId(id),'status' :5 }, function (err, totalCount) {
            if (err) {
                response = {
                    "error": true,
                    "message": "Error fetching data"
                }
                return false;
            }

            var totalPages = Math.ceil(totalCount / size)
            dbo.collection('TBL_BOOKINS').aggregate([
            { $match: { 'gym_id': ObjectId(id) ,'status' :5 } },
            // {
            //     $skip: query.skip
            // },
            // {
            //     $limit: query.limit
            // },
            {
                $lookup: {
                    from: 'TBL_TRAINERS',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            {
                $lookup: {
                    from: 'TBL_TRAINER_DETAILS',
                    localField: 'user_id',
                    foreignField: 'user_id',
                    as: 'userDetails'
                }
            },
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
            { $group: { _id : null, sum : { $sum: "$price" } ,articles: {$push: '$$ROOT'}} },
            { $project: {sum: '$sum', articles: {$slice: ['$articles', query.skip, query.limit]}}},
            ]).sort({created_at: -1}).toArray(function (err, data) {
                if (err) {
                    throw err;
                } else {
                    console.log(totalCount)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                             "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                }
            });
        });
    // });
}
exports.allGyms = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    }
    else {
        cPage = req.body.pageNo
    }
    // console.log(cPage)
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = { "error": true, "message": "invalid page number, should start with 1" };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size

        let dbo =  await mongodbutil.Get();
        // dbo.collection("TBL_GYMS").count({}, function (err, totalCount1) {
        // dbo.collection("TBL_GYMS").countDocuments({}, function (err, totalCount) {
            
            // if (err) {
            //     response = { "error": true, "message": "Error fetching data" }
            // }
            // else {
                dbo.collection('TBL_GYMS').aggregate([
                
                {
                    $lookup: {
                        from: 'TBL_BOOKINS',
                        localField: '_id',
                        foreignField: 'gym_id',
                        as: 'bookings'
                    }
                },
                // {"$unwind":"$bookings"},
                // {"$unwind":"$bookings.price"},
                // {"$unwind":"$bookings.status"},
              
                // {"$match":  
                //     {
                //         "bookings.status": 5
                //     }
                // },
                // { $project: {total: '$posts'}},
                {$skip: query.skip},{ $limit : query.limit },
                { $group : {
                    _id : "$author",
                    posts : { $sum : 1 },
                    // sum : { $sum: "$bookings.price" },
                    articles: {$push: '$$ROOT'},
                }},
                { $project: {total: '$posts',sum: '$sum',articles: '$articles'}},
            ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                dbo.collection('TBL_GYMS').aggregate([
                
                {
                    $lookup: {
                        from: 'TBL_BOOKINS',
                        localField: '_id',
                        foreignField: 'gym_id',
                        as: 'bookings'
                    }
                },
                { $group : {
                    _id : "$author",
                    posts : { $sum : 1 },
                }},
                { $project: {totalP: '$posts',sum: '$sum'}},
                    ]).toArray(function (err, dataT) {
                    if (err) {
                        throw err;
                    }
                    else {
                        console.log(dataT)
                        // console.log(data)
                        if ( data.length === 0) {
                           var totalCount = 0
                        }
                        else{
                            var totalCount = dataT[0].totalP
                        }
                        var totalPages = Math.ceil(totalCount/ size)
                        if (totalCount === 0) {
                            res.send({
                                "status": '0',
                                "message": 'err',
                                "data": [],
                                "currentPage": cPage,
                                "pages": totalPages,
                                "totalItems": totalCount,
                                "perPage": size
                            });
                        } else {
                            res.send({
                                "status": '1',
                                "message": 'Success',
                                "data": data[0].articles,
                                "currentPage": cPage,
                                "pages": totalPages,
                                "totalItems": totalCount,
                                "perPage": size,
                                "sum":  data[0].sum,
                            });
                        }
                    }
                });
                
                // res.send({ "status": '1', "message": 'Success', "data": data });
            }
        });
            // }
        // });
    // });
}
exports.search = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    }
    else {
        cPage = req.body.pageNo
    }
    // console.log(cPage)
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = { "error": true, "message": "invalid page number, should start with 1" };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_GYMS').aggregate([
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: '_id',
                    foreignField: '_id',
                    as: 'gymss'
                }
            },
            {
                $lookup: {
                    from: 'TBL_BOOKINS',
                    localField: '_id',
                    foreignField: 'gym_id',
                    as: 'bookings'
                }
            },
            {"$unwind":"$gymss"},
            {"$unwind":"$bookings"},
            {"$unwind":"$bookings.price"},
            {"$unwind":"$gymss.name"},
            {"$unwind":"$gymss.formatted_address"},
            {"$match":  {$or:[
                {"gymss.name": {
                        $regex: req.body.name,
                        $options: 'i'
                    }
                },
                {"gymss.formatted_address": {
                        $regex: req.body.name,
                        $options: 'i'
                    }
                }]
            }},
            { $group : {
                _id : "$author",
                posts : { $sum : 1 },
                sum : { $sum: "bookings.price" },
                articles: {$push: '$$ROOT'},
            }},
            { $project: {total: '$posts',sum: '$sum', articles: {$slice: ['$articles', query.skip, query.limit]}}},
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                console.log(data)
                if ( data.length === 0) {
                   var totalCount = 0
                }
                else{
                    var totalCount = data[0].total
                }
                var totalPages = Math.ceil( totalCount/ size)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0].articles,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size,
                            "sum": data[0].sum,
                        });
                    }
                // res.send({ "status": '1', "message": 'Success', "data": data });
            }
        });
    // });
}