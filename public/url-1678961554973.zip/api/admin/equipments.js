var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
var ObjectId = require('mongodb').ObjectID; 
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
     
var app = express()  
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json()); 
var mongodbutil = require( './mongodbutil' );
exports.equipments = async function(req,res){ 
    let dbo =  await mongodbutil.Get();
    dbo.collection("TBL_EQUIPMENTS").find({}).toArray(function(err, data) {
        if (err) throw err;
        res.send({ "status":'1',"message": 'EQUIPMENTS',"data" : data });  
        // console.log(data)
        // db.close();
    });
  // });  
} 
exports.allEquipments = async function (req, res) {
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size
    let dbo =  await mongodbutil.Get();
        var id = req.body.id
        dbo.collection("TBL_EQUIPMENTS").count({}, function (err, totalCount) {
            if (err) {
                response = {
                    "error": true,
                    "message": "Error fetching data"
                }
                return false;
            }

            var totalPages = Math.ceil(totalCount / size)
            dbo.collection('TBL_EQUIPMENTS').aggregate([
              
            {
                $skip: query.skip
            },
            {
                $limit: query.limit
            },
            ]).toArray(function (err, data) {
                if (err) {
                    throw err;
                } else {
                    if (Object.keys(data).length === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "data": [],
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                }
            });
        });
    // });
}
exports.addEquipments = async function(req,res){ 
  let dbo =  await mongodbutil.Get();
  var myobj = { 'name':req.body.amenity};
  dbo.collection("TBL_EQUIPMENTS").find({'name':{ $regex: new RegExp("^" + req.body.amenity.toLowerCase(), "i") }}).toArray(function(err, data) {
    if (err) throw err;
    else if (data.length > 0) {
        console.log(data)
        res.send({ "status": '0', "message": 'Equipment already exists', 'data': [] });
    }
    else{
        dbo.collection("TBL_EQUIPMENTS").insertOne(myobj, function(err, data1) {
        if (err) throw err;
            res.send({ "status": '1', "message": 'success', 'data': data1 });
            // db.close();
        });
    }
      
    });
} 
exports.delete = async function (req, res) {
    let dbo =  await mongodbutil.Get();
        var myquery = { _id: ObjectId(req.body.id) };
        dbo.collection("TBL_EQUIPMENTS").deleteOne(myquery, function (err, obj) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'Success' });
            // db.close();
        });  
    // });
}
exports.update =async function (req, res) {
    let dbo =  await mongodbutil.Get();
        var data = {}
        var myquery = { _id: ObjectId(req.body.id) };
        var newvalues = {name:req.body.amenity}
        dbo.collection("TBL_EQUIPMENTS").updateOne(myquery, newvalues, function (err, data) {
            if (err) throw err;
            res.send({ "status": '1', "message": 'Updated' });
            // console.log(img)
        });
       
}