var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var ObjectId = require('mongodb').ObjectID;
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
var fs = require("fs");
let reqPath = path.join(__dirname, '../../../');
var reqLink ='uploads/images/';
var mongodbutil = require( './mongodbutil' );

exports.getIntrestsShown = async function (req, res) {
	// console.log("ravi")
	// return;
    if (Object.keys(req.body).length === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    if (pageNo < 0 || pageNo === 0) {
        response = {
            "error": true,
            "message": "invalid page number, should start with 1"
        };
        return res.json(response)
    }
    query.skip = size * (pageNo - 1)
    query.limit = size

        let dbo =  await mongodbutil.Get();
        dbo.collection("TBL_INTEREST_SHOWN").find( { type: 1 } ).count({}, function (err, totalCount) {
            if (err) {
                response = {
                    "error": true,
                    "message": "Error fetching data"
                }
            } else {
            dbo.collection("TBL_INTEREST_SHOWN").aggregate([
                 {
                    $match: {type:1}
                },
                {
                    $skip: query.skip
                },
                {
                    $limit: query.limit
                }
               
            ]).toArray(function (err, data) {
                    if (err) throw err;
                    var totalPages = Math.ceil(totalCount / size)
                    if (Object.keys(data).length === 0) {
                        status = 3
                    } else {
                        status = 1
                    }
                    res.send({
                        "status": status,
                        "message": 'Success',
                        "data": data,
                        "currentPage": cPage,
                        "pages": totalPages,
                        "totalItems": totalCount,
                        "perPage": size
                    });
                    // console.log(data)
                    // db.close();
                });
            }
        });
    // });
}
exports.search = async function (req, res) {
    if (req.body.pageNo === undefined || req.body.pageNo < 0 || req.body.pageNo === 0) {
        cPage = 1
    } else {
        cPage = req.body.pageNo
    }
    var pageNo = parseInt(cPage)
    var size = 8
    var query = {}
    query.skip = size * (pageNo - 1)
    query.limit = size
    
   let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_INTEREST_SHOWN').aggregate([
             {
                    $match:  {$or:[
                        {
                        type: {
                            $regex: req.body.email,
                            $options: 'i'
                        }
                    },
                    {
                        emai: {
                            $regex: req.body.email,
                            $options: 'i'
                        }
                 }]
                }
            },
            { $group : {
                _id : "$author",
                posts : { $sum : 1 },
                articles: {$push: '$$ROOT'},
            }},
            { $project: {total: '$posts', articles: {$slice: ['$articles', query.skip, query.limit]}}},
           
        ]).toArray(function (err, data) {
            if (err) {
                throw err;
            }
            else {
                console.log(data)
                if ( data.length === 0) {
                   var totalCount = 0
                }
                else{
                    var totalCount = data[0].total
                }
                var totalPages = Math.ceil( totalCount/ size)
                    if (totalCount === 0) {
                        res.send({
                            "status": '0',
                            "message": 'err',
                            "data": [],
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    } else {
                        res.send({
                            "status": '1',
                            "message": 'Success',
                            "data": data[0].articles,
                            "currentPage": cPage,
                            "pages": totalPages,
                            "totalItems": totalCount,
                            "perPage": size
                        });
                    }
                
            }
        });
}