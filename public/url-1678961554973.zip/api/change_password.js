
var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());





var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.change_password = async function(req, res) {
       if(!(req.body.user_id && req.body.old_password && req.body.new_password)){
           res.send({"success":false,"message":"Please send all fields","data":[]});
           return false;
       }
       // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
            // if (err) throw err;
            let dbo =  await mongodbutil.Get();
            dbo.collection('TBL_TRAINERS').aggregate([
                { 
                    $match : { 
                        _id : ObjectId(req.body.user_id) 
                    } 
                }
            ]).toArray(function(err, resr) {
                if (err){
                    throw err;
                }
                else{
                    if(resr){
                        user = resr[0];
                        if(user.type == 0){
                            bcrypt.compare(req.body.old_password, user.password, function(err, response) {
                                if (err){
                                    res.send({"success": false, message: 'Got error while comparing passwords.'});
                                    return false;
                                }
                                if (response){
                                    bcrypt.genSalt(10, (err, salt) => {
                                        bcrypt.hash(req.body.new_password, salt, (err, hash) => {
                                            if (err) throw err;
                                            dbo.collection('TBL_TRAINERS').updateOne({ _id: ObjectId(user._id)}, { $set: {password: hash } }, function(err, rese){
                                                if (err){
                                                    res.send({"success":false,"message":"Something went wrong!"});
                                                    //db.close();
                                                    return false;
                                                } 
                                                else{
                                                    res.send({"success": true, message: 'We have successfully changed your password.'});
                                                    //db.close();
                                                    return false;
                                                }
                                            } );
                                        });
                                    });
                                }
                                else {
                                    res.send({"success": false, message: 'Old Password do not match'});
                                    return false;
                                }
                            });
                        }
                        else{
                            res.send({"success":false,"message":"Not an Email account"});
                            return false;
                        }
                    }
                    else{
                        res.send({"success":false,"message":"something went wrong","data":[]});
                        return false;
                    }
                }
                // console.log(data)
            }); 
       // });  
  }
