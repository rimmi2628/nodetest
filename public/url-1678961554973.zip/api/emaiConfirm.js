var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
var admin = require("firebase-admin");
// var firebase = require('firebase-admin')
var serviceAccount = require("./hourful.json"); 

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://hourful-c541c.firebaseio.com"
});
var dbss = admin.firestore()
exports.dbss = dbss;

const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var sourceFile = require('./register.js');
var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});

  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.emailConfirm = async function(req, res) {
    //console.log(req.query.id);return;
    const {id} = req.body;
     console.log(req.body)
    let errors = [];
  
    if (!id) {
          res.send({"success":false,"message":"Please enter all fields","data":{}});
          return false;
    }
    else{
    //   var verifyEmailId=makeid(20);
      sourceFile.TBL_TRAINERS.findOne({ email_verification_id: id }).then(async user => {
        // console.log(user)    
              if (user) {
                //return;
                      sourceFile.TBL_TRAINERS.findOneAndUpdate({_id:ObjectId(user._id)}, {$set: {email_verification_id:user._id}}, {upsert: true}, async function(err,doc) {
                      if (err) {
                            res.send({"success":false,"message":"something went wrong","data":{}});
                            return false;
                        }
                        else{
                        // MongoClient.connect(url, function(err, db) {
                            let dbo =  await mongodbutil.Get();
                            
                            dbo.collection("TBL_TRAINER_DETAILS").updateOne({user_id:ObjectId(user._id)},{$set:{email_verified:1}}, function(err, resv) {
                                if (resv) {
                                    let citiesRef = dbss.collection('Verification');
                                    console.log(user._id)
                                    var id = user._id
                                    // dbss.collection("Verification")
                                    // .get()
                                    // .then(function(querySnapshot) {
                                    //     querySnapshot.forEach(function(doc) {
                                    //         // doc.data() is never undefined for query doc snapshots
                                    //         console.log(doc.id, " => ", doc.data());
                                    //     });
                                    // })
                                    // .catch(function(error) {
                                    //     console.log("Error getting documents: ", error);
                                    // });
                                   // var cityRef = db.collection('Verification').doc(user._id);

                                    dbss.collection("Verification").doc(String(id)).set({emailVerified:true}).then(function() {
                                       res.send({"success":true,"message":"success","data":{}});
                                        return false;
                                  });
                                  }
                                  else{
                                    res.send({"success":false,"message":"something went wrong","data":{}});
                                    return false;
                                  }
                                })
                            // })
                        }
                      })
                    } 
              else {
                res.send({"success":false,"message":"Code expired","data":{}});
                return false;
              }
            });
          //}
      //}); 
    }
}