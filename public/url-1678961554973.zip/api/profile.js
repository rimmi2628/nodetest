var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";

var ObjectId = mongo.Types.ObjectId;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
 function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }
  
  function makeid(length) {
     var result           = '';
     var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
     var charactersLength = characters.length;
     for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
     }
     return result;
  }

var mongodbutil = require( './mongodbutil' );


  exports.profile = async function(req, res) {
    // MongoClient.connect(url, function(err, db) {
      // if (err) throw err;
         // if (err) throw err;
         const {user_id} = req.body;
                  let dbo =  await mongodbutil.Get();
                  // var query = { _id: user_id };
                  dbo.collection('TBL_TRAINERS').aggregate([
                    { $match : { _id : ObjectId(user_id) } } ,
                    { 
                      $lookup:
                       {
                         from: 'TBL_TRAINER_DETAILS',
                         localField: '_id',
                         foreignField: 'user_id',
                         as: 'userdetails'
                       }
                     },
                     {
                        $lookup : 
                        {
                          from : 'TBL_SERVICES', 
                          localField: 'services.id', 
                          foreignField: '_id', 
                          as : 'services'
                        }
                       },
                     
                    ]).toArray(function(err, resr) {
                    if (err){
                      throw err;
                    }
                    else{
                      if(resr){
                        var data = JSON.parse(JSON.stringify(resr));
                        if(data[0]['userdetails'][0]['goverment_id'] != undefined){
                          var gov_id_verified = true;
                        }
                        else{
                          var gov_id_verified = false;
                        }
                        // console.log(data);return ;
                        if(data[0]['isBlocked'] == '1'){
                          res.send({"success":false,"message":"Unfortunately, you have been blocked by Hourful team. Please reach support for more information at info@hourful.io","data":{}});
                          return false;
                        }
                        dat={
                              "user_id":data[0]['_id'],
                              "email":data[0]['email'],
                              "bio":data[0]['userdetails'][0]['bio'],
                              "first_name":data[0]['userdetails'][0]['first_name'],
                              "last_name":data[0]['userdetails'][0]['last_name'],
                              "phone_number":data[0]['userdetails'][0]['phone'],
                              "phone_verified":data[0]['userdetails'][0]['phone_verified'],
                              "email_verified":data[0]['userdetails'][0]['email_verified'],
                              "goverment_id":data[0]['userdetails'][0]['goverment_id'],
                              "gov_id_verified":gov_id_verified,
                              "selfie":data[0]['userdetails'][0]['selfie'],
                              "image":data[0]['userdetails'][0]['image'],
                              "status":data[0]['status'],
                              "latitude":data[0]['latitude']?String(data[0]['latitude']):"",
                              "longitude":data[0]['longitude']?String(data[0]['longitude']):"",
                              "location":data[0]['location']?data[0]['location']:"",
                              "formatted_address":data[0]['formatted_address']?data[0]['formatted_address']:"",
                              "social_image":data[0]['userdetails'][0]['social_image'],
                              "price":data[0]['price']?data[0]['price']:"",
                              "services":data[0]['services'],
                              "type":data[0]['type']
                          }
    
                          if(data[0]['userdetails'][0]['email_verified'] ){
                              dat.email_verified = 1
                          }
                          else{
                            dat.email_verified = 0
                          }
                        // delete resr[0].password
                        // delete resr[0].__v
                        //console.log(data[0]['userdetails'])
                        res.send({"success":true,"message":"successfull","data":dat});
                        return false;
                      }
                      else{
                        res.send({"success":false,"message":"something went wrong","data":{}});
                        return false;
                      }
                    }
                    
                  });
    // })
 };