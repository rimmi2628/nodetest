const admin = require("firebase-admin");

const serviceAccount = require("./hourful-c541c-firebase-adminsdk-pibsy-db40df32b6.json");

var hourful = admin.initializeApp({
credential: admin.credential.cert(serviceAccount),
databaseURL: "https://hourful-c541c.firebaseio.com"
},'hourful');

module.exports.admin = hourful