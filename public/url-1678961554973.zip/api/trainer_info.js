var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var cors = require('cors')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());
var ObjectId = require('mongodb').ObjectID
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
var mongodbutil = require('./mongodbutil');
var sourceFile = require('./register.js');

exports.trainer_info = async function (req, res) {
	const {
		user_id,
		trainer_id,
	} = req.body;
	let errors = [];
	if (!user_id || !trainer_id) {
		res.send({
			"success": false,
			"message": "user_id and trainer_id are required.",
			"data": {}
		});
		return false;
	}
	let dbo = await mongodbutil.Get();
	dbo.collection('TBL_TRAINERS').aggregate([{
			$match: {
				_id: ObjectId(req.body.trainer_id)
			}
		},
		{
			$lookup: {
				from: 'TBL_TRAINER_DETAILS',
				localField: '_id',
				foreignField: 'user_id',
				as: 'userdetails'
			}
		},
		{
			$lookup: {
				from: 'TBL_SERVICES',
				localField: 'services.id',
				foreignField: '_id',
				as: 'services'
			}
		},
		
		{
			$lookup: {
				from: 'TBL_PUSH_TOKENS',
				localField: '_id',
				foreignField: 'trainer_id',
				as: 'trainer_push'
			}
		},


	]).toArray(function (err, resr) {
		if (err) {
			throw err;
		} else {
			if (resr) {
				dbo.collection('TBL_CLIENT_INFO').aggregate([{
				$match: {
						trainer_id: ObjectId(req.body.trainer_id),
						client_id: ObjectId(req.body.user_id),
						}
					},
					]).toArray(function (err, resr1) {
						if (err) {
							throw err;
						}
						else{
							if (resr1) {
								var data1 = JSON.parse(JSON.stringify(resr1));
								console.log(data1)
								if (data1.length == 0) {
									var bb = 0;
								}
								else{
									if (!data1[0]['isTrainerBlocked']) {
										var bb = 0
									}
									else{
										var bb = data1[0]['isTrainerBlocked'];
									}
									
								}
								var data = JSON.parse(JSON.stringify(resr));
								if (data[0]['userdetails'][0]['goverment_id'] != undefined) {
									var gov_id_verified = true;
								} else {
									var gov_id_verified = false;
								}
								if (!data[0]['address']) {
									data[0]['address'] = ''
								}
								var push_tokki = [];
								if (data[0].trainer_push.length != 0 ) {
									for (var kl = 0; kl < data[0].trainer_push.length; kl++) {
										push_tokki.push(data[0].trainer_push[kl].token)
									}
								}
								data = {
									"trainer_id": data[0]['_id'],
									"first_name": data[0]['userdetails'][0]['first_name'],
									"last_name": data[0]['userdetails'][0]['last_name'],
									"phone_number": data[0]['userdetails'][0]['phone_number'],
									"phone_verified": data[0]['userdetails'][0]['phone_verified'],
									"email_verified": data[0]['userdetails'][0]['email_verified'],
									"goverment_id": data[0]['userdetails'][0]['goverment_id'],
									"gov_id_verified": gov_id_verified,
									"selfie": data[0]['userdetails'][0]['selfie'],
									"image": data[0]['userdetails'][0]['image'],
									"status": data[0]['status'],
									"email": data[0]['email'],
									"social": data[0]['social_id'],
									"services": data[0]['services'],
									"bio": data[0]['userdetails'][0]['bio'],
									"timezone": data[0]['timezone'],
									"address": data[0]['address'],
									"timezone_str": data[0]['timezone_str'],
									"push_token": push_tokki,
									"isBlocked": bb

								}
								res.send({
									"success": true,
									"message": "Sucess",
									"data": data
								});
								return false;
							}
						}

				});
				
			} else {
				res.send({
					"success": false,
					"message": "something went wrong",
					"data": {}
				});
				return false;
			}
		}

	});


}