var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});

var sourceFile = require('./register.js');
// console.log(sourceFile)
var db = mongo.connect("mongodb://localhost:27017/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
   if(err){ console.log( err); }  
   else{ //console.log('Connected to ' + db, ' + ', response); 
    }  
});  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);

 exports.gyms = function(req, res) {
    const {latitude,longitude,min_price,max_price,radius,date,user_id,equipments} = req.body;
    if(!latitude || !longitude){
      res.send({"success":false,"message":"Please enter all fields","data":[]});
      return false;
    }
    if(radius == undefined){
      var rad = '16000';
    }
    else{
      var rad = radius
    }
    if(min_price == undefined){
      var min = 0;
    }
    else{
      var min = min_price;
    }
    if(max_price == undefined){
      var max =250;
    }
    else{
      var max =max_price;
    }
    var equipdatefilter = {};
    if(equipments != undefined){
      var equipArr=[]

      equip = req.body.equipments.split(',')
      for (let f = 0; f < equip.length; f++) {
        equipArr.push(ObjectId(equip[f]))
      }
      // varequipdatefilter
      equipdatefilter.equipments_id = { $in: equipArr }
      var eqp = { "equipments_id": { $in: equipArr } };
    }
    else{
      var equipArr=[];
      //equipdatefilter.equipments_id = {}
      var eqp = { };
    }
  // if(date != undefined){
  //     var equipArr=[]
  //     for (let f = 0; f < equip.length; f++) {
  //       equipArr.push(ObjectId(equip[f]))
  //     }
  //     //var eqp = { "equipments_id": { $in: equipArr } };
  //     equipdatefilter.equipments_id = {}
  //   }
  //   else{
  //     var equipArr=[];
  //     var eqp = { };
  // }
    // console.log(eqp)
    
    // if(date == undefined){
    //   var date ="12312312312";
    // }
    // if(date == undefined){
    //   var date ="12312312312";
    // }
    //  console.log(min);
    //   console.log(rad);
    //  return;
    var arrayElemAt = [];
    MongoClient.connect(url, function(err, db) {
      if (err) throw err;
      var dbo = db.db("gymtraining");


      if(date != undefined){

        dbo.collection("TBL_GYM_AVAILABILITY").find({"date":date}).toArray(function(err, result) {
            if (err){
                res.send({"success":false,"message":"something went wrong","data":[]});
                return false;
            }
            else{
                 console.log("result114",result.length)
                if(result.length > 0){
                    // dbo.collection("TBL_AVAILABILITY_SLOTS").find({"gym_availability_id":ObjectId(result[0]['_id'])}).toArray(function(err, ress) {
                    //     if (err){
                    //         res.send({"success":false,"message":"something went wrong","data":[]});
                    //         return false;
                    //     }
                    //     else{
                    //         console.log("ress",ress)
                    //     } 
                        
                    //   });
                    // console.log(result[0])
                    for(var i =0 ;i<result.length;i++){
                      arrayElemAt.push(ObjectId(result[i].gym_id))
                    }
                    equipdatefilter._id = { $in: arrayElemAt }
                    dbo.collection('TBL_GYMS').aggregate([
                    { 

                      $geoNear: {
                      near: { type: "Point", coordinates: [  parseFloat(longitude),
                      parseFloat(latitude) ] },
                      spherical: true,
                      maxDistance: parseInt(rad) * 1600,
                      // distanceMultiplier : 0.001,

                      distanceField: "dist.calculated",
                      query: { "price": { "$gte": parseInt(min), "$lte":parseInt(max) }},
                      }
                    },
                    {
                      $lookup : 
                      {
                        from : 'TBL_EQUIPMENTS', 
                        localField: 'equipments_id', 
                        foreignField: '_id', 
                        as : 'equipments_ids'
                      }
                    },
                    {
                      $lookup : 
                      {
                        from : 'TBL_GYM_IMAGES', 
                        localField: 'images_ids.id', 
                        foreignField: '_id', 
                        as : 'images_ids'
                      }
                    },

                    {
                      $lookup : 
                      {
                        from : 'TBL_FAVORITES', 
                        localField: '_id', 
                        foreignField: 'gym_id', 
                        as : 'favorites'
                      }
                    },
                    {
                      "$addFields": {
                        "favorites": {
                          "$arrayElemAt": [
                            {
                              "$filter": {
                                "input": "$favorites",
                                "as": "comp",
                                "cond": {
                                "$eq": [ "$$comp.trainer_id", ObjectId(user_id) ]
                                }
                              }
                            }, 0
                          ]
                        },
                      }

                    },
                    { $match : equipdatefilter } ,
                    ]).toArray(function(err, resr) {
                    if (err){
                      throw err;
                    }
                    else{
                      if(resr){

                      for(var i = 0;i<resr.length;i++){
                        if(resr[i].favorites !=undefined){
                          delete resr[i].equipments_id
                          resr[i].favorite = true;
                          resr[i].time_zone = "US/Eastern";
                        }
                        else{
                          delete resr[i].equipments_id
                          resr[i].favorite = false;
                          resr[i].time_zone = "US/Eastern";
                        }
                      }
                      var data = JSON.parse(JSON.stringify(resr));
                        res.send({"success":true,"message":"success","data":data});
                        return false;
                      }
                      else{
                        res.send({"success":false,"message":"something went wrong","data":[]});
                        return false;
                      }
                    }

                    });
                    // console.log("arrayElemAt",arrayElemAt);
                }else{
                    var day = new Date(date);
                    day = day.getDay();
                    console.log("day",day)
                    dbo.collection("TBL_GYM_AVAILABILITY").find({"day":String(day),"repeat":"1"}).toArray(function(err, result) {
                      if (err){
                          res.send({"success":false,"message":"something went wrong","data":[]});
                          return false;
                      }
                    else{
                      console.log("141",result)
                            for(var i =0 ;i<result.length;i++){
                              arrayElemAt.push(ObjectId(result[i].gym_id))
                            }
                    }
                            console.log("arrayElemAt",arrayElemAt);
                            equipdatefilter._id = { $in: arrayElemAt }
                            console.log(equipdatefilter)
                              dbo.collection('TBL_GYMS').aggregate([
                              { 

                                $geoNear: {
                                near: { type: "Point", coordinates: [  parseFloat(longitude),
                                parseFloat(latitude) ] },
                                spherical: true,
                                maxDistance: parseInt(rad) * 1600,
                                // distanceMultiplier : 0.001,

                                distanceField: "dist.calculated",
                                query: { "price": { "$gte": parseInt(min), "$lte":parseInt(max) }},
                                }
                              },
                              {
                              $lookup : 
                              {
                              from : 'TBL_EQUIPMENTS', 
                              localField: 'equipments_id', 
                              foreignField: '_id', 
                              as : 'equipments_ids'
                              }
                              },
                              {
                              $lookup : 
                              {
                              from : 'TBL_GYM_IMAGES', 
                              localField: 'images_ids.id', 
                              foreignField: '_id', 
                              as : 'images_ids'
                              }
                              },

                              {
                              $lookup : 
                              {
                              from : 'TBL_FAVORITES', 
                              localField: '_id', 
                              foreignField: 'gym_id', 
                              as : 'favorites'
                              }
                              },
                              {
                              "$addFields": {
                              "favorites": {
                              "$arrayElemAt": [
                              {
                                  "$filter": {
                                      "input": "$favorites",
                                      "as": "comp",
                                      "cond": {
                                          "$eq": [ "$$comp.trainer_id", ObjectId(user_id) ]
                                      }
                                  }
                              }, 0
                              ]
                              },
                              }

                              },
                              { $match : equipdatefilter } ,
                              ]).toArray(function(err, resr) {
                              if (err){
                              throw err;
                              }
                              else{
                              if(resr){

                              for(var i = 0;i<resr.length;i++){
                              if(resr[i].favorites !=undefined){
                              delete resr[i].equipments_id
                              resr[i].favorite = true;
                              resr[i].time_zone = "US/Eastern";
                              }
                              else{
                              delete resr[i].equipments_id
                              resr[i].favorite = false;
                              resr[i].time_zone = "US/Eastern";
                              }
                              }
                              var data = JSON.parse(JSON.stringify(resr));
                              res.send({"success":true,"message":"success","data":data});
                              return false;
                              }
                              else{
                              res.send({"success":false,"message":"something went wrong","data":[]});
                              return false;
                              }
                              }

                              });
                  })

                }

                
                
                
            } 
            // dbo.close();
          });
      } 
      else{
        dbo.collection('TBL_GYMS').aggregate([



        { 

        $geoNear: {
        near: { type: "Point", coordinates: [  parseFloat(longitude),
        parseFloat(latitude) ] },
        spherical: true,
        maxDistance: parseInt(rad) * 1600,
        // distanceMultiplier : 0.001,

        distanceField: "dist.calculated",
        query: { "price": { "$gte": parseInt(min), "$lte":parseInt(max) }},
        }
        },
        {
        $lookup : 
        {
        from : 'TBL_EQUIPMENTS', 
        localField: 'equipments_id', 
        foreignField: '_id', 
        as : 'equipments_ids'
        }
        },
        {
        $lookup : 
        {
        from : 'TBL_GYM_IMAGES', 
        localField: 'images_ids.id', 
        foreignField: '_id', 
        as : 'images_ids'
        }
        },

        {
        $lookup : 
        {
        from : 'TBL_FAVORITES', 
        localField: '_id', 
        foreignField: 'gym_id', 
        as : 'favorites'
        }
        },
        {
        "$addFields": {
        "favorites": {
        "$arrayElemAt": [
        {
            "$filter": {
                "input": "$favorites",
                "as": "comp",
                "cond": {
                    "$eq": [ "$$comp.trainer_id", ObjectId(user_id) ]
                }
            }
        }, 0
        ]
        },
        }

        },
        { $match : equipdatefilter } ,
        ]).toArray(function(err, resr) {
        if (err){
        throw err;
        }
        else{
          console.log("equipdatefilter",equipdatefilter)
        if(resr){

        for(var i = 0;i<resr.length;i++){
        if(resr[i].favorites !=undefined){
        delete resr[i].equipments_id
        resr[i].favorite = true;
        resr[i].time_zone = "US/Eastern";
        }
        else{
        delete resr[i].equipments_id
        resr[i].favorite = false;
        resr[i].time_zone = "US/Eastern";
        }
        }
        var data = JSON.parse(JSON.stringify(resr));
        res.send({"success":true,"message":"success","data":data});
        return false;
        }
        else{
        res.send({"success":false,"message":"something went wrong","data":[]});
        return false;
        }
        }

        });
      }
      console.log("arrayElemAt",arrayElemAt)
      return;
      // var query = { _id: user_id };
      // dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
 
  })

}


