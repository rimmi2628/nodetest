var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";
 
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);


var mongodbutil = require( './mongodbutil' );

 exports.block_client = async function(req, res) {
    const {client_id,trainer_id,type} = req.body;
    if(!client_id ){
      res.send({"success":false,"message":"client_id empty","data":{}});
      return false;
    }
    else if(!trainer_id){
      res.send({"success":false,"message":"trainer_id empty","data":{}});
      return false;
    }
    else if(!type){
      res.send({"success":false,"message":"type empty","data":{}}); // 0->unblocked,1->blocked
      return false;
    }
  
        let dbo =  await mongodbutil.Get();
        var query = {
          'client_id': ObjectId(client_id),
          'trainer_id': ObjectId(trainer_id),
        };

        var update = {
          $set: {
            isBlocked: type
          }
        };
        var options = {
          upsert: false
        };
        dbo.collection('TBL_CLIENT_INFO').findOneAndUpdate(query, update, options, function (err, resv) {
          if (err) {
            throw err;
          } else {
              if(resv){
                    res.send({"success":true,"message":"We have taken your request. Our team will look into this."});
                    return false;
                }
                else{
                    res.send({"success":false,"message":"something went wrong"});
                    return false;
                }
          }
        });
  }
  exports.report_client = async function(req, res) {
    const {trainer_id,client_id,type} = req.body;
    if(!trainer_id ){
      res.send({"success":false,"message":"trainer_id empty","data":{}});
      return false;
    }
    else if(!client_id){
      res.send({"success":false,"message":"client_id empty","data":{}});
      return false;
    }
  
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    //     if (err) throw err;
        let dbo =  await mongodbutil.Get();
        data = {"user_id":ObjectId(trainer_id),"client_id":ObjectId(client_id),"type":0,'created_at':getCurrentTime(),'updated_at':getCurrentTime()}
        
         dbo.collection("TBL_REPORT").insertOne(data, function(err,resr){
            if (err){
                throw err;
            }
            else{
                if(resr){

                    res.send({"success":true,"message":"We have taken your request. Our team will look into this."});
                    return false;
                }
                else{
                    res.send({"success":false,"message":"something went wrong","data":[]});
                    return false;
                }
            }
        }); 
    //});
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

