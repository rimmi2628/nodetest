var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



var sourceFile = require('./register.js');

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);

var mongodbutil = require( './mongodbutil' );

 exports.favorites = async function(req, res) {
    const {user_id,gym_id} = req.body;
    if(!user_id ){
      res.send({"success":false,"message":"user_id empty","data":{}});
      return false;
    }
    else if(!gym_id){
      res.send({"success":false,"message":"gym_id empty","data":{}});
      return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
      let dbo =  await mongodbutil.Get();
        // if (err) throw err;
        // var dbo = db.db("gymtraining");
        if(req.body.type == 0){



                dbo.collection("TBL_TRAINERS").find({"_id":ObjectId(user_id) } ).toArray(function(err, ress) {
                  if (err){
                      res.send({"success":false,"message":"something went wrong","data":[]});
                      return false;
                  }
                  else{
                      // console.log(ress[0].favorites);
                      // return
                       var favorites=[];
                      if(ress[0].favorites == undefined){
                        favorites.push(ObjectId(gym_id))
                      }
                      else{
                        favorites = ress[0].favorites
                        favorites.push(ObjectId(gym_id));
                      }
                      data = {"trainer_id":ObjectId(user_id),"gym_id":ObjectId(gym_id),'created_at':getCurrentTime(),'updated_at':getCurrentTime()}

                      dbo.collection("TBL_FAVORITES").insertOne(data, function(err,resr){
                          if (err){
                            throw err;
                          }
                        else{
                          if(resr){
                              dbo.collection("TBL_TRAINERS").updateOne({_id:ObjectId(ress[0]._id)},{$set:{favorites:favorites }}, function(err, resv) {
                                if (err){
                                  throw err;
                                }
                                else{
                                  if(resv){
                                    res.send({"success":true,"msg":"We have marked this Gym as your favorite."});
                                    return false; 
                                  }
                                  else{
                                    res.send({"success":false,"message":"something went wrong","data":[]});
                                    return false;
                                  }
                                }
                              }); 
                          }
                          else{
                            res.send({"success":false,"message":"something went wrong","data":[]});
                            return false;
                          }
                        }
                      }); 
                      
                  }
                 //})
            // data = {"trainer_id":ObjectId(user_id),"gym_id":ObjectId(gym_id),'created_at':getCurrentTime(),'updated_at':getCurrentTime()}
  
        })
      }
        else{
            var myquery = {"trainer_id":ObjectId(user_id),"gym_id":ObjectId(gym_id)};
            dbo.collection("TBL_FAVORITES").deleteOne(myquery, function(err, obj) {
                if (err){
                    throw err;
                }
                else{
                  dbo.collection("TBL_TRAINERS").find({"_id":ObjectId(user_id) } ).toArray(function(err, ress) {
                  if (err){
                      res.send({"success":false,"message":"something went wrong","data":[]});
                      return false;
                  }
                  else{
                    console.log("adsdasda",ress[0].favorites)
                    var filter =[];
                    for(var i=0;i<ress[0].favorites.length;i++){
                      if(ress[0].favorites[i] != gym_id){
                        filter.push(ress[0].favorites[i])
                      }
                    }
                    console.log("filter",filter)
                    dbo.collection("TBL_TRAINERS").updateOne({_id:ObjectId(ress[0]._id)},{$set:{favorites:filter }}, function(err, resv) {
                    if (err){
                      throw err;
                    }
                    else{
                      if(resv){
                        res.send({"success":true,"msg":"We have unmarked your favorite."});
                        return false; 
                      }
                      else{
                        res.send({"success":false,"message":"something went wrong","data":[]});
                        return false;
                      }
                    }
                  }); 
     
                       
                       
                    // db.close();
                  }
                })
                   
                }
            });
        }
        
    } 
  Array.prototype.remove = function() {
    var what, a = arguments, L = a.length, ax;
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1);
        }
    }
    return this;
}; 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }