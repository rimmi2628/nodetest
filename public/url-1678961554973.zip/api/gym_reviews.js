var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


 
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.gym_reviews = async function(req, res) {
    const {gym_id} = req.body;
    if(!gym_id){
      res.send({"success":false,"message":"Please enter all fields","data":{}});
      return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
        // if (err) throw err;
          let dbo =  await mongodbutil.Get();
          var gymID =  ObjectId(gym_id)
      dbo.collection('TBL_FEEDBACK').aggregate([
       { $sort: { created_at: -1} },
        { $match : { gym_id : gymID } } ,

        { 

          $lookup:
           {
             from: 'TBL_BADGES',
             localField: 'badges.id',
             foreignField: '_id',
             as: 'badges'
           }

         },
         { 

          $lookup:
           {
             from: 'TBL_GYMS',
             localField: 'gym_id',
             foreignField: '_id',
             as: 'gyms'
           }

         },
         {
        "$project": {
          "_id": 1,
          // "user_id": 1,
          "rating": 1,
          "comment": 1,
          "badges": 1,
          "created_at":1,
          "updated_at":1,
         

        }
      },

      ]).toArray(function(err, resr) {
        if (err){
          res.send({"success":false,"message":"something went wrong","data":{}});
          return false;
        }
        else{
          var name = [];
          var totalReview = 0;
          var averagereview = 0;
          for(var i=0;i<resr.length;i++){
            averagereview = averagereview + parseInt(resr[i].rating) ;
            resr[i].date_time = resr[i].created_at;
            for(var j =0;j<resr[i].badges.length;j++){
              if(!name.includes(resr[i].badges[j].name)){
                name.push(resr[i].badges[j].name);  
              }
              
            }
          }
          var filteredArray = name.filter(function(item, pos){
            return name.indexOf(item)== pos; 
          });
          // console.log(resr[1].gyms.length)
         
          // console.log("averagereview",averagereview)
          // console.log("averagereview2", parseInt(resr.length))
          var avg_rating = '0';
          if(parseInt(averagereview) > 0 ){
            avg_rating = String((parseInt(averagereview) / parseInt(resr.length)).toFixed(2));
          }
          var feedBackDetails = {
            avg_rating : avg_rating,
            ratings : String(resr.length),
            tags : name,
            reviews:resr
          }
          
          res.send({"success":true,"message":"success","data":feedBackDetails});
          return false;
        }    
    }); 
  // })
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

