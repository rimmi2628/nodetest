'use strict';
//hourfull
// module.exports.apiLoginKey = '63sdZqT5s8';
// module.exports.transactionKey = '9Bj9Pw4z2967vJac';

/*   acpnayak   */
module.exports.apiLoginKey = '2Qe443Dqm';
module.exports.transactionKey = '7868pLtuN75dV2Yz';