var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
var ApiContracts = require('authorizenet').APIContracts;
var ApiControllers = require('authorizenet').APIControllers;
var utils = require('./utils.js');
const Utility = require("../helper/Constant")
var constants = require('./constants.js');
var debit_bank = require('./debitBank.js');

// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
const stripe = require('stripe')(Utility.STRIPE_KEY);
// const stripe = require('stripe')('sk_test_1tqRe2GJZqKbCChbIZvB4GKs');
// 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
var nodemailer = require('nodemailer');
// var emailTemp = require('../emails');
var transporter = nodemailer.createTransport({
  service: Utility.EMAIL_SERVICE,
  auth: {
    user: Utility.EMAIL,
    pass: Utility.EMAIL_PASSWORD
  }
});

const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json())


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

// mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');

 /*  
 0 - Pending
	 1 - Accepted
	 2 - Auto Accepted
	 3 - Cancelled By Trainer 
	 4 - Rejected
	 5 - Cancelled By Client
   6- completed
*/
var CronJob = require('cron').CronJob;

async function cron(req, res) {
  // var job = new CronJob('0 * * * *', async function() {
  // var job = new CronJob('0 * * * * *', async function() {
  //run every hour
  var job = new CronJob('0 * * * * ', async function () {
    console.log("____________________cron started_________________")

    let dbo = await mongodbutil.Get();
    var time = getCurrentTime() - 3600
    console.log("time-session-cron", time)
    // return false
    dbo.collection("TBL_SESSIONS").find({
      utc: {
        $lt: time.toString()
      },
      // trainer_id: ObjectId("5fe9c04c869f4727171c2f4c"),
      status: {
        $in: [1, 2]
      }
    }).toArray(async function (err, result) {


      const posts = result;
      posts.forEach(post => {

        // console.log(post)
        // return

        var current_client = post.client_id
        var trainer_id = post.trainer_id
        console.log("client _id ---------------->", current_client)
        //return
        // dbo.collection('TBL_CLIENTS').aggregate([{
        //   $match: {
        //     _id: ObjectId(current_client),

        //   }
        // },
        // {
        //   $lookup: {
        //     from: 'TBL_CARDS',
        //     localField: '_id',
        //     foreignField: 'trainer_id',
        //     as: 'payment_info'
        //   }
        // },
        // ]).toArray(async function (err, resr) {
        //   if (err) {
        //     throw err;
        //   } else {
        //     if (resr) {
        //       var data = JSON.parse(JSON.stringify(resr));
        //       console.log('--------client------------>', data)
        //       // return
        //       var NotiObj = {
        //         trainer_id: post.trainer_id,
        //         client_id: post.client_id,
        //         session_id: post._id,
        //         status: 5,
        //         created_at: getCurrentTime(),
        //         updated: getCurrentTime()
        //       };
        //       dbo.collection("TBL_CLIENT_TRAINER_NOTIFICATIONS").insertOne(NotiObj, function (err, resr) {

        //       });

        //       console.log('post-------- ONE')
        //       let insertHistory = {
        //         session_id: ObjectId(post._id),
        //         client_id: post.client_id,
        //         trainer_id: post.trainer_id,
        //         created_at: getCurrentTime(),
        //         updated: getCurrentTime()
        //       }
        //       dbo.collection('TBL_SESSION_HISTORY').insertOne(insertHistory, async function (err, resv) {
        //         if (err) {
        //           throw err;
        //         } else {
        //           if (data[0].payment_info) {
        //             var result_pay = data[0].payment_info.filter(p => p.primary == "1")
        //             // console.log(result_pay)
        //             if (!result_pay || result_pay.length == 0) {
        //               result_pay = data[0].payment_info
        //             }

        //             if (result_pay[0].payment_type == '1') {
        //               // return false
        //               var data_bank = {
        //                 'routing_number': result_pay[0].routing_number,
        //                 'account_number': result_pay[0].account_number,
        //                 'account_type': result_pay[0].account_type,
        //                 'amount': Number(data[0].per_session_fee),
        //                 'user_id': current_client,
        //                 "trainer_id": trainer_id,
        //                 "session_id": post._id
        //               }
        //               // console.log(charge_bank(data_bank))
        //               var debit_stat = await debit_bank.debitBank_fn(data_bank)
        //               console.log(debit_stat)
        //               return false

        //             } else if (result_pay[0].payment_type == '0' && post.transaction_id) {
        //               var charge = await stripe.charges.create({
        //                 amount: Number(data[0].per_session_fee) * 100,
        //                 currency: 'USD',
        //                 customer: post.transaction_id,
        //                 description: 'Charge for customer',
        //               });
        //               console.log(charge)
        //               if (charge.status == 'succeeded') {
        //                 var payment_id = charge.id
        //                 var note = 'Payment succeeded'
        //                 var paymentObj = {
        //                   'trainer_id': ObjectId(trainer_id),
        //                   'client_id': current_client,
        //                   'amount': Number(data[0].per_session_fee),
        //                   'notes_p': note,
        //                   'created_at': getCurrentTime(),
        //                   'status': 1
        //                 }
        //                 dbo.collection("TBL_SESSION_PAYMENTS").insertOne(paymentObj, function (err, resvP) {
        //                 })
        //               } else {
        //                 var payment_id = charge.status
        //                 var note = 'Payment Failed'
        //                 var paymentObj = {
        //                   'trainer_id': ObjectId(trainer_id),
        //                   'client_id': current_client,
        //                   'amount': Number(data[0].per_session_fee),
        //                   'notes_p': note,
        //                   'created_at': getCurrentTime(),
        //                   'status': 0
        //                 }
        //                 dbo.collection("TBL_SESSION_PAYMENTS").insertOne(paymentObj, function (err, resvP) {
        //                 })
        //               }

        //               dbo.collection("TBL_SESSIONS").findOneAndUpdate({
        //                 _id: ObjectId(post._id)
        //               }, {
        //                 $set: {
        //                   payment_id: payment_id,
        //                   note: note,
        //                   status: 5
        //                 }
        //               }, async function (err, result2) {

        //               })
        //             }






        //           }
        //         }
        //       })




        //     }
        //   }
        // });
        if (post.session_type == 0) {
          let paymentObj = {
            session_id: ObjectId(post._id),
            client_id: ObjectId(post.client_id),
            trainer_id: ObjectId(post.trainer_id),
            amount: post.price ? parseInt(post.price) : 0,
            created_at: getCurrentTime(),
            updated_at: getCurrentTime(),
            is_punch_card:0
          }

          let obj = {
            client_id: ObjectId(post.client_id),
            trainer_id: ObjectId(post.trainer_id),
            session_id: ObjectId(post._id)
          }
          dbo.collection('TBL_TRAINER_PAYMENTS').find(obj)
            .toArray(function (payment_err, isPaymentExist) {
              if (payment_err) {
                throw payment_err
              }
              console.log('---payment length----->', isPaymentExist.length)
              if (isPaymentExist.length > 0) {
                dbo.collection("TBL_TRAINER_PAYMENTS").updateOne(obj, { $inc: { amount: post.price } }, function (updateErr, response) {
                  if (updateErr) {
                    throw updateErr
                  }
                })

              }
              else {
                dbo.collection("TBL_TRAINER_PAYMENTS").updateOne(obj, paymentObj,{upsert:true},function (inserErr, response) {
                  if (inserErr) {
                    throw inserErr
                  }
                })
              }

            })


        }
        //add notification into a new table 
        dbo.collection("TBL_CLIENT_TRAINER_NOTIFICATIONS").updateOne({
          client_id: post.client_id,
          session_id: post._id,
          trainer_id: post.trainer_id,
        }, {
          client_id: post.client_id,
          session_id: post._id,
          trainer_id: post.trainer_id,
          created_at: getCurrentTime(),
          updated_at: getCurrentTime()
        }, { upsert: true }, function (noti_err, noti_insert) {
          if (noti_err)
            throw noti_err
        })


        dbo.collection('TBL_SESSIONS').updateOne({ _id: ObjectId(post._id) },
          { $set: { status: 6, updated_at: getCurrentTime() } }, function (err, session_update) {
            console.log(session_update.modifiedCount)

          });



        //send email
        //   var mailOptions = {
        //     from: 'info@hourful.io',
        //     to: req.body.email,
        //     subject: 'HourfulApp',
        //     //text: `Hi `+user.first_name+`, thank you for registering with us.
        //             //Please click this link below to verify your mail <br> `+verifyEmailId
        //     html:'<!doctype html><html lang="en"> <head> <meta charset="utf-8"> <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> <meta name="viewport" content="width=device-width, initial-scale=1.0"/> <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous"> <title>Verify</title> <style>/*body{font-family: "SF Pro Display";}.verify-main-top{max-width: 1140px;margin: auto;width:70%;}.verify{background:#fff3ee;height:100%;padding:60px 0;}.verify-logo{text-align:center;margin-bottom:30px;}.verify-logo img{width:17%;}.verify-main{background:#fff;padding:50px;border-radius:30px;font-weight:600;}.verify-main h2{font-size:35px;margin-bottom:50px;}.verify-main h3,h4,h5,h6{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;line-height:40px;}.verify-main p{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;margin-top:70px;line-height:50px;}.verify-btn{text-align:center;}a.verify-btn{font-size:20px;color:#fff !important;background:#ff885b;font-weight:400;border-radius: 50px;padding:18px 55px;display:inline-block;text-decoration:none;}.verify-bottom{text-align:center;}.verify-bottom ul{display:inline-block;margin:40px 0;}.verify-bottom li{display:inline-block;margin:0 15px;}.verify-bottom p{font-size:22px;color:#232323;font-weight:400;padding:0 60px;}.bottom-text p{font-size:22px;color:#232323;font-weight:400;margin:50px 0 0;}.bottom-text h5{background:none;padding:0;color:#0066cb!important;margin:5px 0 0;}.verify-main h6{margin-top:30px;}*/@media only screen and (max-width: 1599px){.verify-main-top{width:65%;}.verify-main h2{margin-top:0;}.verify-bottom li img{width: 60px;}.verify-bottom li{margin: 0 10px;}}@media only screen and (max-width: 1366px){.verify-main h2{font-size: 30px;font-weight:500;margin-bottom:35px;}.verify-main h3, h4, h5, h6{font-size: 19px;line-height:22px;}a.verify-btn{padding:15px 50px;}.verify{background: #fff3ee; height: 100%; padding: 40px 0;}.verify-main p{font-size: 19px; color: #353535; font-weight: 400; margin-bottom: 0; margin-top: 48px; line-height: 22px;}.verify-main{padding:35px;}.verify-bottom li img{width: 55px;}.bottom-text p{font-size: 19px; color: #232323; font-weight: 400; margin: 26px 0 0;}ul li img{width: 55px !important;}}@media only screen and (max-width:767px){h3, h5, h4, h6, h2 , p{font-size: 1.1em !important; margin-bottom: 18px !important; margin-top: 20px !important; line-height: 26px !important; padding:0px !important; word-break: break-all; white-space: pre-line;}ul li a img{width: 40px !important;}div{width: 100% !important;}div > p > a > img{width: 48% !important;}h6 > a{padding:18px 35px !important;font-size:18px !important}}</style> </head> <body style="font-family: "SF Pro Display";box-sizing: border-box; margin:0px; padding:0px;"> <main class="verify" style="background:#fff3ee;height:100%;padding:60px 0;"> <div class="verify-main-top" style="margin: auto;width:100%;background:#fff3ee;padding:20px; box-sizing: border-box;" bgcolor="#fff3ee"> <div class="container"> <div class="verify-logo" style="text-align:center;margin-bottom:30px;"> <p><a href="http://hourful.io/images/verify-logo.png"><img src="http://hourful.io/images/verify-logo.png" style="width:17%;"></a></p></div><div class="verify-main" style="background:#fff;padding:30px;border-radius:30px;font-weight:600;max-width: 1300px; margin: 10px auto; width: 70%;box-sizing: border-box;"> <h2 style="font-size:1.4em;margin-bottom:36px;">Forgot your password?</h2> <h3 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;line-height:36px;">Hi '+doc.value.first_name+',</h3> <h5 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;line-height:36px;">Please click the button to reset your password.</h5> <h6><a href="http://hourful.io/gymapp/#/forgot-password-trainer?id='+changepasswordId+'" class="verify-btn" style="font-size:20px;color:#fff !important;background:#ff885b;font-weight:400;border-radius: 50px;padding:18px 55px;display:inline-block;text-decoration:none;">Reset Password</a></h6> <div class="bottom-text"><p style="font-size:1.3em;color:#232323;font-weight:400;margin:50px 0 0;">If you have trouble paste this link into your web browser</p><h5 style="background:none;padding:0;color:#0066cb!important;margin:5px 0 0;font-size: 1.3em; font-weight: 500; line-height: 36px; word-break: break-all;">http://hourful.io/gymapp/#/forgot-password-trainer?id='+changepasswordId+'</h5> </div><h6 style="margin-top:30px;font-size:1.3em;color:#353535; text-align:left;font-weight:400;margin-bottom:22px;line-height:36px;">If you did not request for password reset, then please ignore email or contact us at<br>info@hourful.com</h6> <p style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;margin-top:50px;line-height:50px;">- The Hourful Team</p><div class="verify-btn"> </div></div><div class="verify-bottom" style="text-align:center;"> <ul style="display:inline-block;margin:40px 0;padding: 0 20px"> <li style="display:inline-block;margin:0 15px;"> <a href="https://twitter.com/HourfulApp"><img src="http://hourful.io/images/bottom-icon1.png" alt="icon"></a> </li><li style="display:inline-block;margin:0 15px;"> <a href="https://www.instagram.com/HourfulApp"><img src="http://hourful.io/images/bottom-icon4.png" alt="icon"></a> </li><li style="display:inline-block;margin:0 15px;"> <a href="https://www.facebook.com/hourfulapp"><img src="http://hourful.io/images/bottom-icon3.png" alt="icon"></a> </li></ul> </div></div></div></main> </body></html>'

        //   };
        // transporter.sendMail(mailOptions, function(error, info){
        //   if (error) {  
        //    console.log(error)
        //   } 
        // });



      })

    })
  }, null, true, 'America/Los_Angeles');
  job.start();

}

cron()


function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}

function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}