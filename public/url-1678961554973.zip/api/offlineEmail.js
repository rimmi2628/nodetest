var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
const Utill = require('../helper/Constant')

var cors = require('cors')

var emailTemp = require('./emails');

const bcrypt = require('bcrypt')
var app = express() ;
const { admin } = require('./firebaseConfig.js');
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
 
var mongodbutil = require( './mongodbutil' );
 exports.email = async function(req, res) {
    const {gym_id,type,trainer_id,message} = req.body;
    if(!trainer_id ){
      res.send({"success":false,"message":"trainer_id empty","data":{}});
      return false;
    }
    else if(!gym_id ){
      res.send({"success":false,"message":"gym_id empty","data":{}});
      return false;
    }
    else if(!type){
      res.send({"success":false,"message":"gym_id empty","data":{}});
      return false;
    }
    else if(!message){
      res.send({"success":false,"message":"message empty","data":{}});
      return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    // if (err) throw err;
    let dbo =  await mongodbutil.Get();
    
      dbo.collection('TBL_TRAINERS').find({ _id: ObjectId(trainer_id) })
      .toArray(function (err, data) {
        if (err) {
          throw err;
        } else {
           dbo.collection('TBL_TRAINER_DETAILS').find({ user_id: ObjectId(trainer_id) })
              .toArray(function (err, dataT) {
                if (err) {
                  throw err;
                } else { 
                  console.log(dataT)
                  dbo.collection('TBL_GYMS')
                    .find({ _id: ObjectId(gym_id) })
                    .toArray(function (err, dataGy) {
                      if (err) {
                        throw err;
                      } else {
                        if (dataGy['0'].space_owner != '') {
                          dbo.collection('TBL_SPACE_OWNER')
                          .find({ _id: dataGy['0'].space_owner })
                          .toArray(function (err, dataO) {
                            if (err) {
                              throw err;
                            } else {
                              if (type == 1) {
                                var stuff =[];
                                stuff['email'] = data[0].email
                                stuff['name'] = dataGy[0].name
                                stuff['message'] = message
                                stuff['subject'] = ''+dataGy[0].name+' sent you a message.'
                                if (dataGy[0].logo.indexOf("http") != -1 || dataGy[0].logo.indexOf("https") != -1) {
                                    stuff['chat']= Utill.IMAGE_BASE_URL+'/redirect.html?type=chat&gid='+gym_id+'&logo='+dataGy[0].logo+'&name='+ encodeURI(dataGy[0].name) +'&space_owner='+dataO[0]._id+''
                                }
                                else{
                                    var logo = dataGy[0].logo.replace("uploads/images/", "");
                                    stuff['chat']= Utill.IMAGE_BASE_URL+'redirect.html?type=chat&gid='+gym_id+'&logo='+logo+'&name='+ encodeURI(dataGy[0].name) +'&space_owner='+dataO[0]._id+''
                                }
                              }
                              else{
                                var stuff=[];
                                stuff['email'] = dataO[0].email
                                stuff['name'] = dataT[0].first_name+ " " + dataT[0].last_name
                                stuff['message'] = message
                                stuff['subject'] = ''+dataT[0].first_name+' '+ dataT[0].last_name +' sent you a message about your gym space.'
                                stuff['chat'] = Utill.IMAGE_BASE_URL+'gymapp/#/?gymId='+gym_id+'&trainerid='+trainer_id+'&message=true'

                              }
                              console.log(stuff)
                               // if (dataOO[0].email == 'nayakacp@gmail.com' || dataOO[0].email == 'nayakacp@gmail.com') {
                              var email = emailTemp.bookingEmails.notifyViaEmail(stuff)
                              // console.log(email)
                              res.send({
                                  "success": true,
                                  "message": "Email Sent",
                                  // "data": stuff
                                  
                              });
                              // }
                            }
                          })
                        }
                        
                      }
                    })
                  
                  }
              })
           }
        })
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

  function formatDateTime(datetime){
      const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
      const d = new Date(datetime*1000);
      var month =  monthNames[d.getMonth()];
      var date = d.getDate();
      var year = d.getFullYear();

      var hours = d.getHours();
      var minutes = d.getMinutes();
      var ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0'+minutes : minutes;
      var strTime = hours + ':' + minutes + ' ' + ampm;
    // February 10, 2020 at 10:15 AM
      return month+" "+date+","+year+" at "+strTime
    }
    function tConvert (time) {
    // Check correct time format and split into components
    time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join (''); // return adjusted time or original string
  }

 