var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";




var sourceFile = require('./register.js');
// console.log(sourceFile)
 
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);


var mongodbutil = require( './mongodbutil' );

 exports.report_gym = async function(req, res) {
    const {user_id,gym_id,type} = req.body;
    if(!user_id ){
      res.send({"success":false,"message":"user_id empty","data":{}});
      return false;
    }
    else if(!gym_id){
      res.send({"success":false,"message":"gym_id empty","data":{}});
      return false;
    }
  
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    //     if (err) throw err;
        let dbo =  await mongodbutil.Get();
        data = {"user_id":ObjectId(user_id),"gym_id":ObjectId(gym_id),"type":type,'created_at':getCurrentTime(),'updated_at':getCurrentTime()}
        
         dbo.collection("TBL_REPORT").insertOne(data, function(err,resr){
            if (err){
                throw err;
            }
            else{
                if(resr){

                    res.send({"success":true,"message":"We have taken your request. Our team will look into this."});
                    return false;
                }
                else{
                    res.send({"success":false,"message":"something went wrong","data":[]});
                    return false;
                }
            }
        }); 
    //});
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

