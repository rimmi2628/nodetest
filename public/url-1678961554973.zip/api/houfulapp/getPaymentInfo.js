var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.getPaymentInfo = async function(req, res) {   
    // console.log(req.body.id); 
  
        let dbo =  await mongodbutil.Get();
       dbo.collection('TBL_PAYMENT_REQUEST').aggregate([
            { $match : {user_id:ObjectId(req.body.id)  } } ,
            {
                $sort: {"created_at": -1} 
            },  
            { 
                $lookup:
                 {
                   from: 'TBL_EARNING_NOTES',
                   localField: '_id',
                   foreignField: 'earning_id',
                   as: 'notes'
                 }
               },
             
             
            ]).toArray(function(err, resr) {
            if (err){
              throw err;
            }
            else{
                res.send({"success":true,"message":"Success","data":resr});
                return false;
            }
        })
      // })
        
  }



    // MongoClient.connect(url, function(err, db) {
    //     if (err) throw err;
    //       var dbo = db.db("gymtraining");
    //       dbo.collection("TBL_SPACE_OWNER").find({"email":email}).toArray(function(err, result) {
    //         if (err){
    //             res.send({"success":false,"message":"something went wrong","data":[]});
    //             return false;
    //         }
    //         else{
    //             // console.log(result)
    //             if(result.length > 0){
    //                 bcrypt.compare(password, result[0].password, function(err, resaa) {
    //                     if(err){
    //                        //console.log(err)
    //                         res.send({"success":false,"message":"Email or password is wrong","data":[]});
    //                         return false;
    //                     }
    //                     else{
    //                         if(resaa){
    //                             delete result[0].password
    //                             res.send({"success":true,"message":"success","data":result[0]});
    //                             return false;
    //                         }
    //                         else{
    //                             res.send({"success":false,"message":"Email or password is wrong","data":[]});
    //                             return false;
    //                         }
    //                     }
    //                 })
    //             }
    //             else{
    //                 res.send({"success":false,"message":"Email does not exists","data":[]});
    //                 return false;
    //             }
            
    //         } 
            
    //         });
    //         // dbo.close();
    //   })


     function getCurrentTime() {
        var d = new Date();
        var n = d.toUTCString();
        var date = new Date(n);
        var seconds = date.getTime() / 1000; //1440516958
        return seconds;
      }
      
      function makeid(length) {
         var result           = '';
         var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
         var charactersLength = characters.length;
         for ( var i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
         }
         return result;
      }