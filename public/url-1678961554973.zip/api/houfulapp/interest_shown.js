var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



// var sourceFile = require('..register');

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.interest_shown = async function(req, res) {   
    let dbo =  await mongodbutil.Get();
      
    var myobj = { trainer_id: ObjectId(req.body.trainer_id),trainer_name:req.body.trainer_name,gym_id: ObjectId(req.body.gym_id),gym_name:req.body.gym_name,gym_address:req.body.gym_address,type:1,created_at:getCurrentTime()};

                dbo.collection("TBL_INTEREST_SHOWN").insertOne(myobj, function(err,resr){
                        res.send({"success":true,"message":"Thank you. We will contact this location and will send you an update.",data:req.body });      
                  });

};
function getCurrentTime() {
  var d = new Date();
  var n = d.toUTCString();
  var date = new Date(n);
  var seconds = date.getTime() / 1000; //1440516958
  return seconds;
}
      
     