var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
var admin = require("firebase-admin");
// var firebase = require('firebase-admin')
// var serviceAccount = require("./../hourful.json"); 

// admin.initializeApp({
//   credential: admin.credential.cert(serviceAccount),
//   databaseURL: "https://hourful-c541c.firebaseio.com"
// });
// var dbss = admin.firestore()
// var sourceFiles = require('./../emailConfirm.js');
// var servicesAccount = require("./../emailConfirm");
const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});


// console.log(sourceFile)

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;

var sourceFile = require('./../emaiConfirm.js');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.emailConfirmOwner = async function (req, res) {
  //console.log(req.query.id);return;
  const { id } = req.body;
  console.log(req.body)
  let errors = [];

  if (!id) {
    res.send({ "success": false, "message": "Please enter all fields", "data": {} });
    return false;
  }
  else {
    // MongoClient.connect(url, function(err, db) {
    //     if (err) throw err;
    let dbo = await mongodbutil.Get();
    dbo.collection("TBL_SPACE_OWNER").find({ verifyId: id }).toArray(function (err, resr) {
      if (err) {
        res.send({ "success": false, "message": "Something went wrong", "data": [] });
        return false;
      }
      else {
        //console.log(resr[0]['_id']);
        //   return;
        console.log('-----response----->',resr)
        var iiid = resr[0]['_id']
        if (resr.length > 0) {
          sourceFile.dbss.collection("gymOwner").doc(String(iiid)).set({ verified: true }).then(function (resp) {
            console.log("firebase ",resp)
            res.send({ "success": true, "message": "Successfully verified", "data": [],"response":resp });
            return false;
          }).catch(err => console.log(err.message))
        }
        else {
          res.send({ "success": false, "message": "Verification Code expired" });
          return false;
        }

      }
    });
    // })
  }
}