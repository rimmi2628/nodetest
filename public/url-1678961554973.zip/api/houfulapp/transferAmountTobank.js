var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')
var emailTemp = require('../emails');
var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'info@hourful.io',
        pass: 'Panda999$'
    }
});


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



// var sourceFile = require('..register');

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.transferAmountTobank = async function(req, res) {   
    let dbo =  await mongodbutil.Get();

    var myobj = { user_id: ObjectId(req.body.user_id),amount:req.body.amount,routing_number: req.body.routingNumber,account_number:req.body.accountNumber,paypal_email:req.body.paypalEmail,payment_method:req.body.payment_method,status:0,created_at:getCurrentTime()};
    
    dbo.collection('TBL_TRAINER_DETAILS').find({ user_id: ObjectId(req.body.user_id) })
            .toArray(function (err, data1) {
              // if (err) {
              //   throw err;
              // } else { 
                var notiObj = { trainer_id: ObjectId(req.body.user_id),user_id:ObjectId(req.body.user_id),trainer_name:"",gym_id: "",gym_name:"",price:req.body.amount,text:'You requested bank transfer of $'+req.body.amount+' on '+formatDateTime(getCurrentTime(),1)+'',action:1,status:0,created_at:getCurrentTime(),updated:getCurrentTime(),type:7,date:formatDateTime(getCurrentTime(),3),time:formatDateTime(getCurrentTime(),2)};
                dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(notiObj, function(err,resr){
                    // if (err){
                    //   throw err;
                    // }
                  });
              // }
            });

          dbo.collection("TBL_SPACE_OWNER").findOne({_id:ObjectId(req.body.user_id)}, function(err, resvxx) {
            // ,:req.body.outstanding_balance
            console.log(resvxx);
            // return
             var stuff=[];
            stuff['amount']= req.body.amount
            stuff['email']= resvxx.email
            var email = emailTemp.bookingEmails.TransferToBankMail(stuff)
                                                    // console.log(stuff)
                                                    console.log(email)
              // transporter.sendMail(mailOptions, function(error, info) {
              //     if (error) {
              //         // res.send({"success":true,"message":"Mail Not sent","data":{}});
              //         console.log(error)
              //     } else {
              //         console.log('mail sent b trans')
              //     }
              // });
            if(resvxx.total_earning == null || resvxx.total_earning == NaN || isNaN(resvxx.total_earning)) {
                resvxx.total_earning = 0
              }
            myobj.outstanding_balance = parseInt(resvxx.total_earning) - parseInt(req.body.amount)
            dbo.collection("TBL_PAYMENT_REQUEST").insertOne(myobj, function(err, resee) {
            if (err){
              res.send({"success":false,"message":"Something went wrong!","data":{} });
            } 
            else{
            dbo.collection("TBL_SPACE_OWNER").findOne({_id:ObjectId(req.body.user_id)}, function(err, resv) {
            if (err) throw err;
            if (err){
              res.send({"success":false,"message":"Something went wrong!","data":{} });
            } 
            else{
              if(resv.total_earning == null || resv.total_earning == NaN || isNaN(resv.total_earning)) {
                resv.total_earning = 0
              }
              // console.log("ass",resv.received_amount)
              dbo.collection("TBL_SPACE_OWNER").updateOne({_id:ObjectId(req.body.user_id)},{$inc: {total_requested: parseInt(req.body.amount),total_earning: - parseInt(req.body.amount)}}, function(err, resv) {
                  res.send({"success":true,"message":"Success!" });      

              })
            //res.send({"success":true,"message":"Success!" });
            }


            })

            }

            });
          })     





};
     function getCurrentTime() {
        var d = new Date();
        var n = d.toUTCString();
        var date = new Date(n);
        var seconds = date.getTime() / 1000; //1440516958
        return seconds;
      }
      
      function makeid(length) {
         var result           = '';
         var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
         var charactersLength = characters.length;
         for ( var i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
         }
         return result;
      }
      function formatDateTime(datetime,type){
        const monthNames = ["January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"];
        const d = new Date(datetime*1000);
        var month =  monthNames[d.getMonth()];
        var date = d.getDate();
        var year = d.getFullYear();

        var hours = d.getHours();
        var minutes = d.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0'+minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
      // February 10, 2020 at 10:15 AM
        if(type==2){
          return d;
          // return month+" "+date+","+year+" at "+strTime
        }
        else if(type == 3){
          return d;
        }
        else{
          return month+" "+date+","+year+" at "+strTime
        }
      }