var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


 
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.getChatData =  async function(req, res) {
    // console.log(req.body.id.join());

    var id = [];
    for(var i=0;i<req.body.id.length;i++){
        id.push(ObjectId(req.body.id[i]));
    }

    // var ids = id.join();
    console.log(id);
    let dbo =  await mongodbutil.Get();
     // dbo.collection('TBL_TRAINER_DETAILS').find(function(err,result){

   dbo.collection("TBL_TRAINER_DETAILS").find({"user_id": {
        "$in": id
    }}).toArray(function(err, resr) {
        if (err){
          
        }
        else{
          //  console.log("resr",resr)
          res.send({"success":true,"message":"Success","data":resr});
          return false;
        }
      });


}

function objectSize(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}