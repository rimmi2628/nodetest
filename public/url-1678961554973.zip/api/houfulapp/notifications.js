var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
//const {email, first_name, last_name, password, social_id, image,type } = req.body;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.notifications = async function(req, res) {
    if(!req.body.loggedInId){
        res.send({"success":false,"message":"loggedInId empty","data":[]});
        return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
        // if (err) throw err;
        let dbo =  await mongodbutil.Get();
        dbo.collection('TBL_GYM_NOTIFICATIONS').aggregate([
            { 
                $match : { 
                    user_id : ObjectId(req.body.loggedInId),
                    status : 0
                } 
            } ,
            {
                $lookup: {
                    from: 'TBL_GYMS',
                    localField: 'gym_id',
                    foreignField: '_id',
                    as: 'gym'
                }
            },
        ]).toArray(function(err, resr) {
            if (err){
                throw err;
            }
            else{
                if(resr){
                    
                    var notifications =[]
                    for (let p = (resr.length-1); p >= 0; p--) {
                        if(resr[p].gym[0] != undefined){
                            notifications.push({
                                '_id':resr[p]._id,
                                'gym_id':resr[p].gym_id,
                                "trainer_id": resr[p].trainer_id,
                                "trainer_name": resr[p].trainer_name,
                                "price": resr[p].price,
                                'text':resr[p].text,
                                'date_time':resr[p].created_at,
                                'type':resr[p].type,
                                'status':resr[p].status,
                                'action':(resr[p].action)?resr[p].action:0,
                                'booking_id':(resr[p].booking_id)?resr[p].booking_id:"",
                                'gym_name':resr[p].gym[0].name,
                                'logo':resr[p].gym[0].logo,
                                'address':resr[p].gym[0].formatted_address,
                                'date':resr[p].date,
                                'time':resr[p].time
                            })
                        }
                        else{
                            notifications.push({
                                '_id':resr[p]._id,
                                'gym_id':resr[p].gym_id,
                                "trainer_id": resr[p].trainer_id,
                                "trainer_name": resr[p].trainer_name,
                                "price": resr[p].price,
                                'text':resr[p].text,
                                'date_time':resr[p].created_at,
                                'type':resr[p].type,
                                'status':resr[p].status,
                                'action':(resr[p].action)?resr[p].action:0,
                                'booking_id':(resr[p].booking_id)?resr[p].booking_id:"",
                                'date':resr[p].date,
                                'time':resr[p].time
                               
                            })
                        }
                        
                       
                            
                    }

                    res.send({"success":true,"message":"success","data":notifications});
                    return false;
                }
                else{
                    res.send({"success":false,"message":"something went wrong","data":[]});
                    return false;
                }
            }
            // console.log(data)
        }); 
    // });  
}