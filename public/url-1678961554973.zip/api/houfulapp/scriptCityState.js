var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



// var sourceFile = require('..register');

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.scriptCityState = async function(req, res) { 
//  var location = path.join(__dirname, '../../../uploads/images');   
//     console.log(req.body); 
//    //  // return false;
//    // //console.log(JSON.parse(req.body))
//    // //return; 
    let dbo =  await mongodbutil.Get();
    

var arrayCityState = [];
var i = 0 ;
 dbo.collection('TBL_GYMS_LIVE').aggregate([
   
          
   ], 
    
).forEach( function(doc) {
      // var equipments_id = [];
      var images_ids = [];
      if(doc.eqpsData.length > 0){
         dbo.collection("TBL_EQUIPMENTS_test").insertMany(doc.eqpsData, function (err, docsInserted) {
           for (var i = 0; i < Object.keys(docsInserted.insertedIds).length; i++) {
               images_ids.push({ id: ObjectId(docsInserted.insertedIds[i]) });
           }
         })
      }

      console.log(images_ids)
});



}        



     function getCurrentTime() {
        var d = new Date();
        var n = d.toUTCString();
        var date = new Date(n);
        var seconds = date.getTime() / 1000; //1440516958
        return seconds;
      }
      
      function makeid(length) {
         var result           = '';
         var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
         var charactersLength = characters.length;
         for ( var i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
         }
         return result;
      }