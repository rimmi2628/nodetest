var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.saveDetailSetupForm = async function(req, res) {
    const {gym_id,detailSlotsPerHour,detailSetupBooking,repeatSelected, repeatDayChanges, currentDetailedChanges} = req.body;

            let dbo =  await mongodbutil.Get();
            

            dbo.collection('TBL_GYM_AVAILABILITY').find({"gym_id" : ObjectId(gym_id),"type" :2,repeat:1}).toArray(function(err, daysResult) {
                // var alreadyRepeatDays = [];
                // var alreadyRepeatDates = [];
                var datesToIgnore = []
                if(daysResult.length > 0){
                    // console.log(daysResult);
                    for(var j = 0; j < daysResult.length ; j++){
                        // alreadyRepeatDays.push(parseInt( daysResult[j]['day'] ));
                        // alreadyRepeatDates.push( daysResult[j]['date'] );

                        if(repeatSelected[daysResult[j]['day']] == false){
                            datesToIgnore.push(daysResult[j]['date']);
                        }
                    }
                }

                console.log(datesToIgnore);
                var daysToDelete = []
                var datesToDelete = []
                for(var k in repeatDayChanges){
                    daysToDelete.push(parseInt(k));
                }
                for(var k in currentDetailedChanges){
                    if(datesToIgnore.indexOf(k) < 0){
                        datesToDelete.push(k);
                    }
                }
                // console.log(daysToDelete);
                console.log(datesToDelete);
    
                /* dbo.collection('TBL_GYM_AVAILABILITY').deleteMany({"gym_id" : ObjectId(gym_id),"type" :2,repeat:1},function(err,result){
                    // console.log(this)
                }); */
    
                dbo.collection('TBL_GYM_AVAILABILITY').deleteMany(
                    {
                        $and:[
                            {
                                $or: [
                                    {"day":{ $in: daysToDelete }},
                                    {"date":{ $in: datesToDelete }}
                                ]
                            },
                            {"gym_id" : ObjectId(gym_id)}
                        ]
                    },
                    function(err, result2) {
                        // res.send({"success":true,"message":"Data Found.","data":result2 });
                        var repeatDataToInsert = [];
                        // var today = new Date()
                        // var cdate = formatDate(today);
    
                        var dateSlots = [];
                        var inc = 0;
                        var allAvalaibilities = [];
                        for(var k in repeatDayChanges){
                            var cDay = repeatDayChanges[k];
                            var cDayDetail = cDay['detail'];
                            var cDayDate = cDay['date'];
                            var cDayDateObj = new Date(cDay['date']);
                            
                            var varSlots = [];
                            var slotStart = 0;
                            var slotEnd = 0;
                            for(var i=0; i<cDayDetail.length ;i++){
                                var cHour = cDayDetail[i]['key'];
                                var cHourPrice = cDayDetail[i]['value'];
                                
                                if(parseInt(cHourPrice) != 0 && cHourPrice!=''){
    
                                    if((parseInt(slotStart)==0)){
                                        slotStart = cHour;
                                    }
    
                                    if(parseInt(cHour) > slotEnd){
                                        slotEnd = parseInt(cHour)+1;
                                    }
    
                                    var ch = cHour;
                                    if(cHour<10){
                                        ch = 0+(cHour.toString());
                                    }
                                    var o = {
                                            "time":ch+":00",
                                            "price":cHourPrice,
                                            "slots":parseInt(detailSlotsPerHour),
                                            "availableSlots":parseInt(detailSlotsPerHour),
                                            "instantBooking":detailSetupBooking,
                                            "date": formatDate(cDayDate),
                                        };
                                    varSlots.push(o);
                                }
                            }
                        
                            dateSlots.push(varSlots);
                            var ss = slotStart;
                            if(slotStart<10){
                                ss = 0+(slotStart.toString());
                            }
                            var se = slotEnd;
                            
                            if(varSlots.length == 0){
                                se = ss;
                            }
                            else if(slotEnd<10){
                                se = 0+(slotEnd.toString());
                            }
                            var cObj = {
                                "gym_id": ObjectId(gym_id),
                                "type": 2,
                                "date": cDayDate,
                                "start_time": ss+':00',
                                "end_time": se+':00',
                                "repeat": 1,
                                "day": parseInt(k),
                                "year": cDayDateObj.getFullYear() ,
                                "month": cDayDateObj.getMonth()+1
                            }
                            allAvalaibilities.push(cObj)
    
                            /* dbo.collection("TBL_GYM_AVAILABILITY").insertOne(cObj, function(err, result) {
                                if (err) throw err;
                                else{
                                    var aid = result.insertedId;
                                    for(var i=0; i<dateSlots[inc].length ;i++){
                                        dateSlots[inc][i]['gym_availability_id']=ObjectId(aid);
                                        dbo.collection("TBL_AVAILABILITY_SLOTS").insertOne(dateSlots[inc][i])
                                    }
                                    inc++;
                                }
                                
                            }); */
                        }
    
                        if(allAvalaibilities.length > 0){
                            var dates =[];
                            for(var i =0;i<dateSlots.length;i++){
                                for(var j=0;j<dateSlots[i].length;j++){
                                    dates.push(dateSlots[i][j])
                                }
                            }
                            var finalSlots = [];
                            console.log(allAvalaibilities);
                            dbo.collection("TBL_GYM_AVAILABILITY").insertMany(allAvalaibilities, function(err, result) {
                                if (err) throw err;
                                else{
                                    for(var i =0;i<result['ops'].length;i++){
                                        for(var j=0; j<dates.length ;j++){
                                            if(result.ops[i].date == dates[j].date){
                                                dates[j]['gym_availability_id']=ObjectId(result.ops[i]._id);
                                                finalSlots.push(dates[j]);
                                            }
                                        }
                                    }
                                    dbo.collection("TBL_AVAILABILITY_SLOTS").insertMany(finalSlots, function(err, result) {
                                        /* console.log("TBL_AVAILABILITY_SLOTS")
                                        console.log(result) */
                                    })
                                }
                            })
                        }
                        
                        var dateSlots2 = [];
                        var inc2 = 0;
                        var allAvalaibilities2 = [];
                        for(var date in currentDetailedChanges){
                            var dateObj = new Date(date);
                            var cDate = currentDetailedChanges[date];
                            var dDay = dateObj.getDay();
                            
                            if(daysToDelete.indexOf(dDay) < 0){
                                
                                var varSlots = [];
                                var slotStart = 0;
                                var slotEnd = 0;
                                for(var i=0; i<cDate.length ;i++){
                                    var cHour = cDate[i]['key'];
                                    var cHourPrice = cDate[i]['value'];
                                    
                                    if(parseInt(cHourPrice) != 0 && cHourPrice!=''){
    
                                        if((parseInt(slotStart)==0)){
                                            slotStart = cHour;
                                        }
    
                                        if(parseInt(cHour) > slotEnd){
                                            slotEnd = parseInt(cHour)+1;
                                        }
    
                                        var ch = cHour;
                                        if(cHour<10){
                                            ch = 0+(cHour.toString());
                                        }
                                        var o = {
                                            "time":ch+":00",
                                            "price":cHourPrice,
                                            "slots":parseInt(detailSlotsPerHour),
                                            "availableSlots":parseInt(detailSlotsPerHour),
                                            "instantBooking":detailSetupBooking,
                                            "date": formatDate(date),
                                        };
                                        varSlots.push(o)
                                    }
                                }
                                console.log(dateSlots2)
                                dateSlots2.push(varSlots);
                                var ss = slotStart;
                                if(slotStart<10){
                                    ss = 0+(slotStart.toString());
                                }
                                var se = slotEnd;
                                
                                if(varSlots.length == 0){
                                    se = ss;
                                }
                                else if(slotEnd<10){
                                    se = 0+(slotEnd.toString());
                                }
                                var cObj = {
                                    "gym_id": ObjectId(gym_id),
                                    "type": 2,
                                    "date": date,
                                    "start_time": ss+':00',
                                    "end_time": se+':00',
                                    "repeat": 0,
                                    "day": parseInt(dDay),
                                    "year": dateObj.getFullYear() ,
                                    "month": dateObj.getMonth()+1
                                }
                                allAvalaibilities2.push(cObj)
                                
                                /* dbo.collection("TBL_GYM_AVAILABILITY").insertOne(cObj, function(err, result) {
                                    if (err) throw err;
                                    else{
                                        // var aid = result['ops'][0]['_id'];
                                        var aid = result.insertedId;
                                        for(var i=0; i<dateSlots2[inc2].length ;i++){
                                            dateSlots2[inc2][i]['gym_availability_id']=ObjectId(aid);
                                            dbo.collection("TBL_AVAILABILITY_SLOTS").insertOne(dateSlots2[inc2][i])
                                        }
                                        inc2++;
                                    }
                                    
                                }); */
                            }                        
                        }
                        if(allAvalaibilities2.length > 0){
                            var dates2 =[];
                            for(var i =0;i<dateSlots2.length;i++){
                                for(var j=0;j<dateSlots2[i].length;j++){
                                    dates2.push(dateSlots2[i][j])
                                }
                            }
                            var finalSlots2 = [];
                            dbo.collection("TBL_GYM_AVAILABILITY").insertMany(allAvalaibilities2, function(err, result) {
                                if (err) throw err;
                                else{
                                    for(var i =0;i<result['ops'].length;i++){
                                        for(var j=0; j<dates2.length ;j++){
                                            if(result.ops[i].date == dates2[j].date){
                                                dates2[j]['gym_availability_id']=ObjectId(result.ops[i]._id);
                                                finalSlots2.push(dates2[j]);
                                            }
                                        }
                                    }
                                    dbo.collection("TBL_AVAILABILITY_SLOTS").insertMany(finalSlots2, function(err, result) {
                                        /* console.log("TBL_AVAILABILITY_SLOTS")
                                        console.log(result) */
                                    })
                                }
                            })
                        }
                        res.send({"success":true,"message":"Data Updated." });return;
    
                    }
                );
            });

}

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}