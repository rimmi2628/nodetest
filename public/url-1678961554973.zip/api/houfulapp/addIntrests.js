

  var express = require('express');  
  var path = require("path");   
  var bodyParser = require('body-parser');  
  var mongo = require("mongoose");  
  // const multer = require('multer');
  // const upload = multer({dest: __dirname + '/uploads/images'});
  var cors = require('cors')
  
  
  const bcrypt = require('bcrypt')
  var app = express() ;
  app.use(cors());
  app.options('*', cors());
  var fs = require("fs");
  // for parsing application/json
  app.use(bodyParser.json()); 
  var fileupload = require("express-fileupload");
  app.use(fileupload());
  
 
  var ObjectId = mongo.Types.ObjectId;
  var Schema = mongo.Schema ;  
     //const {email, first_name, last_name, password, social_id, image,type } = req.body;
  

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'outlook',
  auth: {
    user: 'info@hourful.io',
    pass: 'Panda999$'
  }
});



  
   app.use(bodyParser.json());
   app.use(bodyParser.urlencoded());
   
   mongo.set('useFindAndModify', false);
  var mongodbutil = require( './mongodbutil' );
   exports.addIntrests = async function(req, res) {   
    //   console.log(req.body.id); 
    const {email,type} = req.body;
    let errors = [];
    if(!email || !type){
        res.send({"success":false,"message":"Please enter all fields","data":{}});
        return false;
    }
                // MongoClient.connect(url, function(err, db) {
                let dbo =  await mongodbutil.Get();
                dbo.collection("TBL_INTEREST_SHOWN").find({"emai":email}).toArray(function(err, result) {
                  // console.log(result);
                  // return;
                  if(result.length > 0){
                     res.send({"success":false,"message":"You are already added to the list. We will reach out shortly."});
                  }
                  else{
                      dbo.collection('TBL_INTEREST_SHOWN').insertOne( {emai:email,type:type,created_at:getCurrentTime()} );
               
                // console.log("email",email)
                 var mailOptions = {
                    from: 'info@hourful.io',
                    to: email,
                    subject: 'Welcome',
                    //text: `Hi `+user.first_name+`, thank you for registering with us.
                            //Please click this link below to verify your mail <br> `+verifyEmailId
                    // html: '<h1>Hi '+doc.first_name+', </h1><p>Please click this link below to verify your mail </p><a href="http://13.56.225.168:8088/api/emailConfirm?id='+verifyEmailId+'">Click</a><br>Thanks'        
                    html:'<!doctype html><html lang="en"> <head> <meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1"> <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous"> <title>Verify</title> <style>/*body{font-family: "SF Pro Display";}.verify-main-top{max-width: 1140px;margin: auto;width:70%;}.verify{background:#fff3ee;height:100%;padding:60px 0;}.verify-logo{text-align:center;margin-bottom:30px;}.verify-logo img{width:17%;}.verify-main{background:#fff;padding:50px;border-radius:30px;font-weight:600;}.verify-main h2{font-size:35px;margin-bottom:50px;}.verify-main h3,h4,h5,h6{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;line-height:40px;}.verify-main p{font-size:23px;color:#353535;font-weight:400;margin-bottom:28px;margin-top:70px;line-height:50px;}.verify-btn{text-align:center;}a.verify-btn{font-size:20px;color:#fff !important;background:#ff885b;font-weight:400;border-radius: 50px;padding:18px 55px;display:inline-block;text-decoration:none;}.verify-bottom{text-align:center;}.verify-bottom ul{display:inline-block;margin:40px 0;}.verify-bottom li{display:inline-block;margin:0 15px;}.verify-bottom p{font-size:22px;color:#232323;font-weight:400;padding:0 60px;}.bottom-text p{font-size:22px;color:#232323;font-weight:400;margin:50px 0 0;}.bottom-text h5{background:none;padding:0;color:#0066cb!important;margin:5px 0 0;}.verify-main h6{margin-top:30px;}*//*@media only screen and (max-width: 1599px){.verify-main-top{width:65%;}.verify-main h2{margin-top:0;}.verify-bottom li img{width: 60px;}.verify-bottom li{margin: 0 10px;}}*/@media only screen and (max-width: 1366px){.verify-main h2{font-size: 30px;font-weight:500;margin-bottom:35px;}.verify-main h3, h4, h5, h6{font-size: 19px;line-height:22px;}a.verify-btn{padding:15px 50px;}.verify{background: #fff3ee; height: 100%; padding: 40px 0;}.verify-main p{font-size: 19px; color: #353535; font-weight: 400; margin-bottom: 0; margin-top: 48px; line-height: 22px;}.verify-main{padding:35px;}ul li img{width: 55px !important;}.bottom-text p{font-size: 19px; color: #232323; font-weight: 400; margin: 26px 0 0;}}/*@media only screen and (max-width:1024px){.verify-main{width: 90% !important;}.verify-main{padding: 40px 40px !important; width: 100% !important;}}*/@media only screen and (max-width:767px){h3, h5, h4, h6, h2 , p{font-size: 1.1em !important; margin-bottom: 18px !important; margin-top: 20px !important; line-height: 26px !important; padding:0px !important;}ul li a img{width: 40px !important;}div{width: 100% !important;}div > p > a > img{width: 48% !important;}}</style> </head> <body style="font-family: "SF Pro Display";height:100%;" bgcolor="#fff3ee"> <main class="verify" style="background:#fff3ee;height:100%;padding:60px 0;" > <div class="verify-main-top" style="margin: auto;width:100%;background:#fff3ee;padding:20px 25px;box-sizing: border-box;" bgcolor="#fff3ee"> <div class="container"> <div class="verify-logo" style="text-align:center;margin-bottom:30px;"> <p><a href=""><img src="http://hourful.io/images/verify-logo.png"  style="width:17%;"></a></p></div><div class="verify-main" style="background:#fff;padding:30px;border-radius:5px;font-weight:600; max-width: 1300px; margin: 34px auto !important; width: 70%;box-sizing: border-box;"> <h3 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;line-height:36px;padding: 0 20px;">Hello,</h3> <h5 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;line-height:36px;padding: 0 20px;">Thank you for signing up. You’re on our list. We will be reaching out shortly. </h5><!-- <div class="bottom-text"><p style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;margin-top:32px;line-height:40px;padding: 0 20px;">We will keep you posted on the Hourful updates.</p></div><h6 style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;line-height:36px;padding: 0 20px;">Don’t forget to add info@hourful.io to your Contact/Address book or Safe Senders list to ensure you receive our emails.</h6> --> <p style="font-size:1.3em;color:#353535;font-weight:400;margin-bottom:22px;margin-top:40px;line-height:40px;padding: 0 20px;"> - The Hourful Team</p><div class="verify-btn" style="text-align:center;"> </div></div><div class="verify-bottom" style="text-align:center;"> <ul style="display:inline-block;margin:20px 0;padding: 0 20px;"> <li style="display:inline-block;margin:0 15px;"><a href="https://twitter.com/HourfulApp"><img src="http://hourful.io/images/bottom-icon1.png" alt="icon"></a></li><li style="display:inline-block;margin:0 15px;"><a href="https://www.instagram.com/HourfulApp"><img src="http://hourful.io/images/bottom-icon4.png" alt="icon"></a></li><li style="display:inline-block;margin:0 15px;"><a href="https://www.facebook.com/hourfulapp"><img src="http://hourful.io/images/bottom-icon3.png" alt="icon"></a></li></ul> </div></div></div></main> </body></html>'
                    //html:'<b>Hey there! </b><br> <a href="http://13.56.225.168:8088/api/emailConfirm?id='+verifyEmailId+'">is</a  >This is our first message sent with Nodemailer'
                  };
                  transporter.sendMail(mailOptions, function(error, info){
                    if (error) {  
                      res.send({"success":true,"message":"Mail Not sent","data":result});
                    } else {
                      res.send({"success":true,"message":"Success"});
                      return false;
                    }
                  });

                  }
                })
                



                
            // })
          
}
  
  
  
      // MongoClient.connect(url, function(err, db) {
      //     if (err) throw err;
      //       var dbo = db.db("gymtraining");
      //       dbo.collection("TBL_SPACE_OWNER").find({"email":email}).toArray(function(err, result) {
      //         if (err){
      //             res.send({"success":false,"message":"something went wrong","data":[]});
      //             return false;
      //         }
      //         else{
      //             // console.log(result)
      //             if(result.length > 0){
      //                 bcrypt.compare(password, result[0].password, function(err, resaa) {
      //                     if(err){
      //                        //console.log(err)
      //                         res.send({"success":false,"message":"Email or password is wrong","data":[]});
      //                         return false;
      //                     }
      //                     else{
      //                         if(resaa){
      //                             delete result[0].password
      //                             res.send({"success":true,"message":"success","data":result[0]});
      //                             return false;
      //                         }
      //                         else{
      //                             res.send({"success":false,"message":"Email or password is wrong","data":[]});
      //                             return false;
      //                         }
      //                     }
      //                 })
      //             }
      //             else{
      //                 res.send({"success":false,"message":"Email does not exists","data":[]});
      //                 return false;
      //             }
              
      //         } 
              
      //         });
      //         // dbo.close();
      //   })
  
  
       function getCurrentTime() {
          var d = new Date();
          var n = d.toUTCString();
          var date = new Date(n);
          var seconds = date.getTime() / 1000; //1440516958
          return seconds;
        }
        
        function makeid(length) {
           var result           = '';
           var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
           var charactersLength = characters.length;
           for ( var i = 0; i < length; i++ ) {
              result += characters.charAt(Math.floor(Math.random() * charactersLength));
           }
           return result;
        }