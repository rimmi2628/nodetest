var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});

var db = mongo.connect("mongodb://localhost:27017/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
   if(err){ console.log( err); }  
   else{ //console.log('Connected to ' + db, ' + ', response); 
    }  
});  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.getMonthSchedule = async function(req, res) {
    const {gym_id, month, year} = req.body;
			let dbo =  await mongodbutil.Get();
            dbo.collection('TBL_GYM_AVAILABILITY').aggregate([
                { $match : { gym_id : ObjectId(gym_id) } } ,
                {
                    $lookup : 
                    {
                        from : 'TBL_AVAILABILITY_SLOTS', 
                        localField: '_id', 
                        foreignField: 'gym_availability_id', 
                        as : 'availability_slots'
                    }
                }
            ]).toArray(function(err, resr) {
                if (err){
                    throw err;
                }
                else{
					console.log(resr)
					var quickrepeatDaysData = {};
					var detailrepeatDaysData = {};
					var monthDays = new Date(year, month, 0).getDate();
					var schedule = {};
					if(resr.length > 0){
						// var schedule = JSON.parse(JSON.stringify(resr));
						for(var j = 0; j < resr.length ; j++){
							if(resr[j]['repeat'] == 1){
								if(resr[j]['type'] == 1){
									quickrepeatDaysData[resr[j]['day']] = resr[j];
								}
								else{
									detailrepeatDaysData[resr[j]['day']] = resr[j];
								}
							}
						}

						console.log(quickrepeatDaysData);
						console.log(detailrepeatDaysData);

						for(var i = 1; i <= monthDays; i++ ){
							var cd = (i < 10)?('0'+i) : i;
							var cm = (month < 10)?('0'+month) : month;
							for(var j = 0; j < resr.length ; j++){
								var sc = resr[j];
								console.log(year+"-"+cm+"-"+cd)
								if(sc['date'] == year+"-"+cm+"-"+cd){
									schedule[i] = sc;
								}
							}
							if(!(i in schedule)){
								dayNum = new Date(year, (month-1), i).getDay();
								if (dayNum in detailrepeatDaysData){
									schedule[i] = detailrepeatDaysData[dayNum];
								}
								else if (dayNum in quickrepeatDaysData){
									schedule[i] = quickrepeatDaysData[dayNum];
								}
								else{
									schedule[i] = [];
								}
							}
						}

						console.log(schedule);
						res.send({"success":true,"message":"Data Found.","data":{'monthSchedule':schedule,'quickrepeatDaysData':quickrepeatDaysData,'detailrepeatDaysData':detailrepeatDaysData} });
					}
					else{
						for(var i = 1; i <= monthDays; i++ ){
							schedule[i] = [];
						}
						res.send({"success":true,"message":"Data Found.","data":{'monthSchedule':schedule,'quickrepeatDaysData':quickrepeatDaysData,'detailrepeatDaysData':detailrepeatDaysData} });
					}
					/* console.log(resr)
					res.send({"success":true,"message":"Data Found.","data":resr }); */
                }

            });

    //});
}