var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')

const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
    //const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.changeNotificatonStatus = async function(req, res) {
    const {id,status} = req.body;
    let errors = [];
    if(!id || !status ){
        res.send({"success":false,"message":"Please enter all fields","data":{}});
        return false;
    }
    let dbo =  await mongodbutil.Get();
    dbo.collection("TBL_GYM_NOTIFICATIONS").updateOne({_id:ObjectId(id)},{$set:{status:parseInt(status)}}, function(err, resv) {
        if (err) throw err;
        //console.log(res.insertedId);
        
        if (err){
            res.send({"success":false,"message":"Something went wrong!","data":{} });
        } 
        else{
            res.send({"success":true,"message":"done","data":{}});
            return false;
        }
    }); 
}