var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.updateUserData = async function(req, res) {   
 
    let dbo =  await mongodbutil.Get();
	

	dbo.collection('TBL_SPACE_OWNER').findOne({ email: req.body.email,_id: { $ne: ObjectId(req.body.id) }  }).then(user => {
		if(user){
			res.send({"success":false,"message":"Email already taken","data":{}});
			return false;
		}
		else{
			var location = path.join(__dirname, '../../../uploads/images'); 
			var image = "";
			if(req.files != undefined || req.files != null){
				console.log(req.files.image)
		        var sampleFile = req.files.image;
		        sampleFile.mv(location + "/" + sampleFile.md5+"."+req.files.image.mimetype.split('/')[1], function(err) {
		            if (err){
		                res.send({"success":false,"message":"Unable to fetch image","data":{}});
		                return false;
		            }
		            else{
		                image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
		                // console.log("image",image)
		            }
		        })
		        image = sampleFile.md5+"."+req.files.image.mimetype.split('/')[1];
		    }
		         
		         console.log(req.body.password);
		         // return;
		         	if(req.body.password != undefined){
		         		bcrypt.hash(req.body.password, 10, (err, hash) => {
		         			var data = {
		         				contact_title:req.body.contact_title,
		         				contact_name:req.body.contact_name,
		         				email:req.body.email,
		         				contact_title:req.body.contact_title,
		         				password:hash,
		         			}
		         			if(image != ""){
		         				data.image = image
		         			}
		                    dbo.collection('TBL_SPACE_OWNER').updateOne( { _id: ObjectId(req.body.id)}, {$set: data }, function(err, rese){

				            //dbo.collection("TBL_SPACE_OWNER").insertOne(data, function(err,resr){
				                if (err){
				                    res.send({"success":false,"message":"Something went wrong","data":[]});
				                    return false;
				                }
				                else{
				                   	 res.send({"success":true,"message":"profile updated","data":data});
				                    return false;
				                }
				            });
			        	})
			        	return false;
		         	}
		         	else{
		         		var data = {
		         				contact_title:req.body.contact_title,
		         				contact_name:req.body.contact_name,
		         				email:req.body.email,
		         				contact_title:req.body.contact_title,
		         				
		         			}
		         			if(image != ""){
		         				data.image = image
		         			}
			 		dbo.collection('TBL_SPACE_OWNER').updateOne( { _id: ObjectId(req.body.id)}, {$set: data }, function(err, rese){		   if (err){
				                    res.send({"success":false,"message":"Something went wrong","data":[]});
				                    return false;
				                }
				                else{
				                    res.send({"success":true,"message":"profile updated","data":data});
				                }
				            });
		         	}
				}	
			});


	

	
	         


  }




     function getCurrentTime() {
        var d = new Date();
        var n = d.toUTCString();
        var date = new Date(n);
        var seconds = date.getTime() / 1000; //1440516958
        return seconds;
      }
      
      function makeid(length) {
         var result           = '';
         var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
         var charactersLength = characters.length;
         for ( var i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
         }
         return result;
      }         	
