var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



// var sourceFile = require('..register');

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.addGym = async function(req, res) { 
 var location = path.join(__dirname, '../../../uploads/images');   
    // console.log(req.body); 
    // return false;
   //console.log(JSON.parse(req.body))
   //return; 
    const {city, equipments_id,formatted_address,latitude,longitude,name,phone,postal_code,state,timezone,country,space_owner} = req.body;
    let errors = [];
    // if(!city || !equipments_id || !formatted_address || !latitude || !longitude || !name || !phone || !postal_code || !state || !timezone || !city) {
    //     res.send({"success":false,"message":"Please enter all fields","data":{}});
    //     return false;
    // }
    var ImgUrl = [];
    // console.log(req.files)
    // return;
    if(req.files.gymImage != undefined){
        var seconds = Math.round(new Date().getTime() / 1000)
        const file = req.files.gymImage;
        if(file.length != undefined){
                for(let i = 0 ; i < file.length; i++){
                    var location = path.join(__dirname, '../../../uploads/images'); 
                    //var ggname = __dirname+"/uploads/images/_"+file[i].md5+"."+file[i].mimetype.split('/')[1]
                    file[i].mv(location + "/" + file[i].md5 + "_" + seconds + "." + file[i].mimetype.split('/')[1], function (err, data){

                        if(err){

                            res.send(err);

                        }
                        else{
                            //ImgUrl.push(ggname)
                        }
                        // callback(null, data);
                        //console.log(ImgUrl)

                    })

            }
        }
        else{
            var location = path.join(__dirname, '../../../uploads/images'); 
                    //var ggname = __dirname+"/uploads/images/_"+file[i].md5+"."+file[i].mimetype.split('/')[1]
                    file.mv(location + "/" + file.md5 + "_" + seconds + "." + file.mimetype.split('/')[1], function (err, data){

                        if(err){

                            res.send(err);

                        }
                        else{
                            //ImgUrl.push(ggname)
                        }
                        // callback(null, data);
                        //console.log(ImgUrl)

                    })
        }
        
        
       //res.send('files uploaded');

    }
   // console.log("req.files.gymImage.length",req.files.gymImage.length)
   if(req.files.gymImage != undefined){
    if(req.files.gymImage.length != undefined){
       // console.log("123123")
        //console.log("l",req.files.gymImage.length)
        for (let j = 0; j < req.files.gymImage.length; j++) {
             var sampleFile = req.files.gymImage[j]
            ImgUrl.push({image:'uploads/images/' + sampleFile.md5 + "_" + seconds + "." + req.files.gymImage[j].mimetype.split('/')[1]});
            console.log("imgUrl;",ImgUrl)
        }
    }
    else{
        console.log(req.files.gymImage)
        console.log("1777773")
            var sampleFile = req.files.gymImage
            ImgUrl.push({image:'uploads/images/' + sampleFile.md5 + "_" + seconds + "." + req.files.gymImage.mimetype.split('/')[1]});
            console.log("imgUrl;",ImgUrl)
    }
   }
    
    
    // console.log("imgUrl;",ImgUrl)
    // MongoClient.connect(url, function(err, db) {
        if(ImgUrl.length > 0){
                var images_ids = [];
                let dbo =  await mongodbutil.Get();
                dbo.collection("TBL_GYM_IMAGES").insertMany(ImgUrl, function (err, docsInserted) {
                    for (var i = 0; i < Object.keys(docsInserted.insertedIds).length; i++) {
                        images_ids.push({ id: ObjectId(docsInserted.insertedIds[i]) });
                    }
                // return;
                    var equipments_ids =equipments_id.split(',');
                    //console.log(equipments_ids);return;
                    var equip = [];
                    for(var i = 0 ;i<equipments_ids.length;i++){
                         equip.push(ObjectId(equipments_ids[i]))
                    }
                    if(req.files != undefined ){ 
                        // console.log(req.files);
                        // return;
                        var location = path.join(__dirname, '../../../uploads/images'); 
                        var sampleFile = req.files.logo;
                        var code = makeid(12)+"_"+req.files.logo.md5;
                        var imgdir = location+"/"+code+"."+req.files.logo.mimetype.split('/')[1]
                        var img = "uploads/images/"+code+"."+req.files.logo.mimetype.split('/')[1];

                        var code2 = makeid(12)+"_"+req.files.storefront.md5;
                        var imgdir2 = location+"/"+code2+"."+req.files.storefront.mimetype.split('/')[1]
                        var img2 = "uploads/images/"+code2+"."+req.files.storefront.mimetype.split('/')[1];

                        var code3 = makeid(12)+"_"+req.files.reception.md5;
                        var imgdir3 = location+"/"+code3+"."+req.files.reception.mimetype.split('/')[1]
                        var img3 = "uploads/images/"+code3+"."+req.files.reception.mimetype.split('/')[1];

                        var code4 = makeid(12)+"_"+req.files.gym_interior.md5;
                        var imgdir4 = location+"/"+code4+"."+req.files.gym_interior.mimetype.split('/')[1]
                        var img4 = "uploads/images/"+code4+"."+req.files.gym_interior.mimetype.split('/')[1];


                        req.files.storefront.mv(imgdir2);
                        req.files.reception.mv(imgdir3);
                        req.files.gym_interior.mv(imgdir4);

                        sampleFile.mv(imgdir, function(err) {
                        if (err){
                            res.send({"success":false,"message":"Unable to fetch image","data":{}});
                            return false;
                        }
                        else{
                        // MongoClient.connect(url, function(err, db) {
                        // var dbo = db.db("gymtraining");
                        dbo.collection('TBL_GYMS').insert( {
                            "name": name,
                            "logo": img,
                            "timezone": timezone,
                            "phone":phone,
                            "bio": "we are best",
                            "price": 50,
                            "min_price": "1",
                            "max_price": "300",
                            "avg_rating": "0",
                            "ratings": "0",
                            "street_number": postal_code,
                            "locality": city,
                            "country": country,
                            "postal_code": postal_code,
                            "formatted_address": formatted_address,
                            "latitude": String(latitude),
                            "longitude": String(longitude),
                            "equipments_id": equip,
                            "images_ids": images_ids,
                            "space_owner":ObjectId(space_owner),
                            "storefront":img2,
                            "reception":img3,
                            "gym_interior":img4,
                            "location": {
                            "type": "Point",
                            "coordinates": [
                                Number(longitude),
                                Number(latitude)
                                ]
                            }
                        }, function (err, docsInserted){
                            dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } );
                            res.send({"success":true,"message":"Success",data:docsInserted});
                            return false;
                        } );
                        
                        // })
                        } 

                        });


                    }
                //console.log(images_ids)
                // var oldImg_idsParsed = JSON.parse(req.body.old);
                // for (var i = 0; i < Object.keys(oldImg_idsParsed).length; i++) {
                //     images_ids.push({ id: ObjectId(oldImg_idsParsed[i]['_id']) });
                // }
                // })
                })
        }
        else{
             var images_ids = [];
                let dbo =  await mongodbutil.Get();
                // dbo.collection("TBL_GYM_IMAGES").insertMany(ImgUrl, function (err, docsInserted) {
                //     for (var i = 0; i < Object.keys(docsInserted.insertedIds).length; i++) {
                //         images_ids.push({ id: ObjectId(docsInserted.insertedIds[i]) });
                //     }
                // return;
                    var equipments_ids =equipments_id.split(',');
                    //console.log(equipments_ids);return;
                    var equip = [];
                    for(var i = 0 ;i<equipments_ids.length;i++){
                         equip.push(ObjectId(equipments_ids[i]))
                    }
                    if(req.files != undefined ){ 
                        // console.log(req.files);
                        // return;
                        var location = path.join(__dirname, '../../../uploads/images'); 
                        var sampleFile = req.files.logo;
                        var code = makeid(12)+"_"+req.files.logo.md5;
                        var imgdir = location+"/"+code+"."+req.files.logo.mimetype.split('/')[1]
                        var img = "uploads/images/"+code+"."+req.files.logo.mimetype.split('/')[1];

                        var code2 = makeid(12)+"_"+req.files.storefront.md5;
                        var imgdir2 = location+"/"+code2+"."+req.files.storefront.mimetype.split('/')[1]
                        var img2 = "uploads/images/"+code2+"."+req.files.storefront.mimetype.split('/')[1];

                        var code3 = makeid(12)+"_"+req.files.reception.md5;
                        var imgdir3 = location+"/"+code3+"."+req.files.reception.mimetype.split('/')[1]
                        var img3 = "uploads/images/"+code3+"."+req.files.reception.mimetype.split('/')[1];

                        var code4 = makeid(12)+"_"+req.files.gym_interior.md5;
                        var imgdir4 = location+"/"+code4+"."+req.files.gym_interior.mimetype.split('/')[1]
                        var img4 = "uploads/images/"+code4+"."+req.files.gym_interior.mimetype.split('/')[1];


                        req.files.storefront.mv(imgdir2);
                        req.files.reception.mv(imgdir3);
                        req.files.gym_interior.mv(imgdir4);

                        sampleFile.mv(imgdir, function(err) {
                        if (err){
                            res.send({"success":false,"message":"Unable to fetch image","data":{}});
                            return false;
                        }
                        else{
                        // MongoClient.connect(url, function(err, db) {
                        // var dbo = db.db("gymtraining");
                       dbo.collection('TBL_GYMS').insert( {
                            "name": name,
                            "logo": img,
                            "timezone": timezone,
                            "phone":phone,
                            "bio": "we are best",
                            "price": 50,
                            "min_price": "1",
                            "max_price": "300",
                            "avg_rating": "0",
                            "ratings": "0",
                            "street_number": postal_code,
                            "locality": city,
                            "country": country,
                            "postal_code": postal_code,
                            "formatted_address": formatted_address,
                            "latitude": String(latitude),
                            "longitude": String(longitude),
                            "equipments_id": equip,
                            "images_ids": images_ids,
                            "space_owner":ObjectId(space_owner),
                            "storefront":img2,
                            "reception":img3,
                            "gym_interior":img4,
                            "location": {
                            "type": "Point",
                            "coordinates": [
                                Number(longitude),
                                Number(latitude)
                                ]
                            }
                        }, function (err, docsInserted){
                            dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } );
                            res.send({"success":true,"message":"Success",data:docsInserted});
                            return false;
                        } );
                        // })
                        } 

                        });


                    }
                //console.log(images_ids)
                // var oldImg_idsParsed = JSON.parse(req.body.old);
                // for (var i = 0; i < Object.keys(oldImg_idsParsed).length; i++) {
                //     images_ids.push({ id: ObjectId(oldImg_idsParsed[i]['_id']) });
                // }
                // })
                //})
        }
 




    // MongoClient.connect(url, function(err, db) {
    //     if (err) throw err;
    //       var dbo = db.db("gymtraining");
    //       dbo.collection("TBL_SPACE_OWNER").find({"email":email}).toArray(function(err, result) {
    //         if (err){
    //             res.send({"success":false,"message":"something went wrong","data":[]});
    //             return false;
    //         }
    //         else{
    //             // console.log(result)
    //             if(result.length > 0){
    //                 bcrypt.compare(password, result[0].password, function(err, resaa) {
    //                     if(err){
    //                        //console.log(err)
    //                         res.send({"success":false,"message":"Email or password is wrong","data":[]});
    //                         return false;
    //                     }
    //                     else{
    //                         if(resaa){
    //                             delete result[0].password
    //                             res.send({"success":true,"message":"success","data":result[0]});
    //                             return false;
    //                         }
    //                         else{
    //                             res.send({"success":false,"message":"Email or password is wrong","data":[]});
    //                             return false;
    //                         }
    //                     }
    //                 })
    //             }
    //             else{
    //                 res.send({"success":false,"message":"Email does not exists","data":[]});
    //                 return false;
    //             }
            
    //         } 
            
    //         });
    //         // dbo.close();
    //   })

};
     function getCurrentTime() {
        var d = new Date();
        var n = d.toUTCString();
        var date = new Date(n);
        var seconds = date.getTime() / 1000; //1440516958
        return seconds;
      }
      
      function makeid(length) {
         var result           = '';
         var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
         var charactersLength = characters.length;
         for ( var i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
         }
         return result;
      }