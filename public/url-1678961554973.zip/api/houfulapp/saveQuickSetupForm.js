var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


 
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.saveQuickSetupForm =  async function(req, res) {
    const {gym_id,events,type,repeat, slotsPerHour, pricePerHour, quickSetupBooking} = req.body;
	let dbo =  await mongodbutil.Get();

            dbo.collection('TBL_GYM_AVAILABILITY').deleteMany({"gym_id" : ObjectId(gym_id),"type" :1},function(err,result){
                // console.log(this)
            });

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var dt = new Date(curr.setDate(first+6));
            // console.log(new Date(curr.setDate(first)))

            var dateSlots = [];
            var inc = 0;
            var results=[];
            var cHourPrice = pricePerHour;
            var coBJ = []
            for(var cDay in events){
                var cDayDetail = events[cDay];

                var varSlots = [];
                var slotStart = 0;
                var slotEnd = 0;

                var doomDate = new Date();
                doomDate.setDate(dt.getDate());
                doomDate.setFullYear(dt.getFullYear());
                doomDate.setMonth(dt.getMonth());
                while (doomDate.getDay() != cDay ) {
                    doomDate.setDate(doomDate.getDate() - 1);
                }
                // console.log(doomDate)

                var  i = 1;
                var size = objectSize(cDayDetail);
                for(var cHour in cDayDetail){
                    if(i == 1){
                        slotStart = cHour;
                    }
                    if(i == size){
                        slotEnd = parseInt(cHour)+1;
                    }

                    var ch = cHour;
                    if(cHour<10){
                        ch = 0+(cHour.toString());
                    }
                    var o = {
                            "time":ch+":00",
                            "price":cHourPrice,
                            "slots":parseInt(slotsPerHour),
                            "availableSlots":parseInt(slotsPerHour),
                            "instantBooking":quickSetupBooking,
                            "date": formatDate(doomDate),
                        };
                    varSlots.push(o)

                    i++;
                }
                dateSlots.push(varSlots);
                var ss = slotStart;
                if(slotStart<10){
                    ss = 0+(slotStart.toString());
                }
                var se = slotEnd;
                if(slotEnd<10){
                    se = 0+(slotEnd.toString());
                }
                var cObj = {
                    "gym_id": ObjectId(gym_id),
                    "type": 1,
                    "date": formatDate(doomDate),
                    "start_time": ss+':00',
                    "end_time": se+':00',
                    "repeat": 1,
                    "day": parseInt(cDay),
                    "month": parseInt(doomDate.getMonth())+1,
                    "year": parseInt(doomDate.getFullYear())
                }
                coBJ.push(cObj)
            }
            var dates =[];
            for(var i =0;i<dateSlots.length;i++){
                for(var j=0;j<dateSlots[i].length;j++){
                    dates.push(dateSlots[i][j])
                }
            }
            var finalSlots = [];
            dbo.collection("TBL_GYM_AVAILABILITY").insertMany(coBJ, function(err, result) {
                if (err) throw err;
                else{
                    for(var i =0;i<result['ops'].length;i++){
                        for(var j=0; j<dates.length ;j++){
                            if(result.ops[i].date == dates[j].date){
                                dates[j]['gym_availability_id']=ObjectId(result.ops[i]._id);
                                finalSlots.push(dates[j]);
                            }
                        }
                    }
                    dbo.collection("TBL_AVAILABILITY_SLOTS").insertMany(finalSlots, function(err, result) {
                        /* console.log("TBL_AVAILABILITY_SLOTS")
                        console.log(result) */
                    })
                }
            })

            res.send({"success":true,"message":"Data Updated." });return;

    // });
}

function objectSize(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}