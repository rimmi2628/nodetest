

  var express = require('express');  
  var path = require("path");   
  var bodyParser = require('body-parser');  
  var mongo = require("mongoose");  
  // const multer = require('multer');
  // const upload = multer({dest: __dirname + '/uploads/images'});
  var cors = require('cors')
  const Utill = require('../../helper/Constant')
  
var nodemailer = require('nodemailer');
var emailTemp = require('../emails');
var transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'info@hourful.io',
        pass: 'Panda999$'
    }
});
  
  const bcrypt = require('bcrypt')
  var app = express() ;
  app.use(cors());
  app.options('*', cors());
  var fs = require("fs");
  // for parsing application/json
  app.use(bodyParser.json()); 
  
 
  var ObjectId = mongo.Types.ObjectId;
  var Schema = mongo.Schema ;  
     //const {email, first_name, last_name, password, social_id, image,type } = req.body;




  
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

// mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );

var CronJob = require('cron').CronJob;

async function cron(req, res) {  
    // var job = new CronJob('0 * * * *', async function() {
    var job = new CronJob('* * * * *', async function() {
     
    let dbo =  await mongodbutil.Get();
    var time  = getCurrentTime() - 3600
    console.log("time",time)
    dbo.collection("TBL_BOOKINS").find({ $or: [ { status:1,schedule_time: { $lt:  time} }, {status:2,schedule_time: { $lt: time } } ]}).toArray( async function(err, result) {
      console.log("result",result)
      for(var i = 0 ; i<result.length;i++){
         dbo.collection("TBL_BOOKINS").findOneAndUpdate({_id:ObjectId(result[i]['_id'])},{$set:{status:5 }},function(err, result) {
            console.log("ult",result)
            dbo.collection("TBL_GYMS").updateOne({_id:ObjectId(result.value.gym_id)},{$inc: {total_earning: result.value.price}} ,  function(err, resultsss) {
            
              dbo.collection('TBL_TRAINER_DETAILS').find({ user_id: ObjectId(result.value.user_id) })
              .toArray(function (err, data1) {
                if (err) {
                  throw err;
                } else { 
                  dbo.collection('TBL_GYMS').find({_id:ObjectId(result.value.gym_id)})
                  .toArray(function (err, data2) {
                  if (err) {
                  throw err;
                  } else { 

                      dbo.collection("TBL_SPACE_OWNER").updateOne({_id:ObjectId(data2[0].space_owner)},{$inc: {total_earning: result.value.price}} ,  function(err, resultsss) {
                      })
                       dbo.collection("TBL_SPACE_OWNER").findOne({_id:ObjectId(data2[0].space_owner)}, function(err, resvxxsd) {

                        
                          var stuff = []
                          stuff['email'] = resvxxsd.email
                          stuff['total_requested'] = resvxxsd.total_requested
                          stuff['total_earning'] = resvxxsd.total_earning
                          stuff['price'] = result.value.price
                          stuff['chat'] =Utill.IMAGE_BASE_URL+'gymapp/#/?message=transfer'
                          // if (resvxxsd.email == 'acpnayak@gmail.com') {
                            var email = emailTemp.bookingEmails.cronEmailjob(stuff)
                            console.log(email)
                          // }
                          
                        // transporter.sendMail(mailOptions, function(error, info) {
                        //     if (error) {
                        //         // res.send({"success":true,"message":"Mail Not sent","data":{}});
                        //         console.log(error)
                        //     } else {
                        //         console.log('mail sent b cron')
                        //     }
                        // });
                      })
                      var gymNotiObj = { trainer_id: ObjectId(result.value.user_id),trainer_name:data1[0].first_name+" "+data1[0].last_name,gym_id: result.value.gym_id,gym_name:"",user_id:ObjectId(data2[0].space_owner),price:''+result.value.price+'',text:"",action:1,status:0,date_time:result.value.schedule_time,created_at:getCurrentTime(),updated:getCurrentTime(),type:4,date:result.value.date,time:result.value.time};

                      var gymNotiObj2 = { trainer_id: ObjectId(result.value.user_id),trainer_name:data1[0].first_name+" "+data1[0].last_name,gym_id: result.value.gym_id,gym_name:"",user_id:ObjectId(data2[0].space_owner),price:''+result.value.price+'',text:"",action:1,status:0,date_time:result.value.schedule_time,created_at:getCurrentTime(),updated:getCurrentTime(),type:5,date:result.value.date,time:result.value.time};

                      dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(gymNotiObj, function(err,resr){
                      // if (err){
                      //  throw err;
                      console.log("1st entry")
                      // }
                      });
                      dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(gymNotiObj2, function(err,resr){
                      // if (err){
                      console.log("2nd entry")
                      //  throw err;
                      // }
                      });
                  }
                })

                }
              });
            })                  
                  
         }) 
         
      }
    })
    }, null, true, 'America/Los_Angeles');
    job.start();

}
cron()

  
      // MongoClient.connect(url, function(err, db) {
      //     if (err) throw err;
      //       var dbo = db.db("gymtraining");
      //       dbo.collection("TBL_SPACE_OWNER").find({"email":email}).toArray(function(err, result) {
      //         if (err){
      //             res.send({"success":false,"message":"something went wrong","data":[]});
      //             return false;
      //         }
      //         else{
      //             // console.log(result)
      //             if(result.length > 0){
      //                 bcrypt.compare(password, result[0].password, function(err, resaa) {
      //                     if(err){
      //                        //console.log(err)
      //                         res.send({"success":false,"message":"Email or password is wrong","data":[]});
      //                         return false;
      //                     }
      //                     else{
      //                         if(resaa){
      //                             delete result[0].password
      //                             res.send({"success":true,"message":"success","data":result[0]});
      //                             return false;
      //                         }
      //                         else{
      //                             res.send({"success":false,"message":"Email or password is wrong","data":[]});
      //                             return false;
      //                         }
      //                     }
      //                 })
      //             }
      //             else{
      //                 res.send({"success":false,"message":"Email does not exists","data":[]});
      //                 return false;
      //             }
              
      //         } 
              
      //         });
      //         // dbo.close();
      //   })
  
  
       function getCurrentTime() {
          var d = new Date();
          var n = d.toUTCString();
          var date = new Date(n);
          var seconds = date.getTime() / 1000; //1440516958
          return seconds;
        }
        
        function makeid(length) {
           var result           = '';
           var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
           var charactersLength = characters.length;
           for ( var i = 0; i < length; i++ ) {
              result += characters.charAt(Math.floor(Math.random() * charactersLength));
           }
           return result;
        }