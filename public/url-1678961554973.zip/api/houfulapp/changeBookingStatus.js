var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

var nodemailer = require('nodemailer');
var emailTemp = require('../emails');
var transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'info@hourful.io',
        pass: 'Panda999$'
    }
});

const Utill = require('../../helper/Constant')
// var stripe = require('stripe')('sk_test_1tqRe2GJZqKbCChbIZvB4GKs');
var stripe = require('stripe')(Utill.STRIPE_KEY);

const bcrypt = require('bcrypt')
var app = express();
const {
    admin
} = require('../firebaseConfig.js');
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
var options = {
    priority: "high",
    timeToLive: 60 * 60 * 24
};
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.changeBookingStatus = async function(req, res) {
    const {
        id,
        status,
        user_id
    } = req.body;
    let errors = [];
    if (!id || !status) {
        res.send({
            "success": false,
            "message": "Please enter all fields",
            "data": {}
        });
        return false;
    }
    let dbo = await mongodbutil.Get();
    if (status == '1' || status == '3') {
        // console.log("44343432")
        const gyymdetails = dbo.collection('TBL_BOOKINS').find({
                _id: ObjectId(id)
            })
            .toArray(function(err, data) {
                if (err) {
                    throw err;
                } else {
                    if (status == '3') {
                        if (data[0].payment_method == '0' && (data[0].status == 0 || data[0].status == 1 || data[0].status == 2)) {
                            stripe.refunds.create({
                                    charge: data[0].transaction_id,
                                },
                                function(err, refund) {
                                    if (err) {
                                        console.log(err)
                                        return false;
                                    } else {

                                        var newvalues1 = {
                                            $set: {
                                                status: 4,
                                                refund_id: refund.id
                                            }
                                        };
                                        var myqueryB = {
                                            _id: ObjectId(id)
                                        };
                                        dbo.collection("TBL_BOOKINS").updateOne(myqueryB, newvalues1, function(err, data) {
                                            console.log(data);
                                        });
                                    }
                                }
                            );

                        }
                    }

                    if (data[0].status == 0) {

                        // }
                        dbo.collection('TBL_GYMS').find({
                                _id: data[0].gym_id
                            })
                            .toArray(function(err, dataG) {
                                if (err) {
                                    throw err;
                                } else {
                                    // console.log(data[0].logo) 

                                    if (status == '1') {
                                        dbo.collection("TBL_AVAILABILITY_SLOTS").updateOne({
                                            _id: ObjectId(data[0].slot_id)
                                        }, {
                                            $inc: {
                                                availableSlots: -1
                                            }
                                        }, function(err, resultsss) {})
                                        var sta = "0";
                                    } else {
                                        var sta = "6"
                                    }
                                    var NotiObj = {
                                        trainer_id: data[0].user_id,
                                        date: data[0].date,
                                        time: data[0].time,
                                        gym_id: data[0].gym_id,
                                        gym_name: dataG[0].name,
                                        logo: dataG[0].logo,
                                        text: "",
                                        type: sta,
                                        status: "0",
                                        date_time: data[0].schedule_time,
                                        created_at: getCurrentTime(),
                                        updated: getCurrentTime()
                                    };
                                    dbo.collection("TBL_NOTIFICATIONS").insertOne(NotiObj, function(err, resr) {
                                        if (err) {
                                            throw err;
                                        }
                                    });

                                    dbo.collection('TBL_TRAINER_DETAILS').find({
                                            user_id: ObjectId(data[0].user_id)
                                        })
                                        .toArray(function(err, data1) {
                                            if (err) {
                                                throw err;
                                            } else {
                                                var date_split = data[0].date.split("-");
                                                   
                                                var time_split = data[0].time.split(":");
                                                var time_Hr = parseInt(time_split[0]) + 1;
                                                var time_till = time_Hr.toString()+':'+time_split[1];

                                            	const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                                                dbo.collection('TBL_AVAILABILITY_SLOTS').find({
                                                        _id: data[0].slot_id
                                                    })
                                                    .toArray(function(err, dataAAA) {
                                                        if (err) {
                                                            // throw err;
                                                        } else {
                                                            dbo.collection('TBL_GYM_AVAILABILITY').find({
                                                                    _id: dataAAA[0].gym_availability_id
                                                                })
                                                                .toArray(function(err, dataAV) {
                                                                    if (err) {
                                                                        // throw err;
                                                                    } else {
                                                                        dbo.collection('TBL_TRAINERS').find({
                                                                                _id: ObjectId(data[0].user_id)
                                                                            })
                                                                            .toArray(function(err, dataTT) {
                                                                                if (err) {
                                                                                    throw err;
                                                                                } else { 
                                                                                	var monthBB = monthNames[date_split[1]-1];
                                                                                	if (status == '3') {
                                                                                        var stuff = []
                                                                                		stuff['email'] = dataTT[0].email
                                                                                        stuff['name'] = dataG[0].name
                                                                                        stuff['monthBB'] = monthBB
                                                                                        stuff['day'] = date_split[2]
                                                                                        stuff['year'] = date_split[0]
                                                                                        stuff['start_time'] = tConvert(data[0].time)
                                                                                        stuff['end_time'] = tConvert(time_till)
                                                                                        stuff['chat']= Utill.IMAGE_BASE_URL+'redirect.html?type=nearbygyms&lat='+dataG[0].latitude+'&lng='+ dataG[0].longitude +'&address='+ encodeURI(dataG[0].formatted_address) +''
                                                                                        // if (dataTT[0].email == 'mohitsetia@gmail.com') {
                                                                                            var email = emailTemp.bookingEmails.changeBookingStatusEmailC(stuff)
                                                                                            console.log(email)
                                                                                        // }
                                                                                	}
                                                                                	else{
                                                                                		var stuff = []
                                                                                        stuff['email'] = dataTT[0].email
                                                                                        stuff['name'] = dataG[0].name
                                                                                        stuff['monthBB'] = monthBB
                                                                                        stuff['day'] = date_split[2]
                                                                                        stuff['year'] = date_split[0]
                                                                                        stuff['start_time'] = tConvert(data[0].time)
                                                                                        stuff['end_time'] = tConvert(time_till)
                                                                                        stuff['price'] = data[0].price
                                                                                        // stuff['chat']= 'hourful://openapp?type=chat&sid='+user_id+'&gid='+dataG[0]._id+''
                                                                                        // stuff['chat']= 'https://hourful.io/redirect.html?type=chat&gid='+user_id+'_'+dataG[0]._id+''
                                                                                        if (dataG[0].logo.indexOf("http") != -1 || dataG[0].logo.indexOf("https") != -1) {
                                                                                            stuff['chat']= Utill.IMAGE_BASE_URL+'redirect.html?type=chat&gid='+dataG[0]._id+'&logo='+dataG[0].logo+'&name='+ encodeURI(dataG[0].name) +'&space_owner='+user_id+''
                                                                                        }
                                                                                        else{
                                                                                            var logo = dataG[0].logo.replace("uploads/images/", "");
                                                                                            stuff['chat']= Utill.IMAGE_BASE_URL+'redirect.html?type=chat&gid='+dataG[0]._id+'&logo='+logo+'&name='+ encodeURI(dataG[0].name) +'&space_owner='+user_id+''
                                                                                        }
                                                                                        console.log(stuff['chat'])
                                                                                        // if (dataTT[0].email == 'mohitsetia@gmail.com') {
                                                                                            var email = emailTemp.bookingEmails.changeBookingStatusEmailA(stuff)
                                                                                            console.log(email)
                                                                                        // }
                                                                                        
                                                                                	}
                                                                                }
                                                                            })

                                                                    }
                                                                })
                                                        }
                                                    })
                                                // if(instantBooking == true){
                                                // 	var actionInstant = 0
                                                // }
                                                // else{
                                                var actionInstant = 1
                                                // }
                                                var text = 'You have accepted ' + data1[0].first_name + " " + data1[0].last_name + ' on  ' + formatDateTime(getCurrentTime()) + ''
                                                var title = 'Booking Accepted'
                                                var nbody = 'Your booking has been accepted.'


                                                console.log("line 106", data[0].user_id, data[0].gym_id)

                                                if (status == '3') {

                                                    text = 'You have rejected ' + data1[0].first_name + " " + data1[0].last_name + ' on  ' + formatDateTime(getCurrentTime()) + ''
                                                    title = 'Booking Rejected'
                                                    nbody = 'Your booking has been rejected.'
                                                }

                                                dbo.collection('TBL_PUSH_TOKENS').find({
                                                        trainer_id: ObjectId(data[0].user_id)
                                                    })
                                                    .toArray(function(err, tokens) {
                                                        var dTokens = []
                                                        for (let e = 0; e < tokens.length; e++) {
                                                            dTokens[e] = tokens[e].token;
                                                        }
                                                        console.log("line 96", data[0].user_id, data[0].gym_id)
                                                        var payload = {
                                                            notification: {
                                                                title: title,
                                                                body: nbody
                                                            },
                                                            data: {
                                                                // booking_id: booking_id,
                                                                user_id: String(data[0].user_id.toString()),
                                                                gym_id: String(data[0].gym_id.toString()),
                                                            }
                                                        };


                                                        //})

                                                        var registrationToken = dTokens;
                                                        if (tokens.length != 0) {
                                                            admin.messaging().sendToDevice(registrationToken, payload, options)
                                                                .then(function(response) {
                                                                    console.log("Successfully sent message:", response);
                                                                })
                                                                .catch(function(error) {
                                                                    console.log("Error sending message:", error);
                                                                });
                                                        }

                                                    });
                                                // console.log(data1)
                                                // return
                                                if (status == '1') {
                                                    var sss = 2;
                                                } else {
                                                    var sss = 6;
                                                }
                                                //if(status == '1'){
                                                var gymNotiObj = {
                                                    trainer_id: data[0].user_id,
                                                    date: data[0].date,
                                                    time: data[0].time,
                                                    trainer_name: data1[0].first_name + " " + data1[0].last_name,
                                                    gym_id: data[0].gym_id,
                                                    gym_name: dataG[0].name,
                                                    price: '' + data[0].price + '',
                                                    user_id: ObjectId(user_id),
                                                    text: text,
                                                    action: actionInstant,
                                                    status: 0,
                                                    date_time: data[0].schedule_time,
                                                    created_at: getCurrentTime(),
                                                    updated: getCurrentTime(),
                                                    type: sss
                                                };
                                                // console.log(gymNotiObj)
                                                // return
                                                dbo.collection("TBL_GYM_NOTIFICATIONS").insertOne(gymNotiObj, function(err, resr) {
                                                    if (err) {
                                                        throw err;
                                                    }
                                                });
                                                //}

                                            }
                                        });
                                }
                            });
                    }

                }
            });
    }

    dbo.collection('TBL_BOOKINS').find({
            _id: ObjectId(id)
        })
        .toArray(function(err, data) {
            if (data[0].status == 0) {
                dbo.collection("TBL_BOOKINS").updateOne({
                    _id: ObjectId(id)
                }, {
                    $set: {
                        status: parseInt(status)
                    }
                }, function(err, resv) {
                    if (err) throw err;
                    if (err) {
                        res.send({
                            "success": false,
                            "message": "Something went wrong!",
                            "data": {}
                        });
                    } else {
                        // console.log(resv)
                        // dbo.collection('TBL_BOOKINS').findOne({_id:ObjectId(id)}).toArray(function(err, resr) {
                        dbo.collection('TBL_BOOKINS').aggregate([{
                                $match: {
                                    _id: ObjectId(id)
                                }
                            },
                            {
                                $lookup: {
                                    from: 'TBL_GYMS',
                                    localField: 'gym_id',
                                    foreignField: '_id',
                                    as: 'gyms'
                                }
                            },
                            {
                                $lookup: {
                                    from: 'TBL_TRAINERS',
                                    localField: 'user_id',
                                    foreignField: '_id',
                                    as: 'trainers'
                                }
                            }
                        ]).toArray(function(err, resr) {
                            console.log(resr)

                            /* resr.user_id
                            resr.gym_id */

                            /* if(status == 1 ){

                            	var obj = {
                            		"user_id": resr.user_id,
                            		"gym_id": resr.gym_id,
                            		"text": "Your booking scheduled on "+formatDateTime(resr.datetime)+" with LA Fitness is now accepted and confirmed.",
                            		"type": 0,
                            		"status": 1,
                            		"created_at":getCurrentTime(),
                            		"updated_at":getCurrentTime()
                            	}
                            	
                            }
                            else if(status == 3){
                            	
                            } */

                            /* {
                            	"user_id": ObjectId("5e8ebb1bac35bc3ed10b1f7b"),
                            	"gym_id": ObjectId("5e6f2b066b632e8863ef49e9"),
                            	"text": "",
                            	"type": 3,
                            	"status": 1,
                            	"created_at": 1584611262,
                            	"updated": 1584611262
                            } */

                            res.send({
                                "success": true,
                                "message": "done",
                                "data": {}
                            });
                            return false;
                        });

                    }
                });
            } else {
                res.send({
                    "success": false,
                    "message": "done",
                    "data": data[0].status
                });
                return false;
            }

        })


}

function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
}

function formatDateTime(datetime) {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const d = new Date(datetime * 1000);
    var month = monthNames[d.getMonth()];
    var date = d.getDate();
    var year = d.getFullYear();

    var hours = d.getHours();
    var minutes = d.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;

    // Dec 10, 2019 @10:30 AM
    return month + " " + date + ", " + year + " at " + strTime;
}
function tConvert (time) {
    // Check correct time format and split into components
    time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join (''); // return adjusted time or original string
  }