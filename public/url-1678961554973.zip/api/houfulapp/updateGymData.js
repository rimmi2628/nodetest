var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.updateGymData = async function(req, res) {   
    const {name, timezone,phone,bio,price,city,country,postal_code,formatted_address,latitude,longitude,id,equipments_id} = req.body;

	var data = {
		"name": name,
		"timezone": timezone,

		"phone":phone,

		"bio": bio,

		"price": parseInt(price),
		"street_number": postal_code,
		"locality": city,

		"country": country,

		"postal_code": postal_code,

		"formatted_address": formatted_address,

		"latitude": String(latitude),
		"longitude": String(longitude),
		"location": {
			"type": "Point",
			"coordinates": [
					Number(longitude),
					Number(latitude)
					]
			}
	}
		let dbo =  await mongodbutil.Get();
		var location = path.join(__dirname, '../../../uploads/images');   
		var ImgUrl = [];


		var deletedImage =req.body.deletedId.split(',');
		console.log(deletedImage.length);
		console.log("deletedImage[0]",deletedImage[0]);
		// return;
		// var deletedImage = [];
		if(deletedImage.length > 0 && deletedImage[0] !="" ){
			console.log("Ee")
			for(var i = 0 ;i<deletedImage.length;i++){
				dbo.collection("TBL_GYM_IMAGES").remove({_id: ObjectId(deletedImage[i])});
			}
		}
		

		// return;
		if(req.files !=null  ){
			if(req.files.gymImage != undefined){
				var seconds = Math.round(new Date().getTime() / 1000)
				const file = req.files.gymImage;
				if(file.length != undefined){
					for(let i = 0 ; i < file.length; i++){
						var location = path.join(__dirname, '../../../uploads/images'); 
						//var ggname = __dirname+"/uploads/images/_"+file[i].md5+"."+file[i].mimetype.split('/')[1]
						file[i].mv(location + "/" + file[i].md5 + "_" + seconds + "." + file[i].mimetype.split('/')[1], function (err, data){

							if(err){

								res.send(err);

							}
							
						})

					}
				}
				else{
					var location = path.join(__dirname, '../../../uploads/images'); 
					//var ggname = __dirname+"/uploads/images/_"+file[i].md5+"."+file[i].mimetype.split('/')[1]
					file.mv(location + "/" + file.md5 + "_" + seconds + "." + file.mimetype.split('/')[1], function (err, data){

							if(err){

								res.send(err);

							}
							

					})
				}
			}
			
		}
		if(req.files !=null ){
			if(req.files.gymImage != undefined){
				if(req.files.gymImage.length != undefined){

					for (let j = 0; j < req.files.gymImage.length; j++) {
						var sampleFile = req.files.gymImage[j]
						ImgUrl.push({image:'uploads/images/' + sampleFile.md5 + "_" + seconds + "." + req.files.gymImage[j].mimetype.split('/')[1]});  
					}
				}
				else{
					var sampleFile = req.files.gymImage
					ImgUrl.push({image:'uploads/images/' + sampleFile.md5 + "_" + seconds + "." + req.files.gymImage.mimetype.split('/')[1]});   
				}
			}
			
		}


		var images_ids = [];
		

		// for(var j = 0 ; j <)
		if(ImgUrl.length>0){
			dbo.collection("TBL_GYM_IMAGES").insertMany(ImgUrl, function (err, docsInserted) {


				dbo.collection('TBL_GYMS').aggregate([
				{ $match : { _id : ObjectId(req.body.id) } } ,


				]).toArray(function(err, resr) {
					if (err){
						throw err;
					}
					else{
						for (var i = 0; i < Object.keys(docsInserted.insertedIds).length; i++) {
							// images_ids.push({ id: ObjectId(docsInserted.insertedIds[i]) });
							resr[0].images_ids.push({ id: ObjectId(docsInserted.insertedIds[i]) }) 	
						}
						data.images_ids = resr[0].images_ids;
						var equipments_ids =equipments_id.split(',');
						//console.log(equipments_ids);return;
						var equip = [];
						for(var i = 0 ;i<equipments_ids.length;i++){
							equip.push(ObjectId(equipments_ids[i]))
						}
						data.equipments_id = equip
						if(req.files != undefined ){ 
							// console.log(req.files);
							// return;
							
							if(req.files.logo != undefined){
								var location = path.join(__dirname, '../../../uploads/images'); 
								var sampleFile = req.files.logo;
								var code = makeid(12)+"_"+req.files.logo.md5;
								var imgdir = location+"/"+code+"."+req.files.logo.mimetype.split('/')[1]
								var img = "uploads/images/"+code+"."+req.files.logo.mimetype.split('/')[1];
								data.logo = img
								req.files.logo.mv(imgdir);
							}
							if(req.files.storefront != undefined){
								// var location = path.join(__dirname, '../../../uploads/images'); 
								// var sampleFile = req.files.storefront;
								var code2 = makeid(12)+"_"+req.files.storefront.md5;
								var imgdir2 = location+"/"+code2+"."+req.files.storefront.mimetype.split('/')[1]
								var img2 = "uploads/images/"+code2+"."+req.files.storefront.mimetype.split('/')[1];
								data.storefront = img2
								req.files.storefront.mv(imgdir2);
							}
							if(req.files.reception != undefined){
								// var location = path.join(__dirname, '../../../uploads/images'); 
								// var sampleFile = req.files.reception;
								var code3 = makeid(12)+"_"+req.files.reception.md5;
								var imgdir3 = location+"/"+code3+"."+req.files.reception.mimetype.split('/')[1]
								var img3 = "uploads/images/"+code3+"."+req.files.reception.mimetype.split('/')[1];
								data.reception = img3
								req.files.reception.mv(imgdir3);
							}
							
						}



						// req.files.storefront.mv(imgdir2);
						// req.files.reception.mv(imgdir3);
						// req.files.gym_interior.mv(imgdir4);

						// sampleFile.mv(imgdir, function(err) {
						// 	if (err){
						// 		res.send({"success":false,"message":"Unable to fetch image","data":{}});
						// 		return false;
						// 	}
						// 	else{
							// MongoClient.connect(url, function(err, db) {
							// var dbo = db.db("gymtraining");

								dbo.collection('TBL_GYMS').updateOne( { _id: ObjectId(req.body.id)}, {$set: data }, function(err, rese){		   
									if (err){
										res.send({"success":false,"message":"Something went wrong","data":[]});
										return false;
									}
									else{
										res.send({"success":true,"message":"gym updated","data":data});
									}
								});
								//dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } );
								// res.send({"success":true,"message":"Success"});
								// return false;
								// })
							} 

						});


						// }
					
				// })
			// return;

			})			
		}
		else{
			dbo.collection('TBL_GYMS').aggregate([
				{ $match : { _id : ObjectId(req.body.id) } } ,


				]).toArray(function(err, resr) {
					if (err){
						throw err;
					}
					else{
						

						var equipments_ids =equipments_id.split(',');
						//console.log(equipments_ids);return;
						var equip = [];
						for(var i = 0 ;i<equipments_ids.length;i++){
							equip.push(ObjectId(equipments_ids[i]))
						}
						data.equipments_id = equip
						if(req.files != undefined ){ 
							// console.log(req.files);
							// return;
							
							if(req.files.logo != undefined){
								var location = path.join(__dirname, '../../../uploads/images'); 
								var sampleFile = req.files.logo;
								var code = makeid(12)+"_"+req.files.logo.md5;
								var imgdir = location+"/"+code+"."+req.files.logo.mimetype.split('/')[1]
								var img = "uploads/images/"+code+"."+req.files.logo.mimetype.split('/')[1];
								data.logo = img
								req.files.logo.mv(imgdir);
							}
							if(req.files.storefront != undefined){
								var location = path.join(__dirname, '../../../uploads/images'); 
								// var sampleFile = req.files.storefront;
								var code2 = makeid(12)+"_"+req.files.storefront.md5;
								var imgdir2 = location+"/"+code2+"."+req.files.storefront.mimetype.split('/')[1]
								var img2 = "uploads/images/"+code2+"."+req.files.storefront.mimetype.split('/')[1];
								data.storefront = img2
								req.files.storefront.mv(imgdir2);
							}
							if(req.files.reception != undefined){
								var location = path.join(__dirname, '../../../uploads/images'); 
								// var sampleFile = req.files.reception;
								var code3 = makeid(12)+"_"+req.files.reception.md5;
								var imgdir3 = location+"/"+code3+"."+req.files.reception.mimetype.split('/')[1]
								var img3 = "uploads/images/"+code3+"."+req.files.reception.mimetype.split('/')[1];
								data.reception = img3
								req.files.reception.mv(imgdir3);
							}
							
						}



						
						
						// req.files.gym_interior.mv(imgdir4);

						// sampleFile.mv(imgdir, function(err) {
						// 	if (err){
						// 		res.send({"success":false,"message":"Unable to fetch image","data":{}});
						// 		return false;
						// 	}
						// 	else{
							// MongoClient.connect(url, function(err, db) {
							// var dbo = db.db("gymtraining");
							
								dbo.collection('TBL_GYMS').updateOne( { _id: ObjectId(req.body.id)}, {$set: data }, function(err, rese){		   
									if (err){
										res.send({"success":false,"message":"Something went wrong","data":[]});
										return false;
									}
									else{
										res.send({"success":true,"message":"gym updated","data":data});
									}
								});
								//dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } );
								// res.send({"success":true,"message":"Success"});
								// return false;
								// })
							} 

						});


						}
					
				// })
		// }


	
  }




function getCurrentTime() {
	var d = new Date();
	var n = d.toUTCString();
	var date = new Date(n);
	var seconds = date.getTime() / 1000; //1440516958
	return seconds;
}

function makeid(length) {
	 var result           = '';
	 var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
	 var charactersLength = characters.length;
	 for ( var i = 0; i < length; i++ ) {
	    result += characters.charAt(Math.floor(Math.random() * charactersLength));
	 }
	 return result;
}         	
