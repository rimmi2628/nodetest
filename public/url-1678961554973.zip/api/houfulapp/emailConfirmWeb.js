var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')

// var firebase = require('firebase-admin')
// var serviceAccount = require("./hourful.json"); 



const bcrypt = require('bcrypt')
var app = express();
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());



var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});


var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
//const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.emailConfirmWeb = async function (req, res) {
  //type==0 space owner 1 for client other trainer
  //console.log(req.query.id);return;
  console.log("-------------------------------wevb----------------------------->", req.body)
  console.log("<---------------------------------------------------------------")
      const { id, password, type ,is_link_expired} = req.body;
  
  let errors = [];

  if (!id) {
    res.send({ "success": false, "message": "Please enter all fields", "data": {} });
    return false;
  }
  else {
    //   var verifyEmailId=makeid(20);
    let dbo = await mongodbutil.Get();
    // sourceFile.TBL_TRAINERS.findOne({ email_verification_id: id }).then(async user => {
    if (type == 0) {
      dbo.collection("TBL_SPACE_OWNER").find({ change_password: String(id) }).toArray(function (err, resr) {
        //console.log(resr)  
        // return;
        if (resr.length > 0) {
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(password, salt, (err, hash) => {
              if (err) throw err;
              var setVar = { "password": hash, change_password: resr[0]._id }
              dbo.collection('TBL_SPACE_OWNER').updateOne({ _id: ObjectId(resr[0]._id) }, { $set: setVar }, function (err, rese) {
                if (err) {
                  res.send({ "success": true, "message": "Unable to save new password." });
                  return false;
                }
                else {
                  res.send({ "success": true, "message": "password changed successfully" });
                  return false;
                }
              });
            });
          });
        }
        else {
          res.send({ "success": false, "message": "user not found" });
          return false;
        }

      });
    }
    else if (type == 2) {
      dbo.collection("TBL_CLIENTS").find({ change_password: String(id) }).
        toArray(function (err, resr) {
          if (resr.length > 0) {
            if (is_link_expired == 1) {
              return res.send({ "success": true, "message": "Link Not Expired" });
   
             }
            bcrypt.genSalt(10, (err, salt) => {
              bcrypt.hash(password, salt, (err, hash) => {
                if (err) throw err;
                var setVar = { "password": hash, change_password: resr[0]._id }
                dbo.collection('TBL_CLIENTS').updateOne({ _id: ObjectId(resr[0]._id) }, { $set: setVar }, function (err, rese) {
                  if (err) {
                    res.send({ "success": true, "message": "Unable to save new password." });
                    return false;
                  }
                  else {
                    res.send({ "success": true, "message": "password changed successfully" });
                    return false;
                  }
                });
              });
            });
          }
          else {
            res.send({ "success": false, "message": "user not found" });
            return false;
          }

        })
    }
    else {
      var idString = makeid(20);
      dbo.collection("TBL_TRAINER_DETAILS").findOneAndUpdate({ change_password: String(id) }, { $set: { change_password: idString } }, { upsert: true }, function (err, resr) {
        console.log(resr)
        // return;
        if (resr.value != null) {
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(password, salt, (err, hash) => {
              if (err) throw err;
              var setVar = { "password": hash }
              dbo.collection("TBL_TRAINERS").find({ "_id": ObjectId(resr.value.user_id) }).toArray(function (err, result) {
                if (err) {
                  res.send({ "success": false, "message": "something went wrong", "data": [] });
                  return false;
                }
                else {
                  console.log(result[0].password)
                  console.log(password)
                  if (result.length > 0) {
                    bcrypt.compare(password, result[0].password, function (err, resaa) {
                      if (!resaa) {
                        dbo.collection('TBL_TRAINERS').updateOne({ _id: ObjectId(resr.value.user_id) }, { $set: setVar }, function (err, rese) {
                          if (err) {
                            res.send({ "success": true, "message": "Unable to save new password." });
                            return false;
                          }
                          else {
                            res.send({ "success": true, "message": "password changed successfully" });
                            return false;
                          }
                        });
                      }
                      else {
                        res.send({ "success": false, "message": "You cannot set old password as new password", "data": [] });
                        return false;
                      }

                    })

                  }
                }
              })

            });
          });
        }
        else {
          res.send({ "success": true, "message": "user not found" });
          return false;
        }

      });
    }

    //}
    //}); 
  }
}
function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}