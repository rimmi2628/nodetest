var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());




var sourceFile = require('./register.js');
// console.log(sourceFile)

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.reschedule = async function(req, res) {
    const {user_id,gym_id,slot_id,date,time,schedule_time,booking_id} = req.body;
    if(!user_id || !gym_id || !booking_id   || !slot_id || !date || !time || !schedule_time){
      res.send({"success":false,"message":"Please enter all fields","data":{}});
      return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    //     if (err) throw err;
              let dbo =  await mongodbutil.Get();
              var gymID =  ObjectId(gym_id)
              var userID =  ObjectId(user_id)
              var booking_id =  ObjectId(booking_id)
              var myobj = { user_id: userID,gym_id: gymID,slot_id:ObjectID(slot_id),date:date,time:time,schedule_time:schedule_time,status:0,booking_id:booking_id};
              if(req.body.duration != undefined){
                myobj.duration = req.body.duration
              }
              if(req.body.client_name != undefined){
                myobj.client_name = req.body.client_name
              }
              dbo.collection("TBL_BOOKINS").updateOne({_id:booking_id},{$set:{myobj}}, function(err, resv) {
                if (err) throw err;
                //console.log(res.insertedId);
                
                  if (err){
                    res.send({"success":false,"message":"Something went wrong!","data":{} });
                  } 
                  else{
                    res.send({"success":true,"message":"We have reschedule your booking.","data":{}});
                    db.close();
                    return false;
                  }
                db.close();
              });
    // }); 
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

