const Utill = require('../../helper/Constant')
var express = require('express');
var path = require("path");
var bodyParser = require('body-parser');
var mongo = require("mongoose");
var cors = require('cors')

var nodemailer = require('nodemailer');

var emailTemp = require('../emails');

var transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'info@hourful.io',
        pass: 'Panda999$'
    }
});

const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json());
var fileupload = require("express-fileupload");
app.use(fileupload());

var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;
    //const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.submitReview = async function(req, res) {
    const {id,ratings,comments,gym_id,user_id,trainer_id} = req.body;
    let errors = [];
    // if(!id || !status ){
    //     res.send({"success":false,"message":"Please enter all fields","data":{}});
    //     return false;
    // }
    let dbo =  await mongodbutil.Get();
    var myobj = { user_id: ObjectId(trainer_id),booking_id:ObjectId(id),gym_id:ObjectId(req.body.gym_id),rating: String(ratings),comment:req.body.comments,created_at:getCurrentTime(),spaceOwnerId:ObjectId(user_id)};

    dbo.collection("TBL_FEEDBACK_TO_TRAINER").insertOne(myobj, function(err, resee){
	    dbo.collection("TBL_BOOKINS").updateOne({_id:ObjectId(id)},{$set:{reviews:1}}, function(err, resv) {
        if (err) throw err;
        //console.log(res.insertedId);
        
        if (err){
            res.send({"success":false,"message":"Something went wrong!","data":{} });
        } 
        else{
			// dbo.collection("TBL_TRAINER_DETAILS").updateOne({user_id:ObjectId(req.body.user_id)},{$set:{}}, function(err, resv) {
				
			// //console.log(res.insertedId);

			// 	if (err){
			// 		res.send({"success":false,"message":"Something went wrong!","data":{} });
			// 	} 
			// 	else{
					
			// 	}
			// });

			dbo.collection("TBL_TRAINER_DETAILS").find( { "user_id":ObjectId(trainer_id)  } ).toArray(     function(err, result) {
				console.log(result[0])
                dbo.collection('TBL_TRAINERS').find({
                        _id: ObjectId(trainer_id)
                    })
                    .toArray(function(err, dataTT) {
                        if (err) {
                            // throw err;
                        } else {
                            dbo.collection('TBL_GYMS').find({
                                    _id: ObjectId(req.body.gym_id)
                                })
                                .toArray(function(err, dataGG) {
                                    if (err) {
                                        // throw err;
                                    } else {
                                    
                                            var stuff=[];
                                            stuff['name']= dataGG[0].name
                                            stuff['email']= dataTT[0].email
                                            stuff['chat']= Utill.IMAGE_BASE_URL+'redirect.html?type=feedback&booking_id='+id+''
                                            // if (dataTT[0].email == 'mohitsetia@gmail.com') {
                                                var email = emailTemp.bookingEmails.gymReview(stuff)
                                                console.log(email)
                                            // }
                                            
                                    }
                                })
                            
                        }
                    })
                    // console.log("1",parseInt(result[0].availableSlots) - 1)
                    // console.log(parseFloat(result[0].avg_rating))
                    // console.log(parseFloat(result[0].ratings))
                    // console.log(result[0].avg_rating)
                    if(result[0].avg_rating == undefined){
                    	result[0].avg_rating = 0;
                    	result[0].ratings = 0;
                    }
                    // var prevTotal =(parseFloat(result[0].avg_rating) * parseFloat(result[0].ratings)) + parseFloat(req.body.ratings);
                    // console.log(prevTotal)
                    var avg = ((parseFloat(result[0].avg_rating) * parseFloat(result[0].ratings)) + parseFloat(req.body.ratings)) / (parseFloat(result[0].ratings) + 1);
                    var total = parseInt(result[0].ratings) + 1
                    console.log(avg);
                    console.log(total);
                        dbo.collection("TBL_TRAINER_DETAILS").updateOne({user_id:ObjectId(trainer_id)},{$set:{avg_rating:String(avg.toFixed(2)),ratings:String(total)}}, function(err, resv) {

                            res.send({"success":true,"message":"Thank you, we have recorded your review."});
                            return false;
                        })
            })
        }
    });
    })
    
 
}
  function getCurrentTime() {
        var d = new Date();
        var n = d.toUTCString();
        var date = new Date(n);
        var seconds = date.getTime() / 1000; //1440516958
        return seconds;
      }