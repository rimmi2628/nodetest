var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/gymtraining/";


var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jotpal.enact@gmail.com',
    pass: 'hkmnrqivtbkyieib'
  }
});

var db = mongo.connect("mongodb://localhost:27017/gymtraining",{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, response){  
   if(err){ console.log( err); }  
   else{ //console.log('Connected to ' + db, ' + ', response); 
    }  
});  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


app.use(bodyParser.json());
app.use(bodyParser.urlencoded());

mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
exports.getQuickSchedule = async function(req, res) {
    const {gym_id, month} = req.body;

            let dbo =  await mongodbutil.Get();
            console.log(gym_id);
            dbo.collection('TBL_GYM_AVAILABILITY').find({gym_id : ObjectId(gym_id),type : 2}).toArray(function(err, resr){
                if(resr.length > 0){
                    res.send({"success":true,"message":"Data Found.","type":2 });
                    return false;
                }
                else{
                    dbo.collection('TBL_GYM_AVAILABILITY').aggregate([
                        { $match : { gym_id : ObjectId(gym_id),type : 1 } } ,
                        {
                            $lookup : 
                            {
                                from : 'TBL_AVAILABILITY_SLOTS', 
                                localField: '_id', 
                                foreignField: 'gym_availability_id', 
                                as : 'availability_slots'
                            }
                        }
                    ]).toArray(function(err, resr) {
                        if (err){
                            throw err;
                        }
                        else{
                            if(resr){
                                var data = JSON.parse(JSON.stringify(resr));
                            }
                            res.send({"success":true,"message":"Data Found.","type":1,"data":resr });
                        }
        
                    });
                }
            });

            
            

    // });
}