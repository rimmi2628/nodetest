var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());


 
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.reschedule = async function(req, res) {
    const {user_id,gym_id,slot_id,date,time,schedule_time,booking_id,instantBooking} = req.body;
    if(!user_id || !gym_id || !booking_id   || !slot_id || !date || !time || !schedule_time || !instantBooking){
      res.send({"success":false,"message":"Please enter all fields","data":{}});
      return false;
    }
    if(!instantBooking){
      res.send({"success":false,"message":"Please send instantBooking","data":{}});
      return false;
    }
    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
    //     if (err) throw err;
              let dbo =  await mongodbutil.Get();
              var gymID =  ObjectId(gym_id)
              var userID =  ObjectId(user_id)
              var bookingx_id =  ObjectId(booking_id)
              var myobj = { user_id: userID,gym_id: gymID,slot_id:ObjectId(slot_id),date:date,time:time,schedule_time:parseInt(schedule_time),status:0};
              if(req.body.duration != undefined){
                myobj.duration = req.body.duration
              }
              if(req.body.client_name != undefined){
                myobj.client_name = req.body.client_name
              }
              dbo.collection('TBL_BOOKINS').find({ _id: ObjectId(booking_id) })
              .toArray(function (err, data) {
                console.log("data",data[0].status)
                console.log("data",data)
                if(data[0].status == 1 || data[0].status == 2){
                  console.log("yes")
                dbo.collection("TBL_AVAILABILITY_SLOTS").updateOne({_id:ObjectId(data[0].slot_id)},{$inc: {availableSlots: 1}} ,  function(err, resultsss) {
                    if(instantBooking == true){
                      dbo.collection("TBL_AVAILABILITY_SLOTS").updateOne({_id:ObjectId(slot_id)},{$inc: {availableSlots: -1}} ,  function(err, resultsss) {
                         
                      })
                    }
                })
                }
               
              })
              dbo.collection("TBL_BOOKINS").updateOne({_id:bookingx_id},{$set:myobj}, function(err, resv) {
                if (err) throw err;
                //console.log(res.insertedId);
                
                  if (err){
                    res.send({"success":false,"message":"Something went wrong!","data":{} });
                  } 
                  else{
                   
                    res.send({"success":true,"message":"We have changed your booking.","data":{}});
                    // db.close();
                    return false;
                  }
                // db.close();
              });

      const gyymdetails = dbo.collection('TBL_GYMS').find({ _id: ObjectId(gym_id) })
      .toArray(function (err, data) {
        if (err) {
            throw err;
        } else {
            // console.log(data[0].logo) 
            if(instantBooking == true){
              var typeee = "0";
            }
            else{
              var typeee = "1";
            }
            var NotiObj = { trainer_id: ObjectId(user_id),date:date,time:time,gym_id: ObjectId(gym_id),gym_name:data[0].name,logo:data[0].logo,text:"",type:typeee,status:'0',date_time:schedule_time,created_at:getCurrentTime(),updated:getCurrentTime()};
            dbo.collection("TBL_NOTIFICATIONS").insertOne(NotiObj, function(err,resr){
              if (err){
                  throw err;
              }
            });
          }
        })
    // }); 
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

