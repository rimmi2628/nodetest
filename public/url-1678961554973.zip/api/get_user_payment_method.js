var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



  
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.get_user_payment_method = async function(req, res) {
       if(!req.body.user_id){
           res.send({"success":false,"message":"user_id empty","data":[]});
           return false;
       }
       // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
       //      if (err) throw err;
            let dbo =  await mongodbutil.Get();
            dbo.collection('TBL_CARDS').aggregate([
                { 
                    $match : { 
                        trainer_id : ObjectId(req.body.user_id) 
                    } 
                } 
            ]).toArray(function(err, resr) {
                if (err){
                    throw err;
                }
                else{
                    if(resr){
                      for(var i =0 ;i<resr.length;i++){
                        resr[i].user_id =resr[i].trainer_id ;
                        delete resr[i].payment_method;
                        delete resr[i].trainer_id;
                        // resr[i].user_id =resr[i].trainer_id ;
                      }
                        res.send({"success":true,"message":"success","data":resr});
                        return false;
                        // console.log(resr)
                    }
                    else{
                        res.send({"success":false,"message":"something went wrong","data":[]});
                        return false;
                    }
                }
                // console.log(data)
            });
        // });  
  }