var express = require('express');  
var path = require("path");   
var bodyParser = require('body-parser');  
var mongo = require("mongoose");  
// const multer = require('multer');
// const upload = multer({dest: __dirname + '/uploads/images'});
var cors = require('cors')


const bcrypt = require('bcrypt')
var app = express() ;
app.use(cors());
app.options('*', cors());
var fs = require("fs");
// for parsing application/json
app.use(bodyParser.json()); 
var fileupload = require("express-fileupload");
app.use(fileupload());



 
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema ;  
   //const {email, first_name, last_name, password, social_id, image,type } = req.body;


 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded());
 
 mongo.set('useFindAndModify', false);
var mongodbutil = require( './mongodbutil' );
 exports.report_problem = async function(req, res) {

    const {user_id,text,appointment_id} = req.body;
    if(!user_id || !text || !appointment_id){
      res.send({"success":false,"message":"field empty","data":{}});
      return false;
    }

    // MongoClient.connect(url,{ useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
        // if (err) throw err;
        let dbo =  await mongodbutil.Get();
        data = {"user_id":ObjectId(user_id),"appointment_id":ObjectId(appointment_id),"text":text,'created_at':getCurrentTime(),'updated_at':getCurrentTime()}
        
         dbo.collection("REPORT_PORBLEM").insertOne(data, function(err,resr){
            if (err){
                throw err;
            }
            else{
                if(resr){

                    res.send({"success":true,"message":"We have taken your request. Our team will look into this."});
                    return false;
                }
                else{
                    res.send({"success":false,"message":"something went wrong","data":[]});
                    return false;
                }
            }
        }); 
    // });
  }
 
function getCurrentTime() {
    var d = new Date();
    var n = d.toUTCString();
    var date = new Date(n);
    var seconds = date.getTime() / 1000; //1440516958
    return seconds;
  }

