var mongo = require("mongoose");
const Utill = require('../helper/Constant')
var ObjectId = mongo.Types.ObjectId;
var Schema = mongo.Schema;


mongo.set('useFindAndModify', false);
var mongodbutil = require('./mongodbutil');
exports.gyms = async function (req, res) {
  console.log('gyms', req.body)
  const { latitude, longitude, min_price, max_price, radius, datetime, user_id, equipments } = req.body;
  if (!latitude || !longitude) {
    res.send({ "success": false, "message": "Please enter all fields", "data": [] });
    return false;
  }
  if (radius == undefined) {
    var rad = '50';
  }
  else {
    if (radius > 50) {
      var rad = '50'
    }
    else {
      var rad = radius
    }

  }
  if (min_price == undefined) {
    var min = 0;
  }
  else {
    var min = min_price;
  }
  if (max_price == undefined) {
    var max = 250;
  }
  else {
    var max = max_price;
  }

  if (equipments != undefined) {
    var equipArr = []
    equip = req.body.equipments.split(',')
    for (let f = 0; f < equip.length; f++) {
      equipArr.push(ObjectId(equip[f]))
    }
    var eqp = { "equipments_id": { $in: equipArr }, isBlocked: { $ne: "1" } };
  }
  else {
    var equipArr = [];
    var eqp = { isBlocked: { $ne: "1" } };
  }
  // console.log(eqp)

  // if(datetime == undefined){
  //   var datetime ="12312312312";
  // }
  // if(datetime == undefined){
  //   var datetime ="12312312312";
  // }
  //  console.log(min);
  //   console.log(rad);
  //  return;
  // MongoClient.connect(url, function(err, db) {
  // if (err) throw err;
  let dbo = await mongodbutil.Get();
  // var query = { _id: user_id };
  // dbo.collection('TBL_GYMS').createIndex( { location: "2dsphere" } )
  dbo.collection('TBL_GYMS').aggregate([



    {

      $geoNear: {
        near: {
          type: "Point", coordinates: [parseFloat(longitude),
          parseFloat(latitude)]
        },
        spherical: true,
        maxDistance: parseInt(rad) * 1609,
        // distanceMultiplier : 0.001,

        distanceField: "dist.calculated",
        query: { "price": { "$gte": parseInt(min), "$lte": parseInt(max) } },
      }
    },
    {
      $lookup:
      {
        from: 'TBL_EQUIPMENTS',
        localField: 'equipments_id',
        foreignField: '_id',
        as: 'equipments_ids'
      }
    },
    {
      $lookup:
      {
        from: 'TBL_GYM_IMAGES',
        localField: 'images_ids.id',
        foreignField: '_id',
        as: 'images_ids'
      }
    },

    {
      $lookup:
      {
        from: 'TBL_FAVORITES',
        localField: '_id',
        foreignField: 'gym_id',
        as: 'favorites'
      }
    },
    {
      "$addFields": {
        "favorites": {
          "$arrayElemAt": [
            {
              "$filter": {
                "input": "$favorites",
                "as": "comp",
                "cond": {
                  "$eq": ["$$comp.trainer_id", ObjectId(user_id)]
                }
              }
            }, 0
          ]
        },
      }


    },

    { $match: eqp },


    {
      "$project": {
        "_id": 1,
        "name": 1,
        "logo": 1,
        // "timezone": 1,
        "price": 1,
        "avg_rating": 1,
        "ratings": 1,
        "images_ids": 1,
        "favorites": 1,
        "latitude": 1,
        "longitude": 1,
        "location": 1,
        "space_owner": 1,
        "dist": 1,
        "storefront": 1,
        "reception": 1,
        "gym_interior": 1,

      }
    },
  ]).toArray(function (err, resr) {
    if (err) {
      throw err;
    }
    else {
      // console.log("resr",resr)
      if (resr) {
        // return res.json(resr)

        for (var i = 0; i < resr.length; i++) {
          if (resr[i].space_owner == "") {
            resr[i].claim = 0;
          }
          else {
            resr[i].claim = 1;
          }
          if (resr[i].favorites != undefined) {
            //delete resr[i].equipments_id
            resr[i].favorite = true;
            resr[i].time_zone = resr[i].timezone;
          }
          else {
            //delete resr[i].equipments_id
            resr[i].favorite = false;
            resr[i].time_zone = resr[i].timezone;
          }
          if (resr[i].logo != undefined) {
            if (String(resr[i].logo).includes('http')) {
              resr[i].logo = resr[i].logo
            }
            else {
              resr[i].logo = Utill.IMAGE_BASE_URL + resr[i].logo
            }

          }
          var images = [];
          if (String(resr[i]['storefront']).includes('http')) {
            var attach = "";
          }
          else {
            var attach = Utill.IMAGE_BASE_URL;
          }
          images.push({
            "_id": "5ec38a821a9ca845e0831a8c",
            "image": attach + "" + resr[i]['storefront']
          })
          images.push({
            "_id": "5ec38a821a9ca845e0831a8c",
            "image": attach + "" + resr[i]['reception']
          })
          images.push({
            "_id": "5ec38a821a9ca845e0831a8c",
            "image": attach + "" + resr[i]['gym_interior']
          })
          if(!resr[i].storefront.includes('http')){
            resr[i].storefront= Utill.IMAGE_BASE_URL + resr[i].storefront
          }
          if(!resr[i].reception.includes('http')){
            resr[i].reception= Utill.IMAGE_BASE_URL + resr[i].reception
          }
          if(!resr[i].gym_interior.includes('http')){
            resr[i].gym_interior= Utill.IMAGE_BASE_URL + resr[i].gym_interior
          }
          if (resr[i].images_ids != undefined || resr[i].images_ids.length) {

            for (var j = 0; j < resr[i].images_ids.length; j++) {
              if (String(resr[i].images_ids[j]['image']).includes('http')) {

                resr[i].images_ids[j]['image'] = resr[i].images_ids[j]['image']
                if (resr[i].images_ids[j]['image'] == undefined || resr[i].images_ids[j]['image'] == null || resr[i].images_ids[j]['image'] == "") {
                  resr[i].images_ids[j]['image'] = resr[i].images_ids[j]['name']
                }

                // console.log(resr[i].images_ids[j]['image'])

              }
              else {
               
                if (!resr[i].images_ids[j]['name']) {
                   resr[i].images_ids[j]['image'] = Utill.IMAGE_BASE_URL + resr[i].images_ids[j]['image'] 
                  }
                else {
                  if (String(resr[i].images_ids[j]['name']).includes('http')) {
                    resr[i].images_ids[j]['image'] =  resr[i].images_ids[j]['name']
                  }
                  else{
                  resr[i].images_ids[j]['image'] = Utill.IMAGE_BASE_URL + resr[i].images_ids[j]['name']
                  }
                }
                // console.log(resr[i].images_ids[j]['image'])
                if (resr[i].images_ids[j]['image'] == Utill.IMAGE_BASE_URL + "/undefined") {
                  resr[i].images_ids[j]['image'] = resr[i].images_ids[j]['name']
                }
              }

              images.push(resr[i].images_ids[j])
            }
          }
          resr[i].images_ids = images;
          delete resr[i].favorites;
        }

        // return;
        var data = JSON.parse(JSON.stringify(resr));
        res.send({ "success": true, "message": "success", "data": data });
        return false;
      }
      else {
        res.send({ "success": false, "message": "something went wrong", "data": [] });
        return false;
      }
    }

  });
  // });
}